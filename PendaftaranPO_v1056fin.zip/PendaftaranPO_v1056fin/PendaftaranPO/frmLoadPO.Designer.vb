﻿Imports Oracle.ManagedDataAccess.Client

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmLoadPO
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim OracleParameter1 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmLoadPO))
        Dim OracleParameter2 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter3 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter4 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter5 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter6 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter7 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter8 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter9 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter10 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter11 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter12 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter13 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter14 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter15 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter16 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter17 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter18 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter19 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter20 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter21 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter22 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter23 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter24 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter25 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter26 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter27 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter28 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter29 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter30 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter31 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter32 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter33 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter34 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter35 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter36 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter37 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter38 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter39 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter40 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter41 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter42 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter43 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter44 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter45 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter46 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter47 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter48 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter49 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter50 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter51 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter52 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter53 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter54 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter55 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter56 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter57 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter58 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter59 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter60 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter61 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter62 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter63 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter64 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter65 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter66 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter67 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter68 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter69 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter70 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter71 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter72 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter73 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter74 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter75 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter76 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter77 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter78 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter79 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter80 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter81 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter82 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter83 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter84 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter85 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter86 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter87 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter88 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter89 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter90 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter91 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter92 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter93 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter94 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter95 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter96 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter97 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter98 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter99 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter100 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter101 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter102 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter103 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter104 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter105 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter106 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter107 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter108 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter109 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter110 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter111 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter112 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter113 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter114 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter115 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter116 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter117 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter118 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter119 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter120 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter121 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter122 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter123 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter124 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter125 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter126 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter127 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter128 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter129 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter130 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter131 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter132 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter133 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter134 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter135 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter136 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter137 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter138 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter139 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter140 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter141 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter142 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter143 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter144 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter145 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter146 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter147 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter148 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter149 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter150 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter151 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter152 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter153 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter154 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter155 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter156 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter157 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter158 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter159 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter160 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter161 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter162 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter163 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter164 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter165 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.btnBatal = New System.Windows.Forms.Button()
        Me.btnSimpan = New System.Windows.Forms.Button()
        Me.DsPO1 = New PendaftaranPO.DS_()
        Me.olcon = New Oracle.ManagedDataAccess.Client.OracleConnection()
        Me.oldapPO = New Oracle.ManagedDataAccess.Client.OracleDataAdapter()
        Me.OleDbDeleteCommand2 = New Oracle.ManagedDataAccess.Client.OracleCommand()
        Me.OleDbInsertCommand2 = New Oracle.ManagedDataAccess.Client.OracleCommand()
        Me.OleDbSelectCommand2 = New Oracle.ManagedDataAccess.Client.OracleCommand()
        Me.OleDbUpdateCommand2 = New Oracle.ManagedDataAccess.Client.OracleCommand()
        Me.oldapMobil = New Oracle.ManagedDataAccess.Client.OracleDataAdapter()
        Me.OleDbDeleteCommand1 = New Oracle.ManagedDataAccess.Client.OracleCommand()
        Me.OleDbInsertCommand1 = New Oracle.ManagedDataAccess.Client.OracleCommand()
        Me.OleDbSelectCommand1 = New Oracle.ManagedDataAccess.Client.OracleCommand()
        Me.OleDbUpdateCommand1 = New Oracle.ManagedDataAccess.Client.OracleCommand()
        Me.dgvLoadPO = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.QTYBPBPCS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.QTYPOPCS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FRACT = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn21 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.DsPO1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvLoadPO, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnBatal
        '
        Me.btnBatal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnBatal.BackColor = System.Drawing.Color.Transparent
        Me.btnBatal.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnBatal.Image = Global.PendaftaranPO.My.Resources.Resources.arrow_undo
        Me.btnBatal.Location = New System.Drawing.Point(634, 434)
        Me.btnBatal.Name = "btnBatal"
        Me.btnBatal.Size = New System.Drawing.Size(105, 36)
        Me.btnBatal.TabIndex = 4
        Me.btnBatal.Text = "&Batal"
        Me.btnBatal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnBatal.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnBatal.UseVisualStyleBackColor = False
        '
        'btnSimpan
        '
        Me.btnSimpan.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSimpan.BackColor = System.Drawing.Color.Transparent
        Me.btnSimpan.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.btnSimpan.Image = Global.PendaftaranPO.My.Resources.Resources.disk
        Me.btnSimpan.Location = New System.Drawing.Point(523, 434)
        Me.btnSimpan.Name = "btnSimpan"
        Me.btnSimpan.Size = New System.Drawing.Size(105, 36)
        Me.btnSimpan.TabIndex = 3
        Me.btnSimpan.Text = "&Simpan"
        Me.btnSimpan.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSimpan.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnSimpan.UseVisualStyleBackColor = False
        '
        'DsPO1
        '
        Me.DsPO1.DataSetName = "dsPO"
        Me.DsPO1.Locale = New System.Globalization.CultureInfo("en-US")
        Me.DsPO1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'oldapPO
        '
        Me.oldapPO.DeleteCommand = Me.OleDbDeleteCommand2
        Me.oldapPO.InsertCommand = Me.OleDbInsertCommand2
        Me.oldapPO.SelectCommand = Me.OleDbSelectCommand2
        Me.oldapPO.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "DC_JLR_DAFTARPO_T", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("ID_DAFTARPO", "ID_DAFTARPO"), New System.Data.Common.DataColumnMapping("TANGGAL", "TANGGAL"), New System.Data.Common.DataColumnMapping("RECID", "RECID"), New System.Data.Common.DataColumnMapping("ID_DAFTARJALUR", "ID_DAFTARJALUR"), New System.Data.Common.DataColumnMapping("NO_FAK", "NO_FAK"), New System.Data.Common.DataColumnMapping("TGL_FAK", "TGL_FAK"), New System.Data.Common.DataColumnMapping("NOPO", "NOPO"), New System.Data.Common.DataColumnMapping("SUPCO", "SUPCO"), New System.Data.Common.DataColumnMapping("SNAMA", "SNAMA"), New System.Data.Common.DataColumnMapping("BUAT_PO", "BUAT_PO"), New System.Data.Common.DataColumnMapping("ADA_HARGA", "ADA_HARGA"), New System.Data.Common.DataColumnMapping("QTY", "QTY"), New System.Data.Common.DataColumnMapping("ITEM", "ITEMnya"), New System.Data.Common.DataColumnMapping("RUPIAH", "RUPIAH"), New System.Data.Common.DataColumnMapping("PPN", "PPN"), New System.Data.Common.DataColumnMapping("BPB_NO", "BPB_NO"), New System.Data.Common.DataColumnMapping("TGL_MULAI", "TGL_MULAI"), New System.Data.Common.DataColumnMapping("JAM_MULAI", "JAM_MULAI"), New System.Data.Common.DataColumnMapping("TGL_AKHIR", "TGL_AKHIR"), New System.Data.Common.DataColumnMapping("JAM_AKHIR", "JAM_AKHIR"), New System.Data.Common.DataColumnMapping("JML_MOBIL", "JML_MOBIL"), New System.Data.Common.DataColumnMapping("TGL_REVISI", "TGL_REVISI"), New System.Data.Common.DataColumnMapping("JAM_REVISI", "JAM_REVISI"), New System.Data.Common.DataColumnMapping("USER_NAME", "USER_NAME"), New System.Data.Common.DataColumnMapping("MRBREAD", "MRBREAD"), New System.Data.Common.DataColumnMapping("UPDATE", "UPDATE"), New System.Data.Common.DataColumnMapping("SUPID", "SUPID"), New System.Data.Common.DataColumnMapping("GUDANG_KODE", "GUDANG_KODE"), New System.Data.Common.DataColumnMapping("LOKASI_KODE", "LOKASI_KODE"), New System.Data.Common.DataColumnMapping("TOTAL", "Total"), New System.Data.Common.DataColumnMapping("STATUS", "Status")})})
        Me.oldapPO.UpdateCommand = Me.OleDbUpdateCommand2
        '
        'OleDbDeleteCommand2
        '
        Me.OleDbDeleteCommand2.CommandText = "DELETE FROM DC_JLR_DAFTARPO_T WHERE (ID_DAFTARPO = ?)"
        Me.OleDbDeleteCommand2.Connection = Me.olcon
        OracleParameter1.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter1.ParameterName = "ID_DAFTARPO"
        OracleParameter1.Precision = CType(38, Byte)
        OracleParameter1.SourceColumn = "ID_DAFTARPO"
        OracleParameter1.SourceVersion = System.Data.DataRowVersion.Original
        Me.OleDbDeleteCommand2.Parameters.Add(OracleParameter1)
        Me.OleDbDeleteCommand2.Transaction = Nothing
        '
        'OleDbInsertCommand2
        '
        Me.OleDbInsertCommand2.CommandText = resources.GetString("OleDbInsertCommand2.CommandText")
        Me.OleDbInsertCommand2.Connection = Me.olcon
        OracleParameter2.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter2.ParameterName = "ID_DAFTARPO"
        OracleParameter2.Precision = CType(38, Byte)
        OracleParameter2.SourceColumn = "ID_DAFTARPO"
        OracleParameter3.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter3.ParameterName = "TANGGAL"
        OracleParameter3.SourceColumn = "TANGGAL"
        OracleParameter4.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter4.ParameterName = "RECID"
        OracleParameter4.Size = 1
        OracleParameter4.SourceColumn = "RECID"
        OracleParameter5.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter5.ParameterName = "ID_DAFTARJALUR"
        OracleParameter5.Precision = CType(38, Byte)
        OracleParameter5.SourceColumn = "ID_DAFTARJALUR"
        OracleParameter6.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter6.ParameterName = "NO_FAK"
        OracleParameter6.Size = 15
        OracleParameter6.SourceColumn = "NO_FAK"
        OracleParameter7.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter7.ParameterName = "TGL_FAK"
        OracleParameter7.SourceColumn = "TGL_FAK"
        OracleParameter8.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter8.ParameterName = "NOPO"
        OracleParameter8.Size = 9
        OracleParameter8.SourceColumn = "NOPO"
        OracleParameter9.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter9.ParameterName = "SUPCO"
        OracleParameter9.Size = 4
        OracleParameter9.SourceColumn = "SUPCO"
        OracleParameter10.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter10.ParameterName = "SNAMA"
        OracleParameter10.Size = 50
        OracleParameter10.SourceColumn = "SNAMA"
        OracleParameter11.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter11.ParameterName = "BUAT_PO"
        OracleParameter11.Precision = CType(38, Byte)
        OracleParameter11.SourceColumn = "BUAT_PO"
        OracleParameter12.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter12.ParameterName = "ADA_HARGA"
        OracleParameter12.Precision = CType(38, Byte)
        OracleParameter12.SourceColumn = "ADA_HARGA"
        OracleParameter13.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter13.ParameterName = "QTY"
        OracleParameter13.Precision = CType(38, Byte)
        OracleParameter13.SourceColumn = "QTY"
        OracleParameter14.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter14.ParameterName = "ITEM"
        OracleParameter14.Precision = CType(38, Byte)
        OracleParameter14.SourceColumn = "ITEM"
        OracleParameter15.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter15.ParameterName = "RUPIAH"
        OracleParameter15.Precision = CType(38, Byte)
        OracleParameter15.SourceColumn = "RUPIAH"
        OracleParameter16.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter16.ParameterName = "PPN"
        OracleParameter16.Precision = CType(38, Byte)
        OracleParameter16.SourceColumn = "PPN"
        OracleParameter17.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter17.ParameterName = "BPB_NO"
        OracleParameter17.Precision = CType(38, Byte)
        OracleParameter17.SourceColumn = "BPB_NO"
        OracleParameter18.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter18.ParameterName = "TGL_MULAI"
        OracleParameter18.SourceColumn = "TGL_MULAI"
        OracleParameter19.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter19.ParameterName = "JAM_MULAI"
        OracleParameter19.Size = 8
        OracleParameter19.SourceColumn = "JAM_MULAI"
        OracleParameter20.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter20.ParameterName = "TGL_AKHIR"
        OracleParameter20.SourceColumn = "TGL_AKHIR"
        OracleParameter21.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter21.ParameterName = "JAM_AKHIR"
        OracleParameter21.Size = 8
        OracleParameter21.SourceColumn = "JAM_AKHIR"
        OracleParameter22.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter22.ParameterName = "JML_MOBIL"
        OracleParameter22.Precision = CType(38, Byte)
        OracleParameter22.SourceColumn = "JML_MOBIL"
        OracleParameter23.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter23.ParameterName = "TGL_REVISI"
        OracleParameter23.SourceColumn = "TGL_REVISI"
        OracleParameter24.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter24.ParameterName = "JAM_REVISI"
        OracleParameter24.Size = 8
        OracleParameter24.SourceColumn = "JAM_REVISI"
        OracleParameter25.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter25.ParameterName = "USER_NAME"
        OracleParameter25.Size = 15
        OracleParameter25.SourceColumn = "USER_NAME"
        OracleParameter26.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter26.ParameterName = "MRBREAD"
        OracleParameter26.Size = 1
        OracleParameter26.SourceColumn = "MRBREAD"
        OracleParameter27.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter27.ParameterName = "UPDATE"
        OracleParameter27.SourceColumn = "UPDATE"
        OracleParameter28.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter28.ParameterName = "SUPID"
        OracleParameter28.Precision = CType(38, Byte)
        OracleParameter28.SourceColumn = "SUPID"
        OracleParameter29.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter29.ParameterName = "GUDANG_KODE"
        OracleParameter29.Size = 8
        OracleParameter29.SourceColumn = "GUDANG_KODE"
        OracleParameter30.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter30.ParameterName = "LOKASI_KODE"
        OracleParameter30.Size = 8
        OracleParameter30.SourceColumn = "LOKASI_KODE"
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter2)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter3)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter4)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter5)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter6)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter7)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter8)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter9)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter10)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter11)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter12)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter13)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter14)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter15)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter16)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter17)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter18)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter19)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter20)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter21)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter22)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter23)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter24)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter25)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter26)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter27)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter28)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter29)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter30)
        Me.OleDbInsertCommand2.Transaction = Nothing
        '
        'OleDbSelectCommand2
        '
        Me.OleDbSelectCommand2.CommandText = resources.GetString("OleDbSelectCommand2.CommandText")
        Me.OleDbSelectCommand2.Connection = Me.olcon
        Me.OleDbSelectCommand2.Transaction = Nothing
        '
        'OleDbUpdateCommand2
        '
        Me.OleDbUpdateCommand2.CommandText = resources.GetString("OleDbUpdateCommand2.CommandText")
        Me.OleDbUpdateCommand2.Connection = Me.olcon
        OracleParameter31.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter31.ParameterName = "ID_DAFTARPO"
        OracleParameter31.Precision = CType(38, Byte)
        OracleParameter31.SourceColumn = "ID_DAFTARPO"
        OracleParameter32.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter32.ParameterName = "TANGGAL"
        OracleParameter32.SourceColumn = "TANGGAL"
        OracleParameter33.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter33.ParameterName = "RECID"
        OracleParameter33.Size = 1
        OracleParameter33.SourceColumn = "RECID"
        OracleParameter34.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter34.ParameterName = "ID_DAFTARJALUR"
        OracleParameter34.Precision = CType(38, Byte)
        OracleParameter34.SourceColumn = "ID_DAFTARJALUR"
        OracleParameter35.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter35.ParameterName = "NO_FAK"
        OracleParameter35.Size = 15
        OracleParameter35.SourceColumn = "NO_FAK"
        OracleParameter36.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter36.ParameterName = "TGL_FAK"
        OracleParameter36.SourceColumn = "TGL_FAK"
        OracleParameter37.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter37.ParameterName = "NOPO"
        OracleParameter37.Size = 9
        OracleParameter37.SourceColumn = "NOPO"
        OracleParameter38.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter38.ParameterName = "SUPCO"
        OracleParameter38.Size = 4
        OracleParameter38.SourceColumn = "SUPCO"
        OracleParameter39.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter39.ParameterName = "SNAMA"
        OracleParameter39.Size = 50
        OracleParameter39.SourceColumn = "SNAMA"
        OracleParameter40.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter40.ParameterName = "BUAT_PO"
        OracleParameter40.Precision = CType(38, Byte)
        OracleParameter40.SourceColumn = "BUAT_PO"
        OracleParameter41.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter41.ParameterName = "ADA_HARGA"
        OracleParameter41.Precision = CType(38, Byte)
        OracleParameter41.SourceColumn = "ADA_HARGA"
        OracleParameter42.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter42.ParameterName = "QTY"
        OracleParameter42.Precision = CType(38, Byte)
        OracleParameter42.SourceColumn = "QTY"
        OracleParameter43.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter43.ParameterName = "ITEM"
        OracleParameter43.Precision = CType(38, Byte)
        OracleParameter43.SourceColumn = "ITEM"
        OracleParameter44.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter44.ParameterName = "RUPIAH"
        OracleParameter44.Precision = CType(38, Byte)
        OracleParameter44.SourceColumn = "RUPIAH"
        OracleParameter45.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter45.ParameterName = "PPN"
        OracleParameter45.Precision = CType(38, Byte)
        OracleParameter45.SourceColumn = "PPN"
        OracleParameter46.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter46.ParameterName = "BPB_NO"
        OracleParameter46.Precision = CType(38, Byte)
        OracleParameter46.SourceColumn = "BPB_NO"
        OracleParameter47.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter47.ParameterName = "TGL_MULAI"
        OracleParameter47.SourceColumn = "TGL_MULAI"
        OracleParameter48.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter48.ParameterName = "JAM_MULAI"
        OracleParameter48.Size = 8
        OracleParameter48.SourceColumn = "JAM_MULAI"
        OracleParameter49.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter49.ParameterName = "TGL_AKHIR"
        OracleParameter49.SourceColumn = "TGL_AKHIR"
        OracleParameter50.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter50.ParameterName = "JAM_AKHIR"
        OracleParameter50.Size = 8
        OracleParameter50.SourceColumn = "JAM_AKHIR"
        OracleParameter51.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter51.ParameterName = "JML_MOBIL"
        OracleParameter51.Precision = CType(38, Byte)
        OracleParameter51.SourceColumn = "JML_MOBIL"
        OracleParameter52.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter52.ParameterName = "TGL_REVISI"
        OracleParameter52.SourceColumn = "TGL_REVISI"
        OracleParameter53.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter53.ParameterName = "JAM_REVISI"
        OracleParameter53.Size = 8
        OracleParameter53.SourceColumn = "JAM_REVISI"
        OracleParameter54.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter54.ParameterName = "USER_NAME"
        OracleParameter54.Size = 15
        OracleParameter54.SourceColumn = "USER_NAME"
        OracleParameter55.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter55.ParameterName = "MRBREAD"
        OracleParameter55.Size = 1
        OracleParameter55.SourceColumn = "MRBREAD"
        OracleParameter56.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter56.ParameterName = "UPDATE"
        OracleParameter56.SourceColumn = "UPDATE"
        OracleParameter57.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter57.ParameterName = "SUPID"
        OracleParameter57.Precision = CType(38, Byte)
        OracleParameter57.SourceColumn = "SUPID"
        OracleParameter58.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter58.ParameterName = "GUDANG_KODE"
        OracleParameter58.Size = 8
        OracleParameter58.SourceColumn = "GUDANG_KODE"
        OracleParameter59.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter59.ParameterName = "LOKASI_KODE"
        OracleParameter59.Size = 8
        OracleParameter59.SourceColumn = "LOKASI_KODE"
        OracleParameter60.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter60.ParameterName = "Original_ID_DAFTARPO"
        OracleParameter60.Precision = CType(38, Byte)
        OracleParameter60.SourceColumn = "ID_DAFTARPO"
        OracleParameter60.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter61.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter61.ParameterName = "Original_ADA_HARGA"
        OracleParameter61.Precision = CType(38, Byte)
        OracleParameter61.SourceColumn = "ADA_HARGA"
        OracleParameter61.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter62.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter62.ParameterName = "Original_ADA_HARGA1"
        OracleParameter62.Precision = CType(38, Byte)
        OracleParameter62.SourceColumn = "ADA_HARGA"
        OracleParameter62.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter63.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter63.ParameterName = "Original_BPB_NO"
        OracleParameter63.Precision = CType(38, Byte)
        OracleParameter63.SourceColumn = "BPB_NO"
        OracleParameter63.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter64.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter64.ParameterName = "Original_BPB_NO1"
        OracleParameter64.Precision = CType(38, Byte)
        OracleParameter64.SourceColumn = "BPB_NO"
        OracleParameter64.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter65.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter65.ParameterName = "Original_BUAT_PO"
        OracleParameter65.Precision = CType(38, Byte)
        OracleParameter65.SourceColumn = "BUAT_PO"
        OracleParameter65.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter66.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter66.ParameterName = "Original_BUAT_PO1"
        OracleParameter66.Precision = CType(38, Byte)
        OracleParameter66.SourceColumn = "BUAT_PO"
        OracleParameter66.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter67.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter67.ParameterName = "Original_GUDANG_KODE"
        OracleParameter67.Size = 8
        OracleParameter67.SourceColumn = "GUDANG_KODE"
        OracleParameter67.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter68.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter68.ParameterName = "Original_GUDANG_KODE1"
        OracleParameter68.Size = 8
        OracleParameter68.SourceColumn = "GUDANG_KODE"
        OracleParameter68.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter69.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter69.ParameterName = "Original_ID_DAFTARJALUR"
        OracleParameter69.Precision = CType(38, Byte)
        OracleParameter69.SourceColumn = "ID_DAFTARJALUR"
        OracleParameter69.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter70.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter70.ParameterName = "Original_ID_DAFTARJALUR1"
        OracleParameter70.Precision = CType(38, Byte)
        OracleParameter70.SourceColumn = "ID_DAFTARJALUR"
        OracleParameter70.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter71.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter71.ParameterName = "Original_ITEM"
        OracleParameter71.Precision = CType(38, Byte)
        OracleParameter71.SourceColumn = "ITEM"
        OracleParameter71.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter72.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter72.ParameterName = "Original_ITEM1"
        OracleParameter72.Precision = CType(38, Byte)
        OracleParameter72.SourceColumn = "ITEM"
        OracleParameter72.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter73.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter73.ParameterName = "Original_JAM_AKHIR"
        OracleParameter73.Size = 8
        OracleParameter73.SourceColumn = "JAM_AKHIR"
        OracleParameter73.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter74.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter74.ParameterName = "Original_JAM_AKHIR1"
        OracleParameter74.Size = 8
        OracleParameter74.SourceColumn = "JAM_AKHIR"
        OracleParameter74.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter75.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter75.ParameterName = "Original_JAM_MULAI"
        OracleParameter75.Size = 8
        OracleParameter75.SourceColumn = "JAM_MULAI"
        OracleParameter75.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter76.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter76.ParameterName = "Original_JAM_MULAI1"
        OracleParameter76.Size = 8
        OracleParameter76.SourceColumn = "JAM_MULAI"
        OracleParameter76.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter77.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter77.ParameterName = "Original_JAM_REVISI"
        OracleParameter77.Size = 8
        OracleParameter77.SourceColumn = "JAM_REVISI"
        OracleParameter77.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter78.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter78.ParameterName = "Original_JAM_REVISI1"
        OracleParameter78.Size = 8
        OracleParameter78.SourceColumn = "JAM_REVISI"
        OracleParameter78.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter79.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter79.ParameterName = "Original_JML_MOBIL"
        OracleParameter79.Precision = CType(38, Byte)
        OracleParameter79.SourceColumn = "JML_MOBIL"
        OracleParameter79.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter80.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter80.ParameterName = "Original_JML_MOBIL1"
        OracleParameter80.Precision = CType(38, Byte)
        OracleParameter80.SourceColumn = "JML_MOBIL"
        OracleParameter80.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter81.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter81.ParameterName = "Original_LOKASI_KODE"
        OracleParameter81.Size = 8
        OracleParameter81.SourceColumn = "LOKASI_KODE"
        OracleParameter81.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter82.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter82.ParameterName = "Original_LOKASI_KODE1"
        OracleParameter82.Size = 8
        OracleParameter82.SourceColumn = "LOKASI_KODE"
        OracleParameter82.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter83.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter83.ParameterName = "Original_MRBREAD"
        OracleParameter83.Size = 1
        OracleParameter83.SourceColumn = "MRBREAD"
        OracleParameter83.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter84.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter84.ParameterName = "Original_MRBREAD1"
        OracleParameter84.Size = 1
        OracleParameter84.SourceColumn = "MRBREAD"
        OracleParameter84.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter85.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter85.ParameterName = "Original_NOPO"
        OracleParameter85.Size = 9
        OracleParameter85.SourceColumn = "NOPO"
        OracleParameter85.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter86.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter86.ParameterName = "Original_NOPO1"
        OracleParameter86.Size = 9
        OracleParameter86.SourceColumn = "NOPO"
        OracleParameter86.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter87.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter87.ParameterName = "Original_NO_FAK"
        OracleParameter87.Size = 15
        OracleParameter87.SourceColumn = "NO_FAK"
        OracleParameter87.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter88.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter88.ParameterName = "Original_NO_FAK1"
        OracleParameter88.Size = 15
        OracleParameter88.SourceColumn = "NO_FAK"
        OracleParameter88.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter89.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter89.ParameterName = "Original_PPN"
        OracleParameter89.Precision = CType(38, Byte)
        OracleParameter89.SourceColumn = "PPN"
        OracleParameter89.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter90.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter90.ParameterName = "Original_PPN1"
        OracleParameter90.Precision = CType(38, Byte)
        OracleParameter90.SourceColumn = "PPN"
        OracleParameter90.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter91.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter91.ParameterName = "Original_QTY"
        OracleParameter91.Precision = CType(38, Byte)
        OracleParameter91.SourceColumn = "QTY"
        OracleParameter91.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter92.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter92.ParameterName = "Original_QTY1"
        OracleParameter92.Precision = CType(38, Byte)
        OracleParameter92.SourceColumn = "QTY"
        OracleParameter92.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter93.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter93.ParameterName = "Original_RECID"
        OracleParameter93.Size = 1
        OracleParameter93.SourceColumn = "RECID"
        OracleParameter93.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter94.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter94.ParameterName = "Original_RECID1"
        OracleParameter94.Size = 1
        OracleParameter94.SourceColumn = "RECID"
        OracleParameter94.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter95.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter95.ParameterName = "Original_RUPIAH"
        OracleParameter95.Precision = CType(38, Byte)
        OracleParameter95.SourceColumn = "RUPIAH"
        OracleParameter95.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter96.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter96.ParameterName = "Original_RUPIAH1"
        OracleParameter96.Precision = CType(38, Byte)
        OracleParameter96.SourceColumn = "RUPIAH"
        OracleParameter96.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter97.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter97.ParameterName = "Original_SNAMA"
        OracleParameter97.Size = 50
        OracleParameter97.SourceColumn = "SNAMA"
        OracleParameter97.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter98.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter98.ParameterName = "Original_SNAMA1"
        OracleParameter98.Size = 50
        OracleParameter98.SourceColumn = "SNAMA"
        OracleParameter98.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter99.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter99.ParameterName = "Original_SUPCO"
        OracleParameter99.Size = 4
        OracleParameter99.SourceColumn = "SUPCO"
        OracleParameter99.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter100.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter100.ParameterName = "Original_SUPID"
        OracleParameter100.Precision = CType(38, Byte)
        OracleParameter100.SourceColumn = "SUPID"
        OracleParameter100.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter101.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter101.ParameterName = "Original_SUPID1"
        OracleParameter101.Precision = CType(38, Byte)
        OracleParameter101.SourceColumn = "SUPID"
        OracleParameter101.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter102.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter102.ParameterName = "Original_TANGGAL"
        OracleParameter102.SourceColumn = "TANGGAL"
        OracleParameter102.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter103.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter103.ParameterName = "Original_TANGGAL1"
        OracleParameter103.SourceColumn = "TANGGAL"
        OracleParameter103.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter104.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter104.ParameterName = "Original_TGL_AKHIR"
        OracleParameter104.SourceColumn = "TGL_AKHIR"
        OracleParameter104.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter105.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter105.ParameterName = "Original_TGL_AKHIR1"
        OracleParameter105.SourceColumn = "TGL_AKHIR"
        OracleParameter105.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter106.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter106.ParameterName = "Original_TGL_FAK"
        OracleParameter106.SourceColumn = "TGL_FAK"
        OracleParameter106.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter107.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter107.ParameterName = "Original_TGL_FAK1"
        OracleParameter107.SourceColumn = "TGL_FAK"
        OracleParameter107.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter108.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter108.ParameterName = "Original_TGL_MULAI"
        OracleParameter108.SourceColumn = "TGL_MULAI"
        OracleParameter108.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter109.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter109.ParameterName = "Original_TGL_MULAI1"
        OracleParameter109.SourceColumn = "TGL_MULAI"
        OracleParameter109.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter110.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter110.ParameterName = "Original_TGL_REVISI"
        OracleParameter110.SourceColumn = "TGL_REVISI"
        OracleParameter110.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter111.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter111.ParameterName = "Original_TGL_REVISI1"
        OracleParameter111.SourceColumn = "TGL_REVISI"
        OracleParameter111.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter112.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter112.ParameterName = "Original_UPDATE"
        OracleParameter112.SourceColumn = "UPDATE"
        OracleParameter112.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter113.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter113.ParameterName = "Original_UPDATE1"
        OracleParameter113.SourceColumn = "UPDATE"
        OracleParameter113.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter114.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter114.ParameterName = "Original_USER_NAME"
        OracleParameter114.Size = 15
        OracleParameter114.SourceColumn = "USER_NAME"
        OracleParameter114.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter115.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter115.ParameterName = "Original_USER_NAME1"
        OracleParameter115.Size = 15
        OracleParameter115.SourceColumn = "USER_NAME"
        OracleParameter115.SourceVersion = System.Data.DataRowVersion.Original
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter31)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter32)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter33)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter34)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter35)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter36)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter37)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter38)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter39)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter40)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter41)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter42)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter43)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter44)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter45)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter46)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter47)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter48)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter49)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter50)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter51)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter52)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter53)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter54)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter55)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter56)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter57)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter58)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter59)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter60)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter61)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter62)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter63)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter64)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter65)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter66)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter67)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter68)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter69)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter70)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter71)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter72)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter73)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter74)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter75)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter76)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter77)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter78)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter79)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter80)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter81)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter82)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter83)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter84)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter85)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter86)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter87)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter88)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter89)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter90)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter91)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter92)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter93)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter94)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter95)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter96)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter97)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter98)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter99)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter100)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter101)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter102)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter103)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter104)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter105)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter106)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter107)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter108)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter109)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter110)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter111)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter112)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter113)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter114)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter115)
        Me.OleDbUpdateCommand2.Transaction = Nothing
        '
        'oldapMobil
        '
        Me.oldapMobil.DeleteCommand = Me.OleDbDeleteCommand1
        Me.oldapMobil.InsertCommand = Me.OleDbInsertCommand1
        Me.oldapMobil.SelectCommand = Me.OleDbSelectCommand1
        Me.oldapMobil.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "DC_JLR_DAFTARJALUR_T", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("ID_DAFTARJALUR", "ID_DAFTARJALUR"), New System.Data.Common.DataColumnMapping("DC_ID", "DC_ID"), New System.Data.Common.DataColumnMapping("TANGGAL", "TANGGAL"), New System.Data.Common.DataColumnMapping("RECID", "RECID"), New System.Data.Common.DataColumnMapping("NOMOBIL", "NOMOBIL"), New System.Data.Common.DataColumnMapping("NOURUT", "NOURUT"), New System.Data.Common.DataColumnMapping("SUPCO", "SUPCO"), New System.Data.Common.DataColumnMapping("SNAMA", "SNAMA"), New System.Data.Common.DataColumnMapping("ITEM", "ITEMnya"), New System.Data.Common.DataColumnMapping("RUPIAH", "RUPIAH"), New System.Data.Common.DataColumnMapping("TGLSTART", "TGLSTART"), New System.Data.Common.DataColumnMapping("TGLEND", "TGLEND"), New System.Data.Common.DataColumnMapping("JALUR", "JALUR")})})
        Me.oldapMobil.UpdateCommand = Me.OleDbUpdateCommand1
        '
        'OleDbDeleteCommand1
        '
        Me.OleDbDeleteCommand1.CommandText = "DELETE FROM DC_JLR_DAFTARJALUR_T WHERE (ID_DAFTARJALUR = ?)"
        Me.OleDbDeleteCommand1.Connection = Me.olcon
        OracleParameter116.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter116.ParameterName = "ID_DAFTARJALUR"
        OracleParameter116.Precision = CType(38, Byte)
        OracleParameter116.SourceColumn = "ID_DAFTARJALUR"
        OracleParameter116.SourceVersion = System.Data.DataRowVersion.Original
        Me.OleDbDeleteCommand1.Parameters.Add(OracleParameter116)
        Me.OleDbDeleteCommand1.Transaction = Nothing
        '
        'OleDbInsertCommand1
        '
        Me.OleDbInsertCommand1.CommandText = resources.GetString("OleDbInsertCommand1.CommandText")
        Me.OleDbInsertCommand1.Connection = Me.olcon
        OracleParameter117.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter117.ParameterName = "ID_DAFTARJALUR"
        OracleParameter117.Precision = CType(38, Byte)
        OracleParameter117.SourceColumn = "ID_DAFTARJALUR"
        OracleParameter118.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter118.ParameterName = "DC_ID"
        OracleParameter118.Precision = CType(38, Byte)
        OracleParameter118.SourceColumn = "DC_ID"
        OracleParameter119.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter119.ParameterName = "TANGGAL"
        OracleParameter119.SourceColumn = "TANGGAL"
        OracleParameter120.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter120.ParameterName = "RECID"
        OracleParameter120.Size = 1
        OracleParameter120.SourceColumn = "RECID"
        OracleParameter121.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter121.ParameterName = "NOMOBIL"
        OracleParameter121.Size = 11
        OracleParameter121.SourceColumn = "NOMOBIL"
        OracleParameter122.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter122.ParameterName = "NOURUT"
        OracleParameter122.Precision = CType(38, Byte)
        OracleParameter122.SourceColumn = "NOURUT"
        OracleParameter123.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter123.ParameterName = "SUPCO"
        OracleParameter123.Size = 4
        OracleParameter123.SourceColumn = "SUPCO"
        OracleParameter124.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter124.ParameterName = "SNAMA"
        OracleParameter124.Size = 50
        OracleParameter124.SourceColumn = "SNAMA"
        OracleParameter125.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter125.ParameterName = "ITEM"
        OracleParameter125.Precision = CType(38, Byte)
        OracleParameter125.SourceColumn = "ITEM"
        OracleParameter126.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter126.ParameterName = "RUPIAH"
        OracleParameter126.Precision = CType(38, Byte)
        OracleParameter126.SourceColumn = "RUPIAH"
        OracleParameter127.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter127.ParameterName = "TGLSTART"
        OracleParameter127.SourceColumn = "TGLSTART"
        OracleParameter128.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter128.ParameterName = "TGLEND"
        OracleParameter128.SourceColumn = "TGLEND"
        OracleParameter129.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter129.ParameterName = "JALUR"
        OracleParameter129.Size = 50
        OracleParameter129.SourceColumn = "JALUR"
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter117)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter118)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter119)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter120)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter121)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter122)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter123)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter124)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter125)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter126)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter127)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter128)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter129)
        Me.OleDbInsertCommand1.Transaction = Nothing
        '
        'OleDbSelectCommand1
        '
        Me.OleDbSelectCommand1.CommandText = "SELECT     ID_DAFTARJALUR, DC_ID, TANGGAL, RECID, NOMOBIL, NOURUT, SUPCO, SNAMA, " &
    "ITEM, trunc(RUPIAH,8) as rupiah, TGLSTART, TGLEND, JALUR, PRINT_ID" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "FROM        " &
    " DC_JLR_DAFTARJALUR_T"
        Me.OleDbSelectCommand1.Connection = Me.olcon
        Me.OleDbSelectCommand1.Transaction = Nothing
        '
        'OleDbUpdateCommand1
        '
        Me.OleDbUpdateCommand1.CommandText = resources.GetString("OleDbUpdateCommand1.CommandText")
        Me.OleDbUpdateCommand1.Connection = Me.olcon
        OracleParameter130.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter130.ParameterName = "ID_DAFTARJALUR"
        OracleParameter130.Precision = CType(38, Byte)
        OracleParameter130.SourceColumn = "ID_DAFTARJALUR"
        OracleParameter131.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter131.ParameterName = "DC_ID"
        OracleParameter131.Precision = CType(38, Byte)
        OracleParameter131.SourceColumn = "DC_ID"
        OracleParameter132.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter132.ParameterName = "TANGGAL"
        OracleParameter132.SourceColumn = "TANGGAL"
        OracleParameter133.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter133.ParameterName = "RECID"
        OracleParameter133.Size = 1
        OracleParameter133.SourceColumn = "RECID"
        OracleParameter134.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter134.ParameterName = "NOMOBIL"
        OracleParameter134.Size = 11
        OracleParameter134.SourceColumn = "NOMOBIL"
        OracleParameter135.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter135.ParameterName = "NOURUT"
        OracleParameter135.Precision = CType(38, Byte)
        OracleParameter135.SourceColumn = "NOURUT"
        OracleParameter136.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter136.ParameterName = "SUPCO"
        OracleParameter136.Size = 4
        OracleParameter136.SourceColumn = "SUPCO"
        OracleParameter137.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter137.ParameterName = "SNAMA"
        OracleParameter137.Size = 50
        OracleParameter137.SourceColumn = "SNAMA"
        OracleParameter138.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter138.ParameterName = "ITEM"
        OracleParameter138.Precision = CType(38, Byte)
        OracleParameter138.SourceColumn = "ITEM"
        OracleParameter139.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter139.ParameterName = "RUPIAH"
        OracleParameter139.Precision = CType(38, Byte)
        OracleParameter139.SourceColumn = "RUPIAH"
        OracleParameter140.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter140.ParameterName = "TGLSTART"
        OracleParameter140.SourceColumn = "TGLSTART"
        OracleParameter141.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter141.ParameterName = "TGLEND"
        OracleParameter141.SourceColumn = "TGLEND"
        OracleParameter142.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter142.ParameterName = "JALUR"
        OracleParameter142.Size = 50
        OracleParameter142.SourceColumn = "JALUR"
        OracleParameter143.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter143.ParameterName = "Original_ID_DAFTARJALUR"
        OracleParameter143.Precision = CType(38, Byte)
        OracleParameter143.SourceColumn = "ID_DAFTARJALUR"
        OracleParameter143.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter144.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter144.ParameterName = "Original_DC_ID"
        OracleParameter144.Precision = CType(38, Byte)
        OracleParameter144.SourceColumn = "DC_ID"
        OracleParameter144.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter145.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter145.ParameterName = "Original_ITEM"
        OracleParameter145.Precision = CType(38, Byte)
        OracleParameter145.SourceColumn = "ITEM"
        OracleParameter145.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter146.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter146.ParameterName = "Original_ITEM1"
        OracleParameter146.Precision = CType(38, Byte)
        OracleParameter146.SourceColumn = "ITEM"
        OracleParameter146.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter147.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter147.ParameterName = "Original_JALUR"
        OracleParameter147.Size = 50
        OracleParameter147.SourceColumn = "JALUR"
        OracleParameter147.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter148.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter148.ParameterName = "Original_JALUR1"
        OracleParameter148.Size = 50
        OracleParameter148.SourceColumn = "JALUR"
        OracleParameter148.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter149.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter149.ParameterName = "Original_NOMOBIL"
        OracleParameter149.Size = 11
        OracleParameter149.SourceColumn = "NOMOBIL"
        OracleParameter149.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter150.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter150.ParameterName = "Original_NOURUT"
        OracleParameter150.Precision = CType(38, Byte)
        OracleParameter150.SourceColumn = "NOURUT"
        OracleParameter150.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter151.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter151.ParameterName = "Original_NOURUT1"
        OracleParameter151.Precision = CType(38, Byte)
        OracleParameter151.SourceColumn = "NOURUT"
        OracleParameter151.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter152.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter152.ParameterName = "Original_RECID"
        OracleParameter152.Size = 1
        OracleParameter152.SourceColumn = "RECID"
        OracleParameter152.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter153.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter153.ParameterName = "Original_RECID1"
        OracleParameter153.Size = 1
        OracleParameter153.SourceColumn = "RECID"
        OracleParameter153.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter154.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter154.ParameterName = "Original_RUPIAH"
        OracleParameter154.Precision = CType(38, Byte)
        OracleParameter154.SourceColumn = "RUPIAH"
        OracleParameter154.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter155.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter155.ParameterName = "Original_RUPIAH1"
        OracleParameter155.Precision = CType(38, Byte)
        OracleParameter155.SourceColumn = "RUPIAH"
        OracleParameter155.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter156.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter156.ParameterName = "Original_SNAMA"
        OracleParameter156.Size = 50
        OracleParameter156.SourceColumn = "SNAMA"
        OracleParameter156.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter157.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter157.ParameterName = "Original_SNAMA1"
        OracleParameter157.Size = 50
        OracleParameter157.SourceColumn = "SNAMA"
        OracleParameter157.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter158.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter158.ParameterName = "Original_SUPCO"
        OracleParameter158.Size = 4
        OracleParameter158.SourceColumn = "SUPCO"
        OracleParameter158.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter159.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter159.ParameterName = "Original_SUPCO1"
        OracleParameter159.Size = 4
        OracleParameter159.SourceColumn = "SUPCO"
        OracleParameter159.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter160.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter160.ParameterName = "Original_TANGGAL"
        OracleParameter160.SourceColumn = "TANGGAL"
        OracleParameter160.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter161.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter161.ParameterName = "Original_TANGGAL1"
        OracleParameter161.SourceColumn = "TANGGAL"
        OracleParameter161.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter162.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter162.ParameterName = "Original_TGLEND"
        OracleParameter162.SourceColumn = "TGLEND"
        OracleParameter162.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter163.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter163.ParameterName = "Original_TGLEND1"
        OracleParameter163.SourceColumn = "TGLEND"
        OracleParameter163.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter164.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter164.ParameterName = "Original_TGLSTART"
        OracleParameter164.SourceColumn = "TGLSTART"
        OracleParameter164.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter165.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter165.ParameterName = "Original_TGLSTART1"
        OracleParameter165.SourceColumn = "TGLSTART"
        OracleParameter165.SourceVersion = System.Data.DataRowVersion.Original
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter130)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter131)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter132)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter133)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter134)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter135)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter136)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter137)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter138)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter139)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter140)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter141)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter142)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter143)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter144)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter145)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter146)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter147)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter148)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter149)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter150)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter151)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter152)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter153)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter154)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter155)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter156)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter157)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter158)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter159)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter160)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter161)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter162)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter163)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter164)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter165)
        Me.OleDbUpdateCommand1.Transaction = Nothing
        '
        'dgvLoadPO
        '
        Me.dgvLoadPO.AllowUserToAddRows = False
        Me.dgvLoadPO.AllowUserToDeleteRows = False
        Me.dgvLoadPO.BackgroundColor = System.Drawing.Color.LightGoldenrodYellow
        Me.dgvLoadPO.CausesValidation = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvLoadPO.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvLoadPO.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvLoadPO.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.QTYBPBPCS, Me.DataGridViewTextBoxColumn2, Me.QTYPOPCS, Me.DataGridViewTextBoxColumn3, Me.FRACT, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12, Me.DataGridViewTextBoxColumn13, Me.DataGridViewTextBoxColumn14, Me.DataGridViewTextBoxColumn15, Me.DataGridViewTextBoxColumn16, Me.DataGridViewTextBoxColumn17, Me.DataGridViewTextBoxColumn18, Me.DataGridViewTextBoxColumn19, Me.DataGridViewTextBoxColumn20, Me.DataGridViewTextBoxColumn21})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvLoadPO.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgvLoadPO.GridColor = System.Drawing.Color.Olive
        Me.dgvLoadPO.Location = New System.Drawing.Point(2, 2)
        Me.dgvLoadPO.Name = "dgvLoadPO"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvLoadPO.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgvLoadPO.Size = New System.Drawing.Size(737, 416)
        Me.dgvLoadPO.TabIndex = 5
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "PRDCD"
        Me.DataGridViewTextBoxColumn1.HeaderText = "PLU"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn1.Width = 34
        '
        'QTYBPBPCS
        '
        Me.QTYBPBPCS.HeaderText = "Qty Pcs BPB"
        Me.QTYBPBPCS.Name = "QTYBPBPCS"
        Me.QTYBPBPCS.ReadOnly = True
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "FRAC"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Qty FRAC BPB"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn2.Width = 76
        '
        'QTYPOPCS
        '
        Me.QTYPOPCS.HeaderText = "Qty Pcs PO"
        Me.QTYPOPCS.Name = "QTYPOPCS"
        Me.QTYPOPCS.ReadOnly = True
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "FRACASAL"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Qty FRAC PO"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn3.Width = 70
        '
        'FRACT
        '
        Me.FRACT.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.FRACT.HeaderText = "FRAC"
        Me.FRACT.Name = "FRACT"
        Me.FRACT.ReadOnly = True
        Me.FRACT.Width = 60
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "PO_GROSS"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Nilai"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn4.Visible = False
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "PO_PPN"
        Me.DataGridViewTextBoxColumn5.HeaderText = "PPn"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn5.Visible = False
        Me.DataGridViewTextBoxColumn5.Width = 80
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "PO_DISC"
        Me.DataGridViewTextBoxColumn6.HeaderText = "Disc"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn6.Visible = False
        Me.DataGridViewTextBoxColumn6.Width = 80
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.HeaderText = "Unit"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn7.Visible = False
        Me.DataGridViewTextBoxColumn7.Width = 40
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.DataPropertyName = "QTYBONUS"
        Me.DataGridViewTextBoxColumn8.HeaderText = "Bonus"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn8.Visible = False
        Me.DataGridViewTextBoxColumn8.Width = 40
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn9.DataPropertyName = "DESKRIPSI"
        Me.DataGridViewTextBoxColumn9.HeaderText = "Deskripsi"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn9.Width = 56
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.HeaderText = "NO PO"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn10.Visible = False
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.HeaderText = "SATUAN"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn11.Visible = False
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.HeaderText = "PO DTL PRICE"
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn12.Visible = False
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.HeaderText = "PEMBAGI DISC"
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn13.Visible = False
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.HeaderText = "PO PPN ASAL"
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        Me.DataGridViewTextBoxColumn14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn14.Visible = False
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.HeaderText = "PO DISCASAL"
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        Me.DataGridViewTextBoxColumn15.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn15.Visible = False
        '
        'DataGridViewTextBoxColumn16
        '
        Me.DataGridViewTextBoxColumn16.HeaderText = "PPN BOTOLASAL"
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        Me.DataGridViewTextBoxColumn16.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn16.Visible = False
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.HeaderText = "PPN BOTOL"
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        Me.DataGridViewTextBoxColumn17.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn17.Visible = False
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.HeaderText = "QTYBONUSASAL"
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        Me.DataGridViewTextBoxColumn18.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn18.Visible = False
        '
        'DataGridViewTextBoxColumn19
        '
        Me.DataGridViewTextBoxColumn19.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn19.DataPropertyName = "MBRTAG"
        Me.DataGridViewTextBoxColumn19.HeaderText = "TAG"
        Me.DataGridViewTextBoxColumn19.Name = "DataGridViewTextBoxColumn19"
        Me.DataGridViewTextBoxColumn19.ReadOnly = True
        Me.DataGridViewTextBoxColumn19.Width = 54
        '
        'DataGridViewTextBoxColumn20
        '
        Me.DataGridViewTextBoxColumn20.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn20.DataPropertyName = "EXTAG"
        Me.DataGridViewTextBoxColumn20.HeaderText = "F_EXC TAG"
        Me.DataGridViewTextBoxColumn20.Name = "DataGridViewTextBoxColumn20"
        Me.DataGridViewTextBoxColumn20.ReadOnly = True
        Me.DataGridViewTextBoxColumn20.Width = 83
        '
        'DataGridViewTextBoxColumn21
        '
        Me.DataGridViewTextBoxColumn21.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn21.HeaderText = "PPN RATE"
        Me.DataGridViewTextBoxColumn21.Name = "DataGridViewTextBoxColumn21"
        Me.DataGridViewTextBoxColumn21.ReadOnly = True
        Me.DataGridViewTextBoxColumn21.Visible = False
        '
        'frmLoadPO
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SeaGreen
        Me.ClientSize = New System.Drawing.Size(742, 491)
        Me.Controls.Add(Me.dgvLoadPO)
        Me.Controls.Add(Me.btnBatal)
        Me.Controls.Add(Me.btnSimpan)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "frmLoadPO"
        Me.Text = "frmLoadPO"
        CType(Me.DsPO1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvLoadPO, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnBatal As System.Windows.Forms.Button
    Friend WithEvents btnSimpan As System.Windows.Forms.Button
    Friend WithEvents DsPO1 As PendaftaranPO.DS_
    Friend WithEvents olcon As OracleConnection
    Private WithEvents oldapPO As OracleDataAdapter
    Private WithEvents OleDbDeleteCommand2 As OracleCommand
    Private WithEvents OleDbInsertCommand2 As OracleCommand
    Private WithEvents OleDbSelectCommand2 As OracleCommand
    Private WithEvents OleDbUpdateCommand2 As OracleCommand
    Private WithEvents oldapMobil As OracleDataAdapter
    Private WithEvents OleDbDeleteCommand1 As OracleCommand
    Private WithEvents OleDbInsertCommand1 As OracleCommand
    Private WithEvents OleDbSelectCommand1 As OracleCommand
    Private WithEvents OleDbUpdateCommand1 As OracleCommand
    Friend WithEvents dgvLoadPO As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents QTYBPBPCS As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents QTYPOPCS As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents FRACT As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn17 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn19 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn20 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn21 As DataGridViewTextBoxColumn
End Class
