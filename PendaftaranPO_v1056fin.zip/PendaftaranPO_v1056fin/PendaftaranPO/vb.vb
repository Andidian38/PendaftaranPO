﻿Imports Oracle.ManagedDataAccess.Client
Imports SD3Fungsi
Imports SettingLib
Public Class vb
    Public lokasi As String = "Indomaret\RegOracle"
    Sub Cek_Program(ByVal KodeDc As String, ByVal ConStrORA As String)
        Dim IpLocal As String = IpKomp.GetIPAddress()

        Dim cls As New SettingLib.Class1

        Dim cek As New cls_ProgramMonitor
        Dim Ret As String
        Ret = cls.GetVersi(ConStrORA, KodeDc, Application.ProductName & ".EXE", Application.ProductVersion, IpLocal)
        If Ret.ToString.Contains("OKE") = False Then
            MsgBox(Ret)
            End
        End If

        'Dim cek As New cls_ProgramMonitor
        'Dim Ret As String
        'Ret = cek.Get_VersiProgram(ConStrORA, KodeDc, Application.ProductName & ".EXE", Application.ProductVersion, IpLocal)
        'If Ret.ToString.Contains("OKE") = False Then
        '    MsgBox(Ret)
        '    End
        'End If

    End Sub
    Public Function ambilDataDC(ByVal constr As String) As String()
        Dim con As New OracleConnection(constr)
        Try
            Dim com As New OracleCommand("", con)
            Dim da As New OracleDataAdapter("", con)
            Dim dr As OracleDataReader
            Dim dc(2) As String
            con.Open()
            Dim sql As String = "select tbl_dc_nama,tbl_dc_kode from dc_tabel_dc_t"
            'MessageBox.Show(sql)
            com.CommandText = sql
            dr = com.ExecuteReader
            dr.Read()
            dc(0) = dr.Item("TBL_DC_KODE")
            dc(1) = dr.Item("TBL_DC_NAMA")
            dr.Close()

            Return dc
        Catch ex As Exception
            Return Nothing
            MessageBox.Show("Error cek data :" & vbCrLf & ex.Message)
        Finally
            con.Close()
        End Try
    End Function
    Public Function execNonQuery(ByVal strConOra As String, ByVal query As String) As String
        Dim con As New OracleConnection(strConOra)
        Dim com As New OracleCommand("", con)
        Dim _e As String = ""
        Try
            con.Open()
            com.CommandText = query
            com.ExecuteNonQuery()

        Catch ex As Exception
            _e = ex.ToString
        Finally
            con.Close()
        End Try

        Return _e
    End Function
    Public Function execScalarSTR(ByVal strConOra As String, ByVal query As String) As String
        Dim con As New OracleConnection(strConOra)
        Dim com As New OracleCommand("", con)
        Dim _e As Integer = 0
        Try
            con.Open()
            com.CommandText = query
            _e = com.ExecuteScalar()
        Catch ex As Exception
            _e = -1
        Finally
            con.Close()
        End Try
        Return _e
    End Function
    Public Function execScalar(ByVal strConOra As String, ByVal query As String) As Integer
        Dim con As New OracleConnection(strConOra)
        Dim com As New OracleCommand("", con)
        Dim _e As Integer = 0
        Try
            con.Open()
            com.CommandText = query
            _e = com.ExecuteScalar()
        Catch ex As Exception
            _e = -1
        Finally
            con.Close()
        End Try
        Return _e
    End Function
    Public Function Cek_Update_Prog(ByVal OraCommString As String, ByVal program As String) As String
        Dim OraCon As New OracleConnection(OraCommString)
        Dim Oracomm As New OracleCommand("", OraCon)
        Cek_Update_Prog = "0"
        Try
            OraCon.Open()
            Oracomm.CommandText = " SELECT Versi FROM DC_PROGRAM_VB_T where nama_prog like '%" & program.ToUpper & "%' "
            Cek_Update_Prog = IIf(IsDBNull(Oracomm.ExecuteScalar), "0", Oracomm.ExecuteScalar)
            If IsNothing(Cek_Update_Prog) Then
                Cek_Update_Prog = "0"
            End If
        Catch ex As Exception

        Finally
            OraCon.Close()
        End Try
        Return Cek_Update_Prog
        'Dim oradb As String = "Data Source=" & BacaRegistry(lokasi, "S") & ";User Id=" & BacaRegistry(lokasi, "U") & ";Password=" & BacaRegistry(lokasi, "P") & ";"
        'Dim conn As New OracleConnection(oradb)
        'Cek_Update_Prog = "0"
        'Try
        '    conn.Open()
        '    Dim sql As String = "SELECT Versi FROM DC_PROGRAM_VB_T@DCHO where nama_prog like '%" & program.ToUpper & "%'"  ' VB.NET"
        '    Dim cmd As New OracleCommand(sql, conn)
        '    cmd.CommandType = CommandType.Text
        '    Cek_Update_Prog = IIf(IsDBNull(cmd.ExecuteScalar), "0", cmd.ExecuteScalar)
        '    If IsNothing(Cek_Update_Prog) Then
        '        Cek_Update_Prog = "0"
        '    End If
        'Catch ex As Exception

        'Finally
        '    conn.Close()
        'End Try
        'Return Cek_Update_Prog
    End Function
End Class
