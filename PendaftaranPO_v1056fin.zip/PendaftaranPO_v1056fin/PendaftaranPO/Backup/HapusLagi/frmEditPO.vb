Public Class frmEditPO
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents DataGrid1 As System.Windows.Forms.DataGrid
    Friend WithEvents btnSimpan As System.Windows.Forms.Button
    Friend WithEvents btnBatal As System.Windows.Forms.Button
    Friend WithEvents DsPO1 As AntrianDC.dsPO
    Friend WithEvents DataGridTableStyle1 As System.Windows.Forms.DataGridTableStyle
    Friend WithEvents DataGridTextBoxColumn1 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents DataGridTextBoxColumn2 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents DataGridTextBoxColumn3 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents DataGridTextBoxColumn4 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents DataGridTextBoxColumn5 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents DataGridTextBoxColumn6 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents DataGridTextBoxColumn8 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents DataGridTextBoxColumn7 As System.Windows.Forms.DataGridTextBoxColumn
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.DataGrid1 = New System.Windows.Forms.DataGrid
        Me.DsPO1 = New AntrianDC.dsPO
        Me.DataGridTableStyle1 = New System.Windows.Forms.DataGridTableStyle
        Me.DataGridTextBoxColumn2 = New System.Windows.Forms.DataGridTextBoxColumn
        Me.DataGridTextBoxColumn3 = New System.Windows.Forms.DataGridTextBoxColumn
        Me.DataGridTextBoxColumn6 = New System.Windows.Forms.DataGridTextBoxColumn
        Me.DataGridTextBoxColumn7 = New System.Windows.Forms.DataGridTextBoxColumn
        Me.DataGridTextBoxColumn5 = New System.Windows.Forms.DataGridTextBoxColumn
        Me.DataGridTextBoxColumn4 = New System.Windows.Forms.DataGridTextBoxColumn
        Me.DataGridTextBoxColumn8 = New System.Windows.Forms.DataGridTextBoxColumn
        Me.DataGridTextBoxColumn1 = New System.Windows.Forms.DataGridTextBoxColumn
        Me.btnSimpan = New System.Windows.Forms.Button
        Me.btnBatal = New System.Windows.Forms.Button
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsPO1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGrid1
        '
        Me.DataGrid1.AlternatingBackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.DataGrid1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGrid1.BackColor = System.Drawing.Color.White
        Me.DataGrid1.BackgroundColor = System.Drawing.Color.LightGoldenrodYellow
        Me.DataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.DataGrid1.CaptionBackColor = System.Drawing.Color.Olive
        Me.DataGrid1.CaptionFont = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
        Me.DataGrid1.CaptionForeColor = System.Drawing.Color.DarkSlateBlue
        Me.DataGrid1.DataMember = ""
        Me.DataGrid1.DataSource = Me.DsPO1.EditPO
        Me.DataGrid1.FlatMode = True
        Me.DataGrid1.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.DataGrid1.ForeColor = System.Drawing.Color.DarkSlateBlue
        Me.DataGrid1.GridLineColor = System.Drawing.Color.Peru
        Me.DataGrid1.GridLineStyle = System.Windows.Forms.DataGridLineStyle.None
        Me.DataGrid1.HeaderBackColor = System.Drawing.Color.Maroon
        Me.DataGrid1.HeaderFont = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
        Me.DataGrid1.HeaderForeColor = System.Drawing.Color.LightGoldenrodYellow
        Me.DataGrid1.LinkColor = System.Drawing.Color.Maroon
        Me.DataGrid1.Location = New System.Drawing.Point(8, 8)
        Me.DataGrid1.Name = "DataGrid1"
        Me.DataGrid1.ParentRowsBackColor = System.Drawing.Color.BurlyWood
        Me.DataGrid1.ParentRowsForeColor = System.Drawing.Color.DarkSlateBlue
        Me.DataGrid1.SelectionBackColor = System.Drawing.Color.DarkSlateBlue
        Me.DataGrid1.SelectionForeColor = System.Drawing.Color.GhostWhite
        Me.DataGrid1.Size = New System.Drawing.Size(658, 160)
        Me.DataGrid1.TabIndex = 0
        Me.DataGrid1.TableStyles.AddRange(New System.Windows.Forms.DataGridTableStyle() {Me.DataGridTableStyle1})
        '
        'DsPO1
        '
        Me.DsPO1.DataSetName = "dsPO"
        Me.DsPO1.Locale = New System.Globalization.CultureInfo("en-US")
        Me.DsPO1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DataGridTableStyle1
        '
        Me.DataGridTableStyle1.AlternatingBackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.DataGridTableStyle1.BackColor = System.Drawing.Color.White
        Me.DataGridTableStyle1.DataGrid = Me.DataGrid1
        Me.DataGridTableStyle1.ForeColor = System.Drawing.Color.DarkSlateBlue
        Me.DataGridTableStyle1.GridColumnStyles.AddRange(New System.Windows.Forms.DataGridColumnStyle() {Me.DataGridTextBoxColumn2, Me.DataGridTextBoxColumn3, Me.DataGridTextBoxColumn6, Me.DataGridTextBoxColumn7, Me.DataGridTextBoxColumn5, Me.DataGridTextBoxColumn4, Me.DataGridTextBoxColumn8, Me.DataGridTextBoxColumn1})
        Me.DataGridTableStyle1.GridLineColor = System.Drawing.Color.FloralWhite
        Me.DataGridTableStyle1.HeaderBackColor = System.Drawing.Color.DarkKhaki
        Me.DataGridTableStyle1.HeaderForeColor = System.Drawing.Color.Black
        Me.DataGridTableStyle1.MappingName = "EDITPo"
        Me.DataGridTableStyle1.SelectionBackColor = System.Drawing.Color.DarkSlateBlue
        Me.DataGridTableStyle1.SelectionForeColor = System.Drawing.Color.White
        '
        'DataGridTextBoxColumn2
        '
        Me.DataGridTextBoxColumn2.Alignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.DataGridTextBoxColumn2.Format = ""
        Me.DataGridTextBoxColumn2.FormatInfo = Nothing
        Me.DataGridTextBoxColumn2.HeaderText = "PLU"
        Me.DataGridTextBoxColumn2.MappingName = "PRDCD"
        Me.DataGridTextBoxColumn2.NullText = ""
        Me.DataGridTextBoxColumn2.ReadOnly = True
        Me.DataGridTextBoxColumn2.Width = 50
        '
        'DataGridTextBoxColumn3
        '
        Me.DataGridTextBoxColumn3.Alignment = System.Windows.Forms.HorizontalAlignment.Right
        Me.DataGridTextBoxColumn3.Format = ""
        Me.DataGridTextBoxColumn3.FormatInfo = Nothing
        Me.DataGridTextBoxColumn3.HeaderText = "Frac"
        Me.DataGridTextBoxColumn3.MappingName = "FRAC"
        Me.DataGridTextBoxColumn3.NullText = ""
        Me.DataGridTextBoxColumn3.Width = 50
        '
        'DataGridTextBoxColumn6
        '
        Me.DataGridTextBoxColumn6.Alignment = System.Windows.Forms.HorizontalAlignment.Right
        Me.DataGridTextBoxColumn6.Format = "#,##0.##"
        Me.DataGridTextBoxColumn6.FormatInfo = Nothing
        Me.DataGridTextBoxColumn6.HeaderText = "Nilai"
        Me.DataGridTextBoxColumn6.MappingName = "PO_GROSS"
        Me.DataGridTextBoxColumn6.NullText = ""
        Me.DataGridTextBoxColumn6.ReadOnly = True
        Me.DataGridTextBoxColumn6.Width = 75
        '
        'DataGridTextBoxColumn7
        '
        Me.DataGridTextBoxColumn7.Alignment = System.Windows.Forms.HorizontalAlignment.Right
        Me.DataGridTextBoxColumn7.Format = "#,##0.##"
        Me.DataGridTextBoxColumn7.FormatInfo = Nothing
        Me.DataGridTextBoxColumn7.HeaderText = "PPn"
        Me.DataGridTextBoxColumn7.MappingName = "PO_PPN"
        Me.DataGridTextBoxColumn7.NullText = ""
        Me.DataGridTextBoxColumn7.ReadOnly = True
        Me.DataGridTextBoxColumn7.Width = 75
        '
        'DataGridTextBoxColumn5
        '
        Me.DataGridTextBoxColumn5.Alignment = System.Windows.Forms.HorizontalAlignment.Right
        Me.DataGridTextBoxColumn5.Format = "#,##0.##"
        Me.DataGridTextBoxColumn5.FormatInfo = Nothing
        Me.DataGridTextBoxColumn5.HeaderText = "Tot. Disc"
        Me.DataGridTextBoxColumn5.MappingName = "PO_DISC"
        Me.DataGridTextBoxColumn5.NullText = ""
        Me.DataGridTextBoxColumn5.ReadOnly = True
        Me.DataGridTextBoxColumn5.Width = 75
        '
        'DataGridTextBoxColumn4
        '
        Me.DataGridTextBoxColumn4.Alignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.DataGridTextBoxColumn4.Format = "#,##0"
        Me.DataGridTextBoxColumn4.FormatInfo = Nothing
        Me.DataGridTextBoxColumn4.HeaderText = "Unit"
        Me.DataGridTextBoxColumn4.MappingName = "UNIT"
        Me.DataGridTextBoxColumn4.NullText = ""
        Me.DataGridTextBoxColumn4.ReadOnly = True
        Me.DataGridTextBoxColumn4.Width = 50
        '
        'DataGridTextBoxColumn8
        '
        Me.DataGridTextBoxColumn8.Alignment = System.Windows.Forms.HorizontalAlignment.Right
        Me.DataGridTextBoxColumn8.Format = "#,##0"
        Me.DataGridTextBoxColumn8.FormatInfo = Nothing
        Me.DataGridTextBoxColumn8.HeaderText = "Bonus"
        Me.DataGridTextBoxColumn8.MappingName = "QTYBONUS"
        Me.DataGridTextBoxColumn8.NullText = "0"
        Me.DataGridTextBoxColumn8.Width = 50
        '
        'DataGridTextBoxColumn1
        '
        Me.DataGridTextBoxColumn1.Format = ""
        Me.DataGridTextBoxColumn1.FormatInfo = Nothing
        Me.DataGridTextBoxColumn1.HeaderText = "Deskripsi"
        Me.DataGridTextBoxColumn1.MappingName = "DESKRIPSI"
        Me.DataGridTextBoxColumn1.NullText = ""
        Me.DataGridTextBoxColumn1.ReadOnly = True
        Me.DataGridTextBoxColumn1.Width = 200
        '
        'btnSimpan
        '
        Me.btnSimpan.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSimpan.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.btnSimpan.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnSimpan.Location = New System.Drawing.Point(474, 176)
        Me.btnSimpan.Name = "btnSimpan"
        Me.btnSimpan.Size = New System.Drawing.Size(75, 23)
        Me.btnSimpan.TabIndex = 1
        Me.btnSimpan.Text = "&Simpan"
        '
        'btnBatal
        '
        Me.btnBatal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnBatal.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnBatal.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnBatal.Location = New System.Drawing.Point(586, 176)
        Me.btnBatal.Name = "btnBatal"
        Me.btnBatal.Size = New System.Drawing.Size(75, 23)
        Me.btnBatal.TabIndex = 2
        Me.btnBatal.Text = "&Batal"
        '
        'frmEditPO
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.CancelButton = Me.btnBatal
        Me.ClientSize = New System.Drawing.Size(674, 205)
        Me.Controls.Add(Me.btnBatal)
        Me.Controls.Add(Me.btnSimpan)
        Me.Controls.Add(Me.DataGrid1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmEditPO"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Edit PO"
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsPO1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region
    Public sNoPo As String
    Public nQTY As Integer
    Public nItem As Integer
    Public nGROSS As Double
    Public nPPN As Double
    Public nIdDaftarPO As Integer

    Private _faktur As String
    Property FakturMBread() As String
        Get
            Return _faktur
        End Get
        Set(ByVal value As String)
            _faktur = value
        End Set
    End Property

    Private Sub HandleRow(ByVal sender As Object, ByVal e As System.Data.DataRowChangeEventArgs)
        If e.Action = DataRowAction.Add Then
            Err.Raise(99, "EditPO", "Tidak Bisa Tambah Data")
        End If
    End Sub
    Private Sub HandleColom(ByVal sender As Object, ByVal e As System.Data.DataColumnChangeEventArgs)
        Debug.WriteLine(e.Column.ColumnName)
        'If e.Column.ColumnName = "FRACNYA" Then

        '    Dim rw As DataRow
        '    rw = e.Row

        '    If (e.ProposedValue * rw("FRAC") > rw("QTYPO")) Or (rw("QTYPO") = 0) Then
        '        If (rw("QTYPO") = 0) Then
        '            MessageBox.Show("Qty PO = 0. Item tidak bisa diedit.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
        '        Else
        '            MessageBox.Show("Qty beli tidak boleh > dari pada qty PO (" & rw("QTYPO") / rw("FRAC") & ")", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
        '        End If
        '        e.ProposedValue = rw("FRACNYA")
        '        Exit Sub
        '    End If

        '    ':dc_trnbpb_dtl_t.nilai    := (nvl(:dc_trnbpb_dtl_t.frac, 0) * x_frac)*nvl(:dc_trnbpb_dtl_t.harga, 0);
        '    rw("QTYNYA") = e.ProposedValue * rw("FRAC") * rw("HARGA")

        '    rw("PPNBMNYA") = (((e.ProposedValue * rw("FRAC"))) / rw("QTYPO")) * rw("PPNBM")
        '    rw("DISCR1nya") = (((e.ProposedValue * rw("FRAC"))) / rw("QTYPO")) * rw("DISC1")
        '    rw("DISCR2nya") = (((e.ProposedValue * rw("FRAC"))) / rw("QTYPO")) * rw("DISC2")
        '    rw("DISCR3nya") = (((e.ProposedValue * rw("FRAC"))) / rw("QTYPO")) * rw("DISC3")
        '    rw("DISC4CRnya") = (((e.ProposedValue * rw("FRAC"))) / rw("QTYPO")) * rw("DISC4")
        '    rw("DISC4RRnya") = (((e.ProposedValue * rw("FRAC"))) / rw("QTYPO")) * rw("DISC5")
        '    rw("DISC4JRnya") = (((e.ProposedValue * rw("FRAC"))) / rw("QTYPO")) * rw("DISC6")
        '    rw("BONUSNYA") = _
        '        rw("DISCR1nya") + rw("DISCR2nya") + rw("DISCR3nya") + _
        '        rw("DISC4CRnya") + rw("DISC4RRnya") + rw("DISC4JRnya")

        '    If rw("PPNPO") > 0 Then
        '        'rw("PPNRP") = ((e.ProposedValue * rw("FRAC"))) * rw("HARGA") - rw("BONUSNYA")

        '        'rw("PPNRP") = (((e.ProposedValue * rw("FRAC"))) / rw("QTYPO")) * rw("PPNPO")
        '        rw("PPNRPNYA") = (((e.ProposedValue * rw("FRAC"))) / rw("QTYPO")) * rw("PPNPO")
        '    End If


        '    'frmDaftarPO.txtPO_QTY.Text = Format(nQTY, "#,##0")
        '    'frmDaftarPO.txtPO_GROSS.Text = Format(nGross, "#,##.##############")
        '    'frmDaftarPO.txtPO_PPN.Text = Format(nPPN, "#,##.##############")
        '    'frmDaftarPO.txtPO_Total.Text = Format(nGross + nPPN, "#,##.##############")
        'End If

        If e.Column.ColumnName = "FRAC" Then

            Dim rw As DataRow
            rw = e.Row

            If (e.ProposedValue) > rw("FRACAsal") Or (rw("FRACAsal") = 0) Then
                If (rw("FRACAsal") = 0) Then
                    MessageBox.Show("Qty PO = 0. Item tidak bisa diedit.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Else
                    MessageBox.Show("Qty beli tidak boleh > dari pada qty PO (" & rw("FRACAsal") & ")", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
                e.ProposedValue = rw("FRACAsal")
                Exit Sub
            End If

            rw("PO_GROSS") = e.ProposedValue * rw("SATUAN") * rw("PODTL_PRICE") 'PODTL_QTYB*PODTL_ISI_SATB*PODTL_PRICE
            If rw("PO_PPNAsal") > 0 Then
                rw("PO_PPN") = (e.ProposedValue * rw("SATUAN") * rw("PODTL_PRICE") - (e.ProposedValue * rw("SATUAN") / rw("PEMBAGIDISC") * rw("PO_DISCAsal"))) * 0.1
            End If
            rw("PO_DISC") = ((e.ProposedValue * rw("SATUAN") / rw("PEMBAGIDISC") * rw("PO_DISCAsal")))

            rw("PPN_BOTOL") = ((e.ProposedValue * rw("SATUAN") / rw("PEMBAGIDISC") * rw("PPN_BOTOLAsal")))
            rw("QTYBONUS") = ((e.ProposedValue * rw("SATUAN") / rw("PEMBAGIDISC") * rw("QTYBONUSAsal")))

            'frmDaftarPO.txtPO_QTY.Text = Format(nQTY, "#,##0")
            'frmDaftarPO.txtPO_GROSS.Text = Format(nGross, "#,##.##############")
            'frmDaftarPO.txtPO_PPN.Text = Format(nPPN, "#,##.##############")
            'frmDaftarPO.txtPO_Total.Text = Format(nGross + nPPN, "#,##.##############")
        End If
    End Sub

    Private Sub frmEditPO_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        AddHandler DsPO1.EditPO.ColumnChanging, AddressOf HandleColom


        Dim SQL As String
        'SQL = "select * from jlr_get_detail_daftarpo_v where po_no_po='" & sNoPo & "' "
        'SQL &= "order by prdcd"

        'SQL &= "FROM DC_PO_T P, DC_PODTL_T D, (SELECT * FROM DC_BARANG_DC_V WHERE MBR_FK_DCID=" & cDC_ID & ") BR,"
        'SQL &= "where podisc_fk_no_po='" & sNoPo & "' "

        SQL = " SELECT "
        SQL &= "PO.PO_NO_PO "
        SQL &= ",PODTL_PLU as PRDCD "
        SQL &= ",BRG.MBR_FULL_NAMA AS DESKRIPSI "
        SQL &= ",IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG) as BolehBPB "
        SQL &= ",IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*PODTL_QTYB as FracAsal "
        SQL &= ",IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*PODTL_QTYB as Frac "
        SQL &= ",PODTL_ISI_SATB AS Satuan "
        SQL &= ",0 AS Unit "
        SQL &= ",PODTL_PRICE "
        SQL &= ",IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*PODTL_QTYB"
        SQL &= "	*PODTL_ISI_SATB*PODTL_PRICE as PO_GROSS "
        SQL &= ",IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*PODTL_PPN as PO_PPNAsal "
        SQL &= ",CASE WHEN PODTL_PPN > 0 THEN (IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)"
        SQL &= "	*((PODTL_QTYB*PODTL_ISI_SATB*PODTL_PRICE"
        SQL &= "	-((PODTL_QTYB*PODTL_ISI_SATB)"
        SQL &= "	/((PODTL_QTYB*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
        SQL &= "	*NVL(TotDisc,0)))*.1)) ELSE 0 END as PO_PPN "
        SQL &= ",(PODTL_QTYB*PODTL_ISI_SATB)+PODTL_FRAC_QTYB as PembagiDisc "
        SQL &= ",IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*NVL(TotDisc,0) AS PO_DISCAsal "
        SQL &= ",IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*((PODTL_QTYB*PODTL_ISI_SATB)"
        SQL &= "	/((PODTL_QTYB*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
        SQL &= "	*NVL(TotDisc,0)) AS PO_DISC "
        SQL &= ",IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*NVL(PODTL_PPN_BTL,0) AS PPN_BOTOLAsal "
        SQL &= ",IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*((PODTL_QTYB*PODTL_ISI_SATB)"
        SQL &= "	/((PODTL_QTYB*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
        SQL &= "	*NVL(PODTL_PPN_BTL,0)) AS PPN_BOTOL "
        SQL &= ",IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*NVL(BNS.POBNS_QTY,0) AS QTYBONUSAsal "
        SQL &= ",IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*((PODTL_QTYB*PODTL_ISI_SATB)"
        SQL &= "	/((PODTL_QTYB*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
        SQL &= "	*NVL(BNS.POBNS_QTY,0)) AS QTYBONUS "
        SQL &= "FROM DC_PO_T PO "
        SQL &= "LEFT JOIN DC_PODTL_T DT ON PO.PO_NO_PO = DT.PODTL_FK_NO_PO "
        SQL &= "LEFT JOIN ("
        SQL &= "	SELECT MBR_FK_PLUID,(MBR_TAG) AS MBR_TAG,"
        SQL &= "		(MBR_FULL_NAMA) as MBR_FULL_NAMA "
        SQL &= "	FROM DC_BARANG_DC_V WHERE TBL_DC_KODE='" & cDC_KODE & "') BRG "
        SQL &= "	ON DT.PODTL_PLUMD=BRG.MBR_FK_PLUID "
        SQL &= "LEFT JOIN ("
        SQL &= "	SELECT podisc_fk_no_po,PODISC_FK_PLU, "
        SQL &= "		SUM(NVL(podisc_nilai,0)) AS TotDisc "
        SQL &= "	FROM DC_PODISC_T "
        SQL &= "	GROUP BY podisc_fk_no_po,PODISC_FK_PLU) S "
        SQL &= "	ON PO.PO_NO_PO=S.podisc_fk_no_po AND DT.PODTL_PLUMD=S.PODISC_FK_PLU "
        SQL &= "LEFT JOIN ("
        SQL &= "	SELECT pobns_fk_no_po,POBNS_FK_PLU,nvl(POBNS_QTY,0) as POBNS_QTY "
        SQL &= "	from DC_POBNS_T) BNS ON  "
        SQL &= "	PO.PO_NO_PO=BNS.pobns_fk_no_po AND DT.PODTL_PLUMD=BNS.POBNS_FK_PLU "
        SQL &= "WHERE (PODTL_RECID IS NULL OR PODTL_RECID='') "
        SQL &= "AND PO_NO_PO='" & sNoPo & "'"

        
        Dim Scon As New OleDb.OleDbConnection(ConStrORA)
        Dim sdap As New OleDb.OleDbDataAdapter(SQL, Scon)
        Scon.Open()
        DsPO1.EditPO.Clear()
        sdap.Fill(DsPO1.EditPO)
        Scon.Close()

        'AddHandler DsPO1.EditPO.ColumnChanged, AddressOf HandleRow
    End Sub

    Public Function CekItemPO() As Boolean
        CekItemPO = True

        'Cek Status PO
        Dim Recid As String, Expired As String, ErrMsg As String = ""
        Dim Scon As New OleDb.OleDbConnection(ConStrORA)
        Dim Scom As New OleDb.OleDbCommand("", Scon)
        Dim Sdar As OleDb.OleDbDataReader

        Scon.Open()
        Scom.CommandText = "SELECT PO_RECID,PO_TGL_PO,PO_UMUR From DC_PO_T where PO_NO_PO='" & sNoPo & "'"
        Sdar = Scom.ExecuteReader
        If Sdar.Read Then
            Recid = Sdar("PO_RECID") & ""
            Expired = (Sdar("PO_TGL_PO") + IIf(Sdar("PO_UMUR") <= 0, 7, Sdar("PO_UMUR"))) < Now.Date
            Scon.Close()
            ' C               R                      H           A                        1                 2
            '"PO Di-Closing","PO Sudah ada BPB-nya","PO Hangus","PO Sedang dibuat BPB-nya,"Item PO dihapus","PO Revisi""
            Select Case Recid
                Case "C"
                    ErrMsg = "PO Di-Closing"
                Case "R"
                    ErrMsg = "PO Sudah ada BPB-nya"
                Case "H"
                    ErrMsg = "PO Hangus"
                Case "A"
                    ErrMsg = "PO Sedang dibuat BPB-nya"
                Case "1"
                    ErrMsg = "Item PO dihapus"
                Case "2"
                    ErrMsg = "PO Revisi"
            End Select
            If ErrMsg <> "" Then
                MsgBox("Tidak Bisa Edit, " & ErrMsg, vbCritical)
                GoTo keluar
            End If

            ''Todo: Lepas Kadaluarsa
            'If Expired = "True" Then
            '    MsgBox("PO Sudah Kadaluarsa", vbCritical)
            '    GoTo keluar
            'End If
            Exit Function
        End If
keluar:
        CekItemPO = False
    End Function
    Private Function Cek_EditPO_MBread(ByVal ds As DataTable) As Boolean
        Dim Scon As New OleDb.OleDbConnection(ConStrORA)
        Dim Scom As New OleDb.OleDbCommand("", Scon)
        Dim Sdap As New OleDb.OleDbDataAdapter("", Scon)
        Dim dt As New DataTable

        Dim Sql As String

        Dim lOke As Boolean = True

        Try
            Scon.Open()
            Sql = " SELECT   a.plu AS PLU, SUM (a.qty) AS QTY "
            Sql &= "FROM alokasi_tampung a "
            Sql &= "WHERE (a.no_sj = '" & _faktur & "') "
            Sql &= "GROUP BY a.no_sj, a.tgl_sj, a.plu "
            Sql &= "order by plu "
            Sdap.SelectCommand.CommandText = Sql
            Sdap.Fill(dt)
            If dt.Rows.Count <> ds.Rows.Count Then
                lOke = False
                Exit Try
            End If

            For i As Integer = 0 To ds.Rows.Count - 1
                If (dt.Rows(i)("PLU") <> ds.Rows(i)("PRDCDNYA")) Or (dt.Rows(i)("QTY") <> ds.Rows(i)("FRACNYA")) Then
                    lOke = False
                    Exit Try
                End If
            Next

        Catch ex As Exception
            IDM.Fungsi.ShowError("Error Cek Edit PO Mr. Bread", ex)
        Finally
            Scon.Close()
        End Try

        Return lOke
    End Function
    Private lNoClose As Boolean = False
    Public IsMrBread As Boolean
    Private Sub frmEditPO_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        e.Cancel = lNoClose
    End Sub
    Private Sub btnSimpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimpan.Click

        'btnSimpan.DialogResult = Windows.Forms.DialogResult.None
        If IsMrBread Then
            If Not Cek_EditPO_MBread(DsPO1.EditPO) Then
                MessageBox.Show("Total PO <> Total Faktur.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                lNoClose = True
                Exit Sub
            Else
                lNoClose = False
            End If
        End If
        

        'btnSimpan.DialogResult = Windows.Forms.DialogResult.OK
        Dim X As Double

        nItem = 0
        nQTY = 0
        nGROSS = 0
        nPPN = 0
        For I As Integer = 0 To DsPO1.EditPO.Rows.Count - 1
            X = (DsPO1.EditPO.Rows(I)("FRAC") * DsPO1.EditPO.Rows(I)("SATUAN")) * DsPO1.EditPO.Rows(I)("PODTL_PRICE")
            If X > 0 Then
                nItem += 1
                nQTY = nQTY + DsPO1.EditPO.Rows(I)("FRAC") * DsPO1.EditPO.Rows(I)("SATUAN")
                nGROSS = nGROSS + X - DsPO1.EditPO.Rows(I)("PO_DISC")

                'Ditambah PPN BOTOL
                nGROSS += DsPO1.EditPO.Rows(I)("PPN_BOTOL")

                nPPN = nPPN + DsPO1.EditPO.Rows(I)("PO_PPN")
                'nPPN += nGROSS * 0.1
            End If

            'Hitung Ulang QTYBONUS & update ke TRNBPB_DTL
            If DsPO1.EditPO.Rows(I)("QTYBONUS") > 0 Or DsPO1.EditPO.Rows(I)("PPN_BOTOL") > 0 Then
                Dim Scon As New OleDb.OleDbConnection(ConStrORA)
                Dim Scom As New OleDb.OleDbCommand("", Scon)
                Dim nHdr As Integer

                Scon.Open()
                Scom.CommandText = "Select HDR_ID FROM DC_TRNBPB_HDR_T where ID_DAFTARPO=" & nIdDaftarPO
                nHdr = "0" & Scom.ExecuteScalar

                Scom.CommandText = "UPDATE DC_TRNBPB_DTL_T SET "
                Scom.CommandText &= "BONUS=0" & DsPO1.EditPO.Rows(I)("QTYBONUS") & " "
                Scom.CommandText &= ",BOTOL=0" & DsPO1.EditPO.Rows(I)("PPN_BOTOL") & " "
                Scom.CommandText &= "WHERE HDR_FK_ID=" & nHdr & " AND PLU_KODE='" & DsPO1.EditPO.Rows(I)("PRDCD") & "'"
                Scom.CommandText &= ""
                Scom.ExecuteNonQuery()
                Scon.Close()
            End If
        Next
        Me.Close()

    End Sub

    Private Sub btnBatal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBatal.Click
        lNoClose = False
    End Sub
End Class

