Imports IDM.Fungsi
'Imports System.Data.OracleClient

Module ModJalur
    Public cDC_ID As String
    Public cDC_KODE As String
    Public cDC_NAMA As String

    Public cGUDANG_ID As String
    Public cGUDANG_KODE As String
    Public cGUDANG_NAMA As String

    Public cLOKASI_KODE As String
    Public cLOKASI_TYPE As String

    Public ConStrORA As String
    Public Sub Main(ByVal CmdArgs() As String)
        If CmdArgs.Length > 0 Then
        End If

        'ConStrORA = "user id=DCSIM;data source=SIMULASIA;password=DCSIM"
        'Dim Scon As New OracleConnection(ConStrORA)
        'Dim Scom As New OracleCommand("", Scon)
        'Dim Sdar As OracleDataReader

        Dim cUsrOra As String = GetSetting("Indomaret\AntrianDC", "Setup", "U")
        Dim cPassOra As String = GetSetting("Indomaret\AntrianDC", "Setup", "P")
        Dim cTnsOra As String = GetSetting("Indomaret\AntrianDC", "Setup", "S")

        If cTnsOra = "" Then
            MessageBox.Show("Setting Server Oracle Kurang.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            SaveSetting("Indomaret\AntrianDC", "Setup", "U", "DCSIM")
            SaveSetting("Indomaret\AntrianDC", "Setup", "P", "DCSIM")
            SaveSetting("Indomaret\AntrianDC", "Setup", "S", "SIMULASIA")
            Exit Sub
        End If

        ConStrORA = "Provider=MSDAORA.1;User ID=" & cUsrOra & ";password=" & cPassOra & ";Data Source=" & cTnsOra & ""
        Dim Scon As New OleDb.OleDbConnection(ConStrORA)
        Dim Scom As New OleDb.OleDbCommand("", Scon)
        Dim Sdar As OleDb.OleDbDataReader

        Dim Sql As String

        'If GetSetting("Indomaret\JalurDC ORA", "Setup", "OraData") <> "1" Then
        '    Call SetUpDbOra()
        '    Call SaveSetting("Indomaret\JalurDC ORA", "Setup", "OraData", "1")
        'End If
        Dim f As New FormLogin
        f.Text = "Login - [" & Application.ProductName & " v" & Application.ProductVersion & "]"
        Dim lcount As Integer = 0
        Try
            Scon.Open()

Pass:
            If f.ShowDialog() <> DialogResult.OK Then
                Exit Sub
            End If

            Dim cUser As String, cPass As String
            cUser = f.txtUser.Text
            cPass = f.txtPass.Text
            'Todo: Hilangkan Password
            'If cUser = "" Then
            '    cUser = "BPO1"
            '    cPass = "7670"
            'End If
            cUser = cUser.ToUpper
            cPass = cPass.ToUpper
            Scom.CommandText = "Select Count(*) as JUM from DC_USER_T " & _
                "Where UPPER(USER_NAME)='" & cUser & "' AND UPPER(USER_PASSWORD)='" & cPass & "'"
            If Scom.ExecuteScalar = 0 Then
                MsgBox("NAMA USER ATAU PASSWORD SALAH.", vbCritical)
                If lcount = 2 Then
                    Exit Sub
                End If
                lcount += 1
                GoTo Pass
            End If
            f.Dispose()

            'Cek HAK
            Sql = " SELECT U.USER_NAME,DC.TBL_DCID,DC.TBL_DC_KODE,DC.TBL_DC_NAMA,"
            Sql &= "U.USER_FK_TBL_DEPOID,G.TBL_GUDANG_KODE,"
            Sql &= "G.TBL_GUDANG_NAMA,U.USER_FK_TBL_LOKASIID,L.TBL_LOKASI_KODE,"
            Sql &= "L.TBL_LOKASIID,L.TBL_LOKASI_NAMA,L.TBL_LOKASI_TYPE "
            Sql &= "from DC_USER_T U "
            Sql &= "LEFT JOIN DC_TABEL_DC_T DC ON U.USER_FK_TBL_DCID = DC.TBL_DCID "
            Sql &= "LEFT JOIN DC_TABEL_GUDANG_T G ON U.USER_FK_TBL_DEPOID=G.TBL_GUDANGID "
            Sql &= "LEFT JOIN DC_TABEL_LOKASI_T L ON U.USER_FK_TBL_LOKASIID=L.TBL_LOKASIID "
            Sql &= "WHERE 1=1 "
            Sql &= "AND USER_NAME='" & cUser & "' "
            'Sql &= "AND L.TBL_LOKASI_TYPE='BAIK' "
            Scom.CommandText = Sql
            Sdar = Scom.ExecuteReader

            Sdar.Read()
            cDC_ID = "" & Sdar("TBL_DCID")
            cDC_KODE = "" & Sdar("TBL_DC_KODE")
            cDC_NAMA = "" & Sdar("TBL_DC_NAMA")

            cGUDANG_ID = "" & Sdar("USER_FK_TBL_DEPOID")
            cGUDANG_KODE = "" & Sdar("TBL_GUDANG_KODE")
            cGUDANG_NAMA = "" & Sdar("TBL_GUDANG_NAMA")

            cLOKASI_KODE = "" & Sdar("TBL_LOKASIID")
            cLOKASI_TYPE = "" & Sdar("TBL_LOKASI_TYPE")
            Sdar.Close()

            'Cek DC
            'Scom.CommandText = "SELECT USER_FK_TBL_DCID from DC_USER_T " & _
            '    "Where USER_NAME='" & cUser & "' AND USER_PASSWORD='" & cPass & "'"
            'cDC_ID = "" & Scom.ExecuteScalar
            If cDC_ID = "" Then
                'Pilih DC Sendiri
                Dim fp As New frmPilih
                fp.Text = "PILIH KODE DC - " & Application.ProductName

                Scom.CommandText = "Select TBL_DCID,TBL_DC_KODE,TBL_DC_NAMA FROM DC_TABEL_DC_T ORDER BY TBL_DC_KODE"
                Sdar = Scom.ExecuteReader
                Dim ls As New Collection

                fp.ListBox1.Items.Clear()
                Do While Sdar.Read
                    'ls.Add(Sdar("TBL_DC_KODE") & " - " & Sdar("TBL_DC_NAMA"), Sdar("TBL_DCID"))
                    ls.Add(Sdar("TBL_DCID"))

                    fp.ListBox1.Items.Add(Sdar("TBL_DC_KODE") & " - " & Sdar("TBL_DC_NAMA"))
                    'fp.ListBox1.Items.Add(ls)
                Loop
                Sdar.Close()
                fp.ListBox1.SelectedIndex = 0

                If fp.ShowDialog <> DialogResult.OK Then
                    Exit Sub
                End If
                cDC_ID = ls(fp.ListBox1.SelectedIndex + 1)
                cDC_KODE = fp.ListBox1.SelectedItem

                cDC_NAMA = cDC_KODE.Substring(cDC_KODE.IndexOf("-") + 2)
                cDC_KODE = cDC_KODE.Substring(0, cDC_KODE.IndexOf("-") - 1)

                fp.Dispose()
                ls = Nothing

            Else
                ''PUNYA DC
                'Scom.CommandText = "Select TBL_DCID,TBL_DC_KODE,TBL_DC_NAMA FROM DC_TABEL_DC_T " & _
                '    "WHERE TBL_DC_ID='" & cDC_ID & "'"
                'Sdar = Scom.ExecuteReader
                'Do While Sdar.Read
                '    cDC_KODE = Sdar("TBL_DC_KODE")
                '    cDC_NAMA = Sdar("TBL_DC_NAMA")
                'Loop
                'Sdar.Close()
            End If

            'Cek DEPO
            If cGUDANG_KODE = "" Then
                'Pilih DC Sendiri
                Dim fp As New frmPilih
                fp.Text = "PILIH DEPO - " & Application.ProductName

                Scom.CommandText = "Select TBL_GUDANGID,TBL_GUDANG_KODE,TBL_GUDANG_NAMA " & _
                    "FROM DC_TABEL_GUDANG_T " & _
                    "WHERE TBL_FK_DCID='" & cDC_ID & "' ORDER BY TBL_GUDANG_KODE"
                Sdar = Scom.ExecuteReader
                Dim ls As New Collection

                fp.ListBox1.Items.Clear()
                Do While Sdar.Read
                    'ls.Add(Sdar("TBL_DC_KODE") & " - " & Sdar("TBL_DC_NAMA"), Sdar("TBL_DCID"))
                    ls.Add(Sdar("TBL_GUDANGID"))

                    fp.ListBox1.Items.Add(Sdar("TBL_GUDANG_KODE") & " - " & Sdar("TBL_GUDANG_NAMA"))
                    'fp.ListBox1.Items.Add(ls)
                Loop
                Sdar.Close()
                Try
                    fp.ListBox1.SelectedIndex = 0
                Catch
                    MessageBox.Show("Tidak Ada Data Gudang.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End Try


                If fp.ShowDialog <> DialogResult.OK Then
                    Exit Sub
                End If
                cGUDANG_ID = ls(fp.ListBox1.SelectedIndex + 1)
                cGUDANG_KODE = fp.ListBox1.SelectedItem

                cGUDANG_NAMA = cGUDANG_KODE.Substring(cGUDANG_KODE.IndexOf("-") + 2)
                cGUDANG_KODE = cGUDANG_KODE.Substring(0, cGUDANG_KODE.IndexOf("-") - 1)

                fp.Dispose()
                ls = Nothing

                'Cek Lokasinya
                Scom.CommandText = "SELECT TBL_LOKASIID,TBL_LOKASI_TYPE FROM DC_TABEL_LOKASI_T " & _
                    "WHERE TBL_FK_GUDANGID='" & cGUDANG_ID & "' " & _
                    "AND TBL_LOKASI_TYPE='BAIK'"
                Sdar = Scom.ExecuteReader
                If Sdar.Read Then
                    cLOKASI_KODE = "" & Sdar("TBL_LOKASIID")
                    cLOKASI_TYPE = "" & Sdar("TBL_LOKASI_TYPE")
                End If
                Sdar.Close()
            End If


            'Cek Lokasi
            If cLOKASI_TYPE <> "BAIK" Then
                MsgBox("User Bukan Untuk Lokasi Barang Baik.", vbCritical)

                Exit Sub
            End If


            'Cara Lama
            'Sql = "SELECT COUNT(*) FROM "
            'Sql &= "DC_USER_V U,DC_TABEL_DC_T DC,DC_TABEL_GUDANG_T G,DC_TABEL_LOKASI_T L "
            'Sql &= "Where U.USER_FK_TBL_DCID = DC.TBL_DCID "
            'Sql &= "AND U.USER_FK_TBL_DEPOID=G.TBL_GUDANGID "
            'Sql &= "AND U.USER_FK_TBL_LOKASIID=L.TBL_LOKASIID "

            'Sql &= "AND USER_NAME='" & cUser & "' "
            'Sql &= "AND L.TBL_LOKASI_TYPE='BAIK' "
            'Scom.CommandText = Sql
            'If Scom.ExecuteScalar = 0 Then
            '    MsgBox("User Bukan Untuk Lokasi Barang Baik.", vbCritical)
            '    Exit Sub
            'End If

            'Sql = "select U.USER_NAME,DC.TBL_DCID,DC.TBL_DC_KODE,DC.TBL_DC_NAMA,"
            'Sql &= "U.USER_FK_TBL_DEPOID,G.TBL_GUDANG_KODE,G.TBL_GUDANG_NAMA,U.USER_FK_TBL_LOKASIID,"
            'Sql &= "L.TBL_LOKASI_KODE,L.TBL_LOKASIID,L.TBL_LOKASI_NAMA from "
            'Sql &= "DC_USER_V U,DC_TABEL_DC_T DC,DC_TABEL_GUDANG_T G,DC_TABEL_LOKASI_T L "
            'Sql &= "Where U.USER_FK_TBL_DCID = DC.TBL_DCID "
            'Sql &= "AND U.USER_FK_TBL_DEPOID=G.TBL_GUDANGID "
            'Sql &= "AND U.USER_FK_TBL_LOKASIID=L.TBL_LOKASIID "

            'Sql &= "AND USER_NAME='" & cUser & "' "
            'Sql &= "AND L.TBL_LOKASI_TYPE='BAIK' "
            'Scom.CommandText = Sql
            'Sdar = Scom.ExecuteReader

            'Sdar.Read()
            'cDC_KODE = Sdar("TBL_DC_KODE")
            'cDC_ID = Sdar("TBL_DCID")
            'cDC_NAMA = Sdar("TBL_DC_NAMA")
            'cGUDANG_KODE = Sdar("TBL_GUDANG_KODE")
            'cLOKASI_KODE = Sdar("TBL_LOKASIID")
            'Sdar.Close()

            'Scom.CommandText = "Select TANGGAL From DC_JLR_OPTION_T " & _
            '    "WHERE DC_ID=" & cDC_ID & " AND OPT='LST'"

            Scom.CommandText = "Select COUNT(*) From DC_JLR_Setting_T WHERE DC_ID=" & cDC_ID
            If Scom.ExecuteScalar = 0 Then
                Scom.CommandText = "INSERT INTO DC_JLR_SETTING_T(DC_ID,NEXTNOURUT,LASTDATE) VALUES(" & cDC_ID & ",1,TRUNC(SYSDATE))"
                Scom.ExecuteNonQuery()
                GoTo UPD
            End If

            Scom.CommandText = "Select Trunc(LastDate) as LastDate From DC_JLR_Setting_T WHERE DC_ID=" & cDC_ID
            If Scom.ExecuteScalar <> Now.Date Then
UPD:            Sql = "UPDATE DC_JLR_Antrian_T Set Recid='O',Supplier=NULL,NoAntrian=Null Where DC_ID=" & cDC_ID & ""
                Scom.CommandText = Sql
                Scom.ExecuteNonQuery()

                Sql = "UPDATE DC_JLR_Setting_T Set NextNoUrut=1,LastDate=Trunc(sysdate) Where DC_ID=" & cDC_ID & ""
                Scom.CommandText = Sql
                Scom.ExecuteNonQuery()

                Sql = "Delete from DC_JLR_TempAntrian_T Where DC_ID=" & cDC_ID & ""
                Scom.CommandText = Sql
                Scom.ExecuteNonQuery()
            End If

            If Scom.ExecuteScalar > Now.Date Then
                MessageBox.Show("Program tidak bisa Mundur Tanggal", Application.ProductName, MessageBoxButtons.OK)
                Exit Try
            End If

            Dim fu As New frmUtama
            fu.lblUser.Text = cUser
            fu.lblDC.Text = cDC_KODE & " - " & cDC_NAMA
            fu.lblGudang.Text = cGUDANG_NAMA
            fu.lblLok.Text = cLOKASI_TYPE
            'Dim fu As New DataForm1


            If fu.ShowDialog() = DialogResult.OK Then

            End If

        Catch ex As Exception
            ShowError("Error Initial Data.", ex)
        Finally
            Scon.Close()
        End Try


    End Sub

    'Private Function SetUpDbOra() As Boolean
    '    Dim s As String
    '    Dim Scon As New OleDb.OleDbConnection(ConStrORA)
    '    Dim Scom As New OleDb.OleDbCommand("", Scon)

    '    Scon.Open()
    '    s = " CREATE TABLE DC_JLR_OPTION_T"
    '    s &= "("
    '    s &= "  OPT      VARCHAR2(3)                          NOT NULL,"
    '    s &= "  DC_ID    NUMBER                               NOT NULL,"
    '    s &= "  KET      VARCHAR2(30),"
    '    s &= "  TANGGAL  DATE,"
    '    s &= "  NILAI    NUMBER,"
    '    s &= "CONSTRAINT  DC_JLR_OPTION_T_PK PRIMARY KEY (DC_ID,OPT) USING INDEX TABLESPACE DCSIM_IDX ENABLE,"
    '    s &= "CONSTRAINT DC_JLR_OPTION_T_FK FOREIGN KEY (DC_ID) "
    '    s &= "  REFERENCES  DC_TABEL_DC_T (TBL_DCID) ON DELETE CASCADE ENABLE"
    '    s &= ")"
    '    Scom.CommandText = s : Scom.ExecuteNonQuery()

    '    s = "CREATE TABLE DC_JLR_ANTRIAN_T(" & _
    '            "ID_Antrian NUMBER NOT NULL," & _
    '            "DC_ID NUMBER NOT NULL," & _
    '            "RECID varchar2(1) NULL ," & _
    '            "Jalur varchar2(50) NOT NULL," & _
    '            "Supplier varchar2(50) NULL," & _
    '            "NoAntrian NUMBER NULL," & _
    '            "MinItem NUMBER Default 0," & _
    '            "MinRp NUMBER Default 0," & _
    '            "Jam1 Date," & _
    '            "Jam2 Date," & _
    '            "ListSupp varchar2(50) NULL," & _
    '            "IsBesar Integer DEFAULT 0," & _
    '            "CONSTRAINT  DC_JLR_ANTRIAN_T_PK PRIMARY KEY (ID_ANTRIAN) USING INDEX TABLESPACE DCSIM_INDEX ENABLE," & _
    '            "CONSTRAINT DC_JLR_ANTRIAN_T_UK1 UNIQUE (DC_ID,JALUR) USING INDEX TABLESPACE DCSIM_INDEX ENABLE," & _
    '            "CONSTRAINT DC_JLR_ANTRIAN_T_FK FOREIGN KEY (DC_ID) " & _
    '            "REFERENCES  DC_TABEL_DC_T (TBL_DCID) ON DELETE CASCADE ENABLE" & _
    '            ")"
    '    Scom.CommandText = s : Scom.ExecuteNonQuery()

    '    s = "CREATE sequence DC_JLR_ANTRIAN_T_SEQ"
    '    Scom.CommandText = s : Scom.ExecuteNonQuery()

    '    s = "CREATE trigger BI_DC_JLR_ANTRIAN_T " & _
    '            "before insert on DC_JLR_ANTRIAN_T " & _
    '            "for each row " & _
    '            "begin " & _
    '                "select DC_JLR_ANTRIAN_T_SEQ.nextval into " & _
    '                ":NEW.ID_ANTRIAN from dual;" & _
    '            "end;"
    '    Scom.CommandText = s : Scom.ExecuteNonQuery()


    '    ''''''SENIN
    '    s = "CREATE TABLE DC_JLR_Supp1st_T(" & _
    '            "ID_Supp1st NUMBER NOT NULL," & _
    '            "ID_Antrian NUMBER NOT NULL," & _
    '            "SUPCO varchar(4) NOT NULL," & _
    '            "SNAMA varchar(50) NULL," & _
    '            "Jam1 Date NULL," & _
    '            "Jam2 Date NULL," & _
    '            "Hari NUMBER NULL," & _
    '            "CONSTRAINT DC_JLR_SUPP1ST_T_PK PRIMARY KEY (ID_SUPP1ST) USING INDEX TABLESPACE DCSIM_INDEX ENABLE," & _
    '            "CONSTRAINT DC_JLR_SUPP1ST_T_UK1 UNIQUE (SUPCO,HARI) USING INDEX TABLESPACE DCSIM_INDEX ENABLE," & _
    '            "CONSTRAINT DC_JLR_SUPP1ST_T_FK FOREIGN KEY (ID_ANTRIAN)" & _
    '            "REFERENCES  DC_JLR_ANTRIAN_T (ID_ANTRIAN)ON DELETE CASCADE ENABLE" & _
    '            ")"
    '    Scom.CommandText = s : Scom.ExecuteNonQuery()
    '    s = "CREATE sequence DC_JLR_Supp1st_T_SEQ"
    '    Scom.CommandText = s : Scom.ExecuteNonQuery()

    '    s = "CREATE OR REPLACE TRIGGER  BI_DC_JLR_SUPP1ST_T " & _
    '            "before insert on DC_JLR_SUPP1ST_T " & _
    '            "for each row " & _
    '                "begin " & _
    '            "select DC_JLR_SUPP1ST_T_SEQ.nextval into :NEW.ID_SUPP1ST from dual; " & _
    '            "end;"
    '    Scom.CommandText = s : Scom.ExecuteNonQuery()

    '    s = "ALTER TRIGGER  BI_DC_JLR_SUPP1ST_T ENABLE"
    '    Scom.CommandText = s : Scom.ExecuteNonQuery()
    '    '''''

    '    '    ''''''SELASA
    '    '    s = "CREATE TABLE DC_JLR_SuppSelasa_T(" & _
    '    '            "ID_Supp1st NUMBER NOT NULL," & _
    '    '            "ID_Antrian NUMBER NULL," & _
    '    '            "SUPCO varchar2(4) NOT NULL," & _
    '    '            "SNAMA varchar2(50) NULL," & _
    '    '            "Jam1 Date NULL," & _
    '    '            "Jam2 Date NULL," & _
    '    '            "CONSTRAINT DC_JLR_SuppSelasa_T_PK PRIMARY KEY (ID_SUPP1ST) USING INDEX TABLESPACE DCSIM_INDEX ENABLE," & _
    '    '            "CONSTRAINT DC_JLR_SuppSelasa_T_UK1 UNIQUE (SUPCO) USING INDEX TABLESPACE DCSIM_INDEX ENABLE," & _
    '    '            "CONSTRAINT DC_JLR_SuppSelasa_T_FK FOREIGN KEY (ID_ANTRIAN)" & _
    '    '            "REFERENCES  DC_JLR_ANTRIAN_T (ID_ANTRIAN) ENABLE" & _
    '    '            ")"
    '    '    con.Execute (s)
    '    '    s = "CREATE sequence DC_JLR_SuppSelasa_T_SEQ"
    '    '    con.Execute (s)
    '    '
    '    '    s = "CREATE OR REPLACE TRIGGER  BI_DC_JLR_SuppSelasa_T " & _
    '    '            "before insert on DC_JLR_SuppSelasa_T " & _
    '    '            "for each row " & _
    '    '                "begin " & _
    '    '            "select DC_JLR_SuppSelasa_T_SEQ.nextval into :NEW.ID_SUPP1ST from dual; " & _
    '    '            "end;"
    '    '    con.Execute (s)
    '    '
    '    '    s = "ALTER TRIGGER  BI_DC_JLR_SuppSelasa_T ENABLE"
    '    '    con.Execute (s)
    '    '    '''''
    '    '
    '    '    ''''''Rabu
    '    '    s = "CREATE TABLE DC_JLR_SuppRabu_T(" & _
    '    '            "ID_Supp1st NUMBER NOT NULL," & _
    '    '            "ID_Antrian NUMBER NULL," & _
    '    '            "SUPCO varchar(4) NOT NULL," & _
    '    '            "SNAMA varchar(50) NULL," & _
    '    '            "Jam1 Date NULL," & _
    '    '            "Jam2 Date NULL," & _
    '    '            "CONSTRAINT DC_JLR_SuppRabu_T_PK PRIMARY KEY (ID_SUPP1ST) USING INDEX TABLESPACE DCSIM_INDEX ENABLE," & _
    '    '            "CONSTRAINT DC_JLR_SuppRabu_T_UK1 UNIQUE (SUPCO) USING INDEX TABLESPACE DCSIM_INDEX ENABLE," & _
    '    '            "CONSTRAINT DC_JLR_SuppRabu_T_FK FOREIGN KEY (ID_ANTRIAN)" & _
    '    '            "REFERENCES  DC_JLR_ANTRIAN_T (ID_ANTRIAN) ENABLE" & _
    '    '            ")"
    '    '    con.Execute (s)
    '    '    s = "CREATE sequence DC_JLR_SuppRabu_T_SEQ"
    '    '    con.Execute (s)
    '    '
    '    '    s = "CREATE OR REPLACE TRIGGER  BI_DC_JLR_SuppRabu_T " & _
    '    '            "before insert on DC_JLR_SuppRabu_T " & _
    '    '            "for each row " & _
    '    '                "begin " & _
    '    '            "select DC_JLR_SuppRabu_T_SEQ.nextval into :NEW.ID_SUPP1ST from dual; " & _
    '    '            "end;"
    '    '    con.Execute (s)
    '    '
    '    '    s = "ALTER TRIGGER  BI_DC_JLR_SuppRabu_T ENABLE"
    '    '    con.Execute (s)
    '    '    '''''
    '    '
    '    '    ''''''Kamis
    '    '    s = "CREATE TABLE DC_JLR_SuppKamis_T(" & _
    '    '            "ID_Supp1st NUMBER NOT NULL," & _
    '    '            "ID_Antrian NUMBER NULL," & _
    '    '            "SUPCO varchar(4) NOT NULL," & _
    '    '            "SNAMA varchar(50) NULL," & _
    '    '            "Jam1 Date NULL," & _
    '    '            "Jam2 Date NULL," & _
    '    '            "CONSTRAINT DC_JLR_SuppKamis_T_PK PRIMARY KEY (ID_SUPP1ST) USING INDEX TABLESPACE DCSIM_INDEX ENABLE," & _
    '    '            "CONSTRAINT DC_JLR_SuppKamis_T_UK1 UNIQUE (SUPCO) USING INDEX TABLESPACE DCSIM_INDEX ENABLE," & _
    '    '            "CONSTRAINT DC_JLR_SuppKamis_T_FK FOREIGN KEY (ID_ANTRIAN)" & _
    '    '            "REFERENCES  DC_JLR_ANTRIAN_T (ID_ANTRIAN) ENABLE" & _
    '    '            ")"
    '    '    con.Execute (s)
    '    '    s = "CREATE sequence DC_JLR_SuppKamis_T_SEQ"
    '    '    con.Execute (s)
    '    '
    '    '    s = "CREATE OR REPLACE TRIGGER  BI_DC_JLR_SuppKamis_T " & _
    '    '            "before insert on DC_JLR_SuppKamis_T " & _
    '    '            "for each row " & _
    '    '                "begin " & _
    '    '            "select DC_JLR_SuppKamis_T_SEQ.nextval into :NEW.ID_SUPP1ST from dual; " & _
    '    '            "end;"
    '    '    con.Execute (s)
    '    '
    '    '    s = "ALTER TRIGGER  BI_DC_JLR_SuppKamis_T ENABLE"
    '    '    con.Execute (s)
    '    '    '''''
    '    '
    '    '    ''''''Jumat
    '    '    s = "CREATE TABLE DC_JLR_SuppJumat_T(" & _
    '    '            "ID_Supp1st NUMBER NOT NULL," & _
    '    '            "ID_Antrian NUMBER NULL," & _
    '    '            "SUPCO varchar(4) NOT NULL," & _
    '    '            "SNAMA varchar(50) NULL," & _
    '    '            "Jam1 Date NULL," & _
    '    '            "Jam2 Date NULL," & _
    '    '            "CONSTRAINT DC_JLR_SuppJumat_T_PK PRIMARY KEY (ID_SUPP1ST) USING INDEX TABLESPACE DCSIM_INDEX ENABLE," & _
    '    '            "CONSTRAINT DC_JLR_SuppJumat_T_UK1 UNIQUE (SUPCO) USING INDEX TABLESPACE DCSIM_INDEX ENABLE," & _
    '    '            "CONSTRAINT DC_JLR_SuppJumat_T_FK FOREIGN KEY (ID_ANTRIAN)" & _
    '    '            "REFERENCES  DC_JLR_ANTRIAN_T (ID_ANTRIAN) ENABLE" & _
    '    '            ")"
    '    '    con.Execute (s)
    '    '    s = "CREATE sequence DC_JLR_SuppJumat_T_SEQ"
    '    '    con.Execute (s)
    '    '
    '    '    s = "CREATE OR REPLACE TRIGGER  BI_DC_JLR_SuppJumat_T " & _
    '    '            "before insert on DC_JLR_SuppJumat_T " & _
    '    '            "for each row " & _
    '    '                "begin " & _
    '    '            "select DC_JLR_SuppJumat_T_SEQ.nextval into :NEW.ID_SUPP1ST from dual; " & _
    '    '            "end;"
    '    '    con.Execute (s)
    '    '
    '    '    s = "ALTER TRIGGER  BI_DC_JLR_SuppJumat_T ENABLE"
    '    '    con.Execute (s)
    '    '    '''''
    '    '
    '    '    ''''''SABTU
    '    '    s = "CREATE TABLE DC_JLR_SuppSabtu_T(" & _
    '    '            "ID_Supp1st NUMBER NOT NULL," & _
    '    '            "ID_Antrian NUMBER NULL," & _
    '    '            "SUPCO varchar(4) NOT NULL," & _
    '    '            "SNAMA varchar(50) NULL," & _
    '    '            "Jam1 Date NULL," & _
    '    '            "Jam2 Date NULL," & _
    '    '            "CONSTRAINT DC_JLR_SuppSabtu_T_PK PRIMARY KEY (ID_SUPP1ST) USING INDEX TABLESPACE DCSIM_INDEX ENABLE," & _
    '    '            "CONSTRAINT DC_JLR_SuppSabtu_T_UK1 UNIQUE (SUPCO) USING INDEX TABLESPACE DCSIM_INDEX ENABLE," & _
    '    '            "CONSTRAINT DC_JLR_SuppSabtu_T_FK FOREIGN KEY (ID_ANTRIAN)" & _
    '    '            "REFERENCES  DC_JLR_ANTRIAN_T (ID_ANTRIAN) ENABLE" & _
    '    '            ")"
    '    '    con.Execute (s)
    '    '    s = "CREATE sequence DC_JLR_SuppSabtu_T_SEQ"
    '    '    con.Execute (s)
    '    '
    '    '    s = "CREATE OR REPLACE TRIGGER  BI_DC_JLR_SuppSabtu_T " & _
    '    '            "before insert on DC_JLR_SuppSabtu_T " & _
    '    '            "for each row " & _
    '    '                "begin " & _
    '    '            "select DC_JLR_SuppSabtu_T_SEQ.nextval into :NEW.ID_SUPP1ST from dual; " & _
    '    '            "end;"
    '    '    con.Execute (s)
    '    '
    '    '    s = "ALTER TRIGGER  BI_DC_JLR_SuppSabtu_T ENABLE"
    '    '    con.Execute (s)
    '    '    '''''
    '    '
    '    '    ''''''MINGGU
    '    '    s = "CREATE TABLE DC_JLR_SuppMinggu_T(" & _
    '    '            "ID_Supp1st NUMBER NOT NULL," & _
    '    '            "ID_Antrian NUMBER NULL," & _
    '    '            "SUPCO varchar(4) NOT NULL," & _
    '    '            "SNAMA varchar(50) NULL," & _
    '    '            "Jam1 Date NULL," & _
    '    '            "Jam2 Date NULL," & _
    '    '            "CONSTRAINT DC_JLR_SuppMinggu_T_PK PRIMARY KEY (ID_SUPP1ST) USING INDEX TABLESPACE DCSIM_INDEX ENABLE," & _
    '    '            "CONSTRAINT DC_JLR_SuppMinggu_T_UK1 UNIQUE (SUPCO) USING INDEX TABLESPACE DCSIM_INDEX ENABLE," & _
    '    '            "CONSTRAINT DC_JLR_SuppMinggu_T_FK FOREIGN KEY (ID_ANTRIAN)" & _
    '    '            "REFERENCES  DC_JLR_ANTRIAN_T (ID_ANTRIAN) ENABLE" & _
    '    '            ")"
    '    '    con.Execute (s)
    '    '    s = "CREATE sequence DC_JLR_SuppMinggu_T_SEQ"
    '    '    con.Execute (s)
    '    '
    '    '    s = "CREATE OR REPLACE TRIGGER  BI_DC_JLR_SuppMinggu_T " & _
    '    '            "before insert on DC_JLR_SuppMinggu_T " & _
    '    '            "for each row " & _
    '    '                "begin " & _
    '    '            "select DC_JLR_SuppMinggu_T_SEQ.nextval into :NEW.ID_SUPP1ST from dual; " & _
    '    '            "end;"
    '    '    con.Execute (s)
    '    '
    '    '    s = "ALTER TRIGGER  BI_DC_JLR_SuppMinggu_T ENABLE"
    '    '    con.Execute (s)
    '    '    '''''

    '    '###########
    '    '''''DaftarJalur
    '    s = "CREATE TABLE DC_JLR_DaftarJalur_T(" & _
    '            "ID_DaftarJalur NUMBER NOT NULL," & _
    '            "DC_ID NUMBER NOT NULL," & _
    '            "Tanggal Date NULL," & _
    '            "Recid varchar(1) NULL," & _
    '            "NoMobil varchar(11) NOT NULL," & _
    '            "NoUrut NUMBER," & _
    '            "SUPCO varchar(4) NULL," & _
    '            "SNAMA varchar(50) NULL," & _
    '            "Item NUMBER DEFAULT 0," & _
    '            "Rupiah NUMBER DEFAULT 0," & _
    '            "TglStart Date," & _
    '            "TglEnd Date," & _
    '            "Jalur Varchar(50) NULL," & _
    '            "CONSTRAINT DC_JLR_DaftarJalur_PK PRIMARY KEY (ID_DaftarJalur) USING INDEX TABLESPACE DCSIM_INDEX ENABLE," & _
    '            "CONSTRAINT DC_JLR_DaftarJalur_T_FK FOREIGN KEY (DC_ID) " & _
    '            "REFERENCES DC_TABEL_DC_T (TBL_DCID)ON DELETE CASCADE ENABLE" & _
    '            ")"
    '    Scom.CommandText = s : Scom.ExecuteNonQuery()
    '    s = "CREATE sequence DC_JLR_DaftarJalur_T_SEQ"
    '    Scom.CommandText = s : Scom.ExecuteNonQuery()

    '    s = "CREATE OR REPLACE TRIGGER  BI_DC_JLR_DaftarJalur_T " & _
    '            "before insert on DC_JLR_DaftarJalur_T " & _
    '            "for each row " & _
    '                "begin " & _
    '            "select DC_JLR_DaftarJalur_T_SEQ.nextval into :NEW.ID_DaftarJalur from dual; " & _
    '            "end;"
    '    Scom.CommandText = s : Scom.ExecuteNonQuery()

    '    s = "ALTER TRIGGER  BI_DC_JLR_DaftarJalur_T ENABLE"
    '    Scom.CommandText = s : Scom.ExecuteNonQuery()
    '    '''''''''''''''''''''

    '    '''''''''DaftarPO
    '    s = "CREATE TABLE DC_JLR_DaftarPO_T(" & _
    '            "ID_DaftarPO NUMBER NOT NULL," & _
    '            "Tanggal Date NULL, Recid varchar(1) NULL," & _
    '            "ID_DaftarJalur NUMBER Default 0," & _
    '            "NO_FAK NUMBER Default 0,TGL_FAK Date NULL, NoPO varchar(9) NULL," & _
    '            "SUPCO varchar(4) NOT NULL,SNAMA varchar(50) NULL," & _
    '            "BUAT_PO integer Default 0,ADA_HARGA Integer Default 0," & _
    '            "QTY NUMBER Default 0,Item NUMBER Default 0," & _
    '            "Rupiah NUMBER Default 0,PPN NUMBER Default 0 ," & _
    '            "BPB_NO NUMBER Default 0,TGL_MULAI Date NULL," & _
    '            "JAM_MULAI varchar(8) NULL,TGL_AKHIR Date NULL," & _
    '            "JAM_AKHIR varchar(8) NULL,JML_MOBIL NUMBER Default 0 ," & _
    '            "TGL_REVISI Date NULL,JAM_REVISI varchar(8) NULL, " & _
    '            "USER_NAME varchar(15) NULL, " & _
    '            "MRBREAD varchar(1) NULL, " & _
    '            """UPDATE"" Date NULL," & _
    '            "SUPID NUMBER NULL," & _
    '            "CONSTRAINT DC_JLR_DaftarPO_PK PRIMARY KEY (ID_DaftarPO) USING INDEX TABLESPACE DCSIM_INDEX ENABLE," & _
    '            "CONSTRAINT DC_JLR_DaftarPO_FK FOREIGN KEY (ID_DaftarJalur)" & _
    '            "REFERENCES  DC_JLR_DaftarJalur_T (ID_DaftarJalur)ON DELETE CASCADE ENABLE" & _
    '            ")"
    '    Scom.CommandText = s : Scom.ExecuteNonQuery()
    '    s = "CREATE sequence DC_JLR_DaftarPO_T_SEQ"
    '    Scom.CommandText = s : Scom.ExecuteNonQuery()

    '    s = "CREATE OR REPLACE TRIGGER  BI_DC_JLR_DaftarPO_T " & _
    '            "before insert on DC_JLR_DaftarPO_T " & _
    '            "for each row " & _
    '                "begin " & _
    '            "select DC_JLR_DaftarPO_T_SEQ.nextval into :NEW.ID_DaftarPO from dual; " & _
    '            "end;"
    '    Scom.CommandText = s : Scom.ExecuteNonQuery()

    '    s = "ALTER TRIGGER  BI_DC_JLR_DaftarPO_T ENABLE"
    '    Scom.CommandText = s : Scom.ExecuteNonQuery()
    '    ''''''''''''''''''''

    '    s = "CREATE TABLE DC_JLR_Setting_T(" & _
    '            "DC_ID NUMBER NOT NULL," & _
    '            "NextNoUrut NUMBER Default 0," & _
    '            "LastDate Date NULL," & _
    '            "CONSTRAINT DC_JLR_Setting_T_FK FOREIGN KEY (DC_ID) " & _
    '            "REFERENCES  DC_TABEL_DC_T (TBL_DCID)ON DELETE CASCADE ENABLE" & _
    '            ")"
    '    Scom.CommandText = s : Scom.ExecuteNonQuery()
    '    ''''''''''''''''''''

    '    s = "CREATE TABLE DC_JLR_TempAntrian_T(" & _
    '            "ID_Antrian NUMBER," & _
    '            "DC_ID NUMBER NOT NULL," & _
    '            "Jalur varchar(50) Default 0," & _
    '            "SUPCO varchar(4) NOT NULL," & _
    '            "SNAMA varchar(50) NULL," & _
    '            "NoMobil varchar(12) NULL," & _
    '            "NoAntrian NUMBER," & _
    '            "CONSTRAINT DC_JLR_TempAntrian_PK PRIMARY KEY (ID_Antrian) USING INDEX TABLESPACE DCSIM_INDEX ENABLE," & _
    '            "CONSTRAINT DC_JLR_TempAntrian_T_FK FOREIGN KEY (DC_ID) " & _
    '            "REFERENCES  DC_TABEL_DC_T (TBL_DCID)ON DELETE CASCADE ENABLE" & _
    '            ")"
    '    Scom.CommandText = s : Scom.ExecuteNonQuery()
    '    s = "CREATE sequence DC_JLR_TempAntrian_T_SEQ"
    '    Scom.CommandText = s : Scom.ExecuteNonQuery()

    '    s = "CREATE OR REPLACE TRIGGER  BI_DC_JLR_TempAntrian_T " & _
    '            "before insert on DC_JLR_TempAntrian_T " & _
    '            "for each row " & _
    '                "begin " & _
    '            "select DC_JLR_TempAntrian_T_SEQ.nextval into :NEW.ID_Antrian from dual; " & _
    '            "end;"
    '    Scom.CommandText = s : Scom.ExecuteNonQuery()

    '    s = "ALTER TRIGGER  BI_DC_JLR_TempAntrian_T ENABLE"
    '    Scom.CommandText = s : Scom.ExecuteNonQuery()

    '    s = "CREATE OR REPLACE VIEW DC_JLR_SUPP1ST_V" & _
    '            "(ID_SUPP1ST, ID_ANTRIAN, SUPCO, SNAMA, JAM1, JAM2, HARI)AS " & _
    '            "Select ID_SUPP1ST,ID_ANTRIAN,SUPCO,SNAMA,JAM1,JAM2,HARI from DC_JLR_SUPP1st_T " & _
    '            "Where HARI=TO_CHAR(SYSDATE,'d')"
    '    Scom.CommandText = s : Scom.ExecuteNonQuery()


    '    Scon.Close()
    'End Function

    Public Function IsMrBread(ByVal sSupco As String, ByVal sDC_Kode As String) As Boolean
        Dim Scon As New OleDb.OleDbConnection(ConStrORA)
        Dim Scom As New OleDb.OleDbCommand("", Scon)
        Dim SQL As String

        Try
            Scon.Open()
            SQL = "select COUNT(*) from DC_TABEL_ALOKASI_T "
            SQL &= "WHERE TBL_ALOKASI_ID=GET_SUP_TBL_ALOKASI_ID('" & sSupco & "','" & sDC_Kode & "')"
            SQL &= "AND TBL_NAMA_ALOKASI='MR BREAD'"
            Scom.CommandText = SQL
            If Scom.ExecuteScalar > 0 Then
                Return True
            End If
        Catch ex As Exception
            ShowError("Error Baca", ex)
        Finally
            Scon.Close()
        End Try

    End Function
End Module
