﻿Module ModuleODP
    Public TNSDB As String
    Public USERDB As String
    Public PASSDB As String
    Public ODP As String
    Public FASTTRANSFER As String
    Public STRKONEKSIODP As String
    Public Function getStrKoneksiODP() As String
        Try
            strKoneksiODP = ""
            tnsDB = NewEncrypt.GetVariabel("ServerOrcl")
            userDB = NewEncrypt.GetVariabel("UserOrcl")
            passDB = NewEncrypt.GetVariabel("PasswordOrcl")
            odp = NewEncrypt.GetVariabel("ODPOrcl")
            FastTransfer = BacaRegistry("Software\Indomaret\Cluster", "Fast")
            If tnsDB <> "" Then
                If odp = "" Then
                    MessageBox.Show("Gunakan SettingWeb ODP.", "Hubungi SUpport SD3.", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Application.Exit()
                    End
                Else
                    strKoneksiODP = "Data Source=" & odp & ";;User Id=" & userDB & ";;Password=" & passDB
                    Return strKoneksiODP
                End If
            Else
                strKoneksiODP = ""
                Return False
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return ex.Message
        End Try
    End Function
End Module
