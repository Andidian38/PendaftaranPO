﻿Imports Oracle.ManagedDataAccess.Client

Public Class FormPassHapusPO
    Public OKSLP As Boolean = False
    Public Function execScalar_(ByVal strConOra As String, ByVal query As String) As String
        Dim con As New OracleConnection(strConOra)
        Dim com As New OracleCommand("", con)
        Dim _e As String = ""
        Try
            con.Open()
            com.CommandText = query
            _e = com.ExecuteScalar()
        Catch ex As Exception
            _e = -1
        Finally
            con.Close()
        End Try
        Return _e
    End Function
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim PassDCM As String = execScalar_(getStrKoneksiODP, "SELECT NVL(db_pass_dcm, TO_CHAR(SYSDATE,'YYYY')) AS db_pass_dcm FROM DC_SETUP_DB")
        If PassDCM = txtPass.Text.Trim Then
            OKSLP = True
            Me.DialogResult = DialogResult.OK
            'frmDaftarPO.btn_Next(SUPCO)
            frmDaftarPO.btnTambahPO.Enabled = True
            'frmDaftarPO.showdialogLoadPO()
            Me.Close()
        Else
            MessageBox.Show("Password salah.", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    Private Sub FormPassHapusPO_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        frmDaftarPO.btnTambahPO.Enabled = False
    End Sub

    Private Sub FormPassHapusPO_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        If OKSLP = False Then
            Me.DialogResult = DialogResult.No
        Else
            Me.DialogResult = DialogResult.OK
        End If
        frmDaftarPO.btnTambahPO.Enabled = True

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click


        txtPass.Text = ""
    End Sub
End Class