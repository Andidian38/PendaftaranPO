Imports System.Data
Imports Oracle.ManagedDataAccess.Client
Public Class frmEditPO
    Inherits System.Windows.Forms.Form
    Public dt_MBR_EX As DataTable
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents DataGrid1 As System.Windows.Forms.DataGrid
    Friend WithEvents btnSimpan As System.Windows.Forms.Button
    Friend WithEvents btnBatal As System.Windows.Forms.Button
    Friend WithEvents DsPO1 As PendaftaranPO.DS_
    Friend WithEvents DataGridTableStyle1 As System.Windows.Forms.DataGridTableStyle
    Friend WithEvents DataGridTextBoxColumn1 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents DataGridTextBoxColumn2 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents DataGridTextBoxColumn3 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents DataGridTextBoxColumn4 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents DataGridTextBoxColumn5 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents DataGridTextBoxColumn6 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents DataGridTextBoxColumn7 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents DataGridTextBoxColumn8 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents DataGridTextBoxColumn9 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents DataGridTextBoxColumn10 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents DataGridTextBoxColumn11 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents DataGridTextBoxColumn12 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents DataGridTextBoxColumn13 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents DataGridTextBoxColumn14 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents DsPO1BindingSource As System.Windows.Forms.BindingSource
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmEditPO))
        Me.btnSimpan = New System.Windows.Forms.Button()
        Me.btnBatal = New System.Windows.Forms.Button()
        Me.DataGrid1 = New System.Windows.Forms.DataGrid()
        Me.DsPO1 = New PendaftaranPO.DS_()
        Me.DataGridTableStyle1 = New System.Windows.Forms.DataGridTableStyle()
        Me.DataGridTextBoxColumn2 = New System.Windows.Forms.DataGridTextBoxColumn()
        Me.DataGridTextBoxColumn3 = New System.Windows.Forms.DataGridTextBoxColumn()
        Me.DataGridTextBoxColumn9 = New System.Windows.Forms.DataGridTextBoxColumn()
        Me.DataGridTextBoxColumn6 = New System.Windows.Forms.DataGridTextBoxColumn()
        Me.DataGridTextBoxColumn7 = New System.Windows.Forms.DataGridTextBoxColumn()
        Me.DataGridTextBoxColumn5 = New System.Windows.Forms.DataGridTextBoxColumn()
        Me.DataGridTextBoxColumn4 = New System.Windows.Forms.DataGridTextBoxColumn()
        Me.DataGridTextBoxColumn8 = New System.Windows.Forms.DataGridTextBoxColumn()
        Me.DataGridTextBoxColumn1 = New System.Windows.Forms.DataGridTextBoxColumn()
        Me.DataGridTextBoxColumn10 = New System.Windows.Forms.DataGridTextBoxColumn()
        Me.DataGridTextBoxColumn11 = New System.Windows.Forms.DataGridTextBoxColumn()
        Me.DataGridTextBoxColumn12 = New System.Windows.Forms.DataGridTextBoxColumn()
        Me.DataGridTextBoxColumn13 = New System.Windows.Forms.DataGridTextBoxColumn()
        Me.DataGridTextBoxColumn14 = New System.Windows.Forms.DataGridTextBoxColumn()
        Me.DsPO1BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsPO1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsPO1BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnSimpan
        '
        Me.btnSimpan.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSimpan.BackColor = System.Drawing.Color.Transparent
        Me.btnSimpan.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.btnSimpan.Image = Global.PendaftaranPO.My.Resources.Resources.disk
        Me.btnSimpan.Location = New System.Drawing.Point(732, 457)
        Me.btnSimpan.Name = "btnSimpan"
        Me.btnSimpan.Size = New System.Drawing.Size(94, 37)
        Me.btnSimpan.TabIndex = 1
        Me.btnSimpan.Text = "&Simpan"
        Me.btnSimpan.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSimpan.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnSimpan.UseVisualStyleBackColor = False
        '
        'btnBatal
        '
        Me.btnBatal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnBatal.BackColor = System.Drawing.Color.Transparent
        Me.btnBatal.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnBatal.Image = Global.PendaftaranPO.My.Resources.Resources.arrow_undo
        Me.btnBatal.Location = New System.Drawing.Point(636, 457)
        Me.btnBatal.Name = "btnBatal"
        Me.btnBatal.Size = New System.Drawing.Size(94, 37)
        Me.btnBatal.TabIndex = 2
        Me.btnBatal.Text = "&Batal"
        Me.btnBatal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnBatal.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnBatal.UseVisualStyleBackColor = False
        '
        'DataGrid1
        '
        Me.DataGrid1.AlternatingBackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.DataGrid1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGrid1.BackColor = System.Drawing.Color.White
        Me.DataGrid1.BackgroundColor = System.Drawing.Color.LightGoldenrodYellow
        Me.DataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.DataGrid1.CaptionBackColor = System.Drawing.Color.Olive
        Me.DataGrid1.CaptionFont = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
        Me.DataGrid1.CaptionForeColor = System.Drawing.Color.DarkSlateBlue
        Me.DataGrid1.CausesValidation = False
        Me.DataGrid1.DataMember = ""
        Me.DataGrid1.DataSource = Me.DsPO1.EditPO
        Me.DataGrid1.FlatMode = True
        Me.DataGrid1.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.DataGrid1.ForeColor = System.Drawing.Color.DarkSlateBlue
        Me.DataGrid1.GridLineColor = System.Drawing.Color.Peru
        Me.DataGrid1.GridLineStyle = System.Windows.Forms.DataGridLineStyle.None
        Me.DataGrid1.HeaderBackColor = System.Drawing.Color.Maroon
        Me.DataGrid1.HeaderFont = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
        Me.DataGrid1.HeaderForeColor = System.Drawing.Color.LightGoldenrodYellow
        Me.DataGrid1.LinkColor = System.Drawing.Color.Maroon
        Me.DataGrid1.Location = New System.Drawing.Point(7, 5)
        Me.DataGrid1.Name = "DataGrid1"
        Me.DataGrid1.ParentRowsBackColor = System.Drawing.Color.BurlyWood
        Me.DataGrid1.ParentRowsForeColor = System.Drawing.Color.DarkSlateBlue
        Me.DataGrid1.ParentRowsVisible = False
        Me.DataGrid1.ReadOnly = True
        Me.DataGrid1.RowHeadersVisible = False
        Me.DataGrid1.RowHeaderWidth = 30
        Me.DataGrid1.SelectionBackColor = System.Drawing.Color.DarkSlateBlue
        Me.DataGrid1.SelectionForeColor = System.Drawing.Color.GhostWhite
        Me.DataGrid1.Size = New System.Drawing.Size(816, 446)
        Me.DataGrid1.TabIndex = 0
        Me.DataGrid1.TableStyles.AddRange(New System.Windows.Forms.DataGridTableStyle() {Me.DataGridTableStyle1})
        '
        'DsPO1
        '
        Me.DsPO1.DataSetName = "DS_"
        Me.DsPO1.Locale = New System.Globalization.CultureInfo("en-US")
        Me.DsPO1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DataGridTableStyle1
        '
        Me.DataGridTableStyle1.AlternatingBackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.DataGridTableStyle1.BackColor = System.Drawing.Color.White
        Me.DataGridTableStyle1.DataGrid = Me.DataGrid1
        Me.DataGridTableStyle1.ForeColor = System.Drawing.Color.DarkSlateBlue
        Me.DataGridTableStyle1.GridColumnStyles.AddRange(New System.Windows.Forms.DataGridColumnStyle() {Me.DataGridTextBoxColumn2, Me.DataGridTextBoxColumn3,
                                                         Me.DataGridTextBoxColumn12, Me.DataGridTextBoxColumn9, Me.DataGridTextBoxColumn13,
                                                         Me.DataGridTextBoxColumn14, Me.DataGridTextBoxColumn6, Me.DataGridTextBoxColumn7,
                                                            Me.DataGridTextBoxColumn5, Me.DataGridTextBoxColumn4, Me.DataGridTextBoxColumn8,
                                                            Me.DataGridTextBoxColumn1, Me.DataGridTextBoxColumn10, Me.DataGridTextBoxColumn11})
        Me.DataGridTableStyle1.GridLineColor = System.Drawing.Color.FloralWhite
        Me.DataGridTableStyle1.HeaderBackColor = System.Drawing.Color.DarkKhaki
        Me.DataGridTableStyle1.HeaderForeColor = System.Drawing.Color.Black
        Me.DataGridTableStyle1.MappingName = "EDITPo"
        Me.DataGridTableStyle1.RowHeaderWidth = 30
        Me.DataGridTableStyle1.SelectionBackColor = System.Drawing.Color.DarkSlateBlue
        Me.DataGridTableStyle1.SelectionForeColor = System.Drawing.Color.White
        '
        'DataGridTextBoxColumn2
        '
        Me.DataGridTextBoxColumn2.Alignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.DataGridTextBoxColumn2.Format = ""
        Me.DataGridTextBoxColumn2.FormatInfo = Nothing
        Me.DataGridTextBoxColumn2.HeaderText = "PLU"
        Me.DataGridTextBoxColumn2.MappingName = "PRDCD"
        Me.DataGridTextBoxColumn2.NullText = ""
        Me.DataGridTextBoxColumn2.ReadOnly = True
        Me.DataGridTextBoxColumn2.Width = 75

        'DataGridTextBoxColumn3
        '
        Me.DataGridTextBoxColumn3.Alignment = System.Windows.Forms.HorizontalAlignment.Right
        Me.DataGridTextBoxColumn3.Format = ""
        Me.DataGridTextBoxColumn3.FormatInfo = Nothing
        Me.DataGridTextBoxColumn3.HeaderText = "Qty BPB"
        Me.DataGridTextBoxColumn3.MappingName = "FRAC"
        Me.DataGridTextBoxColumn3.NullText = ""
        Me.DataGridTextBoxColumn3.Width = 80
        '
        'DataGridTextBoxColumn12
        '
        Me.DataGridTextBoxColumn12.Alignment = System.Windows.Forms.HorizontalAlignment.Right
        Me.DataGridTextBoxColumn12.Format = ""
        Me.DataGridTextBoxColumn12.FormatInfo = Nothing
        Me.DataGridTextBoxColumn12.HeaderText = "Qty Pcs BPB"
        Me.DataGridTextBoxColumn12.MappingName = "PCSBPB"
        Me.DataGridTextBoxColumn12.NullText = ""
        Me.DataGridTextBoxColumn12.Width = 80
        '
        'DataGridTextBoxColumn9
        '
        Me.DataGridTextBoxColumn9.Alignment = System.Windows.Forms.HorizontalAlignment.Right
        Me.DataGridTextBoxColumn9.Format = ""
        Me.DataGridTextBoxColumn9.FormatInfo = Nothing
        Me.DataGridTextBoxColumn9.HeaderText = "Qty PO"
        Me.DataGridTextBoxColumn9.MappingName = "FracAsal"
        Me.DataGridTextBoxColumn9.NullText = ""
        Me.DataGridTextBoxColumn9.ReadOnly = True
        Me.DataGridTextBoxColumn9.Width = 80
        '

        '
        'DataGridTextBoxColumn13
        '
        Me.DataGridTextBoxColumn13.Alignment = System.Windows.Forms.HorizontalAlignment.Right
        Me.DataGridTextBoxColumn13.Format = ""
        Me.DataGridTextBoxColumn13.FormatInfo = Nothing
        Me.DataGridTextBoxColumn13.HeaderText = "Qty Pcs PO"
        Me.DataGridTextBoxColumn13.MappingName = "fracasalpo"
        Me.DataGridTextBoxColumn13.NullText = ""
        Me.DataGridTextBoxColumn13.Width = 80
        '
        'DataGridTextBoxColumn14
        '
        Me.DataGridTextBoxColumn14.Alignment = System.Windows.Forms.HorizontalAlignment.Right
        Me.DataGridTextBoxColumn14.Format = ""
        Me.DataGridTextBoxColumn14.FormatInfo = Nothing
        Me.DataGridTextBoxColumn14.HeaderText = "FRAC"
        Me.DataGridTextBoxColumn14.MappingName = "SATUAN"
        Me.DataGridTextBoxColumn14.NullText = ""
        Me.DataGridTextBoxColumn14.ReadOnly = True
        Me.DataGridTextBoxColumn14.Width = 50
        '
        'DataGridTextBoxColumn6
        '
        Me.DataGridTextBoxColumn6.Alignment = System.Windows.Forms.HorizontalAlignment.Right
        Me.DataGridTextBoxColumn6.Format = "#,##0.##"
        Me.DataGridTextBoxColumn6.FormatInfo = Nothing
        Me.DataGridTextBoxColumn6.HeaderText = "" '"Nilai."
        Me.DataGridTextBoxColumn6.MappingName = "PO_GROSS"
        Me.DataGridTextBoxColumn6.NullText = ""
        Me.DataGridTextBoxColumn6.ReadOnly = True
        Me.DataGridTextBoxColumn6.Width = 0
        '
        'DataGridTextBoxColumn7
        '
        Me.DataGridTextBoxColumn7.Alignment = System.Windows.Forms.HorizontalAlignment.Right
        Me.DataGridTextBoxColumn7.Format = "#,##0.##"
        Me.DataGridTextBoxColumn7.FormatInfo = Nothing
        Me.DataGridTextBoxColumn7.HeaderText = "" '"PPn"
        Me.DataGridTextBoxColumn7.MappingName = "PO_PPN"
        Me.DataGridTextBoxColumn7.NullText = ""
        Me.DataGridTextBoxColumn7.ReadOnly = True
        Me.DataGridTextBoxColumn7.Width = 0
        '
        'DataGridTextBoxColumn5
        '
        Me.DataGridTextBoxColumn5.Alignment = System.Windows.Forms.HorizontalAlignment.Right
        Me.DataGridTextBoxColumn5.Format = "#,##0.##"
        Me.DataGridTextBoxColumn5.FormatInfo = Nothing
        Me.DataGridTextBoxColumn5.HeaderText = "" '"Tot. Disc"
        Me.DataGridTextBoxColumn5.MappingName = "PO_DISC"
        Me.DataGridTextBoxColumn5.NullText = ""
        Me.DataGridTextBoxColumn5.ReadOnly = True
        Me.DataGridTextBoxColumn5.Width = 0
        '
        'DataGridTextBoxColumn4
        '
        Me.DataGridTextBoxColumn4.Alignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.DataGridTextBoxColumn4.Format = "#,##0"
        Me.DataGridTextBoxColumn4.FormatInfo = Nothing
        Me.DataGridTextBoxColumn4.HeaderText = "Unit"
        Me.DataGridTextBoxColumn4.MappingName = "UNIT"
        Me.DataGridTextBoxColumn4.NullText = ""
        Me.DataGridTextBoxColumn4.ReadOnly = True
        Me.DataGridTextBoxColumn4.Width = 100
        '
        'DataGridTextBoxColumn8
        '
        Me.DataGridTextBoxColumn8.Alignment = System.Windows.Forms.HorizontalAlignment.Right
        Me.DataGridTextBoxColumn8.Format = "#,##0"
        Me.DataGridTextBoxColumn8.FormatInfo = Nothing
        Me.DataGridTextBoxColumn8.HeaderText = "Bonus"
        Me.DataGridTextBoxColumn8.MappingName = "QTYBONUS"
        Me.DataGridTextBoxColumn8.NullText = "0"
        Me.DataGridTextBoxColumn8.ReadOnly = True
        Me.DataGridTextBoxColumn8.Width = 100
        '
        'DataGridTextBoxColumn1
        '
        Me.DataGridTextBoxColumn1.Format = ""
        Me.DataGridTextBoxColumn1.FormatInfo = Nothing
        Me.DataGridTextBoxColumn1.HeaderText = "Deskripsi"
        Me.DataGridTextBoxColumn1.MappingName = "DESKRIPSI"
        Me.DataGridTextBoxColumn1.NullText = ""
        Me.DataGridTextBoxColumn1.ReadOnly = True
        Me.DataGridTextBoxColumn1.Width = 200
        '
        'DataGridTextBoxColumn10
        '
        Me.DataGridTextBoxColumn10.Alignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.DataGridTextBoxColumn10.Format = ""
        Me.DataGridTextBoxColumn10.FormatInfo = Nothing
        Me.DataGridTextBoxColumn10.HeaderText = "TAG"
        Me.DataGridTextBoxColumn10.MappingName = "MBR_TAG"
        Me.DataGridTextBoxColumn10.NullText = ""
        Me.DataGridTextBoxColumn10.ReadOnly = True
        Me.DataGridTextBoxColumn10.Width = 80
        '
        'DataGridTextBoxColumn11
        '
        Me.DataGridTextBoxColumn11.Alignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.DataGridTextBoxColumn11.Format = ""
        Me.DataGridTextBoxColumn11.FormatInfo = Nothing
        Me.DataGridTextBoxColumn11.HeaderText = "F_EXCBPB"
        Me.DataGridTextBoxColumn11.MappingName = "EXTAG"
        Me.DataGridTextBoxColumn11.NullText = ""
        Me.DataGridTextBoxColumn11.ReadOnly = True
        Me.DataGridTextBoxColumn11.Width = 80
        '
        'DsPO1BindingSource
        '
        Me.DsPO1BindingSource.DataSource = Me.DsPO1
        Me.DsPO1BindingSource.Position = 0
        '
        'frmEditPO
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.SeaGreen
        Me.CancelButton = Me.btnBatal
        Me.ClientSize = New System.Drawing.Size(829, 498)
        Me.Controls.Add(Me.btnBatal)
        Me.Controls.Add(Me.btnSimpan)
        Me.Controls.Add(Me.DataGrid1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmEditPO"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Edit PO"
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsPO1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsPO1BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region
    Public sNoPo As String
    Public esNoPo As String
    Public eNOMOBIL As String
    Public eSUPCO As String
    Public eSNAMA As String
    Public eITEMnya As String
    Public eRUPIAH As String
    Public eFAKTUR As String
    Public eNoAntrian As String
    Public etglDaftar As String
    Public etglFaktur As String
    Public nQTY As Integer
    Public nItem As Integer
    Public nGROSS As Double
    Public nPPN As Double
    Public nIdDaftarPO As Integer

    Private _faktur As String
    Property FakturMBread() As String
        Get
            Return _faktur
        End Get
        Set(ByVal value As String)
            _faktur = value
        End Set
    End Property

    Private Sub HandleRow(ByVal sender As Object, ByVal e As System.Data.DataRowChangeEventArgs)
        If e.Action = DataRowAction.Add Then
            Err.Raise(99, "EditPO", "Tidak Bisa Tambah Data")
        End If
    End Sub
    Private Sub HandleColom(ByVal sender As Object, ByVal e As System.Data.DataColumnChangeEventArgs)
        Debug.WriteLine(e.Column.ColumnName)
        '  If e.Column.ColumnName = "FRAC" Then
        If e.Column.ColumnName = "FRAC" Then

            Dim rw As DataRow
            rw = e.Row
            rw("PCSBPB") = e.ProposedValue * rw("SATUAN")
            If Convert.IsDBNull(e.ProposedValue) Then
                e.ProposedValue = 0
            End If
            If (e.ProposedValue) > rw("FRACAsal") Or (rw("FRACAsal") = 0) Then
                If (rw("FRACAsal") = 0) Then
                    MessageBox.Show("Qty PO = 0. Item tidak bisa diedit.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Else
                    MessageBox.Show("Qty beli tidak boleh > dari pada qty PO (" & rw("FRACAsal") & ")", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
                e.ProposedValue = rw("FRACAsal")
                Exit Sub
            End If

            rw("PO_GROSS") = e.ProposedValue * rw("SATUAN") * rw("PODTL_PRICE") 'PODTL_QTYB*PODTL_ISI_SATB*PODTL_PRICE
            If rw("PO_PPNAsal") > 0 Then
                rw("PO_PPN") = (e.ProposedValue * rw("SATUAN") * rw("PODTL_PRICE") - (e.ProposedValue * rw("SATUAN") / rw("PEMBAGIDISC") * rw("PO_DISCAsal"))) * 0.1
            End If
            rw("PO_DISC") = ((e.ProposedValue * rw("SATUAN") / rw("PEMBAGIDISC") * rw("PO_DISCAsal")))

            rw("PPN_BOTOL") = ((e.ProposedValue * rw("SATUAN") / rw("PEMBAGIDISC") * rw("PPN_BOTOLAsal")))
            'yang lama
            'rw("QTYBONUS") = ((e.ProposedValue * rw("SATUAN") / rw("PEMBAGIDISC") * rw("QTYBONUSAsal")))

            If rw("QTYBONUSAsal") <> 0 Then
                rw("QTYBONUS") = 0
                MessageBox.Show("Qty Bonus di receive melalui BPB Lain-Lain !", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub frmEditPO_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        AddHandler DsPO1.EditPO.ColumnChanging, AddressOf HandleColom
        Dim SQL As String
        ' kasus lombok jd harus matiin optimizer use feedback 14/3/2017 /*+OPT_PARAM(_'OPTIMIZER_USE_FEEDBACK' 'FALSE)*/
        SQL = " SELECT   po_no_po, prdcd, deskripsi, bolehbpb, fracasal,  frac,fracasalpo, pcsbpb,satuan, unit, trunc(podtl_price,8) as podtl_price, " &
              " trunc(DECODE(fracasal,0,0,(po_gross/fracasal))* frac,8) as po_gross, po_ppnasal," &
                " trunc(DECODE(fracasal,0,0,(po_ppn/fracasal))* frac,8) as po_ppn, pembagidisc," &
                "  trunc(po_discasal,8) as po_discasal, trunc(DECODE(fracasal,0,0,(po_disc/fracasal))* frac,8)  as po_disc, " &
                " trunc(ppn_botolasal,8) as ppn_botolasal, trunc(ppn_botol,8) as ppn_botol, EXTAG, qtybonus, qtybonusasal, MBR_TAG FROM" &
                " (" &
                " SELECT   po.po_no_po, podtl_plu AS prdcd, brg.mbr_full_nama AS deskripsi," &
                "          istag_bolehbpb (" & cDC_ID & ", mbr_tag) AS bolehbpb," &
                "          istag_bolehbpb (" & cDC_ID & ", mbr_tag) * podtl_qtyb AS fracasal,   istag_bolehbpb (122, mbr_tag) * podtl_qtyb * podtl_isi_satb AS fracasalPO," &
                "          NVL (trn.frac, 0) * istag_bolehbpb ( 122 , mbr_tag) * podtl_isi_satb AS   PCSbpb,  " &
                "          NVL (trn.frac, 0) AS frac, podtl_isi_satb AS satuan, 0 AS unit," &
                "          podtl_price," &
                "            istag_bolehbpb (" & cDC_ID & ", mbr_tag)" &
                "          * podtl_qtyb" &
                "          * podtl_isi_satb" &
                "          * podtl_price AS po_gross," &
                "          istag_bolehbpb (" & cDC_ID & ", mbr_tag) * podtl_ppn AS po_ppnasal," &
                "          CASE" &
                "             WHEN podtl_ppn > 0" &
                "                THEN (  istag_bolehbpb (" & cDC_ID & ", mbr_tag)" &
                "                      * (  (  podtl_qtyb * podtl_isi_satb * podtl_price" &
                "                            - (  (podtl_qtyb * podtl_isi_satb)" &
                "                               / (  (podtl_qtyb * podtl_isi_satb)" &
                "                                  + podtl_frac_qtyb" &
                "                                 )" &
                "                               * NVL (totdisc, 0)" &
                "                              )" &
                "                           )" &
                "                         * (Nvl(podtl_ppn_persen,getppnnew(null)) / 100)" &
                "                        )" &
                "                     )" &
                "             ELSE 0" &
                "          END AS po_ppn," &
                "          (podtl_qtyb * podtl_isi_satb) + podtl_frac_qtyb AS pembagidisc," &
                "          istag_bolehbpb (" & cDC_ID & ", mbr_tag) * NVL (totdisc, 0) AS po_discasal," &
                "            istag_bolehbpb (" & cDC_ID & ", mbr_tag)" &
                "          * (  (podtl_qtyb * podtl_isi_satb)" &
                "             / ((podtl_qtyb * podtl_isi_satb) + podtl_frac_qtyb)" &
                "             * NVL (totdisc, 0)" &
                "            ) AS po_disc," &
                "            istag_bolehbpb (" & cDC_ID & ", mbr_tag)" &
                "          * NVL (podtl_ppn_btl, 0) AS ppn_botolasal," &
                "            istag_bolehbpb (" & cDC_ID & ", mbr_tag)" &
                "          * (  (podtl_qtyb * podtl_isi_satb)" &
                "             / ((podtl_qtyb * podtl_isi_satb) + podtl_frac_qtyb)" &
                "             * NVL (podtl_ppn_btl, 0)" &
                "            ) AS ppn_botol," &
                "            istag_bolehbpb (" & cDC_ID & ", mbr_tag)" &
                "          * NVL (bns.pobns_qty, 0) AS qtybonusasal," &
                "            istag_bolehbpb (" & cDC_ID & ", mbr_tag)" &
                "          * (  (podtl_qtyb * podtl_isi_satb)" &
                "             / ((podtl_qtyb * podtl_isi_satb) + podtl_frac_qtyb)" &
                "             * NVL (bns.pobns_qty, 0)" &
                "            ) AS qtybonus , MBR_TAG, DECODE(istag_bolehbpb(" & cDC_ID & ", mbr_tag), 1, '', 'Y') as EXTAG" &
                "     FROM dc_po_t po LEFT JOIN dc_podtl_t dt ON po.po_no_po = dt.podtl_fk_no_po" &
                "          LEFT JOIN (SELECT mbr_fk_pluid, (mbr_tag) AS mbr_tag," &
                "                            (mbr_full_nama) AS mbr_full_nama" &
                "                       FROM dc_barang_dc_v" &
                "                      WHERE tbl_dc_kode = '" & cDC_KODE & "') brg ON dt.podtl_plumd =" &
                "                                                               brg.mbr_fk_pluid" &
                "          LEFT JOIN (SELECT   podisc_fk_no_po, podisc_fk_plu," &
                "                                  (SUM (NVL (podisc_nilai, 0)))" &
                "                                 AS totdisc" &
                "                         FROM dc_podisc_t" &
                "                     GROUP BY podisc_fk_no_po, podisc_fk_plu) s ON po.po_no_po =" &
                "                                                                     s.podisc_fk_no_po" &
                "                                                              AND dt.podtl_plumd =" &
                "                                                                     s.podisc_fk_plu" &
                "          LEFT JOIN (SELECT pobns_fk_no_po, pobns_fk_plu," &
                "                            NVL (pobns_qty, 0) AS pobns_qty" &
                "                       FROM dc_pobns_t) bns ON po.po_no_po = bns.pobns_fk_no_po" &
                "                                          AND dt.podtl_plumd = bns.pobns_fk_plu" &
                "          LEFT JOIN (SELECT no_po, plu_id, frac" &
                "                       FROM dc_trnbpb_dtl_t" &
                "                      WHERE hdr_fk_id =" &
                "                               (SELECT hdr_id" &
                "                                  FROM dc_trnbpb_hdr_t" &
                "                                 WHERE id_daftarpo =" &
                "                                          (SELECT id_daftarpo" &
                "                                             FROM dc_jlr_daftarpo_t" &
                "                                            WHERE supco = '" & eSUPCO & "'" &
                "                                              AND nopo = '" & sNoPo & "'" &
                "                                              AND no_fak = '" & eFAKTUR & "'))) trn ON po.po_no_po =" &
                "                                                                           trn.no_po" &
                "                                                                    AND dt.podtl_plumd =" &
                "                                                                           trn.plu_id  ,(SELECT EX_TAG_BPB FROM DC_EXCLUDE_TAG_T) EXTAG" &
                "    WHERE ((podtl_recid IS NULL OR podtl_recid = '') AND podtl_no_bpb IS NULL " &
                "          )" &
                "      AND po_no_po = '" & sNoPo & "'" &
                " ORDER BY prdcd)"


        Dim Scon As New OracleConnection(ConStrORA)
        Dim sdap As New OracleDataAdapter(SQL, Scon)
        Scon.Open()
        DsPO1.EditPO.Clear()
        sdap.Fill(DsPO1.EditPO)
        Scon.Close()

        Dim CekExtag As String = ""
        Dim dt_CEKEXTAG As DataTable = getDS(SQL, ConStrORA).Tables(0)
        For xy As Integer = 0 To dt_CEKEXTAG.Rows.Count - 1
            If dt_CEKEXTAG.Rows(xy)("EXTAG").ToString = "Y" Then
                If dt_CEKEXTAG.Rows(xy)("FRAC") <> 0 Then
                    CekExtag &= "PLU: " & dt_CEKEXTAG.Rows(xy)("EXTAG") & "|| TAG: " & dt_CEKEXTAG.Rows(xy)("MBR_TAG") & vbNewLine
                End If
            End If
        Next
        If CekExtag <> "" Then
            MessageBox.Show(CekExtag, "Ada PLU Exclude Tag BPB, QTY <> 0", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    Public Function CekItemPO() As Boolean
        CekItemPO = True

        'Cek Status PO
        Dim Recid As String, Expired As String, ErrMsg As String = ""
        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Dim Sdar As OracleDataReader

        Scon.Open()
        Scom.CommandText = "SELECT PO_RECID,PO_TGL_PO,PO_UMUR From DC_PO_T where PO_NO_PO='" & sNoPo & "'"
        Sdar = Scom.ExecuteReader
        If Sdar.Read Then
            Recid = Sdar("PO_RECID") & ""
            Expired = (Sdar("PO_TGL_PO") + IIf(Sdar("PO_UMUR") <= 0, 7, Sdar("PO_UMUR"))) < Now.Date
            Scon.Close()
            ' C               R                      H           A                        1                 2
            '"PO Di-Closing","PO Sudah ada BPB-nya","PO Hangus","PO Sedang dibuat BPB-nya,"Item PO dihapus","PO Revisi""
            Select Case Recid
                Case "C"
                    ErrMsg = "PO Di-Closing"
                Case "R"
                    ErrMsg = "PO Sudah ada BPB-nya"
                Case "H"
                    ErrMsg = "PO Hangus"
                Case "A"
                    ErrMsg = "PO Sedang dibuat BPB-nya"
                Case "1"
                    ErrMsg = "Item PO dihapus"
                Case "2"
                    ErrMsg = "PO Revisi"
            End Select
            If ErrMsg <> "" Then
                MsgBox("Tidak Bisa Edit, " & ErrMsg, vbCritical)
                GoTo keluar
            End If

            ''Todo: Lepas Kadaluarsa
            'If Expired = "True" Then
            '    MsgBox("PO Sudah Kadaluarsa", vbCritical)
            '    GoTo keluar
            'End If
            Exit Function
        End If
keluar:
        CekItemPO = False
    End Function
    Private Function Cek_EditPO_MBread(ByVal ds As DataTable) As Boolean
        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Dim Sdap As New OracleDataAdapter("", Scon)
        Dim dt As New DataTable

        Dim Sql As String

        Dim lOke As Boolean = True

        Try
            Scon.Open()
            Sql = " SELECT   a.plu AS PLU, SUM (a.qty) AS QTY "
            Sql &= "FROM alokasi_tampung a "
            Sql &= "WHERE (a.no_sj = '" & _faktur & "') "
            Sql &= "GROUP BY a.no_sj, a.tgl_sj, a.plu "
            Sql &= "order by plu "
            Sdap.SelectCommand.CommandText = Sql
            Sdap.Fill(dt)
            If dt.Rows.Count <> ds.Rows.Count Then
                lOke = False
                Exit Try
            End If

            For i As Integer = 0 To ds.Rows.Count - 1
                If (dt.Rows(i)("PLU") <> ds.Rows(i)("PRDCDNYA")) Or (dt.Rows(i)("QTY") <> ds.Rows(i)("FRACNYA")) Then
                    lOke = False
                    Exit Try
                End If
            Next

        Catch ex As Exception
            IDM.Fungsi.ShowError("Error Cek Edit PO Mr. Bread", ex)
        Finally
            Scon.Close()
        End Try

        Return lOke
    End Function
    Private lNoClose As Boolean = False
    Public IsMrBread As Boolean
    Private Sub frmEditPO_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        e.Cancel = lNoClose
    End Sub
    Private Sub btnSimpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimpan.Click

        Dim totQTYperFAKTUR As Integer = 0

        'kalo total frac = 0  langsung di skip
        For xy As Integer = 0 To DsPO1.EditPO.Rows.Count - 1
            totQTYperFAKTUR += Val(IIf(IsDBNull(DsPO1.EditPO.Rows(xy)("FRAC")), 0, DsPO1.EditPO.Rows(xy)("FRAC"))) * Val(IIf(IsDBNull(DsPO1.EditPO.Rows(xy)("SATUAN")), 0, DsPO1.EditPO.Rows(xy)("SATUAN")))
        Next
        If totQTYperFAKTUR = 0 Then
            GoTo batalEdit
        End If

        lNoClose = False
        'btnSimpan.DialogResult = Windows.Forms.DialogResult.None
        If IsMrBread Then
            If Not Cek_EditPO_MBread(DsPO1.EditPO) Then
                MessageBox.Show("Total PO <> Total Faktur.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                lNoClose = True
                Exit Sub
            Else
                lNoClose = False
            End If
        End If
        Dim X As Double

        nItem = 0
        nQTY = 0
        nGROSS = 0
        nPPN = 0
        '19/10
        'Dim ppnbotol_ As Double = 0, _
        '    ppnbotolasal_ As Double = 0
        For I As Integer = 0 To DsPO1.EditPO.Rows.Count - 1
            X = (DsPO1.EditPO.Rows(I)("FRAC") * DsPO1.EditPO.Rows(I)("SATUAN")) * DsPO1.EditPO.Rows(I)("PODTL_PRICE")
            If X > 0 Then
                nItem += 1
                nQTY = nQTY + (DsPO1.EditPO.Rows(I)("FRAC") * DsPO1.EditPO.Rows(I)("SATUAN"))
                nGROSS = nGROSS + (X - IIf(IsDBNull(DsPO1.EditPO.Rows(I)("PO_DISC")), 0, DsPO1.EditPO.Rows(I)("PO_DISC")))

                'Ditambah PPN BOTOL
                'For xy As Integer = 0 To dt_MBR_EX.Rows.Count - 1
                '    If dt_MBR_EX.Rows(xy)("prdcd") = DsPO1.EditPO.Rows(xy)("prdcd") Then
                '        ppnbotol_ = dt_MBR_EX.Rows(xy)("ppn_botol_")
                '    End If
                'Next

                nGROSS += IIf(IsDBNull(DsPO1.EditPO.Rows(I)("PPN_BOTOL")), 0, DsPO1.EditPO.Rows(I)("PPN_BOTOL"))
                'nGROSS += IIf(IsDBNull(ppnbotol_), 0, ppnbotol_)

                nPPN = nPPN + IIf(IsDBNull(DsPO1.EditPO.Rows(I)("PO_PPN")), 0, DsPO1.EditPO.Rows(I)("PO_PPN"))
                'nPPN += nGROSS * 0.1
            End If

            Dim con As New OracleConnection(ConStrORA)
            Dim com As New OracleCommand("", con)
            Dim Hdr As Integer
            Dim frac_hh As Integer
            Dim frac_slp As Integer

            con.Open()

            com.CommandText = " SELECT hdr_id" &
                    "   FROM dc_trnbpb_hdr_t" &
                    "  WHERE id_daftarpo =" &
                    "           (SELECT id_daftarpo" &
                    "              FROM dc_jlr_daftarpo_t" &
                    "             WHERE supco = '" & eSUPCO & "'" &
                    " 			  AND nopo = '" & sNoPo & "'" &
                    "               AND no_fak = '" & eFAKTUR & "')"
            Hdr = "0" & com.ExecuteScalar

            com.CommandText = "Select FRAC_SLP FROM DC_TRNBPB_DTL_T where HDR_FK_ID=" & Hdr & " AND PLU_KODE='" & DsPO1.EditPO.Rows(I)("PRDCD") & "'"
            frac_slp = "0" & com.ExecuteScalar
            'cek apakah plu itu sudah di SLP atau belum. Jika sudah, maka tidak boleh diubah jadi nol (0)
            If frac_slp <> 0 And Val(IIf(IsDBNull(DsPO1.EditPO.Rows(I)("FRAC")), 0, DsPO1.EditPO.Rows(I)("FRAC"))) * Val(IIf(IsDBNull(DsPO1.EditPO.Rows(I)("SATUAN")), 0, DsPO1.EditPO.Rows(I)("SATUAN"))) = 0 Then
                MessageBox.Show("PLU : '" & DsPO1.EditPO.Rows(I)("PRDCD") & "' sudah di SLP dan qty-nya tidak bisa diubah menjadi 0", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                con.Close()
                lNoClose = True
                Exit Sub
            ElseIf IIf(IsDBNull(DsPO1.EditPO.Rows(I)("FRAC")), 0, DsPO1.EditPO.Rows(I)("FRAC")) < frac_slp Then
                MessageBox.Show("PLU : '" & DsPO1.EditPO.Rows(I)("PRDCD") & "' sudah di SLP sebanyak " & frac_slp & " . tidak bisa ubah kurang dari qty SLP", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                con.Close()
                lNoClose = True
                Exit Sub
            End If
            'Dim K As String = DsPO1.EditPO.Rows(I)("FRAC")
            'Dim J As String = DsPO1.EditPO.Rows(I)("PRDCD")
            'If DsPO1.EditPO.Rows(I)("FRAC") = 0 Then
            '    com.CommandText = "UPDATE DC_TRNBPB_DTL_T SET "
            '    com.CommandText &= "QTY=" & Val(IIf(IsDBNull(DsPO1.EditPO.Rows(I)("FRAC")), 0, DsPO1.EditPO.Rows(I)("FRAC"))) * Val(IIf(IsDBNull(DsPO1.EditPO.Rows(I)("SATUAN")), 0, DsPO1.EditPO.Rows(I)("SATUAN")))
            '    com.CommandText &= ", FRAC=" & IIf(IsDBNull(DsPO1.EditPO.Rows(I)("FRAC")), 0, DsPO1.EditPO.Rows(I)("FRAC"))
            '    com.CommandText &= ", FRAC_HH=" & IIf(IsDBNull(DsPO1.EditPO.Rows(I)("FRAC")), 0, DsPO1.EditPO.Rows(I)("FRAC")) & " "
            '    com.CommandText &= "WHERE HDR_FK_ID=" & Hdr & " AND PLU_KODE='" & DsPO1.EditPO.Rows(I)("PRDCD") & "'"
            '    com.CommandText &= ""
            'Else
            '    com.CommandText = "Select FRAC_HH FROM DC_TRNBPB_DTL_T where HDR_FK_ID=" & Hdr & " AND PLU_KODE='" & DsPO1.EditPO.Rows(I)("PRDCD") & "'"
            '    frac_hh = "0" & com.ExecuteScalar

            '    If frac_hh = 0 Then
            '        com.CommandText = "UPDATE DC_TRNBPB_DTL_T SET "
            '        com.CommandText &= "QTY=" & Val(IIf(IsDBNull(DsPO1.EditPO.Rows(I)("FRAC")), 0, DsPO1.EditPO.Rows(I)("FRAC"))) * Val(IIf(IsDBNull(DsPO1.EditPO.Rows(I)("SATUAN")), 0, DsPO1.EditPO.Rows(I)("SATUAN")))
            '        com.CommandText &= ", FRAC=" & IIf(IsDBNull(DsPO1.EditPO.Rows(I)("FRAC")), 0, DsPO1.EditPO.Rows(I)("FRAC")) & ", FRAC_HH=null " '0" & DsPO1.EditPO.Rows(I)("FRAC") & " "
            '        com.CommandText &= "WHERE HDR_FK_ID=" & Hdr & " AND PLU_KODE='" & DsPO1.EditPO.Rows(I)("PRDCD") & "'"
            '        com.CommandText &= ""
            '    Else
            '        com.CommandText = "UPDATE DC_TRNBPB_DTL_T SET "
            '        com.CommandText &= "QTY=" & Val(IIf(IsDBNull(DsPO1.EditPO.Rows(I)("FRAC")), 0, DsPO1.EditPO.Rows(I)("FRAC"))) * Val(IIf(IsDBNull(DsPO1.EditPO.Rows(I)("SATUAN")), 0, DsPO1.EditPO.Rows(I)("SATUAN")))
            '        com.CommandText &= ",FRAC=" & IIf(IsDBNull(DsPO1.EditPO.Rows(I)("FRAC")), 0, DsPO1.EditPO.Rows(I)("FRAC")) & " " '"FRAC_HH=0" & DsPO1.EditPO.Rows(I)("FRAC") & " "
            '        com.CommandText &= "WHERE HDR_FK_ID=" & Hdr & " AND PLU_KODE='" & DsPO1.EditPO.Rows(I)("PRDCD") & "'"
            '        com.CommandText &= ""
            '    End If
            'End If
            Dim FracInput As String = IIf(IsDBNull(DsPO1.EditPO.Rows(I)("FRAC")), 0, DsPO1.EditPO.Rows(I)("FRAC"))
            If DsPO1.EditPO.Rows(I)("FRAC") = 0 Then
                com.CommandText = " UPDATE dc_trnbpb_dtl_t SET (qty, frac, frac_hh, nilai, disc1, disc2, disc3, disc4, disc5, disc6, tot_disc, ppnrp)= " &
                            " (SELECT  " &
                            " NVL(a.podtl_isi_satb, 0) * " & FracInput & " AS QTY, " &
                            " " & FracInput & " AS Frac, " & FracInput & " AS frac_hh, " &
                            " ((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb) * a.podtl_price AS NILAI,  " &
                            " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc1,0)  AS DISC_1, " &
                            " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc2,0)  AS DISC_2, " &
                            " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc3,0)  AS DISC_3, " &
                            " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc4,0)  AS DISC_4, " &
                            " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc5,0)  AS DISC_5, " &
                            " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc6,0)  AS DISC_6, " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc1,0)) + " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc2,0)) + " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc3,0)) + " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc4,0)) + " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc5,0)) + " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc6,0))  AS TOT_DISC,  CASE WHEN A.PODTL_PPN > 0  THEN  " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb)* a.podtl_price ) - ( " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc1,0)) + " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc2,0)) + " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc3,0)) + " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc4,0)) + " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc5,0)) + " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc6,0))))* (Nvl(podtl_ppn_persen,getppnnew(null)) / 100) ELSE 0 END AS PPNRP " &
                            "  FROM dc_podtl_t a, DC_PODISC_DTL_V b " &
                            " WHERE a.podtl_fk_no_po = b.po (+)   " &
                            " AND a.podtl_plumd = b.plu (+)" &
                            " AND podtl_fk_no_po = '" & sNoPo & "' " &
                            " AND podtl_plumd = " & DsPO1.EditPO.Rows(I)("PRDCD") & ") " &
                            " WHERE hdr_fk_id = " & Hdr &
                            " AND plu_id = " & DsPO1.EditPO.Rows(I)("PRDCD")
            Else
                com.CommandText = "Select FRAC_HH FROM DC_TRNBPB_DTL_T where HDR_FK_ID=" & Hdr & " AND PLU_KODE='" & DsPO1.EditPO.Rows(I)("PRDCD") & "'"
                frac_hh = "0" & com.ExecuteScalar

                If frac_hh = 0 Then
                    com.CommandText = " UPDATE dc_trnbpb_dtl_t SET (qty, frac, frac_hh, nilai, disc1, disc2, disc3, disc4, disc5, disc6, tot_disc, ppnrp)= " &
                        " (SELECT  " &
                        " NVL(a.podtl_isi_satb, 0) * " & FracInput & " AS QTY, " &
                        " " & FracInput & " AS Frac, NULL AS frac_hh, " &
                        " ((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb) * a.podtl_price AS NILAI,  " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc1,0)  AS DISC_1, " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc2,0)  AS DISC_2, " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc3,0)  AS DISC_3, " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc4,0)  AS DISC_4, " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc5,0)  AS DISC_5, " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc6,0)  AS DISC_6, " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc1,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc2,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc3,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc4,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc5,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc6,0))  AS TOT_DISC,  CASE WHEN A.PODTL_PPN > 0  THEN  " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb)* a.podtl_price ) - ( " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc1,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc2,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc3,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc4,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc5,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc6,0))))* (Nvl(podtl_ppn_persen,getppnnew(null)) / 100)  ELSE 0 END AS PPNRP " &
                        "  FROM dc_podtl_t a, DC_PODISC_DTL_V b " &
                        " WHERE a.podtl_fk_no_po = b.po (+)   " &
                        " AND a.podtl_plumd = b.plu (+)" &
                        " AND podtl_fk_no_po = '" & sNoPo & "' " &
                        " AND podtl_plumd = " & DsPO1.EditPO.Rows(I)("PRDCD") & ") " &
                        " WHERE hdr_fk_id = " & Hdr &
                        " AND plu_id = " & DsPO1.EditPO.Rows(I)("PRDCD")
                Else
                    com.CommandText = " UPDATE dc_trnbpb_dtl_t SET (qty, frac, nilai, disc1, disc2, disc3, disc4, disc5, disc6, tot_disc, ppnrp)= " &
                        " (SELECT  " &
                        " NVL(a.podtl_isi_satb, 0) * " & FracInput & " AS QTY, " &
                        " " & FracInput & " AS Frac, " &
                        " ((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb) * a.podtl_price AS NILAI,  " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc1,0)  AS DISC_1, " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc2,0)  AS DISC_2, " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc3,0)  AS DISC_3, " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc4,0)  AS DISC_4, " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc5,0)  AS DISC_5, " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc6,0)  AS DISC_6, " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc1,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc2,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc3,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc4,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc5,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc6,0))  AS TOT_DISC,  CASE WHEN A.PODTL_PPN > 0  THEN  " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb)* a.podtl_price ) - ( " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc1,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc2,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc3,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc4,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc5,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc6,0))))*  (Nvl(podtl_ppn_persen,getppnnew(null)) / 100) ELSE 0 END AS PPNRP " &
                        "  FROM dc_podtl_t a, DC_PODISC_DTL_V b " &
                        " WHERE a.podtl_fk_no_po = b.po (+)   " &
                        " AND a.podtl_plumd = b.plu (+)" &
                        " AND podtl_fk_no_po = '" & sNoPo & "' " &
                        " AND podtl_plumd = " & DsPO1.EditPO.Rows(I)("PRDCD") & ") " &
                        " WHERE hdr_fk_id = " & Hdr &
                        " AND plu_id = " & DsPO1.EditPO.Rows(I)("PRDCD")


                End If
            End If
            com.ExecuteNonQuery()
            con.Close()

            'Hitung Ulang QTYBONUS & update ke TRNBPB_DTL
            'If DsPO1.EditPO.Rows(I)("QTYBONUS") > 0 Or DsPO1.EditPO.Rows(I)("PPN_BOTOL") > 0 Then
            'Dim Scon As New OleDb.OleDbConnection(ConStrORA)
            'Dim Scom As New OleDb.OleDbCommand("", Scon)
            'Dim nHdr As Integer

            con.Open()
            'Scom.CommandText = "Select HDR_ID FROM DC_TRNBPB_HDR_T where ID_DAFTARPO=" & nIdDaftarPO
            'nHdr = "0" & Scom.ExecuteScalar
            'For xy As Integer = 0 To dt_MBR_EX.Rows.Count - 1
            '    If dt_MBR_EX.Rows(xy)("prdcd") = DsPO1.EditPO.Rows(xy)("prdcd") Then
            '        ppnbotol_ = dt_MBR_EX.Rows(xy)("ppn_botol_")
            '    End If
            'Next
            com.CommandText = "UPDATE DC_TRNBPB_DTL_T SET "
            com.CommandText &= "BONUS=0" & DsPO1.EditPO.Rows(I)("QTYBONUS") & " "
            com.CommandText &= ",BOTOL=0" & DsPO1.EditPO.Rows(I)("PPN_BOTOL") & " "
            com.CommandText &= "WHERE HDR_FK_ID=" & Hdr & " AND PLU_KODE='" & DsPO1.EditPO.Rows(I)("PRDCD") & "'"
            com.CommandText &= ""
            com.ExecuteNonQuery()
            con.Close()


            Dim UPDATE_HDR As String = " UPDATE   dc_trnbpb_hdr_t SET(tot_item, nilai, ppn)=" &
                                        " (SELECT COUNT (PLU_ID),  SUM (nilai),  SUM (ppnrp)" &
                                        "   FROM dc_trnbpb_dtl_t" &
                                        "  WHERE hdr_fk_id = " & Hdr &
                                        "  AND QTY <> 0)" &
                                        "  WHERE hdr_id = " & Hdr
            execQuery(UPDATE_HDR, ConStrORA)
        Next



        Dim GET_DTLPO As String = " SELECT ID_DAFTARPO FROM DC_JLR_DAFTARPO_T WHERE supco = '" & eSUPCO & "'" &
                " 			  AND nopo = '" & sNoPo & "'" &
                "               AND no_fak = '" & eFAKTUR & "'"
        Dim dt_idpo As DataTable = getDS(GET_DTLPO, ConStrORA).Tables(0)
        Dim IDPO As String = dt_idpo.Rows(0)(0).ToString

        Dim get_totdisc As String = " SELECT trunc(SUM(nvl(tot_disc,0)),8) FROM dc_trnbpb_dtl_t WHERE hdr_fk_id = (select hdr_id from dc_trnbpb_hdr_t where id_daftarpo = " & IDPO & ")"
        Dim dt_totdisc As DataTable = getDS(get_totdisc, ConStrORA).Tables(0)
        Dim totdisc As String = dt_totdisc.Rows(0)(0).ToString

        Dim get_rupiahPo As String = " SELECT trunc((  SUM (a.podtl_price * b.QTY)" &
                            "         - SUM ((b.QTY / (a.podtl_qtyb * a.podtl_isi_satb)) * podtl_disc)" &
                            "        ),8) AS RUPIAHPO" &
                            "   FROM dc_podtl_t a, dc_trnbpb_dtl_t b" &
                            "  WHERE a.podtl_fk_no_po = b.no_po" &
                            "    AND a.podtl_plumd = b.plu_id" &
                            "    AND a.podtl_fk_no_po = '" & sNoPo & "'" &
                            "    AND b.qty > 0"
        Dim dt_RupiahPO As DataTable = getDS(get_rupiahPo, ConStrORA).Tables(0)
        Dim rupiahPO As String = 0
        If dt_RupiahPO.Rows.Count > 0 Then
            rupiahPO = dt_RupiahPO.Rows(0)(0).ToString
        End If

        Dim UPDATE_DAFTARPO As String = "  UPDATE DC_JLR_DAFTARPO_T SET (RUPIAH, PPN, ITEM, tgl_mulai, jam_mulai) =" &
                " (select " & rupiahPO & ", SUM (NVL(ppn,0)), SUM (NVL(tot_item,0)),SYSDATE AS TGL_MULAI, TO_CHAR(SYSDATE, 'hh:mm:ss') AS JAM_MULAI" &
                "   FROM dc_trnbpb_hdr_t  " &
                "  WHERE supco = '" & eSUPCO & "' AND no_po = '" & sNoPo & "' AND id_daftarpo = " & IDPO & "), QTY = " &
                " (SELECT SUM(NVL(qty,0)) FROM DC_TRNBPB_DTL_T WHERE  no_po='" & sNoPo & "' AND HDR_FK_ID IN (SELECT HDR_ID FROM DC_TRNBPB_HDR_T WHERE ID_DAFTARPO= " & IDPO & "))" &
                " WHERE supco= '" & eSUPCO & "' AND nopo='" & sNoPo & "' AND id_daftarpo = " & IDPO
        execQuery(UPDATE_DAFTARPO, ConStrORA)

batalEdit:
    End Sub

    Private Sub btnBatal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBatal.Click
        lNoClose = False
    End Sub

    Private Sub DataGrid1_CurrentCellChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataGrid1.CurrentCellChanged
        Dim col As String = DataGrid1.CurrentCell.ColumnNumber.ToString
        Dim row As Integer = DataGrid1.CurrentRowIndex.ToString
        'Dim selrow As String = DataGrid1.CurrentCell.ToString
        If row <> DsPO1.EditPO.Rows.Count Then
            If DsPO1.EditPO.Rows(row)("FRAC").ToString = 0 Then
                DataGrid1.ReadOnly = True
                DataGridTextBoxColumn3.ReadOnly = True
            ElseIf col = "1" Then
                DataGridTextBoxColumn3.ReadOnly = False
                DataGrid1.ReadOnly = False
            ElseIf col <> "1" Then
                DataGrid1.ReadOnly = True
                DataGridTextBoxColumn3.ReadOnly = True
            End If
        End If
    End Sub

    Private Sub dgBatch_MouseUp(ByVal sender As System.Object,
       ByVal e As System.Windows.Forms.MouseEventArgs) _
       Handles DataGrid1.MouseUp
        Dim pt As New Point(e.X, e.Y)
        Dim hti As DataGrid.HitTestInfo = DataGrid1.HitTest(pt)
        If hti.Type = Windows.Forms.DataGrid.HitTestType.RowHeader Then
            Dim myCell As New DataGridCell()
            myCell.ColumnNumber = 0
            myCell.RowNumber = hti.Row
            DataGrid1.CurrentCell = myCell
        End If
    End Sub


End Class

