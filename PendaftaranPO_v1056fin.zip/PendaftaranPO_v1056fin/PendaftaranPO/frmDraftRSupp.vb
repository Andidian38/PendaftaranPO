Imports IDM.Fungsi
Imports System.Data
Imports Oracle.ManagedDataAccess.Client

Public Class frmDraftRSupp
    Dim dtSupplier As New DataTable
    Private Sub frmDraftRSupp_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Dim Sdap As New OracleDataAdapter

        Try
            If Scon.State = ConnectionState.Open Then
                Scon.Close()
            End If
            Scon.Open()
            If Scon.State = ConnectionState.Open Then
                Scom.CommandText = "select sup_supkode,sup_nama "
                Scom.CommandText &= "from dc_supplier_dc_v "
                Scom.CommandText &= "where tbl_dc_kode='" & cDC_KODE & "'"
                Scom.CommandText &= "order by sup_nama asc"
                Sdap.SelectCommand = Scom
                Sdap.Fill(dtSupplier)
                CmbSupco.DataSource = dtSupplier
                CmbSupco.DisplayMember = "SUP_SUPKODE"
                CmbNama.DataSource = dtSupplier
                CmbNama.DisplayMember = "SUP_NAMA"
            End If
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical)
        Finally
            Scon.Close()
            Scom.Dispose()
            Scom = Nothing
        End Try
    End Sub

    Private Sub btnBatal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBatal.Click
        Me.Close()
    End Sub

    Private Sub btnDraftRetur_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDraftRetur.Click
        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Dim Sdap As New OracleDataAdapter
        Dim ada As Boolean

        Try
            If Scon.State = ConnectionState.Open Then
                Scon.Close()
            End If
            Scon.Open()
            If Scon.State = ConnectionState.Open Then
                Scom.CommandText = "select count(sup_supkode) " & _
                                    "from dc_supplier_dc_v " & _
                                    "where tbl_dc_kode='" & cDC_KODE & "' " & _
                                    "and sup_supkode='" & CmbSupco.Text & "'" & _
                                    "order by sup_nama asc"
                ada = IIf(IsDBNull(Scom.ExecuteScalar) Or Scom.ExecuteScalar Is Nothing Or Scom.ExecuteScalar = 0, False, True)
                If ada = True Then
                    subDraft()
                    MsgBox("Berhasil Draft Retur Supplier " & CmbSupco.Text)
                Else
                    MsgBox("Tidak Ada Supplier " & CmbSupco.Text)
                End If
                Scom.Dispose()
                Scom = Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical)
        Finally
            Scon.Close()
        End Try
    End Sub

    Private Sub subDraft()
        Dim nBulan As Integer = 12

        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Dim Sdap As New OracleDataAdapter("", Scon)
        Dim dt As New DataTable
        Try
            Scon.Open()
            Dim RunProc As String = JLR_Create_Draft_Retur(CmbSupco.Text, cDC_KODE, nBulan)
            If RunProc <> "Y" Then
                MessageBox.Show("Procedure JLR_Create_Draft_Retur Error" & vbNewLine & RunProc, "Error Procedure!", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            'Scom.CommandText = "JLR_Create_Draft_Retur('" & CmbSupco.Text & "','" & cDC_KODE & "'," & nBulan & ")"
            'Scom.CommandType = CommandType.StoredProcedure
            'Scom.ExecuteNonQuery()
            Scom.CommandType = CommandType.Text

            dt.Clear()

            Scom.CommandText = "Select D.*,PRDCD,NAMA,SINGKAT from dc_jlr_draft_retur_t d, "
            Scom.CommandText &= "(SELECT MBR_FK_PLUID,mbr_plukode PRDCD,MBR_FULL_NAMA NAMA,MBR_SINGKATAN SINGKAT FROM DC_BARANG_DC_V WHERE MBR_FK_DCID=" & cDC_ID & ") brg "
            Scom.CommandText &= "WHERE(SUPCO = '" & CmbSupco.Text & "') "
            Scom.CommandText &= "AND Tanggal=TRUNC(SYSDATE) "
            Scom.CommandText &= "AND D.PLUID=BRG.MBR_FK_PLUID "
            Scom.CommandText &= "ORDER BY  PRDCD "
            Sdap.SelectCommand = Scom
            Sdap.Fill(dt)

            Scom.CommandText = "select alamat from dc_printer_t where printer='RETUR' and DC_ID='" & cDC_ID & "'"
            Dim almt As String = IIf(IsNothing(Scom.ExecuteScalar) Or IsDBNull(Scom.ExecuteScalar), "", Scom.ExecuteScalar)
            If almt = "" Then
                MsgBox("Tidak Ada Alamat Printer")
            End If
            If dt.Rows.Count > 0 Then
                Cetak_DrafRetur(dt, almt)
                MessageBox.Show("Draft Retur Selesai.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("Tidak Ada Data Untuk Draft Retur.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        Catch ex As Exception
            MsgBox("error Create Draft Retur - ", ex.ToString)
        Finally
            Scon.Close()
        End Try
    End Sub

    Private Function JLR_Create_Draft_Retur(ByVal sd_supco As String, ByVal sd_dckode As String, ByVal nBulan As Integer) As String
        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Dim Hasil As String = ""
        Try
            If Scon.State = ConnectionState.Open Then
                Scon.Close()

            End If
            Scon.Open()
            If Scon.State = ConnectionState.Open Then
                Scom.CommandType = CommandType.StoredProcedure
                Scom.CommandText = "JLR_CREATE_DRAFT_RETUR"
                Scom.CommandType = System.Data.CommandType.StoredProcedure
                Scom.Parameters.Clear()
                Scom.Parameters.Add(New OracleParameter("P_SUPCO", OracleDbType.Varchar2)).Value = sd_supco
                Scom.Parameters.Add(New OracleParameter("P_DCKODE", OracleDbType.Varchar2)).Value = sd_dckode
                Scom.Parameters.Add(New OracleParameter("P_BULAN", OracleDbType.Int32)).Value = nBulan
                Scom.ExecuteNonQuery()
            End If
            Return "Y"
        Catch ex As Exception
            Return ex.Message
        Finally
            Scom.Dispose()
            Scom = Nothing
            Scon.Close()
        End Try
    End Function
    'Private Sub Cetak_DrafRetur(ByVal dt As DataTable, ByVal nmPrinter As String)
    '    'Cetak PB BKL
    '    Dim nProw As Integer = 0
    '    Dim nHal As Integer = 0
    '    Dim NoUrut As Integer = 0
    '    Dim mDIV As String = ""
    '    Dim sw As New IO.StreamWriter(Application.StartupPath & "\TempCetakDraftRetur.TXT", False)

    '    sw.WriteLine(Chr(27) & "x" & "0" & Chr(27) & "M" + Chr(15))

    '    'SETENGAH PLY
    '    sw.Write(Chr(27) & "C" & Chr(33))
    '    For i As Short = 0 To dt.Rows.Count - 1
    '        If nProw = 0 Then
    '            nHal += 1
    '            If nHal < 2 Then
    '                sw.WriteLine(Chr(27) & "W" & "0")
    '                sw.WriteLine((cDC_KODE & "-" & cDC_NAMA).PadRight(104) & Format(Now, "dd/MM/yyyy"))
    '                'sw.WriteLine(Chr(14) & Chr(27) & "W" & "1")
    '                sw.Write(Chr(14) + (Chr(27) + "W" + "1"))
    '                sw.WriteLine(strCenter("DRAFT RETUR SUPPLIER", 65))
    '                'sw.WriteLine(Chr(20) & Chr(27) & "W" & "0")
    '                sw.WriteLine(Chr(20) + (Chr(27) + "W" + "0"))
    '                sw.WriteLine(strCenter("Supplier : " & CmbSupco.Text & "-" & CmbNama.Text, 120))
    '                'sw.WriteLine(strCenter("Nomor PB BKL : " & nDocno & "/Tgl. : " & Format(Now, "dd/MM/yyyy"), 120))
    '                sw.WriteLine(("Halaman: " & CType(nHal, String).PadLeft(2)).PadLeft(108))
    '                nProw += 7
    '            Else
    '                'sw.WriteLine(("PB Kirim Langsung No. : " & nDocno).PadRight(108) & "Halaman: " & CType(nHal, String).PadLeft(2))
    '                sw.WriteLine((" ").PadRight(108) & "Halaman: " & CType(nHal, String).PadLeft(2))
    '                nProw += 1
    '            End If

    '            sw.WriteLine("-".PadRight(120, "-"))
    '            sw.WriteLine("|  No. |   PLU    |  Nama Barang dan Spesifikasi                              | Kuantitas |  Aktual  |    Keterangan    |")
    '            sw.WriteLine("|-----------------------------------------------------------------------------|-----------|----------|------------------|")
    '            nProw += 3
    '        End If
    '        NoUrut += 1
    '        sw.Write("| " & CType(NoUrut, String).PadLeft(3) & ". | ")
    '        If (dt.Rows(i)("PRDCD")).ToString.Length = 4 Then
    '            sw.Write(dt.Rows(i)("PRDCD") & "     |  ")
    '        Else
    '            sw.Write(dt.Rows(i)("PRDCD") & " |  ")
    '        End If
    '        sw.Write(CType("" & dt.Rows(i)("NAMA"), String).PadRight(50).Substring(0, 50) & "   ")
    '        sw.Write(CType(" ", String).PadRight(6).Substring(0, 6) & "  | ")
    '        sw.WriteLine(CType(Format(dt.Rows(i)("QTY"), "#,##0"), String).PadLeft(9) & " | " & "".PadRight(8) & " | " & "".PadRight(17) & "|")
    '        nProw += 1
    '        If nProw >= 28 Then
    '            sw.WriteLine("|" & "-".PadRight(119, "-") & "|")
    '            nProw = 0
    '            'EJECT
    '            sw.Write(Chr(12) + Chr(13))
    '        End If
    '    Next
    '    'sw.WriteLine("|" & "-".PadRight(119, "-") & "|")
    '    'sw.WriteLine(("|".PadRight(16) & ("Disetujui :").PadRight(93 - 16) & "Dicetak :").PadRight(120) & "|")
    '    'sw.WriteLine("|" & " ".PadRight(119) & "|")
    '    'sw.WriteLine("|" & " ".PadRight(119) & "|")
    '    'sw.WriteLine("|" & " ".PadRight(119) & "|")
    '    'sw.WriteLine(("|".PadRight(16) & ("___________").PadRight(93 - 16) & "_________").PadRight(120) & "|")
    '    'sw.WriteLine(("|".PadRight(12) & ("Chief of Store/Asst").PadRight(93 - 12) & "         ").PadRight(120) & "|")
    '    sw.WriteLine("-" & "-".PadRight(119, "-") & "-")
    '    sw.Write(Chr(12) + Chr(13))
    '    sw.Write(Chr(18))
    '    sw.Flush()
    '    sw.Close()

    '    ''''''''''''
    '    Dim sr As New IO.StreamReader(Application.StartupPath & "\TempCetakDraftRetur.TXT")
    '    DoPr(sr.ReadToEnd, nmPrinter)
    '    sr.Close()
    'End Sub
    Private Sub Cetak_DrafRetur(ByVal dt As DataTable, ByVal nmPrinter As String)
        'Cetak PB BKL
        Dim nProw As Integer = 0
        Dim nHal As Integer = 0
        Dim NoUrut As Integer = 0
        Dim mDIV As String = ""
        Dim sw As New IO.StreamWriter(Application.StartupPath & "\TempCetakDraftRetur.TXT", False)

        sw.WriteLine(Chr(27) & "x" & "0" & Chr(27) & "M" + Chr(15))

        'SETENGAH PLY
        sw.Write(Chr(27) & "C" & Chr(33))
        For i As Short = 0 To dt.Rows.Count - 1
            If nProw = 0 Then
                nHal += 1
                If nHal < 2 Then
                    sw.WriteLine(Chr(27) & "W" & "0")
                    sw.WriteLine((cDC_KODE & "-" & cDC_NAMA).PadRight(104) & Format(Now, "dd/MM/yyyy"))
                    'sw.WriteLine(Chr(14) & Chr(27) & "W" & "1")
                    sw.Write(Chr(14) + (Chr(27) + "W" + "1"))
                    sw.WriteLine(strCenter("DRAFT RETUR SUPPLIER", 65))
                    'sw.WriteLine(Chr(20) & Chr(27) & "W" & "0")
                    sw.WriteLine(Chr(20) + (Chr(27) + "W" + "0"))
                    sw.WriteLine(strCenter("Supplier : " & CmbSupco.Text & "-" & CmbNama.Text, 120))
                    'sw.WriteLine(strCenter("Nomor PB BKL : " & nDocno & "/Tgl. : " & Format(Now, "dd/MM/yyyy"), 120))
                    sw.WriteLine(("Halaman: " & CType(nHal, String).PadLeft(2)).PadLeft(108))
                    nProw += 7
                Else
                    'sw.WriteLine(("PB Kirim Langsung No. : " & nDocno).PadRight(108) & "Halaman: " & CType(nHal, String).PadLeft(2))
                    sw.WriteLine((" ").PadRight(108) & "Halaman: " & CType(nHal, String).PadLeft(2))
                    nProw += 1
                End If

                sw.WriteLine("-".PadRight(120, "-"))
                sw.WriteLine("|  No. |   PLU    | Nama Barang dan Spesifikasi                               | Kuantitas |  Aktual  |    Keterangan    |")
                sw.WriteLine("|-----------------------------------------------------------------------------|-----------|----------|------------------|")
                nProw += 3
            End If
            NoUrut += 1
            sw.Write("| " & CType(NoUrut, String).PadLeft(3) & ". | ")
            sw.Write(IIf(dt.Rows(i)("PRDCD").Length = 4, "  " & dt.Rows(i)("PRDCD") & "   | ", dt.Rows(i)("PRDCD") & " | "))
            'sw.Write(dt.Rows(i)("PRDCD") & " |  ")
            sw.Write(CType("" & dt.Rows(i)("NAMA"), String).PadRight(55).Substring(0, 50) & "")
            sw.Write(CType(" ", String).PadRight(6).Substring(0, 6) & "  | ")
            sw.WriteLine(CType(Format(dt.Rows(i)("QTY"), "#,##0"), String).PadLeft(9) & " | " & "".PadRight(8) & " | " & "".PadRight(17) & "|")
            nProw += 1
            If nProw >= 28 Then
                sw.WriteLine("|" & "-".PadRight(119, "-") & "|")
                nProw = 0
                'EJECT
                sw.Write(Chr(12) + Chr(13))
            End If
        Next
        'sw.WriteLine("|" & "-".PadRight(119, "-") & "|")
        'sw.WriteLine(("|".PadRight(16) & ("Disetujui :").PadRight(93 - 16) & "Dicetak :").PadRight(120) & "|")
        'sw.WriteLine("|" & " ".PadRight(119) & "|")
        'sw.WriteLine("|" & " ".PadRight(119) & "|")
        'sw.WriteLine("|" & " ".PadRight(119) & "|")
        'sw.WriteLine(("|".PadRight(16) & ("___________").PadRight(93 - 16) & "_________").PadRight(120) & "|")
        'sw.WriteLine(("|".PadRight(12) & ("Chief of Store/Asst").PadRight(93 - 12) & "         ").PadRight(120) & "|")
        sw.WriteLine("-" & "-".PadRight(119, "-") & "-")
        sw.Write(Chr(12) + Chr(13))
        sw.Write(Chr(18))
        sw.Flush()
        sw.Close()

        ''''''''''''
        Dim sr As New IO.StreamReader(Application.StartupPath & "\TempCetakDraftRetur.TXT")
        DoPr(sr.ReadToEnd, nmPrinter)
        sr.Close()
    End Sub
    Private Sub CmbSupco_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles CmbSupco.Leave
        'If CmbSupco.Text.Length >= 4 And CmbNama.Items.Count > 0 Then
        '    Dim idx As Integer = CmbSupco.Items.IndexOf(CmbSupco.Text.ToUpper)
        '    If idx >= 0 Then
        '        CmbNama.Text = CmbNama.Items.Item(idx)
        '    End If
        'End If
    End Sub

    Private Sub CmbNama_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles CmbNama.Leave
        'Dim idx As Integer = CmbNama.Items.IndexOf(CmbNama.Text.ToUpper)
        'If idx >= 0 Then
        '    CmbSupco.Text = CmbSupco.Items.Item(idx)
        'End If
    End Sub

    Private Sub CmbNama_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CmbNama.TextChanged
        'Dim tes As String = CmbNama.Text
        'tes = tes.Trim
        'CmbNama.Text = tes.ToUpper
        'CmbNama.SelectionStart = tes.Length - 1
    End Sub

    Private Sub CmbSupco_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CmbSupco.TextChanged
        'CmbSupco.Text = CmbSupco.Text.ToUpper
        'CmbSupco.SelectionStart = CmbSupco.Text.Length
    End Sub
End Class