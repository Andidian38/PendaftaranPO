﻿Imports Microsoft.Reporting.WinForms
Imports System.Net
Imports Oracle.ManagedDataAccess.Client
Imports System.Data


Public Class frmCetak
    Public REPORT As String = ""
    Public TGL As String = ""
    Public NOPO_Report As String = ""
    Public dt_Report As DataTable
    Dim rds As ReportDataSource
    Dim erClose As Boolean = False
    Dim IP As String = getIP().Replace(".", "")
    Dim strkoneksiotp As String = getStrKoneksiODP()
    Dim DCKODE As String = execScalar("select tbl_dc_kode from dc_tabel_dc_t", STRKONEKSIODP)
    Dim DCNAMA As String = execScalar("select tbl_dc_kode || ' - ' || tbl_dc_nama from dc_tabel_dc_t", STRKONEKSIODP)
    Function getIP() As String
        For Each ip As IPAddress In Dns.GetHostEntry(Dns.GetHostName()).AddressList
            ' Eg: Display with message box
            If ip.AddressFamily = System.Net.Sockets.AddressFamily.InterNetwork Then
                Return ip.ToString()
                ' TODO: might not be correct. Was : Exit For
                Exit For
            End If
        Next
        Return IP
    End Function
    Public Function execScalar(ByVal Query As String, ByVal conStr As String) As String
        Dim connection As New OracleConnection(conStr)
        Dim cmd As New OracleCommand("", connection)
        Dim adapter As New OracleDataAdapter
        Try
            If connection.State = ConnectionState.Open Then
                connection.Close()
            End If
            connection.Open()
            'Buat data adapter
            cmd = New OracleCommand(Query, connection)
            execScalar = cmd.ExecuteScalar() 'IIf(IsDBNull(cmd.ExecuteScalar()), 0, cmd.ExecuteScalar())
            Return execScalar
        Catch ex As Exception
            Return "-_GAGAL_-" & ex.Message
        Finally
            connection.Close()
        End Try
    End Function
    Private Sub CetakReport_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        CetakReport(REPORT)
        Me.rptviewer.RefreshReport()
        Me.BringToFront()
        If erClose = True Then
            Me.Close()
        End If
        Me.rptviewer.RefreshReport()
    End Sub
    Sub CetakReport(ByVal report As String)
        'Dim rp1 As ReportParameter = New ReportParameter("DC_KODE", DCNAMA)
        'Dim rp2 As ReportParameter = New ReportParameter("P_TGL", TGL)
        'Dim rp3 As ReportParameter = New ReportParameter("P_DIV", DIV)
        Try
            Me.Size = New Size(1110, 550) ' dc_allstok_bacth_dc_t + dc_setup_obat_t
            Dim dt_report As DataTable = getDS(" SELECT nm_sikttk AS NAMAFASILITAS," &
                                                " 	   jbt_sikttk AS ALAMATKANTOR," &
                                                " 	   NO_sikttk AS NOIZINFASILITAS," &
                                                " 	   SATUAN AS BULAN," &
                                                " 	   ZAT_AKTIF AS KODEPOS," &
                                                " 	   fmbentuk AS TANGGAL," &
                                                " 	   NM_BARANG AS NAMAOBAT," &
                                                " 	   FMBENTUK AS BENTUK," &
                                                " 	   QTY_PCS AS STOKAWAL," &
                                                " 	   '' AS TGLPEMASUKAN," &
                                                " 	   '' AS JUMLAHPEMASUKAN," &
                                                " 	   '' AS NOBETSPEMASUKAN," &
                                                " 	   qty_pcs AS JUMLAHPENYERAHAN," &
                                                " 	   QTY_PCS-(po_frac *frac) AS STOKAKHIR," &
                                                " 	   KETER AS KETERANGAN," &
                                                " 	   NM_SIKTTK AS NAMAPENANGGUNGJAWAB," &
                                                " 	   NO_SIKTTK AS NOPENANGGUNGJAWAB," &
                                                " 	   tbl_dc_kode, no_spobat, tgl_spobat, no_po, tgl_po, no_pb, tgl_pb," &
                                                "        supid, supkode, flag_cetak, last_cetak, hdr_id, nm_sikttk, jbt_sikttk," &
                                                "        no_sikttk, noijin_tkobat, kota_tkobat, hdr_fk_id, pluid, qty_pcs," &
                                                "        nm_barang, zat_aktif, fmbentuk, satuan, keter, frac, po_frac" &
                                                "   FROM DC_SPOBAT_HDR_T a, DC_SPOBAT_DTL_T b" &
                                                "  WHERE no_po = '" & NOPO_Report & "' AND hdr_id = hdr_fk_id", STRKONEKSIODP).Tables(0)
            Dim Jum As Integer = dt_report.Rows.Count
            If Jum > 0 Then
                rptviewer.Reset()
                rptviewer.LocalReport.ReportPath = "rptSPTOBATPRECURSOR.rdlc"
                rptviewer.ProcessingMode = Microsoft.Reporting.WinForms.ProcessingMode.Local
                rptviewer.LocalReport.DataSources.Clear()
                Dim rds As New ReportDataSource
                rds.Name = "DS_OBATPREKURSOR"
                rds.Value = dt_report
                rptviewer.LocalReport.DataSources.Add(rds)
                'rptviewer.LocalReport.SetParameters(New ReportParameter() {rp1})
                'rptviewer.LocalReport.SetParameters(New ReportParameter() {rp2})
                'rptviewer.LocalReport.SetParameters(New ReportParameter() {rp3})
                rptviewer.LocalReport.Refresh()
            Else
                rptviewer.Reset()
                rptviewer.LocalReport.Refresh()
                MessageBox.Show("Tidak ada data...", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
                erClose = True
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            erClose = True
        End Try
        Me.rptviewer.RefreshReport()
    End Sub



End Class