﻿Imports System.Data
Imports IDM.Fungsi
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.Drawing.Printing.PaperSize
Imports Oracle.ManagedDataAccess.Client


Public Class frmLoadPO
    Inherits System.Windows.Forms.Form
    Public sNoPo As String
    Public nQTY As Integer
    Public nItem As Integer
    Public nGROSS As Double
    Public nPPN As Double
    Public nIdDaftarPO As Integer
    Public CurRow As String
    Public JumRow As String
    Public FAKTUR As String
    Public SUPCO As String
    Public SNAMA As String
    Public ITEMnya As String
    Public NoAntrian As String
    Public tglDaftar As Date
    Public tglFaktur As Date
    Public RUPIAH As String
    Public NOMOBIL As String
    Public adaPO As String
    Public adaHarga As String
    Private lNoClose As Boolean = False
    Public saveLoadPO As String
    Public NOURUT, cancelLoadPO As String
    Public nomsg As String

    Public bindingSource1 As BindingSource = New BindingSource()
    Public dt1 As New DataTable


    Private Sub frmLoadPO_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'sNoPo = frmDaftarPO.txtNo_PO.Text

        updt_inisial()

    End Sub


    Public Function execScalar(ByVal Query As String, ByVal conStr As String) As String
        Dim connection As New OracleConnection(conStr)
        Dim cmd As New OracleCommand("", connection)
        Dim adapter As New OracleDataAdapter
        Try
            If connection.State = ConnectionState.Open Then
                connection.Close()
            End If
            connection.Open()
            'Buat data adapter
            cmd = New OracleCommand(Query, connection)
            execScalar = cmd.ExecuteScalar() 'IIf(IsDBNull(cmd.ExecuteScalar()), 0, cmd.ExecuteScalar())
            Return execScalar
        Catch ex As Exception
            Return "-_GAGAL_-" & ex.Message
        Finally
            connection.Close()
        End Try
    End Function
    Sub updt_inisial()

        Dim cek_poppn As String = execScalar("SELECT nvl(cek_poppn('" & sNoPo & "'),'OK') FROM dual", ConStrORA)
        If cek_poppn <> "OK" Then
            If MessageBox.Show(cek_poppn, "Konfirmasi", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.No Then
                Exit Sub
            End If
        End If


        dgvLoadPO.Rows.Clear()
        'PO OBAT GA BISA DI EDIT

        Dim cekObat As String = execScalar(" SELECT count(*)" &
                        "   FROM DC_PO_T a, DC_PODTL_T b" &
                        "  WHERE po_no_po = '" & sNoPo & "'" &
                        "    AND po_no_po = podtl_fk_no_po" &
                        "    AND podtl_plu IN (SELECT DISTINCT mbr_fk_pluid" &
                        "                                 FROM DC_BARANG_DC_T" &
                        "                                WHERE mbr_tgl_plumati IS NULL" &
                        "                                  AND mbr_obat IS NOT NULL)", ConStrORA)
        If cekObat <> "0" Then
            dgvLoadPO.Enabled = False
        Else
            dgvLoadPO.Enabled = True
        End If

        Dim SQL As String

        ' kasus lombok jd harus matiin optimizer use feedback 14/3/2017 /*+OPT_PARAM(_'OPTIMIZER_USE_FEEDBACK' 'FALSE)*/
        SQL = " SELECT    "
        SQL &= "PO.PO_NO_PO "
        SQL &= ",PODTL_PLU as PRDCD "
        SQL &= ",BRG.MBR_FULL_NAMA AS DESKRIPSI "
        SQL &= ",IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG) as BolehBPB "
        SQL &= ",IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*PODTL_QTYB as FracAsal "
        SQL &= ",IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*PODTL_QTYB as Frac "
        SQL &= ",PODTL_ISI_SATB AS Satuan "
        SQL &= ",0 AS Unit "
        SQL &= ",trunc(PODTL_PRICE,8) as PODTL_PRICE "
        SQL &= ",trunc(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*PODTL_QTYB"
        SQL &= "	*PODTL_ISI_SATB*PODTL_PRICE,8) as PO_GROSS "
        SQL &= ",trunc(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*PODTL_PPN,8) as PO_PPNAsal "
        SQL &= ",trunc(CASE WHEN PODTL_PPN > 0 THEN (IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)"
        SQL &= "	*((PODTL_QTYB*PODTL_ISI_SATB*PODTL_PRICE"
        SQL &= "	-((PODTL_QTYB*PODTL_ISI_SATB)"
        SQL &= "	/((PODTL_QTYB*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
        SQL &= "	*NVL(TotDisc,0)))*(Nvl(podtl_ppn_persen,getppnnew(null)) / 100))) ELSE 0 END,8) as PO_PPN "
        SQL &= ",trunc((PODTL_QTYB*PODTL_ISI_SATB)+PODTL_FRAC_QTYB,8) as PembagiDisc "
        SQL &= ",trunc(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*NVL(TotDisc,0),8) AS PO_DISCAsal "
        SQL &= ",trunc(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*((PODTL_QTYB*PODTL_ISI_SATB)"
        SQL &= "	/((PODTL_QTYB*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
        SQL &= "	*NVL(TotDisc,0)),8) AS PO_DISC "
        SQL &= ",trunc(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*NVL(PODTL_PPN_BTL,0),8) AS PPN_BOTOLAsal "
        SQL &= ",trunc(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*((PODTL_QTYB*PODTL_ISI_SATB)"
        SQL &= "	/((PODTL_QTYB*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
        SQL &= "	*NVL(PODTL_PPN_BTL,0)),8) AS PPN_BOTOL "
        SQL &= ",IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*NVL(BNS.POBNS_QTY,0) AS QTYBONUSAsal "
        SQL &= ",trunc(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*((PODTL_QTYB*PODTL_ISI_SATB)"
        SQL &= "	/((PODTL_QTYB*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
        SQL &= "	*NVL(BNS.POBNS_QTY,0)),8) AS QTYBONUS, MBR_TAG, DECODE(istag_bolehbpb(" & cDC_ID & ", mbr_tag), 1, '', 'Y')  as EXTAG "
        SQL &= "    ,NVL(podtl_ppn_persen,Getppnnew(NULL)) as PPN_RATE "
        SQL &= "FROM DC_PO_T PO "
        SQL &= "LEFT JOIN DC_PODTL_T DT ON PO.PO_NO_PO = DT.PODTL_FK_NO_PO "
        SQL &= "LEFT JOIN ("
        SQL &= "	SELECT MBR_FK_PLUID,(MBR_TAG) AS MBR_TAG,"
        SQL &= "		(MBR_FULL_NAMA) as MBR_FULL_NAMA "
        SQL &= "	FROM DC_BARANG_DC_V WHERE TBL_DC_KODE='" & cDC_KODE & "') BRG "
        SQL &= "	ON DT.PODTL_PLUMD=BRG.MBR_FK_PLUID "
        SQL &= "LEFT JOIN ("
        SQL &= "	SELECT podisc_fk_no_po,PODISC_FK_PLU, "
        SQL &= "		SUM(NVL(podisc_nilai,0)) AS TotDisc "
        SQL &= "	FROM DC_PODISC_T "
        SQL &= "	GROUP BY podisc_fk_no_po,PODISC_FK_PLU) S "
        SQL &= "	ON PO.PO_NO_PO=S.podisc_fk_no_po AND DT.PODTL_PLUMD=S.PODISC_FK_PLU "
        SQL &= "LEFT JOIN ("
        SQL &= "	SELECT pobns_fk_no_po,POBNS_FK_PLU,nvl(POBNS_QTY,0) as POBNS_QTY "
        SQL &= "	from DC_POBNS_T) BNS ON  "
        SQL &= "	PO.PO_NO_PO=BNS.pobns_fk_no_po AND DT.PODTL_PLUMD=BNS.POBNS_FK_PLU "
        SQL &= "    ,(SELECT EX_TAG_BPB FROM DC_EXCLUDE_TAG_T) EXTAG "
        SQL &= "WHERE ((PODTL_RECID IS NULL OR PODTL_RECID='') AND PODTL_NO_BPB IS NULL) "
        SQL &= "AND PO_NO_PO='" & sNoPo & "'"
        SQL &= "order by prdcd "

        dgvLoadPO.DataSource = Nothing
        dgvLoadPO.Rows.Clear()
        dt1.Clear()
        dt1 = getDS(SQL, ConStrORA).Tables(0)
        'bindingSource1.DataSource = dt1
        'dgvLoadPO.DataSource = dt1
        isiDGVNew()
        Dim ListPLUTAGY As String = ""
        For i As Integer = 0 To dt1.Rows.Count - 1
            dgvLoadPO.Rows.Add()
            dgvLoadPO.Rows(i).Cells("PRDCD").Value = dt1.Rows(i)(1).ToString
            Dim dt_cekfracplu As New DataTable
            dt_cekfracplu = getDS("SELECT nvl(sum(frac),0) FROM dc_trnbpb_dtl_t WHERE plu_id = '" & dt1.Rows(i)(1).ToString & "' and no_po ='" & sNoPo & "'", ConStrORA).Tables(0)
            Dim cekfrac As String = dt_cekfracplu.Rows(0)(0).ToString
            If cekfrac <> 0 Then
                dgvLoadPO.Rows(i).Cells("FRAC").Value = 0
                Dim dt_cek_posisiqty As New DataTable
                dt_cek_posisiqty = getDS("SELECT b.no_faktur" &
                            "   FROM dc_trnbpb_dtl_t a, dc_trnbpb_hdr_t b" &
                            "  WHERE b.no_po = '" & sNoPo & "'" &
                            "    AND b.hdr_id = a.hdr_fk_id" &
                            "    AND a.plu_id = '" & dt1.Rows(i)(1).ToString & "'" &
                            "    AND a.qty <> 0", ConStrORA).Tables(0)
                dgvLoadPO.Rows(i).Cells("FRAC").ToolTipText = "Sudah diisi pada faktur " & dt_cek_posisiqty.Rows(0)(0).ToString & " dengan Jumlah Qty = " & cekfrac
                dgvLoadPO.Rows(i).Cells("FRAC").ReadOnly = True
                dgvLoadPO.Rows(i).Cells("FRAC").Style.BackColor = Color.LightGray
            Else
                dgvLoadPO.Rows(i).Cells("FRAC").Value = dt1.Rows(i)(5).ToString
            End If
            '            dgvLoadPO.Rows(i).Cells("FRAC").Value = dt1.Rows(i)(5).ToString
            dgvLoadPO.Rows(i).Cells("PO_GROSS").Value = dt1.Rows(i)(9).ToString
            dgvLoadPO.Rows(i).Cells("PO_PPN").Value = dt1.Rows(i)(11).ToString
            dgvLoadPO.Rows(i).Cells("PO_DISC").Value = dt1.Rows(i)(14).ToString
            dgvLoadPO.Rows(i).Cells("UNIT").Value = dt1.Rows(i)(7).ToString
            dgvLoadPO.Rows(i).Cells("QTYBONUS").Value = dt1.Rows(i)(18).ToString
            dgvLoadPO.Rows(i).Cells("DESKRIPSI").Value = dt1.Rows(i)(2).ToString
            dgvLoadPO.Rows(i).Cells("FRACT").Value = dt1.Rows(i)(6).ToString
            dgvLoadPO.Rows(i).Cells("PODTL_PRICE").Value = dt1.Rows(i)(8).ToString
            dgvLoadPO.Rows(i).Cells("PO_PPNAsal").Value = dt1.Rows(i)(10).ToString
            dgvLoadPO.Rows(i).Cells("PEMBAGIDISC").Value = dt1.Rows(i)(12).ToString
            dgvLoadPO.Rows(i).Cells("PO_DISCAsal").Value = dt1.Rows(i)(13).ToString
            dgvLoadPO.Rows(i).Cells("PPN_BOTOL").Value = dt1.Rows(i)(16).ToString
            dgvLoadPO.Rows(i).Cells("PPN_BOTOLAsal").Value = dt1.Rows(i)(15).ToString
            dgvLoadPO.Rows(i).Cells("FRACASAL").Value = dt1.Rows(i)(4).ToString
            dgvLoadPO.Rows(i).Cells("PCSBPB").Value = dt1.Rows(i)(6) * dgvLoadPO.Rows(i).Cells("FRAC").Value
            dgvLoadPO.Rows(i).Cells("PCSPO").Value = dt1.Rows(i)(6) * dt1.Rows(i)(4)
            dgvLoadPO.Rows(i).Cells("QTYBONUSASAL").Value = dt1.Rows(i)(17).ToString
            dgvLoadPO.Rows(i).Cells("MBRTAG").Value = dt1.Rows(i)("MBR_TAG").ToString
            dgvLoadPO.Rows(i).Cells("EXTAG").Value = dt1.Rows(i)("EXTAG").ToString
            ' dgvLoadPO.Rows(i).Cells("PPN_RATE").Value = dt1.Rows(i)("PPN_RATE").ToString 
            If dt1.Rows(i)("EXTAG").ToString = "Y" Then
                dgvLoadPO.Rows(i).Cells("PCSBPB").Value = "0"
                dgvLoadPO.Rows(i).ReadOnly = True
                dgvLoadPO.Rows(i).DefaultCellStyle.BackColor = Color.LightGray
            End If
        Next
        Dim a As String = dgvLoadPO.Rows(0).Cells("FRACT").Value
    End Sub
    Private Sub isiDGVNew()

        With dgvLoadPO
            .Columns(0).HeaderText = "PLU"
            .Columns(0).Width = 100
            .Columns(0).ReadOnly = True
            .Columns(0).Visible = True
            .Columns(0).DataPropertyName = "PRDCD"
            .Columns(0).Name = "PRDCD"
            .Columns(0).DefaultCellStyle.BackColor = Color.LightGray


            .Columns(1).HeaderText = "Qty BPB"
            .Columns(1).Width = 100
            .Columns(1).ReadOnly = False
            .Columns(1).Visible = True
            .Columns(1).DataPropertyName = "FRAC"
            .Columns(1).Name = "FRAC"

            .Columns(2).HeaderText = "Qty pcs BPB"
            .Columns(2).Width = 100
            .Columns(2).ReadOnly = True
            .Columns(2).Visible = True
            .Columns(2).DataPropertyName = "PCSBPB"
            .Columns(2).Name = "PCSBPB"
            .Columns(2).DefaultCellStyle.BackColor = Color.LightGray

            .Columns(3).HeaderText = "Qty PO"
            .Columns(3).Width = 100
            .Columns(3).ReadOnly = True
            .Columns(3).Visible = True
            .Columns(3).DataPropertyName = "FRACASAL"
            .Columns(3).Name = "FRACASAL"
            .Columns(3).DefaultCellStyle.BackColor = Color.LightGray

            .Columns(4).HeaderText = "Qty pcs PO"
            .Columns(4).Width = 100
            .Columns(4).ReadOnly = True
            .Columns(4).Visible = True
            .Columns(4).DataPropertyName = "PCSPO"
            .Columns(4).Name = "PCSPO"
            .Columns(4).DefaultCellStyle.BackColor = Color.LightGray

            .Columns(5).HeaderText = "Deskripsi"
            .Columns(5).Width = 300
            .Columns(5).ReadOnly = True
            .Columns(5).Visible = True
            .Columns(5).DataPropertyName = "DESKRIPSI"
            .Columns(5).Name = "DESKRIPSI"
            .Columns(5).DefaultCellStyle.BackColor = Color.LightGray

            .Columns(6).HeaderText = "TAG"
            .Columns(6).Width = 100
            .Columns(6).ReadOnly = True
            .Columns(6).Visible = True
            .Columns(6).DataPropertyName = "MBRTAG"
            .Columns(6).Name = "MBRTAG"
            .Columns(6).DefaultCellStyle.BackColor = Color.LightGray

            .Columns(7).HeaderText = "F_EXCBPB"
            .Columns(7).Width = 100
            .Columns(7).ReadOnly = True
            .Columns(7).Visible = True
            .Columns(7).DataPropertyName = "EXTAG"
            .Columns(7).Name = "EXTAG"
            .Columns(7).DefaultCellStyle.BackColor = Color.LightGray


            .Columns(8).HeaderText = "FRAC"
            .Columns(8).Width = 100
            .Columns(8).ReadOnly = True
            .Columns(8).Visible = True
            .Columns(8).DataPropertyName = "FRACT"
            .Columns(8).Name = "FRACT"
            .Columns(8).DefaultCellStyle.BackColor = Color.LightGray

            .Columns(9).HeaderText = "Nilai"
            .Columns(9).Width = 100
            .Columns(9).ReadOnly = True
            .Columns(9).Visible = False
            .Columns(9).DataPropertyName = "PO_GROSS"
            .Columns(9).Name = "PO_GROSS"
            .Columns(9).DefaultCellStyle.BackColor = Color.LightGray

            .Columns(10).HeaderText = "PPn"
            .Columns(10).Width = 0
            .Columns(10).ReadOnly = True
            .Columns(10).Visible = False
            .Columns(10).DataPropertyName = "PO_PPN"
            .Columns(10).Name = "PO_PPN"
            .Columns(10).DefaultCellStyle.BackColor = Color.LightGray

            .Columns(11).HeaderText = "Tot. Disc"
            .Columns(11).Width = 0
            .Columns(11).ReadOnly = True
            .Columns(11).Visible = False
            .Columns(11).DataPropertyName = "PO_DISC"
            .Columns(11).Name = "PO_DISC"
            .Columns(11).DefaultCellStyle.BackColor = Color.LightGray

            .Columns(12).HeaderText = "Unit"
            .Columns(12).Width = 100
            .Columns(12).ReadOnly = True
            .Columns(12).Visible = True
            .Columns(12).DataPropertyName = "UNIT"
            .Columns(12).Name = "UNIT"
            .Columns(12).DefaultCellStyle.BackColor = Color.LightGray

            .Columns(13).HeaderText = "Bonus"
            .Columns(13).Width = 100
            .Columns(13).ReadOnly = True
            .Columns(13).Visible = True
            .Columns(13).DataPropertyName = "QTYBONUS"
            .Columns(13).Name = "QTYBONUS"
            .Columns(13).DefaultCellStyle.BackColor = Color.LightGray

            .Columns(14).HeaderText = "PoNoPo"
            .Columns(14).Width = 0
            .Columns(14).Visible = False
            .Columns(14).DataPropertyName = "PO_NO_PO"
            .Columns(14).Name = "PO_NO_PO"

            .Columns(15).HeaderText = "SATUAN"
            .Columns(15).Width = 0
            .Columns(15).Visible = False
            .Columns(15).DataPropertyName = "SATUAN"
            .Columns(15).Name = "SATUAN"

            .Columns(16).HeaderText = "PODTL_PRICE"
            .Columns(16).Width = 0
            .Columns(16).Visible = False
            .Columns(16).DataPropertyName = "PODTL_PRICE"
            .Columns(16).Name = "PODTL_PRICE"

            .Columns(17).HeaderText = "PEMBAGIDISC"
            .Columns(17).Width = 0
            .Columns(17).Visible = False
            .Columns(17).DataPropertyName = "PEMBAGIDISC"
            .Columns(17).Name = "PEMBAGIDISC"

            .Columns(18).HeaderText = "PO_PPNASAL"
            .Columns(18).Width = 0
            .Columns(18).Visible = False
            .Columns(18).DataPropertyName = "PO_PPNASAL"
            .Columns(18).Name = "PO_PPNASAL"

            .Columns(19).HeaderText = "PO_DISCASAL"
            .Columns(19).Width = 0
            .Columns(19).Visible = False
            .Columns(19).DataPropertyName = "PO_DISCASAL"
            .Columns(19).Name = "PO_DISCASAL"

            .Columns(20).HeaderText = "PPN_BOTOLASAL"
            .Columns(20).Width = 0
            .Columns(20).Visible = False
            .Columns(20).DataPropertyName = "PPN_BOTOLASAL"
            .Columns(20).Name = "PPN_BOTOLASAL"

            .Columns(21).HeaderText = "PPN_BOTOL"
            .Columns(21).Width = 0
            .Columns(21).Visible = False
            .Columns(21).DataPropertyName = "PPN_BOTOL"
            .Columns(21).Name = "PPN_BOTOL"

            .Columns(22).HeaderText = "QTYBONUSASAL"
            .Columns(22).Width = 0
            .Columns(22).Visible = False
            .Columns(22).DataPropertyName = "QTYBONUSASAL"
            .Columns(22).Name = "QTYBONUSASAL"


            '.Columns(23).HeaderText = "FRAC"
            '.Columns(23).Width = 100
            '.Columns(23).Visible = True
            '.Columns(23).ReadOnly = True
            '.Columns(23).DataPropertyName = "FRACT"
            '.Columns(23).Name = "FRACT"
            '.Columns(23).DefaultCellStyle.BackColor = Color.LightGray


            '.Columns(21).HeaderText = "QTYPOPCS"
            '.Columns(21).Width = 10
            '.Columns(21).Visible = False
            '.Columns(21).DataPropertyName = "QTYPOPCS"
            '.Columns(21).Name = "QTYPOPCS"

            '.Columns.Add("Karton", "Karton")
            '.Columns.Add("Pieces", "Pieces")
            '.Columns.Add("QtyTot", "Qty Tot")
            'dgvPLU.Rows(CurRow).Cells("QtyTot").ReadOnly = "True"
        End With
    End Sub
    Private Sub isiDGV()

        With dgvLoadPO
            .Columns(0).HeaderText = "PLU"
            .Columns(0).Width = 70
            .Columns(0).ReadOnly = True
            '.Columns(0).Visible = False
            .Columns(0).DataPropertyName = "PRDCD"
            .Columns(0).Name = "PRDCD"
            .Columns(0).DefaultCellStyle.BackColor = Color.LightGray

            .Columns(1).HeaderText = "Qty pcs BPB"
            .Columns(1).Width = 50
            .Columns(1).ReadOnly = False
            .Columns(1).DataPropertyName = "PCSBPB"
            .Columns(1).Name = "PCSBPB"


            .Columns(21).HeaderText = "Qty Frac BPB"
            .Columns(21).Width = 50
            .Columns(21).ReadOnly = False
            .Columns(21).DataPropertyName = "FRAC"
            .Columns(21).Name = "FRAC"
            .Columns(21).DefaultCellStyle.BackColor = Color.LightGray

            .Columns(2).HeaderText = "Qty pcs PO"
            .Columns(2).Width = 50
            .Columns(2).ReadOnly = True
            .Columns(2).Visible = True
            .Columns(2).DataPropertyName = "PCSPO"
            .Columns(2).Name = "PCSPO"
            .Columns(2).DefaultCellStyle.BackColor = Color.LightGray

            .Columns(22).HeaderText = "Qty Frac PO"
            .Columns(22).Width = 50
            .Columns(22).ReadOnly = True
            .Columns(22).Visible = True
            .Columns(22).DataPropertyName = "FRACASAL"
            .Columns(22).Name = "FRACASAL"
            .Columns(22).DefaultCellStyle.BackColor = Color.LightGray

            .Columns(23).HeaderText = "FRAC"
            .Columns(23).Width = 50
            .Columns(23).ReadOnly = True
            .Columns(23).Visible = False
            .Columns(23).DataPropertyName = "FRACT"
            .Columns(23).Name = "FRACT"
            .Columns(23).DefaultCellStyle.BackColor = Color.LightGray


            .Columns(3).HeaderText = "Nilai"
            .Columns(3).Width = 100
            .Columns(3).ReadOnly = True
            .Columns(3).Visible = False
            .Columns(3).DataPropertyName = "PO_GROSS"
            .Columns(3).Name = "PO_GROSS"
            .Columns(3).DefaultCellStyle.BackColor = Color.LightGray

            .Columns(4).HeaderText = "PPn"
            .Columns(4).Width = 100
            .Columns(4).ReadOnly = True
            .Columns(4).Visible = False
            .Columns(4).DataPropertyName = "PO_PPN"
            .Columns(4).Name = "PO_PPN"
            .Columns(4).DefaultCellStyle.BackColor = Color.LightGray

            .Columns(5).HeaderText = "Tot. Disc"
            .Columns(5).Width = 100
            .Columns(5).ReadOnly = True
            .Columns(5).Visible = False
            .Columns(5).DataPropertyName = "PO_DISC"
            .Columns(5).Name = "PO_DISC"
            .Columns(5).DefaultCellStyle.BackColor = Color.LightGray

            .Columns(6).HeaderText = "Unit"
            .Columns(6).Width = 50
            .Columns(6).ReadOnly = True
            .Columns(9).Visible = False
            .Columns(6).DataPropertyName = "UNIT"
            .Columns(6).Name = "UNIT"
            .Columns(6).DefaultCellStyle.BackColor = Color.LightGray

            .Columns(7).HeaderText = "Bonus"
            .Columns(7).Width = 0
            .Columns(7).ReadOnly = True
            .Columns(9).Visible = False
            .Columns(7).DataPropertyName = "QTYBONUS"
            .Columns(7).Name = "QTYBONUS"
            .Columns(7).DefaultCellStyle.BackColor = Color.LightGray

            .Columns(8).HeaderText = "Deskripsi"
            .Columns(8).Width = 300
            .Columns(8).ReadOnly = True
            .Columns(8).DataPropertyName = "DESKRIPSI"
            .Columns(8).Name = "DESKRIPSI"
            .Columns(8).DefaultCellStyle.BackColor = Color.LightGray

            .Columns(9).HeaderText = "PoNoPo"
            .Columns(9).Width = 10
            .Columns(9).Visible = False
            .Columns(9).DataPropertyName = "PO_NO_PO"
            .Columns(9).Name = "PO_NO_PO"

            .Columns(10).HeaderText = "SATUAN"
            .Columns(10).Width = 10
            .Columns(10).Visible = False
            .Columns(10).DataPropertyName = "SATUAN"
            .Columns(10).Name = "SATUAN"

            .Columns(11).HeaderText = "PODTL_PRICE"
            .Columns(11).Width = 10
            .Columns(11).Visible = False
            .Columns(11).DataPropertyName = "PODTL_PRICE"
            .Columns(11).Name = "PODTL_PRICE"

            .Columns(13).HeaderText = "PEMBAGIDISC"
            .Columns(13).Width = 10
            .Columns(13).Visible = False
            .Columns(13).DataPropertyName = "PEMBAGIDISC"
            .Columns(13).Name = "PEMBAGIDISC"

            .Columns(14).HeaderText = "PO_PPNASAL"
            .Columns(14).Width = 10
            .Columns(14).Visible = False
            .Columns(14).DataPropertyName = "PO_PPNASAL"
            .Columns(14).Name = "PO_PPNASAL"

            .Columns(15).HeaderText = "PO_DISCASAL"
            .Columns(15).Width = 10
            .Columns(15).Visible = False
            .Columns(15).DataPropertyName = "PO_DISCASAL"
            .Columns(15).Name = "PO_DISCASAL"

            .Columns(16).HeaderText = "PPN_BOTOLASAL"
            .Columns(16).Width = 10
            .Columns(16).Visible = False
            .Columns(16).DataPropertyName = "PPN_BOTOLASAL"
            .Columns(16).Name = "PPN_BOTOLASAL"

            .Columns(17).HeaderText = "PPN_BOTOL"
            .Columns(17).Width = 10
            .Columns(17).Visible = False
            .Columns(17).DataPropertyName = "PPN_BOTOL"
            .Columns(17).Name = "PPN_BOTOL"

            .Columns(12).HeaderText = "QTYBONUSASAL"
            .Columns(12).Width = 10
            .Columns(12).Visible = False
            .Columns(12).DataPropertyName = "QTYBONUSASAL"
            .Columns(12).Name = "QTYBONUSASAL"


            .Columns(18).HeaderText = "FRAC"
            .Columns(18).Width = 10
            .Columns(18).Visible = True
            .Columns(18).DataPropertyName = "FRACT"
            .Columns(18).Name = "FRACT"
            .Columns(18).DefaultCellStyle.BackColor = Color.LightGray

            .Columns(19).HeaderText = "TAG"
            .Columns(19).Width = 10
            .Columns(19).Visible = True
            .Columns(19).DataPropertyName = "MBRTAG"
            .Columns(19).Name = "MBRTAG"
            .Columns(19).DefaultCellStyle.BackColor = Color.LightGray

            .Columns(20).HeaderText = "F_EXCTAG"
            .Columns(20).Width = 10
            .Columns(20).Visible = True
            .Columns(20).DataPropertyName = "EXTAG"
            .Columns(20).Name = "EXTAG"
            .Columns(20).DefaultCellStyle.BackColor = Color.LightGray


            '.Columns(21).HeaderText = "QTYPOPCS"
            '.Columns(21).Width = 10
            '.Columns(21).Visible = False
            '.Columns(21).DataPropertyName = "QTYPOPCS"
            '.Columns(21).Name = "QTYPOPCS"

            '.Columns.Add("Karton", "Karton")
            '.Columns.Add("Pieces", "Pieces")
            '.Columns.Add("QtyTot", "Qty Tot")
            'dgvPLU.Rows(CurRow).Cells("QtyTot").ReadOnly = "True"
        End With
    End Sub

    Private Sub dgvLoadPOCellBeginEdit(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellCancelEventArgs) Handles dgvLoadPO.CellBeginEdit
        Dim colName As String = dgvLoadPO.Columns(e.ColumnIndex).Name

        CurRow = Me.dgvLoadPO.CurrentRow.Index.ToString
        btnSimpan.Enabled = False

    End Sub

    Private Sub dgvLoadPOCellEndEdit(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvLoadPO.CellEndEdit
        Dim colName As String = dgvLoadPO.Columns(e.ColumnIndex).Name
        ' Dim subcellid As String
        Dim err As String = ""
        CurRow = Me.dgvLoadPO.CurrentRow.Index.ToString
        'Dim qty_po As Integer
        'Dim qty_po_ASAL As Integer
        'Dim po_gross As String
        'Dim satuan As Integer
        'Dim podtl_price As Integer
        'Dim po_ppnasal As Integer
        'Dim pembagidisc As Integer
        'Dim po_discasal As Integer
        'Dim po_ppn As Integer
        'Dim ppn_botol As Integer
        'Dim ppn_botolasal As Integer
        'Dim qtybonusasal As Integer
        'Dim qtybonus As Integer
        'Dim podisc As Integer

        Dim qty_po As String
        Dim qty_po_ASAL As String
        Dim po_gross As String
        Dim satuan As String
        Dim podtl_price As String
        Dim po_ppnasal As String
        Dim pembagidisc As String
        Dim po_discasal As String
        Dim po_ppn As String
        Dim ppn_botol As String
        Dim ppn_botolasal As String
        Dim qtybonusasal As String
        Dim qtybonus As String
        Dim podisc As String

        If Convert.IsDBNull(dgvLoadPO.Rows(CurRow).Cells("FRAC").Value) Then
            qty_po = 0
        Else
            qty_po = (dgvLoadPO.Rows(CurRow).Cells("FRAC").Value)
            dgvLoadPO.Rows(CurRow).Cells("PCSBPB").Value = dgvLoadPO.Rows(CurRow).Cells("FRACT").Value * dgvLoadPO.Rows(CurRow).Cells("FRAC").Value
        End If

        If Convert.IsDBNull(dgvLoadPO.Rows(CurRow).Cells("FRACASAL").Value) Then
            qty_po_ASAL = 0
        Else
            qty_po_ASAL = (dgvLoadPO.Rows(CurRow).Cells("FRACASAL").Value)
        End If

        If Convert.IsDBNull(dgvLoadPO.Rows(CurRow).Cells("PO_GROSS").Value) Then
            po_gross = 0
        Else
            po_gross = (dgvLoadPO.Rows(CurRow).Cells("PO_GROSS").Value)
        End If

        If Convert.IsDBNull(dgvLoadPO.Rows(CurRow).Cells("SATUAN").Value) Then
            satuan = 0
        Else
            satuan = (dgvLoadPO.Rows(CurRow).Cells("SATUAN").Value)
        End If

        If Convert.IsDBNull(dgvLoadPO.Rows(CurRow).Cells("PODTL_PRICE").Value) Then
            podtl_price = 0
        Else
            podtl_price = (dgvLoadPO.Rows(CurRow).Cells("PODTL_PRICE").Value)
        End If

        If Convert.IsDBNull(dgvLoadPO.Rows(CurRow).Cells("PO_PPNAsal").Value) Then
            po_ppnasal = 0
        Else
            po_ppnasal = (dgvLoadPO.Rows(CurRow).Cells("PO_PPNAsal").Value)
        End If

        If Convert.IsDBNull(dgvLoadPO.Rows(CurRow).Cells("PEMBAGIDISC").Value) Then
            pembagidisc = 0
        Else
            pembagidisc = (dgvLoadPO.Rows(CurRow).Cells("PEMBAGIDISC").Value)
        End If

        If Convert.IsDBNull(dgvLoadPO.Rows(CurRow).Cells("PO_DISCAsal").Value) Then
            po_discasal = 0
        Else
            po_discasal = (dgvLoadPO.Rows(CurRow).Cells("PO_DISCAsal").Value)
        End If

        If Convert.IsDBNull(dgvLoadPO.Rows(CurRow).Cells("PO_PPN").Value) Then
            po_ppn = 0
        Else
            po_ppn = (dgvLoadPO.Rows(CurRow).Cells("PO_PPN").Value)
        End If

        If Convert.IsDBNull(dgvLoadPO.Rows(CurRow).Cells("PPN_BOTOL").Value) Then
            ppn_botol = 0
        Else
            ppn_botol = (dgvLoadPO.Rows(CurRow).Cells("PPN_BOTOL").Value)
        End If

        If Convert.IsDBNull(dgvLoadPO.Rows(CurRow).Cells("PPN_BOTOLAsal").Value) Then
            ppn_botolasal = 0
        Else
            ppn_botolasal = (dgvLoadPO.Rows(CurRow).Cells("PPN_BOTOLAsal").Value)
        End If

        If Convert.IsDBNull(dgvLoadPO.Rows(CurRow).Cells("QTYBONUSAsal").Value) Then
            qtybonusasal = 0
        Else
            qtybonusasal = (dgvLoadPO.Rows(CurRow).Cells("QTYBONUSAsal").Value)
        End If

        If Convert.IsDBNull(dgvLoadPO.Rows(CurRow).Cells("QTYBONUS").Value) Then
            qtybonus = 0
        Else
            qtybonus = (dgvLoadPO.Rows(CurRow).Cells("QTYBONUS").Value)
        End If

        If Convert.IsDBNull(dgvLoadPO.Rows(CurRow).Cells("PO_DISC").Value) Then
            podisc = 0
        Else
            podisc = (dgvLoadPO.Rows(CurRow).Cells("PO_DISC").Value)
        End If

        If colName = "FRAC" Then
            'Dim dt_cekfracplu As New DataTable
            'dt_cekfracplu = getDS("SELECT nvl(sum(frac),0), Count(*)  FROM dc_trnbpb_dtl_t WHERE plu_id = '" & dgvLoadPO.Rows(CurRow).Cells("PRDCD").Value & "' and no_po ='" & sNoPo & "'", ConStrORA).Tables(0)
            'Dim cekfrac As String = dt_cekfracplu.Rows(0)(0).ToString
            'If cekfrac <> 0 Then
            '    MessageBox.Show("PLU ini sudah ada Qty di Faktur Lain..", "Perhatian!", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            '    GoTo endeditfrac
            'ElseIf dt_cekfracplu.Rows(0)(1).ToString <> 0 Then
            '    dgvLoadPO.Rows(CurRow).Cells("FRAC").Value = dt1.Rows(CurRow)(5).ToString
            'End If

            JumRow = dgvLoadPO.Rows.Count()

            If (qty_po > qty_po_ASAL) Or (qty_po_ASAL = 0) And nomsg = "" Then
                If (qty_po_ASAL = 0) Then
                    MessageBox.Show("Qty PO = 0. Item tidak bisa diedit.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Else
                    MessageBox.Show("Qty beli tidak boleh > dari pada qty PO (" & qty_po_ASAL & ")", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
                dgvLoadPO.Rows(CurRow).Cells("FRAC").Value = qty_po_ASAL
                dgvLoadPO.Rows(CurRow).Cells("PCSBPB").Value = qty_po_ASAL
                btnSimpan.Enabled = True
                Exit Sub
            End If

            If dgvLoadPO.Rows(CurRow).Cells("FRAC").Value = "" Then
                dgvLoadPO.Rows(CurRow).Cells("FRAC").Value = 0
                dgvLoadPO.Rows(CurRow).Cells("PCSBPB").Value = 0
            End If

            dgvLoadPO.Rows(CurRow).Cells("PO_GROSS").Value = qty_po * satuan * podtl_price 'PODTL_QTYB*PODTL_ISI_SATB*PODTL_PRICE
            If po_ppnasal > 0 Then
                ' Dim ppn11 As Integer = execScalar("getppnnew('" & dgvLoadPO.Rows(CurRow).Cells("PRDCD").Value & "')/100", ConStrORA)
                Dim ppn11 As Integer = execScalar("SELECT Nvl(podtl_ppn_persen,getppnnew(null))  FROM dc_podtl_t " &
                                        "WHERE podtl_fk_no_po ='" & sNoPo & "'" &
                                        "AND podtl_plu='" & dgvLoadPO.Rows(CurRow).Cells("PRDCD").Value & "' and rownum =1", ConStrORA)
                dgvLoadPO.Rows(CurRow).Cells("PO_PPN").Value = (qty_po * satuan * podtl_price - (qty_po * satuan / pembagidisc * po_discasal)) * (ppn11 / 100)
            End If
            dgvLoadPO.Rows(CurRow).Cells("PO_DISC").Value = ((qty_po * satuan / pembagidisc * po_discasal))

            dgvLoadPO.Rows(CurRow).Cells("PPN_BOTOL").Value = ((qty_po * satuan / pembagidisc * ppn_botolasal))
            'yang lama
            'rw("QTYBONUS") = ((e.ProposedValue * rw("SATUAN") / rw("PEMBAGIDISC") * rw("QTYBONUSAsal")))
            If qtybonusasal <> 0 Then
                qtybonus = 0
                MessageBox.Show("Qty Bonus di receive melalui BPB Lain-Lain !", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
            'tinggal tampilin deh nilai, ppn, to disc, bonus

            For i As Integer = 0 To JumRow - 2


            Next



        End If
endeditfrac:

        btnSimpan.Enabled = True
    End Sub

    Private Sub DGVPLU_EditingControlShowing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewEditingControlShowingEventArgs)

        If dgvLoadPO.CurrentCell.ColumnIndex = 1 Then 'kolom karton
            AddHandler CType(e.Control, TextBox).KeyPress, AddressOf TextBox_keyPress
        End If
    End Sub


    Private Sub TextBox_keyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs)
        If Char.IsDigit(CChar(CStr(e.KeyChar))) = False And e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If
    End Sub

    Private Sub btnBatal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBatal.Click
        'frmDaftarPO.SAVELOAD.Text = "BATAL"
        'frmDaftarPO.saveLoadPO = "N"
        cancelLoadPO = "!*@)(#*!"

        Me.DialogResult = DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub btnSimpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimpan.Click
        'kalo total frac = 0  langsung di skip
        'Dim colName As String = dgvLoadPO.Columns(e.ColumnIndex).Name
        '' Dim subcellid As String
        'Dim err As String = ""

        Dim KetDC As String() = getDCID_GDGID_LOKID(ConStrORA)
        Dim DCID As Integer = KetDC(0)
        Dim LocID As String = KetDC(2)
        cancelLoadPO = ""
        nomsg = ""
        CurRow = Me.dgvLoadPO.CurrentRow.Index.ToString
        Dim FRACx As Integer = dgvLoadPO.Rows(CurRow).Cells("FRAC").Value
        Dim FRACASALx As Integer = dgvLoadPO.Rows(CurRow).Cells("FRACASAL").Value
        Dim dtBolehBPB As DataTable = getDS("select istag_bolehbpb (" & DCID & ", '" & dgvLoadPO.Rows(CurRow).Cells("MBRTAG").Value & "') from dual", ConStrORA).Tables(0)
        Dim isTag As Boolean = dtBolehBPB.Rows(0)(0)
        If (FRACx > FRACASALx) Or (FRACASALx = 0 And isTag) Then
            nomsg = "(*@&#(*!&"
            dgvLoadPO.Rows(CurRow).Cells("FRAC").Value = FRACASALx
            dgvLoadPO.CurrentCell = Me.dgvLoadPO.Rows(CurRow).Cells("FRACASAL")
            'qty_po = dgvLoadPO.Rows(CurRow).Cells("FRAC_ASAL").Value
            Exit Sub
        End If

        dgvLoadPO.CurrentCell = Me.dgvLoadPO.Rows(CurRow).Cells("FRACASAL")
        Dim QTYperFAKTUR As Integer = 0
        Dim ITEMperFAKTUR As Integer = 0
        Dim PPNperFAKTUR As Double = 0.0
        For xy As Integer = 0 To dgvLoadPO.Rows.Count - 1
            QTYperFAKTUR += dgvLoadPO.Rows(xy).Cells("PCSBPB").Value
            'QTYperFAKTUR += Val(IIf(IsDBNull(dgvLoadPO.Rows(xy).Cells("FRAC").Value), 0, dgvLoadPO.Rows(xy).Cells("FRAC").Value)) * Val(IIf(IsDBNull(dgvLoadPO.Rows(xy).Cells("SATUAN").Value), 0, dgvLoadPO.Rows(xy).Cells("SATUAN").Value))
            If dgvLoadPO.Rows(xy).Cells("FRAC").Value <> 0 Then
                ITEMperFAKTUR += 1
            End If
        Next
        If QTYperFAKTUR = 0 Then
            cancelLoadPO = "!*@)(#*!"
            Me.DialogResult = DialogResult.Cancel
            Exit Sub
        End If


        'JAGAAN DIDALAM 1 PO TIDAK BOLEH ADA PLU YG SAMA PADA BEDA FAKTUR 27/01/2016
        'ambil list plu apa saja
        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Dim Scom2 As New OracleCommand("", Scon)
        Dim sql As String
        ' Dim sql2 As String  
        Dim dtpcs As New DataTable
        Dim dapcs As New OracleDataAdapter("", Scon)
        Dim dtsupa As New DataTable
        Dim dasupa As New OracleDataAdapter("", Scon)
        Dim dt As New DataTable
        Dim da As New OracleDataAdapter("", Scon)
        Dim dta As New DataTable
        Dim dap As New OracleDataAdapter("", Scon)
        Dim tampilJagaPLU As String = " sudah terdaftar difaktur No.: " & vbCrLf
        Dim Err_msg As String = ""
        Try
            Scon.Open()
            Dim plu As String = ""
            'Dim faktur As String = ""
            sql = "SELECT distinct b.plu_kode FROM dc_trnbpb_hdr_t a, dc_trnbpb_dtl_t b WHERE a.hdr_id = b.hdr_fk_id AND a.no_po = '" & sNoPo & "' AND NVL (b.qty, 0) > 0"
            dt.Clear()
            da.SelectCommand.CommandText = sql
            da.Fill(dt)
            If dt.Rows.Count > 0 Then
                For B As Integer = 0 To dt.Rows.Count - 1
                    plu = dt.Rows(B)("plu_kode")
                    'jagaan plu punya supplier terakhir di tabel harga beli 
                    '    Dim abc As String = " SELECT b.podtl_plumd " & _
                    '"   FROM DC_PO_T a, DC_PODTL_T b " & _
                    '"  WHERE a.po_no_po = b.podtl_fk_no_po " & _
                    '"    AND a.po_gudang = 'G001' " & _
                    '"    AND a.po_no_po = '4H5G31126' " & _
                    '"    AND NOT EXISTS (SELECT 1  " & _
                    '"                      FROM DC_BRG_HRGBELI_DC_T " & _
                    '"                     WHERE tbl_dc_kode = a.po_gudang " & _
                    '"                       AND mbr_fk_pluid = b.podtl_plumd " & _
                    '"                       AND mbr_supp_dc = 'Y') "

                    Dim vb As New vb
                    Dim CountSupAkhir As String = vb.execScalar(ConStrORA, "select count(*) from DC_BRG_HRGBELI_DC_T where mbr_fk_pluid = " & plu & "  AND mbr_supp_dc = 'Y'")
                    'sql_supAkhir = "select * from DC_BRG_HRGBELI_DC_T where mbr_fk_pluid = " & plu & "  AND mbr_supp_dc = 'Y'"
                    'dtsupa.Clear()
                    'dasupa.SelectCommand.CommandText = sql_supAkhir
                    'dasupa.Fill(dtsupa)
                    'If dtsupa.Rows.Count = 0 Then
                    If CountSupAkhir = 0 Then
                        'berarti supplier ga ada
                        Scon.Close()
                        Err_msg = "PLU ( " & plu & " ) tidak punya Supplier Terakhir, Hubungi MD !"
                        MessageBox.Show(Err_msg, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        'Exit Sub
                        GoTo batalLoad
                    End If
                    'jagaan plu punya mbr_pcs_beli di tabel harga beli 
                    Dim CountPCS As String = vb.execScalar(ConStrORA, "select count(*) from DC_BRG_HRGBELI_DC_T where mbr_fk_pluid = " & plu & "  AND NVL(mbr_pcs_beli,0)>0")

                    'sql_pcs = "select * from DC_BRG_HRGBELI_DC_T where mbr_fk_pluid = " & plu & "  AND NVL(mbr_pcs_beli,0)>0"
                    'dtpcs.Clear()
                    'dapcs.SelectCommand.CommandText = sql_pcs
                    'dapcs.Fill(dtpcs)
                    'If dtpcs.Rows.Count = 0 Then
                    If CountPCS = 0 Then
                        'berarti supplier ga ada
                        Scon.Close()
                        Err_msg = "Fraction PLU ( " & plu & " ) = 0, Hubungi MD !"
                        MessageBox.Show(Err_msg, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        'Exit Sub
                        GoTo batalLoad
                    End If

                    ''jagaan plu nya udah ada di faktur sebelumnya ga?
                    'sql2 = "SELECT no_faktur FROM DC_TRNBPB_HDR_T a, DC_TRNBPB_DTL_T b WHERE a.hdr_id = b.hdr_fk_id " & _
                    '       " AND a.no_po='" & sNoPo & "'AND b.plu_id=" & plu & " AND NVL(b.qty,0)>0 AND no_faktur <> '" & FAKTUR & "' "
                    'dta.Clear()
                    'dap.SelectCommand.CommandText = sql2
                    'dap.Fill(dta)
                    'If dta.Rows.Count > 0 Then
                    '    'disinicoy
                    '    'faktur = dta.Rows(0)("no_faktur")
                    '    'Scon.Close()
                    '    ''Err_msg = tampilJagaPLU
                    '    'Err_msg = "PLU " & plu & " sudah terdaftar difaktur No.: " & faktur & ""

                    '    'MessageBox.Show(Err_msg, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    '    ''Exit Sub
                    '    'GoTo batalLoad
                    'End If


                Next
                'GoTo Batal
            End If
            Scon.Close()
        Catch ex As Exception
            MessageBox.Show("Error Baca PO ", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        'batas bawah jagaan'


        '##cara baru ga pake dspo.. CEK SUDAH BENAR BELUM, DEBUG 1'1 CUY 
        '##awal daftar jalur
        '##ambil parameter nya buat daftarpo_t


        Dim connection As OracleConnection
        Dim oledbAdapter As OracleDataAdapter
        Dim dsd As New DataSet

        Dim rupiahD As String
        Dim PO_PPN As String
        Dim SUPIDD As String
        Dim PO_QTYD As String
        Dim PO_PPND As String
        ' kasus lombok jd harus matiin optimizer use feedback 14/3/2017 /*+OPT_PARAM(_'OPTIMIZER_USE_FEEDBACK' 'FALSE)*/ 
        sql = " SELECT   "
        sql &= "MAX(PO_RECID) AS RECIDx,MIN(PO_GUDANG) AS PO_GUDANG,PO.PO_NO_PO,PO.PO_EXPIRED, "
        sql &= "PO.PO_TGL_PO, PO.PO_SUPCO_MD AS SUPID, "
        sql &= "GET_SUPCO(PO.PO_SUPCO_MD)AS SUPCO, "
        sql &= "COUNT(*) AS TOT_ITEM "
        sql &= ",SUM(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*PODTL_QTYB*PODTL_ISI_SATB) AS PO_QTY "
        sql &= ",round(SUM( IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*(PODTL_QTYB*PODTL_ISI_SATB*PODTL_PRICE- "
        sql &= "   ((PODTL_QTYB*PODTL_ISI_SATB)/((PODTL_QTYB*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
        sql &= "   *NVL(TotDisc,0))) ),8) AS PO_GROSS "
        sql &= ",trunc(SUM(CASE WHEN PODTL_PPN > 0 THEN (IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)"
        sql &= "	*((PODTL_QTYB*PODTL_ISI_SATB*PODTL_PRICE-((PODTL_QTYB*PODTL_ISI_SATB)"
        sql &= "	/((PODTL_QTYB*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
        sql &= "	*NVL(TotDisc,0)))*(Nvl(podtl_ppn_persen,getppnnew(null)) / 100))) ELSE 0 END),8) AS PO_PPN "
        sql &= ",MIN(PO_UMUR) AS PO_UMUR,PO_TGL_KIRIM "
        sql &= ",trunc(SUM(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*NVL(PODTL_PPN_BTL,0)),8) AS PPN_BOTOL "
        sql &= "FROM DC_PO_T PO "
        sql &= "LEFT JOIN DC_PODTL_T DT ON PO.PO_NO_PO = DT.PODTL_FK_NO_PO "
        sql &= "LEFT JOIN ("
        sql &= "	SELECT MBR_FK_PLUID,(MBR_TAG) AS MBR_TAG "
        sql &= "	FROM DC_BARANG_DC_V WHERE TBL_DC_KODE='" & cDC_KODE & "') BRG ON DT.PODTL_PLUMD=BRG.MBR_FK_PLUID "
        sql &= "LEFT JOIN ( "
        sql &= "	SELECT podisc_fk_no_po,PODISC_FK_PLU, "
        sql &= "	SUM(NVL(podisc_nilai,0)) AS TotDisc "
        sql &= "	FROM DC_PODISC_T "
        sql &= "	GROUP BY podisc_fk_no_po,PODISC_FK_PLU) S ON PO.PO_NO_PO=S.podisc_fk_no_po "
        sql &= "	AND DT.PODTL_PLUMD=S.PODISC_FK_PLU "
        sql &= "WHERE ((PODTL_RECID IS NULL OR PODTL_RECID='') AND PODTL_NO_BPB IS NULL) "
        sql &= "AND PO_NO_PO='" & sNoPo & "' "
        sql &= "GROUP BY PO.PO_NO_PO, PO.PO_TGL_PO, PO.PO_SUPCO_MD, PO.PO_EXPIRED,PO.PO_TGL_KIRIM "


        connection = New OracleConnection(ConStrORA)
        Try
            connection.Open()
            oledbAdapter = New OracleDataAdapter(sql, connection)
            dsd.Clear()
            oledbAdapter.Fill(dsd)
            oledbAdapter.Dispose()
            connection.Close()
        Catch ex As Exception
            MsgBox("Can not open connection ! ")
        End Try

        Dim dt_TGLDAFTAR As DataTable = getDS("Select to_char(sysdate, 'MM/dd/yyyy') from dual", ConStrORA).Tables(0)

        rupiahD = dsd.Tables(0).Rows(0).Item("PO_GROSS")
        PO_PPN = dsd.Tables(0).Rows(0).Item("PO_PPN")
        SUPIDD = dsd.Tables(0).Rows(0).Item("SUPID")
        PO_QTYD = QTYperFAKTUR 'dsd.Tables(0).Rows(0).Item("PO_QTY")
        PO_PPND = dsd.Tables(0).Rows(0).Item("PO_PPN")
        Dim TANGGAL_DAFTAR As String = dt_TGLDAFTAR.Rows(0)(0).ToString 'dsd.Tables(0).Rows(0).Item("PO_TGL_PO")

        Dim lDaftarBaru As Boolean = False
        '   Dim drSup As Object

        Dim nNoUrut As Integer = NOURUT  'frmDaftarPO.NoAntrian

        '424/CPS/23 - 775/0
        'If NOURUT = "" Then
        '    nNoUrut = NextAntrian()
        '    frmDaftarPO.NoAntrian = nNoUrut
        'Else
        '    nNoUrut = NOURUT
        '    frmDaftarPO.NoAntrian = nNoUrut
        'End If


        ''cek dc_jlr_daftarjalur_t, dc_jlr_daftarpo_t, dc_trnbpb_hdr_t sudah ada belum. kalau sudah batalkan semua
        'Try
        '    Dim cekjalur As String = execScalar(" SELECT COUNT(*) FROM dc_jlr_daftarjalur_t " &
        '                                "  WHERE id_daftarjalur= '" & idDaftarJalur & "'" &
        '                                "  	AND dc_id = '" & cDC_ID & "'" &
        '                                "  	AND TRUNC(tanggal) = TRUNC(TO_DATE('" & TANGGAL_DAFTAR & "','mm/dd/yyyy')) ", ConStrORA)
        '    Dim cekpo As String = execScalar(" SELECT COUNT(*) FROM dc_jlr_daftarpo_t" &
        '                                "  WHERE  id_daftarpo ='" & idDaftarPO & "'" &
        '                                " 		AND   TRUNC(tanggal) = TRUNC(TO_DATE('" & TANGGAL_DAFTAR & "','mm/dd/yyyy')) " &
        '                                " 		AND  id_daftarjalur = '" & idDaftarJalur & "'", ConStrORA)
        '    Dim cekbpb As String = execScalar(" SELECT COUNT(*) FROM dc_trnbpb_hdr_t" &
        '                                "  WHERE  tbl_lokasiid = 124" &
        '                                " 		AND  supid = 10188" &
        '                                " 		AND  no_faktur = 123" &
        '                                " 		AND id_daftarpo = 1879422", ConStrORA)

        '    If cekjalur > 0 Or cekpo > 0 Or cekbpb > 0 Then

        '        MessageBox.Show("Pendaftaran Sudah Pernah Diinput. Cek Nomor Faktur.", "Gagal Simpan PO!", MessageBoxButtons.OK, MessageBoxIcon.Warning)


        '        Me.DialogResult = DialogResult.OK
        '        'frmDaftarPO.btn_Next(SUPCO)
        '        frmDaftarPO.btnTambahPO.Enabled = True
        '        'frmDaftarPO.showdialogLoadPO()
        '        Me.Close()
        '        Exit Sub
        '    End If

        'Catch ex As Exception

        'End Try
        'mmm kasih no antrian ini harus bawa sebuah nilai
        lDaftarBaru = True
        Dim idDaftarPO As Integer = NextIDDaftarPO()
        Dim dt_IDJALUR As DataTable = getDS(" SELECT id_daftarjalur" &
                "   FROM dc_jlr_daftarjalur_t" &
                "  WHERE dc_id = '" & cDC_ID & "' AND  nourut = " & nNoUrut & " AND supco = '" & SUPCO & "' and  trunc (tanggal) = trunc (sysdate)", ConStrORA).Tables(0)
        Dim idDaftarJalur As Integer
        If dt_IDJALUR.Rows.Count > 0 Then
            idDaftarJalur = dt_IDJALUR.Rows(0)(0).ToString
        Else
            idDaftarJalur = NextIDDaftarJalur() ''Simpan Langsung
            Try

                ''cek dc_jlr_daftarjalur_t, dc_jlr_daftarpo_t, dc_trnbpb_hdr_t sudah ada belum. kalau sudah batalkan semua
                'Dim cekjalur As String = execScalar(" SELECT COUNT(*) FROM dc_jlr_daftarjalur_t " &
                '                        "  WHERE id_daftarjalur= '" & idDaftarJalur & "'" &
                '                        "  	AND dc_id = '" & cDC_ID & "'" &
                '                        "  	AND TRUNC(tanggal) = TRUNC(TO_DATE('" & TANGGAL_DAFTAR & "','mm/dd/yyyy')) ", ConStrORA)

                'Dim cekpo As String = execScalar(" SELECT COUNT(*) FROM dc_jlr_daftarpo_t" &
                '                        "  WHERE  id_daftarpo ='" & idDaftarPO & "'" &
                '                        " 		AND   TRUNC(tanggal) = TRUNC(TO_DATE('" & TANGGAL_DAFTAR & "','mm/dd/yyyy')) " &
                '                        " 		AND  id_daftarjalur = '" & idDaftarJalur & "'", ConStrORA)
                'Dim cekbpb As String = execScalar(" SELECT COUNT(*) FROM dc_trnbpb_hdr_t" &
                '                        "  WHERE  supid = '" & SUPIDD & "'" &
                '                        " 		AND  no_faktur = '" & FAKTUR & "'" &
                '                        " 		AND id_daftarpo = '" & idDaftarPO & "'", ConStrORA)

                'If cekjalur > 0 Or cekpo > 0 Or cekbpb > 0 Then

                '    MessageBox.Show("Pendaftaran PO Sudah Pernah Diinput. Cek Nomor Faktur.", "Gagal Simpan PO!", MessageBoxButtons.OK, MessageBoxIcon.Warning)


                '    Me.DialogResult = DialogResult.OK
                '    'frmDaftarPO.btn_Next(SUPCO)
                '    frmDaftarPO.btnTambahPO.Enabled = True
                '    'frmDaftarPO.showdialogLoadPO()
                '    Me.Close()
                '    Exit Sub
                'End If





                frmDaftarPO.subDraft(SUPCO, cDC_KODE, cDC_ID)
                Scon.Open()
                Scom.CommandText = "insert into dc_jlr_daftarjalur_t (id_daftarjalur,dc_id,tanggal,nomobil,nourut,supco,snama,item,rupiah) " &
                                   "values('" & idDaftarJalur & "','" & cDC_ID & "',to_date('" & TANGGAL_DAFTAR & "', 'MM/dd/yyyy') " &
                                   ",'" & IIf(NOMOBIL = "", "XX", NOMOBIL) & "','" &
                                   nNoUrut & "','" & SUPCO & "','" & SNAMA &
                                   "','" & ITEMnya & "','" & rupiahD & "')"
                Scom.ExecuteNonQuery()
                Scom.Dispose()
                Scon.Close()
            Catch updateException As System.Exception
                'Add your error handling code here.
                Throw updateException
            Finally
                'Close the connection whether or not the exception was thrown.
                'Me.olcon.Close()
            End Try
        End If


        'btnUpdate_Click(sender, New System.EventArgs)
        'Simpan Langsung

        Dim cnndafpo As OracleConnection
        Dim cmddafpo As OracleCommand
        Dim sqldafpo As String
        ' Dim idDaftarPO As Integer = NextIDDaftarPO()
        sqldafpo = "insert into dc_jlr_daftarpo_t (id_daftarpo,tanggal,id_daftarjalur,no_fak,tgl_fak,nopo,supco,snama,buat_po,ada_harga,qty,item,rupiah,ppn,tgl_mulai,JAM_MULAI,supid,gudang_kode,lokasi_kode) " &
                               "values('" & idDaftarPO & "',to_date('" & TANGGAL_DAFTAR & "', 'MM/dd/yyyy'),'" & idDaftarJalur &
                               "','" & FAKTUR & "',to_date('" & Format(tglFaktur, "MM/dd/yyyy") & "','MM/DD/RR'),'" & sNoPo & "'" &
                               ",'" & SUPCO & "','" & SNAMA & "','" & adaPO & "','" &
                               adaHarga & "','" & PO_QTYD &
                               "','" & ITEMnya & "','" & rupiahD & "','" & PO_PPND & "',sysdate,tO_CHAR(SYSDATE, 'hh:mi:ss')  ,'" & SUPIDD &
                               "','" & cDC_KODE & "','" & LocID & "')"

        cnndafpo = New OracleConnection(ConStrORA)

        Try
            cnndafpo.Open()
            cmddafpo = New OracleCommand(sqldafpo, cnndafpo)
            cmddafpo.ExecuteNonQuery()
            cmddafpo.Dispose()
            cnndafpo.Close()
            'Scon.Open()
            'Scom.CommandText = "insert into dc_jlr_daftarpo_t (id_daftarpo,tanggal,id_daftarjalur,no_fak,tgl_fak,nopo,supco,snama,buat_po,ada_harga,qty,item,rupiah,ppn,tgl_mulai,supid,gudang_kode,lokasi_kode) " & _
            '                   "values('" & idDaftarPO & "',to_date('" & Now.Date & "','MM/DD/RR'),'" & idDaftarJalur & _
            '                   "','" & FAKTUR & "',to_date('" & tglFaktur & "','MM/DD/RR')," & NO_PO & _
            '                   ",'" & SUPCO & "','" & SNAMA & "','" & IIf(NO_PO.ToString = "True", 1, 0) & "','" & _
            '                   IIf(rupiahD.ToString = "True", 1, 0) & "','" & PO_QTYD & _
            '                   "','" & ITEMnya & "','" & rupiahD & "','" & PO_PPND & "',sysdate,'" & SUPIDD & _
            '                   "','" & cDC_KODE & "','" & cDC_ID & "')"
            'Scom.ExecuteNonQuery()
            'Scom.Dispose()
            'Scon.Close()

        Catch ex1 As OracleException
            Debug.WriteLine(ex1.Message)
            If ex1.Message.IndexOf("unique constraint") > 0 Then
                MessageBox.Show("Pendaftaran Sudah Pernah Diinput. Cek Nomor Faktur.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
                execQuery("delete from dc_jlr_daftarjalur_t where id_daftarjalur = '" & idDaftarJalur & "'", ConStrORA)
                'txtNoFak.Focus()
            Else
                ShowError("Error Update PO", ex1)
            End If
            Exit Sub
        Catch updateException As System.Exception
            ShowError("Error Update PO", updateException)
            Exit Sub
        Finally
            'Close the connection whether or not the exception was thrown.
            Me.olcon.Close()
        End Try
        '---akhir daftar jalur

        'LANGSUNG UPDATE PERUBAHAN DISINI
        'ERIK - GANTI DSPO, JANGAN SALAH UPDATE
        lNoClose = False
        'btnSimpan.DialogResult = Windows.Forms.DialogResult.None

        If IsMrBread Then
            If Not Cek_EditPO_MBread(dt1) Then
                MessageBox.Show("Total PO <> Total Faktur.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                lNoClose = True
                'Exit Sub
                GoTo batalLoad
            Else
                lNoClose = False
            End If
        End If

        Dim X As Double

        nItem = 0
        nQTY = 0
        nGROSS = 0
        nPPN = 0
        For I As Integer = 0 To dgvLoadPO.Rows.Count - 1
            Dim dt_cekfracpluIns As New DataTable
            dt_cekfracpluIns = getDS("SELECT nvl(sum(frac),0) FROM dc_trnbpb_dtl_t WHERE plu_id = '" & dgvLoadPO.Rows(I).Cells("FRAC").Value & "' and no_po ='" & sNoPo & "'", ConStrORA).Tables(0)
            Dim cekfracIns As String = dt_cekfracpluIns.Rows(0)(0).ToString
            Dim fracins As Integer
            If cekfracIns <> 0 Then
                fracins = 0
            Else
                fracins = cekfracIns
            End If

            'X = (dgvLoadPO.Rows(I)("FRAC") * DsPO1.EditPO.Rows(I)("SATUAN")) * DsPO1.EditPO.Rows(I)("PODTL_PRICE")
            X = (dgvLoadPO.Rows(I).Cells("FRAC").Value * dgvLoadPO.Rows(I).Cells("SATUAN").Value) * dgvLoadPO.Rows(I).Cells("PODTL_PRICE").Value
            If X > 0 Then
                nItem += 1
                nQTY = nQTY + (dgvLoadPO.Rows(I).Cells("FRAC").Value * dgvLoadPO.Rows(I).Cells("SATUAN").Value)
                nGROSS = nGROSS + (X - IIf(IsDBNull(dgvLoadPO.Rows(I).Cells("PO_DISC").Value), 0, dgvLoadPO.Rows(I).Cells("PO_DISC").Value))

                'Ditambah PPN BOTOL
                nGROSS += IIf(IsDBNull(dgvLoadPO.Rows(I).Cells("PPN_BOTOL").Value), 0, dgvLoadPO.Rows(I).Cells("PPN_BOTOL").Value)

                nPPN = nPPN + IIf(IsDBNull(dgvLoadPO.Rows(I).Cells("PO_PPN").Value), 0, dgvLoadPO.Rows(I).Cells("PO_PPN").Value)
                'nPPN += nGROSS * 0.1
            End If

            Dim con As New OracleConnection(ConStrORA)
            Dim com As New OracleCommand("", con)
            Dim Hdr As Integer
            Dim frac_hh As Integer
            Dim frac_slp As Integer

            Dim query_hdrid As String = "SELECT id_daftarpo" &
           " FROM dc_jlr_daftarpo_t " &
           " WHERE id_daftarjalur = '" & idDaftarJalur & "' AND supco = '" & SUPCO & "' AND no_fak = '" & FAKTUR & "'"
            Dim dt_hdr As New DataTable
            connection.Open()
            oledbAdapter = New OracleDataAdapter(query_hdrid, connection)
            dt_hdr.Clear()
            oledbAdapter.Fill(dt_hdr)
            oledbAdapter.Dispose()
            connection.Close()


            con.Open()
            com.CommandText = "Select HDR_ID FROM DC_TRNBPB_HDR_T where ID_DAFTARPO=" & dt_hdr.Rows(0)(0).ToString
            Hdr = "0" & com.ExecuteScalar


            com.CommandText = "Select FRAC_SLP FROM DC_TRNBPB_DTL_T where HDR_FK_ID=" & Hdr & " AND PLU_KODE='" & dgvLoadPO.Rows(I).Cells("PRDCD").Value & "'"
            frac_slp = "0" & com.ExecuteScalar
            'cek apakah plu itu sudah di SLP atau belum. Jika sudah, maka tidak boleh diubah jadi nol (0)
            If frac_slp <> 0 And Val(IIf(IsDBNull(dgvLoadPO.Rows(I).Cells("FRAC").Value), 0, dgvLoadPO.Rows(I).Cells("FRAC").Value)) * Val(IIf(IsDBNull(dgvLoadPO.Rows(I).Cells("SATUAN").Value), 0, dgvLoadPO.Rows(I).Cells("SATUAN").Value)) = 0 Then
                MessageBox.Show("PLU : '" & dgvLoadPO.Rows(I).Cells("PRDCD").Value & "' sudah di SLP dan qty-nya tidak bisa diubah menjadi 0", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                con.Close()
                lNoClose = True
                'Exit Sub
                GoTo batalLoad

            End If
            'Dim K As String = DsPO1.EditPO.Rows(I)("FRAC")
            'Dim J As String = DsPO1.EditPO.Rows(I)("PRDCD")
            Dim FracInput As String = IIf(IsDBNull(dgvLoadPO.Rows(I).Cells("FRAC").Value), 0, dgvLoadPO.Rows(I).Cells("FRAC").Value)
            If dgvLoadPO.Rows(I).Cells("FRAC").Value = 0 Then
                com.CommandText = " UPDATE dc_trnbpb_dtl_t SET (qty, frac, frac_hh, nilai, disc1, disc2, disc3, disc4, disc5, disc6, tot_disc, ppnrp)= " &
                            " (SELECT  " &
                            " NVL(a.podtl_isi_satb, 0) * " & FracInput & " AS QTY, " &
                            " " & FracInput & " AS Frac, " & FracInput & " AS frac_hh, " &
                            " ((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb) * a.podtl_price AS NILAI,  " &
                            " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc1,0)  AS DISC_1, " &
                            " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc2,0)  AS DISC_2, " &
                            " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc3,0)  AS DISC_3, " &
                            " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc4,0)  AS DISC_4, " &
                            " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc5,0)  AS DISC_5, " &
                            " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc6,0)  AS DISC_6, " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc1,0)) + " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc2,0)) + " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc3,0)) + " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc4,0)) + " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc5,0)) + " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc6,0))  AS TOT_DISC,  CASE WHEN A.PODTL_PPN > 0  THEN " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb)* a.podtl_price ) - ( " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc1,0)) + " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc2,0)) + " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc3,0)) + " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc4,0)) + " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc5,0)) + " &
                            " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc6,0))))*  (Nvl(podtl_ppn_persen,getppnnew(null)) / 100) ELSE 0 END AS PPNRP " &
                            "  FROM dc_podtl_t a, DC_PODISC_DTL_V b " &
                            " WHERE a.podtl_fk_no_po = b.po (+)  " &
                            " AND a.podtl_plumd = b.plu (+)" &
                            " AND podtl_fk_no_po = '" & sNoPo & "' " &
                            " AND podtl_plumd = " & dgvLoadPO.Rows(I).Cells("PRDCD").Value & ") " &
                            " WHERE hdr_fk_id = " & Hdr &
                            " AND plu_id = " & dgvLoadPO.Rows(I).Cells("PRDCD").Value
                'com.CommandText = "UPDATE DC_TRNBPB_DTL_T SET "
                'com.CommandText &= "QTY=" & Val(FracInput) * Val(IIf(IsDBNull(dgvLoadPO.Rows(I).Cells("SATUAN").Value), 0, dgvLoadPO.Rows(I).Cells("SATUAN").Value))
                'com.CommandText &= ", FRAC=" & FracInput
                'com.CommandText &= ", FRAC_HH=" & FracInput & " "
                'com.CommandText &= " WHERE HDR_FK_ID=" & Hdr & " AND PLU_KODE='" & dgvLoadPO.Rows(I).Cells("PRDCD").Value & "'"
                'com.CommandText &= ""
            Else
                com.CommandText = "Select FRAC_HH FROM DC_TRNBPB_DTL_T where HDR_FK_ID=" & Hdr & " AND PLU_KODE='" & dgvLoadPO.Rows(I).Cells("PRDCD").Value & "'"
                frac_hh = "0" & com.ExecuteScalar

                If frac_hh = 0 Then
                    com.CommandText = " UPDATE dc_trnbpb_dtl_t SET (qty, frac, frac_hh, nilai, disc1, disc2, disc3, disc4, disc5, disc6, tot_disc, ppnrp)= " &
                        " (SELECT  " &
                        " NVL(a.podtl_isi_satb, 0) * " & FracInput & " AS QTY, " &
                        " " & FracInput & " AS Frac, NULL AS frac_hh, " &
                        " ((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb) * a.podtl_price AS NILAI,  " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc1,0)  AS DISC_1, " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc2,0)  AS DISC_2, " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc3,0)  AS DISC_3, " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc4,0)  AS DISC_4, " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc5,0)  AS DISC_5, " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc6,0)  AS DISC_6, " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc1,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc2,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc3,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc4,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc5,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc6,0))  AS TOT_DISC,  CASE WHEN A.PODTL_PPN > 0  THEN  " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb)* a.podtl_price ) - ( " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc1,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc2,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc3,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc4,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc5,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc6,0))))*   (Nvl(podtl_ppn_persen,getppnnew(null)) / 100)  ELSE 0 END AS PPNRP " &
                        "  FROM dc_podtl_t a, DC_PODISC_DTL_V b " &
                        " WHERE a.podtl_fk_no_po = b.po (+)   " &
                        " AND a.podtl_plumd = b.plu (+)" &
                        " AND podtl_fk_no_po = '" & sNoPo & "' " &
                        " AND podtl_plumd = " & dgvLoadPO.Rows(I).Cells("PRDCD").Value & ") " &
                        " WHERE hdr_fk_id = " & Hdr &
                        " AND plu_id = " & dgvLoadPO.Rows(I).Cells("PRDCD").Value
                    'com.CommandText = "UPDATE DC_TRNBPB_DTL_T SET "
                    'com.CommandText &= "QTY=" & Val(FracInput) * Val(IIf(IsDBNull(dgvLoadPO.Rows(I).Cells("SATUAN").Value), 0, dgvLoadPO.Rows(I).Cells("SATUAN").Value))
                    'com.CommandText &= ", FRAC=" & FracInput & ", FRAC_HH=null " '0" & DsPO1.EditPO.Rows(I)("FRAC") & " "
                    'com.CommandText &= "WHERE HDR_FK_ID=" & Hdr & " AND PLU_KODE='" & dgvLoadPO.Rows(I).Cells("PRDCD").Value & "'"
                    'com.CommandText &= ""
                Else
                    com.CommandText = " UPDATE dc_trnbpb_dtl_t SET (qty, frac, nilai, disc1, disc2, disc3, disc4, disc5, disc6, tot_disc, ppnrp)= " &
                        " (SELECT  " &
                        " NVL(a.podtl_isi_satb, 0) * " & FracInput & " AS QTY, " &
                        " " & FracInput & " AS Frac, " &
                        " ((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb) * a.podtl_price AS NILAI,  " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc1,0)  AS DISC_1, " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc2,0)  AS DISC_2, " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc3,0)  AS DISC_3, " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc4,0)  AS DISC_4, " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc5,0)  AS DISC_5, " &
                        " (((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc6,0)  AS DISC_6, " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc1,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc2,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc3,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc4,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc5,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc6,0))  AS TOT_DISC,  CASE WHEN A.PODTL_PPN > 0  THEN  " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb)* a.podtl_price ) - ( " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc1,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc2,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc3,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc4,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc5,0)) + " &
                        " ((((" & FracInput & " *  a.podtl_isi_satb)+a.podtl_frac_qtyb )/((a.podtl_isi_satb * a.podtl_qtyb)+a.podtl_frac_qtyb)) * NVL(b.disc6,0))))*  (Nvl(podtl_ppn_persen,getppnnew(null)) / 100)  ELSE 0 END AS PPNRP " &
                        "  FROM dc_podtl_t a, DC_PODISC_DTL_V b " &
                        " WHERE a.podtl_fk_no_po = b.po (+)  " &
                        " AND a.podtl_plumd = b.plu (+) " &
                        " AND podtl_fk_no_po = '" & sNoPo & "' " &
                        " AND podtl_plumd = " & dgvLoadPO.Rows(I).Cells("PRDCD").Value & ") " &
                        " WHERE hdr_fk_id = " & Hdr &
                        " AND plu_id = " & dgvLoadPO.Rows(I).Cells("PRDCD").Value

                    'com.CommandText = "UPDATE DC_TRNBPB_DTL_T SET "
                    'com.CommandText &= "QTY=" & Val(FracInput) * Val(IIf(IsDBNull(dgvLoadPO.Rows(I).Cells("SATUAN").Value), 0, dgvLoadPO.Rows(I).Cells("SATUAN").Value))
                    'com.CommandText &= ",FRAC=" & FracInput & " " '"FRAC_HH=0" & DsPO1.EditPO.Rows(I)("FRAC") & " "
                    'com.CommandText &= "WHERE HDR_FK_ID=" & Hdr & " AND PLU_KODE='" & dgvLoadPO.Rows(I).Cells("PRDCD").Value & "'"
                    'com.CommandText &= ""
                End If
            End If

            com.ExecuteNonQuery()
            con.Close()

            'Hitung Ulang QTYBONUS & update ke TRNBPB_DTL
            'If DsPO1.EditPO.Rows(I)("QTYBONUS") > 0 Or DsPO1.EditPO.Rows(I)("PPN_BOTOL") > 0 Then
            'Dim Scon As New OleDb.OleDbConnection(ConStrORA)
            'Dim Scom As New OleDb.OleDbCommand("", Scon)
            'Dim nHdr As Integer

            con.Open()
            'Scom.CommandText = "Select HDR_ID FROM DC_TRNBPB_HDR_T where ID_DAFTARPO=" & nIdDaftarPO
            'nHdr = "0" & Scom.ExecuteScalar ")

            com.CommandText = "UPDATE DC_TRNBPB_DTL_T SET "
            com.CommandText &= "BONUS=0" & dgvLoadPO.Rows(I).Cells("QTYBONUS").Value & " "
            com.CommandText &= ",BOTOL=0" & dgvLoadPO.Rows(I).Cells("PPN_BOTOL").Value & " "
            com.CommandText &= "WHERE HDR_FK_ID=" & Hdr & " AND PLU_KODE='" & dgvLoadPO.Rows(I).Cells("PRDCD").Value & "'"
            com.CommandText &= ""
            com.ExecuteNonQuery()
            con.Close()
        Next



        'jagaan plu nya udah ada di faktur sebelumnya ga?
        'update faktur sebelumnya
        Dim cek_FakturLama As String = " SELECT distinct no_faktur" &
                    "   FROM dc_trnbpb_hdr_t a, dc_trnbpb_dtl_t b" &
                    "  WHERE a.hdr_id = b.hdr_fk_id" &
                    "  AND a.no_po = b.no_po" &
                    "    AND a.no_po = '" & sNoPo & "'" &
                    "    AND NVL (b.qty, 0) > 0" &
                    "    AND no_faktur <> '" & FAKTUR & "'"
        Dim dt_cekFaktur As New DataTable
        dt_cekFaktur = getDS(cek_FakturLama, ConStrORA).Tables(0)
        'mulai looping masukin nilai sesuai faktur baru
        For y As Integer = 0 To dt_cekFaktur.Rows.Count - 1
            Dim get_hdrid As String = " SELECT hdr_id" &
                    "   FROM dc_trnbpb_hdr_t" &
                    "  WHERE id_daftarpo =" &
                    "           (SELECT id_daftarpo" &
                    "              FROM dc_jlr_daftarpo_t" &
                    "             WHERE supco = '" & SUPCO & "'" &
                    " 			  AND nopo = '" & sNoPo & "'" &
                    "               AND no_fak = '" & dt_cekFaktur.Rows(y)(0).ToString & "')"
            Dim dt_getGHDRID As New DataTable
            dt_getGHDRID = getDS(get_hdrid, ConStrORA).Tables(0)
            Dim hdrid_ As String = ""
            hdrid_ = dt_getGHDRID.Rows(0)(0).ToString
            'mulai looping update perplu
            For z As Integer = 0 To dgvLoadPO.Rows.Count - 1
                Dim query_UPD_TRNBPBDTL As String

                If dgvLoadPO.Rows(z).Cells("FRAC").Value <> 0 Then
                    query_UPD_TRNBPBDTL = "UPDATE DC_TRNBPB_DTL_T SET " &
                                   " QTY = 0 , frac = 0,nilai = 0, disc1 = 0, disc2 = 0, disc3 = 0, disc4 = 0, disc5 = 0, disc6 = 0, tot_disc = 0, ppnrp = 0 " &
                                   " WHERE HDR_FK_ID=" & hdrid_ & " AND PLU_KODE='" & dgvLoadPO.Rows(z).Cells("PRDCD").Value & "'"

                    execQuery(query_UPD_TRNBPBDTL, ConStrORA)
                Else
                    'query_UPD_TRNBPBDTL = "UPDATE DC_TRNBPB_DTL_T SET " & _
                    '               " QTY= " & Val(IIf(IsDBNull(dgvLoadPO.Rows(z).cells("FRAC")), 0, dgvLoadPO.Rows(z).cells("FRAC"))) * Val(IIf(IsDBNull(dgvLoadPO.Rows(z).cells("SATUAN")), 0, dgvLoadPO.Rows(z).cells("SATUAN")) & _
                    '               " WHERE HDR_FK_ID=" & hdrid_ & " AND PLU_KODE='" & dgvLoadPO.Rows(z).Cells("PRDCD").Value & "'"

                    'execQuery(query_UPD_TRNBPBDTL, ConStrORA)
                End If



                ''Hitung Ulang QTYBONUS & update ke TRNBPB_DTL
                ''If DsPO1.EditPO.Rows(I)("QTYBONUS") > 0 Or DsPO1.EditPO.Rows(I)("PPN_BOTOL") > 0 Then
                ''Dim Scon As New OleDb.OleDbConnection(ConStrORA)
                ''Dim Scom As New OleDb.OleDbCommand("", Scon)
                ''Dim nHdr As Integer

                'con.Open()
                ''Scom.CommandText = "Select HDR_ID FROM DC_TRNBPB_HDR_T where ID_DAFTARPO=" & nIdDaftarPO
                ''nHdr = "0" & Scom.ExecuteScalar ")

                'com.CommandText = "UPDATE DC_TRNBPB_DTL_T SET "
                'com.CommandText &= "BONUS=0" & dgvLoadPO.Rows(I).Cells("QTYBONUS").Value & " "
                'com.CommandText &= ",BOTOL=0" & dgvLoadPO.Rows(I).Cells("PPN_BOTOL").Value & " "
                'com.CommandText &= "WHERE HDR_FK_ID=" & Hdr & " AND PLU_KODE='" & dgvLoadPO.Rows(I).Cells("PRDCD").Value & "'"
                'com.CommandText &= ""
                'com.ExecuteNonQuery()
                'con.Close()


                '        Dim UPDATE_HDR As String = " UPDATE   dc_trnbpb_hdr_t SET(tot_item, nilai, ppn)=" & _
                '" (SELECT COUNT (PLU_ID),  SUM (nilai),  SUM (ppnrp)" & _
                '"   FROM dc_trnbpb_dtl_t" & _
                '"  WHERE hdr_fk_id = " & hdrid_ & _
                '"  AND QTY <> 0)" & _
                '"  WHERE hdr_id = " & hdrid_
                '        execQuery(UPDATE_HDR, ConStrORA)
            Next
            'update daftar po biar jumlah nilai sama ppn menyesuaikan dengan faktur baru
            'Dim query_UPDdaftarPO As String = "UPDATE dc_jlr_daftarpo_t SET rupiah = (SELECT SUM(nilai) FROM dc_trnbpb_dtl_t  WHERE hdr_fk_id =" & hdrid_ & ")" & _
            '                            " , ppn =(SELECT SUM(ppnrp) FROM dc_trnbpb_dtl_t  WHERE hdr_fk_id =" & hdrid_ & ") where id_daftarpo=(SELECT id_daftarpo" & _
            '                            "              FROM dc_jlr_daftarpo_t" & _
            '                            "             WHERE supco = '" & SUPCO & "'" & _
            '                            " 			  AND nopo = '" & sNoPo & "'" & _
            '                            "               AND no_fak = '" & dt_cekFaktur.Rows(y)(0).ToString & "')"
            'execQuery(query_UPDdaftarPO, ConStrORA)
        Next

        'update dc_trnbpb_hdr_t berdasarkan hdr_id



        Dim get_totdisc As String = " SELECT trunc(SUM(nvl(tot_disc,0)),8) FROM dc_trnbpb_dtl_t WHERE hdr_fk_id = (select hdr_id from dc_trnbpb_hdr_t where id_daftarpo = " & idDaftarPO & ")"
        Dim dt_totdisc As DataTable = getDS(get_totdisc, ConStrORA).Tables(0)
        Dim get_hdrid_ As String = " select hdr_id from dc_trnbpb_hdr_t where id_daftarpo = " & idDaftarPO
        Dim dt_hdrid_ As DataTable = getDS(get_hdrid_, ConStrORA).Tables(0)
        Dim totdisc As String = dt_totdisc.Rows(0)(0).ToString
        Dim hdrid__ As String = dt_hdrid_.Rows(0)(0).ToString

        Dim UPDATE_HDR As String = " UPDATE   dc_trnbpb_hdr_t SET(tot_item, nilai, ppn)=" &
                " (SELECT COUNT (PLU_ID),  SUM (nilai),  SUM (ppnrp)" &
                "   FROM dc_trnbpb_dtl_t" &
                "  WHERE hdr_fk_id = " & hdrid__ &
                "  AND QTY <> 0)" &
                "  WHERE hdr_id = " & hdrid__
        execQuery(UPDATE_HDR, ConStrORA)


        Dim get_rupiahPo As String = " SELECT trunc((  SUM (a.podtl_price * b.QTY)" &
                            "         - SUM ((b.QTY / (a.podtl_qtyb * a.podtl_isi_satb)) * podtl_disc)" &
                            "        ),8) AS RUPIAHPO" &
                            "   FROM dc_podtl_t a, dc_trnbpb_dtl_t b" &
                            "  WHERE a.podtl_fk_no_po = b.no_po" &
                            "    AND a.podtl_plumd = b.plu_id" &
                            "    AND a.podtl_fk_no_po = '" & sNoPo & "'" &
                            "    AND b.qty > 0"
        Dim dt_RupiahPO As DataTable = getDS(get_rupiahPo, ConStrORA).Tables(0)
        Dim rupiahPO As String = 0
        If dt_RupiahPO.Rows.Count > 0 Then
            rupiahPO = dt_RupiahPO.Rows(0)(0).ToString
        End If

        Dim UPDATE_DAFTARPO As String = "  UPDATE DC_JLR_DAFTARPO_T SET (RUPIAH, PPN, ITEM, TGL_MULAI, JAM_MULAI) =" &
                " (select " & rupiahPO & ", trunc(SUM (NVL(ppn,0)),8), trunc( SUM (NVL(tot_item,0)),8),SYSDATE AS TGL_MULAI, TO_CHAR(SYSDATE, 'hh:mm:ss') AS JAM_MULAI" &
                "   FROM dc_trnbpb_hdr_t  " &
                "  WHERE supco = '" & SUPCO & "' AND no_po = '" & sNoPo & "' AND id_daftarpo = " & idDaftarPO & "), QTY = " &
                " (SELECT SUM(NVL(qty,0)) FROM DC_TRNBPB_DTL_T WHERE  no_po='" & sNoPo & "' AND HDR_FK_ID IN (SELECT HDR_ID FROM DC_TRNBPB_HDR_T WHERE ID_DAFTARPO= " & idDaftarPO & "))" &
                " WHERE supco= '" & SUPCO & "' AND nopo='" & sNoPo & "' AND id_daftarpo = " & idDaftarPO

        '        Dim UPDATE_DAFTARPO As String = "  UPDATE DC_JLR_DAFTARPO_T SET (RUPIAH, PPN, ITEM) =" & _
        '" (SELECT SUM (NVL(nilai,0)) - " & totdisc & ", SUM (NVL(ppn,0)), SUM (NVL(tot_item,0))" & _
        '"   FROM dc_trnbpb_hdr_t  " & _
        '"  WHERE supco = '" & SUPCO & "' AND no_po = '" & sNoPo & "' AND id_daftarpo = " & idDaftarPO & "), QTY = " & _
        '" (SELECT SUM(NVL(qty,0)) FROM DC_TRNBPB_DTL_T WHERE  no_po='" & sNoPo & "' AND HDR_FK_ID IN (SELECT HDR_ID FROM DC_TRNBPB_HDR_T WHERE ID_DAFTARPO= " & idDaftarPO & "))" & _
        '" WHERE supco= '" & SUPCO & "' AND nopo='" & sNoPo & "' AND id_daftarpo = " & idDaftarPO
        execQuery(UPDATE_DAFTARPO, ConStrORA)

        'update daftar po biar jumlah nilai sama ppn menyesuaikan dengan faktur baru (di sum semua faktur)
        'Dim query_UPDdaftarPO As String = "UPDATE dc_jlr_daftarpo_t SET rupiah = (SELECT SUM(nilai) FROM dc_trnbpb_dtl_t  WHERE hdr_fk_id =" & hdrid_ & ")" & _
        '                            " , ppn =(SELECT SUM(ppnrp) FROM dc_trnbpb_dtl_t  WHERE hdr_fk_id =" & hdrid_ & ") where id_daftarpo=(SELECT id_daftarpo" & _
        '                            "              FROM dc_jlr_daftarpo_t" & _
        '                            "             WHERE supco = '" & SUPCO & "'" & _
        '                            " 			  AND nopo = '" & sNoPo & "'" & _
        '                            "               AND no_fak = '" & dt_cekFaktur.Rows(y)(0).ToString & "')"
        'execQuery(query_UPDdaftarPO, ConStrORA)
batalLoad:

        'PO OBAT
        Dim cekObat As Integer = execScalar(" SELECT count(*)" &
                        "   FROM DC_PO_T a, DC_PODTL_T b" &
                        "  WHERE po_no_po = '" & sNoPo & "'" &
                        "    AND po_no_po = podtl_fk_no_po" &
                        "    AND podtl_plu IN (SELECT DISTINCT mbr_fk_pluid" &
                        "                                 FROM DC_BARANG_DC_T" &
                        "                                WHERE mbr_tgl_plumati IS NULL" &
                        "                                  AND mbr_obat IS NOT NULL)", ConStrORA)
        'If cekObat <> "0" Then
        '    dgvLoadPO.Enabled = False
        'Else
        '    dgvLoadPO.Enabled = False
        'End If
        If cekObat > 0 Then
            MsgBox("Ini merupakan PO Obat", vbInformation)
            execQuery("update dc_trnbpb_hdr_t set PO_MBREAD ='O' where no_po ='" & sNoPo & "'", ConStrORA)
            Dim HasilProc As String = frmDaftarPO.runProcIns_Spobat(cDC_KODE, sNoPo)
            If HasilProc = "Y" Then
                Dim cekCetak As String = execScalar("SELECT nvl(flag_cetak,'XXX') FROM DC_SPOBAT_HDR_T WHERE no_po ='" & sNoPo & "'", ConStrORA)
                If cekCetak = "XXX" Then
                    'cetak  Dim result_MSGCTK As MsgBoxResult =  
                    MessageBox.Show("Cetak Form SP Obat Pre-Cursor, siapkan printer!", "Perhatian!", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    frmCetak.NOPO_Report = sNoPo
                    frmCetak.Show()
                End If
            Else
                MessageBox.Show("Error Procedure Ins_SPOBAT : " & vbNewLine & HasilProc, "Perhatian!", MessageBoxButtons.OK, MessageBoxIcon.Stop)

            End If
        End If
        'Dim cekObat As String = execScalar(" SELECT count(*)" &
        '              "   FROM DC_PO_T a, DC_PODTL_T b" &
        '              "  WHERE po_no_po = '" & sNoPo & "'" &
        '              "    AND po_no_po = podtl_fk_no_po" &
        '              "    AND podtl_plu IN (SELECT DISTINCT mbr_fk_pluid" &
        '              "                                 FROM DC_BARANG_DC_T" &
        '              "                                WHERE mbr_tgl_plumati IS NULL" &
        '              "                                  AND mbr_obat IS NOT NULL)", ConStrORA)
        'If cekObat <> "0" Then
        '    MsgBox("Ini merupakan PO Obat", vbInformation)
        '    execQuery("update dc_trnbpb_hdr_t set PO_MBREAD ='O' where no_po ='" & sNoPo & "'", ConStrORA)
        'End If

        'DsPO1.DC_JLR_DAFTARPO_T.AcceptChanges()
        ' frmDaftarPO.JagaanLoad()
        Me.DialogResult = DialogResult.OK
        'frmDaftarPO.btn_Next(SUPCO)
        frmDaftarPO.btnTambahPO.Enabled = True
        'frmDaftarPO.showdialogLoadPO()
        Me.Close()
    End Sub

    Public IsMrBread As Boolean

    Private Function Cek_EditPO_MBread(ByVal ds As DataTable) As Boolean
        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Dim Sdap As New OracleDataAdapter("", Scon)
        Dim dt As New DataTable

        Dim Sql As String

        Dim lOke As Boolean = True

        Try
            Scon.Open()
            Sql = " SELECT   a.plu AS PLU, SUM (a.qty) AS QTY "
            Sql &= "FROM alokasi_tampung a "
            Sql &= "WHERE (a.no_sj = '" & FAKTUR & "') "
            Sql &= "GROUP BY a.no_sj, a.tgl_sj, a.plu "
            Sql &= "order by plu "
            Sdap.SelectCommand.CommandText = Sql
            Sdap.Fill(dt)
            If dt.Rows.Count <> ds.Rows.Count Then
                lOke = False
                Exit Try
            End If

            For i As Integer = 0 To ds.Rows.Count - 1
                If (dt.Rows(i)("PLU") <> ds.Rows(i)("PRDCDNYA")) Or (dt.Rows(i)("QTY") <> ds.Rows(i)("FRACNYA")) Then
                    lOke = False
                    Exit Try
                End If
            Next

        Catch ex As Exception
            IDM.Fungsi.ShowError("Error Cek Edit PO Mr. Bread", ex)
        Finally
            Scon.Close()
        End Try

        Return lOke
    End Function


    Private Function KasihNoAntrian() As Boolean

        Dim nNoUrut As Integer = NextAntrian()

    End Function

    Public Function NextAntrian() As Integer
        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)


        Scon.Open()

        Dim nourutbaru As String = execScalar("select nvl(max(nourut),'0')+1 from dc_jlr_daftarjalur_t where trunc(tanggal) = trunc(sysdate)", ConStrORA)
        Scom.CommandText = "UPDATE DC_JLR_Setting_T  SET NextNoUrut=" & nourutbaru & " WHERE DC_ID=" & cDC_ID
        Scom.ExecuteNonQuery()

        Scon.Close()

        Return nourutbaru

    End Function
    Public Function NextAntrianold() As Integer
        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Dim n As Integer

        Scon.Open()
        Scom.CommandText = "Select COUNT(*) From DC_JLR_Setting_T WHERE DC_ID=" & cDC_ID
        If Scom.ExecuteScalar = 0 Then
            Scom.CommandText = "INSERT INTO VALUES(" & cDC_ID & ",2,TRUNC(SYSDATE())"
            Scom.ExecuteNonQuery()
            Return 1
        End If

        Scom.CommandText = "Select NextNoUrut From DC_JLR_Setting_T WHERE DC_ID=" & cDC_ID
        n = "0" & Scom.ExecuteScalar()
        If n = 0 Then
            n = 1
        End If
        ' Dim nourutbaru As String = execScalar("select nvl(max(nourut),'0') from dc_jlr_daftarjalur_t where trunc(tanggal) = trunc(sysdate)", ConStrORA)
        Scom.CommandText = "UPDATE DC_JLR_Setting_T  SET NextNoUrut=" & n & "+1 WHERE DC_ID=" & cDC_ID
        Scom.ExecuteNonQuery()

        Scon.Close()

        Return n

    End Function
    Private Function NextIDDaftarJalur() As Integer
        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Dim n As Integer

        Scon.Open()

        Scom.CommandText = "SELECT MAX(ID_DAFTARjalur) FROM DC_JLR_DAFTARJALUR_T"
        n = "0" & Scom.ExecuteScalar()
        If n = 0 Then
            n = 1
        Else
            n = n + 1
        End If

        Scon.Close()

        Return n

    End Function

    Private Function NextIDDaftarPO() As Integer
        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Dim n As Integer

        Scon.Open()

        Scom.CommandText = "SELECT MAX(ID_DAFTARPO) FROM DC_JLR_DAFTARPO_T"
        n = "0" & Scom.ExecuteScalar()
        If n = 0 Then
            n = 1
        Else
            n = n + 1
        End If

        Scon.Close()

        Return n

    End Function
    'notifikasi cek faktur sebelumnya dah ada frac yg diisi belum ( berdasarkan plu) 06/17/2016
    Sub dataGridView1_CurrentCellDirtyStateChanged(
     ByVal sender As Object, ByVal e As EventArgs)


        If dgvLoadPO.IsCurrentCellDirty Then
            dgvLoadPO.CommitEdit(DataGridViewDataErrorContexts.Commit)
        End If
    End Sub

    Private Sub dgvLoadPO_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgvLoadPO.CellEndEdit

    End Sub

    Private Sub frmLoadPO_FormClosed(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        If cancelLoadPO = "" Then
            frmDaftarPO.SetTombol(False)
            Me.DialogResult = DialogResult.OK
            frmDaftarPO.btnTambahPO.Enabled = True
        Else
            frmDaftarPO.SetTombol(True)
            Me.DialogResult = DialogResult.Cancel
            frmDaftarPO.btnTambahPO.Enabled = False
        End If
    End Sub
End Class