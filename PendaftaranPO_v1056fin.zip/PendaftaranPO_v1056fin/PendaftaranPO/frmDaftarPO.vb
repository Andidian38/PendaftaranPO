Imports IDM.Fungsi
Imports System.Data
Imports Oracle.ManagedDataAccess.Client
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.Drawing.Printing.PaperSize

Public Class frmDaftarPO
    Inherits System.Windows.Forms.Form
    Public saveLoadPO As String
    Public datasetload As DataTable
    Friend WithEvents txtNoAntrianPO As System.Windows.Forms.TextBox
    Public WithEvents Label25 As System.Windows.Forms.Label
    Public NoAntrian As String
    Dim StringConnODP As String = getStrKoneksiODP()
    Public Cari_SUPCO As String
    Public Cari_TANGGAL As String
    Public Cari_NOPO As String
    Public Cari_ID_DAFTARPO As String
    Public Cari_KODESUPP As String
    Public Cari_NAMASUPP As String
    Public WithEvents Label26 As Label
    Friend WithEvents Panel1 As Panel
    Public WithEvents Label15 As Label
    Public WithEvents Label7 As Label
    Friend WithEvents Panel2 As Panel
    Public WithEvents Label3 As Label
    Public WithEvents Label17 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents txtNamaSupp_ As TextBox
    Public WithEvents Label12 As Label
    Friend WithEvents txtKodeSupp_ As TextBox
    Public WithEvents Label11 As Label
    Public Cari_NOURUT_JALUR As String
    ' Private WithEvents frmLoadPO1 As New frmLoadPO

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        Me.txtTglFaktur.BackColor = System.Drawing.SystemColors.Window
        Me.txtTglFaktur.ForeColor = System.Drawing.SystemColors.WindowText

        ''Format Textbox
        'Dim bd As Binding
        'bd = txtPO_GROSS.DataBindings("Text")
        'AddHandler bd.Format, AddressOf formatTextBox
        'AddHandler bd.Parse, AddressOf formatTextBox

        ''bd = txtPO_QTY.DataBindings("Text")
        ''AddHandler bd.Format, AddressOf formatTextBox
        ''AddHandler bd.Parse, AddressOf formatTextBox

        'bd = txtPO_PPN.DataBindings("Text")
        'AddHandler bd.Format, AddressOf formatTextBox
        'AddHandler bd.Parse, AddressOf formatTextBox

        'bd = txtPO_Total.DataBindings("Text")
        'AddHandler bd.Format, AddressOf formatTextBox
        'AddHandler bd.Parse, AddressOf formatTextBox
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents btnCancelAll As System.Windows.Forms.Button
    Private WithEvents oldapMobil As OracleDataAdapter
    Private WithEvents oldapPO As OracleDataAdapter
    Friend WithEvents olcon As OracleConnection
    Public WithEvents txtNoAntrian As System.Windows.Forms.TextBox
    Public WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents btnNext As System.Windows.Forms.Button
    Friend WithEvents btnPrev As System.Windows.Forms.Button
    Friend WithEvents btnDaftar As System.Windows.Forms.Button
    Friend WithEvents grpSup As System.Windows.Forms.GroupBox
    Friend WithEvents btnTambahPO As System.Windows.Forms.Button
    Public WithEvents lblBPB_NO As System.Windows.Forms.Label
    Public WithEvents Label16 As System.Windows.Forms.Label
    Public WithEvents Label14 As System.Windows.Forms.Label
    Public WithEvents lblStatus As System.Windows.Forms.Label
    Public WithEvents lblStatusKeterangan As System.Windows.Forms.Label
    Public WithEvents txtTgl_PO As FlexMaskEditBox
    Public WithEvents txtNo_PO As System.Windows.Forms.TextBox
    Public WithEvents txtPO_QTY As System.Windows.Forms.TextBox
    Public WithEvents chkBUAT_PO As System.Windows.Forms.CheckBox
    Public WithEvents chkADA_HARGA As System.Windows.Forms.CheckBox
    Public WithEvents txtTot_Item As System.Windows.Forms.TextBox
    Public WithEvents Label1 As System.Windows.Forms.Label
    Public WithEvents Label2 As System.Windows.Forms.Label
    Public WithEvents Label10 As System.Windows.Forms.Label
    Public WithEvents Label8 As System.Windows.Forms.Label
    Public WithEvents Label9 As System.Windows.Forms.Label
    Public WithEvents Label4 As System.Windows.Forms.Label
    Public WithEvents txtNoFak As System.Windows.Forms.TextBox
    Public WithEvents Label5 As System.Windows.Forms.Label
    Public WithEvents Label6 As System.Windows.Forms.Label
    Public WithEvents txtUPDATE As System.Windows.Forms.TextBox
    Public WithEvents txtTGL_AKHIR As FlexMaskEditBox
    Public WithEvents txtTGL_MULAI As FlexMaskEditBox
    Public WithEvents Label21 As System.Windows.Forms.Label
    Public WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents grpDaftar As System.Windows.Forms.GroupBox
    Friend WithEvents btnSimpanPO As System.Windows.Forms.Button
    Friend WithEvents btnBatalPO As System.Windows.Forms.Button
    Friend WithEvents btnNext2 As System.Windows.Forms.Button
    Friend WithEvents btnPrev2 As System.Windows.Forms.Button
    Friend WithEvents btnEditPO As System.Windows.Forms.Button
    Friend WithEvents btnHapusPO As System.Windows.Forms.Button
    Friend WithEvents cmbFilter As System.Windows.Forms.ComboBox
    Friend WithEvents txtTglFaktur As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtTglDaftar As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblSUPID As System.Windows.Forms.Label
    Private WithEvents OleDbSelectCommand1 As OracleCommand
    Private WithEvents OleDbInsertCommand1 As OracleCommand
    Private WithEvents OleDbUpdateCommand1 As OracleCommand
    Private WithEvents OleDbDeleteCommand1 As OracleCommand
    Friend WithEvents DsPO1 As PendaftaranPO.DS_
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Private WithEvents OleDbSelectCommand2 As OracleCommand
    Private WithEvents OleDbInsertCommand2 As OracleCommand
    Private WithEvents OleDbUpdateCommand2 As OracleCommand
    Private WithEvents OleDbDeleteCommand2 As OracleCommand
    Friend WithEvents lblLokasiKode As System.Windows.Forms.Label
    Friend WithEvents lblGudangKode As System.Windows.Forms.Label
    Friend WithEvents grpHidden As System.Windows.Forms.GroupBox
    Friend WithEvents btnKeluar As System.Windows.Forms.Button
    Friend WithEvents lblTglRevisi As System.Windows.Forms.Label
    Friend WithEvents lblIdDaftarPO As System.Windows.Forms.Label
    Friend WithEvents btnDraftRetur As System.Windows.Forms.Button
    Friend WithEvents btnPrint As System.Windows.Forms.Button
    Friend WithEvents btnPrintUlang As System.Windows.Forms.Button
    Friend WithEvents BtnPrintStck As System.Windows.Forms.Button
    Friend WithEvents btnCari As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim OracleParameter1 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter2 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter3 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter4 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter5 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter6 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter7 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter8 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter9 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter10 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter11 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter12 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter13 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter14 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDaftarPO))
        Dim OracleParameter15 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter16 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter17 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter18 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter19 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter20 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter21 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter22 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter23 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter24 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter25 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter26 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter27 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter28 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter29 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter30 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter31 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter32 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter33 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter34 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter35 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter36 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter37 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter38 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter39 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter40 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter41 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter42 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter43 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter44 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter45 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter46 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter47 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter48 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter49 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter50 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter51 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter52 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter53 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter54 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter55 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter56 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter57 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter58 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter59 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter60 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter61 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter62 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter63 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter64 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter65 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter66 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter67 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter68 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter69 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter70 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter71 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter72 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter73 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter74 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter75 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter76 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter77 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter78 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter79 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter80 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter81 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter82 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter83 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter84 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter85 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter86 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter87 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter88 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter89 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter90 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter91 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter92 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter93 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter94 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter95 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter96 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter97 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter98 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter99 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter100 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter101 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter102 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter103 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter104 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter105 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter106 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter107 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter108 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter109 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter110 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter111 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter112 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter113 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter114 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter115 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter116 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter117 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter118 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter119 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter120 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter121 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter122 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter123 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter124 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter125 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter126 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter127 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter128 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter129 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter130 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter131 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter132 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter133 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter134 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter135 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter136 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter137 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter138 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter139 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter140 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter141 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter142 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter143 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter144 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter145 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter146 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter147 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter148 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter149 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter150 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter151 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter152 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter153 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter154 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter155 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter156 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter157 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter158 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter159 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter160 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter161 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter162 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter163 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter164 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Dim OracleParameter165 As Oracle.ManagedDataAccess.Client.OracleParameter = New Oracle.ManagedDataAccess.Client.OracleParameter()
        Me.olcon = New Oracle.ManagedDataAccess.Client.OracleConnection()
        Me.oldapMobil = New Oracle.ManagedDataAccess.Client.OracleDataAdapter()
        Me.OleDbDeleteCommand1 = New Oracle.ManagedDataAccess.Client.OracleCommand()
        Me.OleDbInsertCommand1 = New Oracle.ManagedDataAccess.Client.OracleCommand()
        Me.OleDbSelectCommand1 = New Oracle.ManagedDataAccess.Client.OracleCommand()
        Me.OleDbUpdateCommand1 = New Oracle.ManagedDataAccess.Client.OracleCommand()
        Me.oldapPO = New Oracle.ManagedDataAccess.Client.OracleDataAdapter()
        Me.OleDbDeleteCommand2 = New Oracle.ManagedDataAccess.Client.OracleCommand()
        Me.OleDbInsertCommand2 = New Oracle.ManagedDataAccess.Client.OracleCommand()
        Me.OleDbSelectCommand2 = New Oracle.ManagedDataAccess.Client.OracleCommand()
        Me.OleDbUpdateCommand2 = New Oracle.ManagedDataAccess.Client.OracleCommand()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnCancelAll = New System.Windows.Forms.Button()
        Me.grpSup = New System.Windows.Forms.GroupBox()
        Me.txtNoAntrianPO = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.BtnPrintStck = New System.Windows.Forms.Button()
        Me.btnPrintUlang = New System.Windows.Forms.Button()
        Me.btnPrint = New System.Windows.Forms.Button()
        Me.btnDraftRetur = New System.Windows.Forms.Button()
        Me.btnCari = New System.Windows.Forms.Button()
        Me.txtTglDaftar = New System.Windows.Forms.DateTimePicker()
        Me.DsPO1 = New PendaftaranPO.DS_()
        Me.txtNoAntrian = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.btnPrev = New System.Windows.Forms.Button()
        Me.btnDaftar = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.grpHidden = New System.Windows.Forms.GroupBox()
        Me.lblTglRevisi = New System.Windows.Forms.Label()
        Me.lblSUPID = New System.Windows.Forms.Label()
        Me.lblLokasiKode = New System.Windows.Forms.Label()
        Me.lblGudangKode = New System.Windows.Forms.Label()
        Me.btnTambahPO = New System.Windows.Forms.Button()
        Me.grpDaftar = New System.Windows.Forms.GroupBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.txtTglFaktur = New System.Windows.Forms.DateTimePicker()
        Me.txtNoFak = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.txtNamaSupp_ = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtKodeSupp_ = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtUPDATE = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblStatusKeterangan = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.chkADA_HARGA = New System.Windows.Forms.CheckBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtPO_QTY = New System.Windows.Forms.TextBox()
        Me.lblBPB_NO = New System.Windows.Forms.Label()
        Me.txtTGL_AKHIR = New PendaftaranPO.FlexMaskEditBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtNo_PO = New System.Windows.Forms.TextBox()
        Me.chkBUAT_PO = New System.Windows.Forms.CheckBox()
        Me.txtTgl_PO = New PendaftaranPO.FlexMaskEditBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtTot_Item = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtTGL_MULAI = New PendaftaranPO.FlexMaskEditBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.lblIdDaftarPO = New System.Windows.Forms.Label()
        Me.cmbFilter = New System.Windows.Forms.ComboBox()
        Me.btnHapusPO = New System.Windows.Forms.Button()
        Me.btnEditPO = New System.Windows.Forms.Button()
        Me.btnNext2 = New System.Windows.Forms.Button()
        Me.btnPrev2 = New System.Windows.Forms.Button()
        Me.btnBatalPO = New System.Windows.Forms.Button()
        Me.btnSimpanPO = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnKeluar = New System.Windows.Forms.Button()
        Me.grpSup.SuspendLayout()
        CType(Me.DsPO1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpHidden.SuspendLayout()
        Me.grpDaftar.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'oldapMobil
        '
        Me.oldapMobil.DeleteCommand = Me.OleDbDeleteCommand1
        Me.oldapMobil.InsertCommand = Me.OleDbInsertCommand1
        Me.oldapMobil.SelectCommand = Me.OleDbSelectCommand1
        Me.oldapMobil.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "DC_JLR_DAFTARJALUR_T", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("ID_DAFTARJALUR", "ID_DAFTARJALUR"), New System.Data.Common.DataColumnMapping("DC_ID", "DC_ID"), New System.Data.Common.DataColumnMapping("TANGGAL", "TANGGAL"), New System.Data.Common.DataColumnMapping("RECID", "RECID"), New System.Data.Common.DataColumnMapping("NOMOBIL", "NOMOBIL"), New System.Data.Common.DataColumnMapping("NOURUT", "NOURUT"), New System.Data.Common.DataColumnMapping("SUPCO", "SUPCO"), New System.Data.Common.DataColumnMapping("SNAMA", "SNAMA"), New System.Data.Common.DataColumnMapping("ITEM", "ITEMnya"), New System.Data.Common.DataColumnMapping("RUPIAH", "RUPIAH"), New System.Data.Common.DataColumnMapping("TGLSTART", "TGLSTART"), New System.Data.Common.DataColumnMapping("TGLEND", "TGLEND"), New System.Data.Common.DataColumnMapping("JALUR", "JALUR")})})
        Me.oldapMobil.UpdateCommand = Me.OleDbUpdateCommand1
        '
        'OleDbDeleteCommand1
        '
        Me.OleDbDeleteCommand1.CommandText = "DELETE FROM DC_JLR_DAFTARJALUR_T WHERE (ID_DAFTARJALUR = ?)"
        Me.OleDbDeleteCommand1.Connection = Me.olcon
        OracleParameter1.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter1.ParameterName = "ID_DAFTARJALUR"
        OracleParameter1.Precision = CType(38, Byte)
        OracleParameter1.SourceColumn = "ID_DAFTARJALUR"
        OracleParameter1.SourceVersion = System.Data.DataRowVersion.Original
        Me.OleDbDeleteCommand1.Parameters.Add(OracleParameter1)
        Me.OleDbDeleteCommand1.Transaction = Nothing
        '
        'OleDbInsertCommand1
        '
        Me.OleDbInsertCommand1.CommandText = "INSERT INTO DC_JLR_DAFTARJALUR_T(ID_DAFTARJALUR, DC_ID, TANGGAL, RECID, NOMOBIL, " &
    "NOURUT, SUPCO, SNAMA, ITEM, RUPIAH, TGLSTART, TGLEND, JALUR) VALUES (?, ?, ?, ?," &
    " ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        Me.OleDbInsertCommand1.Connection = Me.olcon
        OracleParameter2.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter2.ParameterName = "ID_DAFTARJALUR"
        OracleParameter2.Precision = CType(38, Byte)
        OracleParameter2.SourceColumn = "ID_DAFTARJALUR"
        OracleParameter3.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter3.ParameterName = "DC_ID"
        OracleParameter3.Precision = CType(38, Byte)
        OracleParameter3.SourceColumn = "DC_ID"
        OracleParameter4.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter4.ParameterName = "TANGGAL"
        OracleParameter4.SourceColumn = "TANGGAL"
        OracleParameter5.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter5.ParameterName = "RECID"
        OracleParameter5.Size = 1
        OracleParameter5.SourceColumn = "RECID"
        OracleParameter6.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter6.ParameterName = "NOMOBIL"
        OracleParameter6.Size = 11
        OracleParameter6.SourceColumn = "NOMOBIL"
        OracleParameter7.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter7.ParameterName = "NOURUT"
        OracleParameter7.Precision = CType(38, Byte)
        OracleParameter7.SourceColumn = "NOURUT"
        OracleParameter8.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter8.ParameterName = "SUPCO"
        OracleParameter8.Size = 4
        OracleParameter8.SourceColumn = "SUPCO"
        OracleParameter9.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter9.ParameterName = "SNAMA"
        OracleParameter9.Size = 50
        OracleParameter9.SourceColumn = "SNAMA"
        OracleParameter10.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter10.ParameterName = "ITEM"
        OracleParameter10.Precision = CType(38, Byte)
        OracleParameter10.SourceColumn = "ITEM"
        OracleParameter11.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter11.ParameterName = "RUPIAH"
        OracleParameter11.Precision = CType(38, Byte)
        OracleParameter11.SourceColumn = "RUPIAH"
        OracleParameter12.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter12.ParameterName = "TGLSTART"
        OracleParameter12.SourceColumn = "TGLSTART"
        OracleParameter13.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter13.ParameterName = "TGLEND"
        OracleParameter13.SourceColumn = "TGLEND"
        OracleParameter14.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter14.ParameterName = "JALUR"
        OracleParameter14.Size = 50
        OracleParameter14.SourceColumn = "JALUR"
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter2)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter3)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter4)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter5)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter6)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter7)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter8)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter9)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter10)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter11)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter12)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter13)
        Me.OleDbInsertCommand1.Parameters.Add(OracleParameter14)
        Me.OleDbInsertCommand1.Transaction = Nothing
        '
        'OleDbSelectCommand1
        '
        Me.OleDbSelectCommand1.CommandText = "Select     ID_DAFTARJALUR, DC_ID, TANGGAL, RECID, NOMOBIL, NOURUT, SUPCO, SNAMA, " &
    "ITEM, trunc(RUPIAH,8) as rupiah, TGLSTART, TGLEND, JALUR, PRINT_ID FROM  DC_JLR_" &
    "DAFTARJALUR_T"
        Me.OleDbSelectCommand1.Connection = Me.olcon
        Me.OleDbSelectCommand1.Transaction = Nothing
        '
        'OleDbUpdateCommand1
        '
        Me.OleDbUpdateCommand1.CommandText = resources.GetString("OleDbUpdateCommand1.CommandText")
        Me.OleDbUpdateCommand1.Connection = Me.olcon
        OracleParameter15.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter15.ParameterName = "ID_DAFTARJALUR"
        OracleParameter15.Precision = CType(38, Byte)
        OracleParameter15.SourceColumn = "ID_DAFTARJALUR"
        OracleParameter16.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter16.ParameterName = "DC_ID"
        OracleParameter16.Precision = CType(38, Byte)
        OracleParameter16.SourceColumn = "DC_ID"
        OracleParameter17.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter17.ParameterName = "TANGGAL"
        OracleParameter17.SourceColumn = "TANGGAL"
        OracleParameter18.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter18.ParameterName = "RECID"
        OracleParameter18.Size = 1
        OracleParameter18.SourceColumn = "RECID"
        OracleParameter19.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter19.ParameterName = "NOMOBIL"
        OracleParameter19.Size = 11
        OracleParameter19.SourceColumn = "NOMOBIL"
        OracleParameter20.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter20.ParameterName = "NOURUT"
        OracleParameter20.Precision = CType(38, Byte)
        OracleParameter20.SourceColumn = "NOURUT"
        OracleParameter21.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter21.ParameterName = "SUPCO"
        OracleParameter21.Size = 4
        OracleParameter21.SourceColumn = "SUPCO"
        OracleParameter22.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter22.ParameterName = "SNAMA"
        OracleParameter22.Size = 50
        OracleParameter22.SourceColumn = "SNAMA"
        OracleParameter23.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter23.ParameterName = "ITEM"
        OracleParameter23.Precision = CType(38, Byte)
        OracleParameter23.SourceColumn = "ITEM"
        OracleParameter24.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter24.ParameterName = "RUPIAH"
        OracleParameter24.Precision = CType(38, Byte)
        OracleParameter24.SourceColumn = "RUPIAH"
        OracleParameter25.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter25.ParameterName = "TGLSTART"
        OracleParameter25.SourceColumn = "TGLSTART"
        OracleParameter26.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter26.ParameterName = "TGLEND"
        OracleParameter26.SourceColumn = "TGLEND"
        OracleParameter27.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter27.ParameterName = "JALUR"
        OracleParameter27.Size = 50
        OracleParameter27.SourceColumn = "JALUR"
        OracleParameter28.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter28.ParameterName = "Original_ID_DAFTARJALUR"
        OracleParameter28.Precision = CType(38, Byte)
        OracleParameter28.SourceColumn = "ID_DAFTARJALUR"
        OracleParameter28.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter29.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter29.ParameterName = "Original_DC_ID"
        OracleParameter29.Precision = CType(38, Byte)
        OracleParameter29.SourceColumn = "DC_ID"
        OracleParameter29.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter30.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter30.ParameterName = "Original_ITEM"
        OracleParameter30.Precision = CType(38, Byte)
        OracleParameter30.SourceColumn = "ITEM"
        OracleParameter30.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter31.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter31.ParameterName = "Original_ITEM1"
        OracleParameter31.Precision = CType(38, Byte)
        OracleParameter31.SourceColumn = "ITEM"
        OracleParameter31.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter32.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter32.ParameterName = "Original_JALUR"
        OracleParameter32.Size = 50
        OracleParameter32.SourceColumn = "JALUR"
        OracleParameter32.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter33.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter33.ParameterName = "Original_JALUR1"
        OracleParameter33.Size = 50
        OracleParameter33.SourceColumn = "JALUR"
        OracleParameter33.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter34.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter34.ParameterName = "Original_NOMOBIL"
        OracleParameter34.Size = 11
        OracleParameter34.SourceColumn = "NOMOBIL"
        OracleParameter34.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter35.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter35.ParameterName = "Original_NOURUT"
        OracleParameter35.Precision = CType(38, Byte)
        OracleParameter35.SourceColumn = "NOURUT"
        OracleParameter35.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter36.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter36.ParameterName = "Original_NOURUT1"
        OracleParameter36.Precision = CType(38, Byte)
        OracleParameter36.SourceColumn = "NOURUT"
        OracleParameter36.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter37.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter37.ParameterName = "Original_RECID"
        OracleParameter37.Size = 1
        OracleParameter37.SourceColumn = "RECID"
        OracleParameter37.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter38.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter38.ParameterName = "Original_RECID1"
        OracleParameter38.Size = 1
        OracleParameter38.SourceColumn = "RECID"
        OracleParameter38.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter39.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter39.ParameterName = "Original_RUPIAH"
        OracleParameter39.Precision = CType(38, Byte)
        OracleParameter39.SourceColumn = "RUPIAH"
        OracleParameter39.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter40.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter40.ParameterName = "Original_RUPIAH1"
        OracleParameter40.Precision = CType(38, Byte)
        OracleParameter40.SourceColumn = "RUPIAH"
        OracleParameter40.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter41.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter41.ParameterName = "Original_SNAMA"
        OracleParameter41.Size = 50
        OracleParameter41.SourceColumn = "SNAMA"
        OracleParameter41.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter42.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter42.ParameterName = "Original_SNAMA1"
        OracleParameter42.Size = 50
        OracleParameter42.SourceColumn = "SNAMA"
        OracleParameter42.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter43.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter43.ParameterName = "Original_SUPCO"
        OracleParameter43.Size = 4
        OracleParameter43.SourceColumn = "SUPCO"
        OracleParameter43.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter44.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter44.ParameterName = "Original_SUPCO1"
        OracleParameter44.Size = 4
        OracleParameter44.SourceColumn = "SUPCO"
        OracleParameter44.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter45.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter45.ParameterName = "Original_TANGGAL"
        OracleParameter45.SourceColumn = "TANGGAL"
        OracleParameter45.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter46.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter46.ParameterName = "Original_TANGGAL1"
        OracleParameter46.SourceColumn = "TANGGAL"
        OracleParameter46.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter47.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter47.ParameterName = "Original_TGLEND"
        OracleParameter47.SourceColumn = "TGLEND"
        OracleParameter47.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter48.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter48.ParameterName = "Original_TGLEND1"
        OracleParameter48.SourceColumn = "TGLEND"
        OracleParameter48.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter49.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter49.ParameterName = "Original_TGLSTART"
        OracleParameter49.SourceColumn = "TGLSTART"
        OracleParameter49.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter50.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter50.ParameterName = "Original_TGLSTART1"
        OracleParameter50.SourceColumn = "TGLSTART"
        OracleParameter50.SourceVersion = System.Data.DataRowVersion.Original
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter15)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter16)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter17)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter18)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter19)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter20)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter21)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter22)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter23)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter24)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter25)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter26)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter27)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter28)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter29)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter30)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter31)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter32)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter33)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter34)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter35)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter36)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter37)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter38)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter39)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter40)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter41)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter42)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter43)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter44)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter45)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter46)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter47)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter48)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter49)
        Me.OleDbUpdateCommand1.Parameters.Add(OracleParameter50)
        Me.OleDbUpdateCommand1.Transaction = Nothing
        '
        'oldapPO
        '
        Me.oldapPO.DeleteCommand = Me.OleDbDeleteCommand2
        Me.oldapPO.InsertCommand = Me.OleDbInsertCommand2
        Me.oldapPO.SelectCommand = Me.OleDbSelectCommand2
        Me.oldapPO.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "DC_JLR_DAFTARPO_T", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("ID_DAFTARPO", "ID_DAFTARPO"), New System.Data.Common.DataColumnMapping("TANGGAL", "TANGGAL"), New System.Data.Common.DataColumnMapping("RECID", "RECID"), New System.Data.Common.DataColumnMapping("ID_DAFTARJALUR", "ID_DAFTARJALUR"), New System.Data.Common.DataColumnMapping("NO_FAK", "NO_FAK"), New System.Data.Common.DataColumnMapping("TGL_FAK", "TGL_FAK"), New System.Data.Common.DataColumnMapping("NOPO", "NOPO"), New System.Data.Common.DataColumnMapping("SUPCO", "SUPCO"), New System.Data.Common.DataColumnMapping("SNAMA", "SNAMA"), New System.Data.Common.DataColumnMapping("BUAT_PO", "BUAT_PO"), New System.Data.Common.DataColumnMapping("ADA_HARGA", "ADA_HARGA"), New System.Data.Common.DataColumnMapping("QTY", "QTY"), New System.Data.Common.DataColumnMapping("ITEM", "ITEMnya"), New System.Data.Common.DataColumnMapping("RUPIAH", "RUPIAH"), New System.Data.Common.DataColumnMapping("PPN", "PPN"), New System.Data.Common.DataColumnMapping("BPB_NO", "BPB_NO"), New System.Data.Common.DataColumnMapping("TGL_MULAI", "TGL_MULAI"), New System.Data.Common.DataColumnMapping("JAM_MULAI", "JAM_MULAI"), New System.Data.Common.DataColumnMapping("TGL_AKHIR", "TGL_AKHIR"), New System.Data.Common.DataColumnMapping("JAM_AKHIR", "JAM_AKHIR"), New System.Data.Common.DataColumnMapping("JML_MOBIL", "JML_MOBIL"), New System.Data.Common.DataColumnMapping("TGL_REVISI", "TGL_REVISI"), New System.Data.Common.DataColumnMapping("JAM_REVISI", "JAM_REVISI"), New System.Data.Common.DataColumnMapping("USER_NAME", "USER_NAME"), New System.Data.Common.DataColumnMapping("MRBREAD", "MRBREAD"), New System.Data.Common.DataColumnMapping("UPDATE", "UPDATE"), New System.Data.Common.DataColumnMapping("SUPID", "SUPID"), New System.Data.Common.DataColumnMapping("GUDANG_KODE", "GUDANG_KODE"), New System.Data.Common.DataColumnMapping("LOKASI_KODE", "LOKASI_KODE"), New System.Data.Common.DataColumnMapping("TOTAL", "Total"), New System.Data.Common.DataColumnMapping("STATUS", "Status")})})
        Me.oldapPO.UpdateCommand = Me.OleDbUpdateCommand2
        '
        'OleDbDeleteCommand2
        '
        Me.OleDbDeleteCommand2.CommandText = "DELETE FROM DC_JLR_DAFTARPO_T WHERE (ID_DAFTARPO = ?)"
        Me.OleDbDeleteCommand2.Connection = Me.olcon
        OracleParameter51.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter51.ParameterName = "ID_DAFTARPO"
        OracleParameter51.Precision = CType(38, Byte)
        OracleParameter51.SourceColumn = "ID_DAFTARPO"
        OracleParameter51.SourceVersion = System.Data.DataRowVersion.Original
        Me.OleDbDeleteCommand2.Parameters.Add(OracleParameter51)
        Me.OleDbDeleteCommand2.Transaction = Nothing
        '
        'OleDbInsertCommand2
        '
        Me.OleDbInsertCommand2.CommandText = resources.GetString("OleDbInsertCommand2.CommandText")
        Me.OleDbInsertCommand2.Connection = Me.olcon
        OracleParameter52.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter52.ParameterName = "ID_DAFTARPO"
        OracleParameter52.Precision = CType(38, Byte)
        OracleParameter52.SourceColumn = "ID_DAFTARPO"
        OracleParameter53.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter53.ParameterName = "TANGGAL"
        OracleParameter53.SourceColumn = "TANGGAL"
        OracleParameter54.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter54.ParameterName = "RECID"
        OracleParameter54.Size = 1
        OracleParameter54.SourceColumn = "RECID"
        OracleParameter55.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter55.ParameterName = "ID_DAFTARJALUR"
        OracleParameter55.Precision = CType(38, Byte)
        OracleParameter55.SourceColumn = "ID_DAFTARJALUR"
        OracleParameter56.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter56.ParameterName = "NO_FAK"
        OracleParameter56.Size = 15
        OracleParameter56.SourceColumn = "NO_FAK"
        OracleParameter57.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter57.ParameterName = "TGL_FAK"
        OracleParameter57.SourceColumn = "TGL_FAK"
        OracleParameter58.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter58.ParameterName = "NOPO"
        OracleParameter58.Size = 9
        OracleParameter58.SourceColumn = "NOPO"
        OracleParameter59.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter59.ParameterName = "SUPCO"
        OracleParameter59.Size = 4
        OracleParameter59.SourceColumn = "SUPCO"
        OracleParameter60.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter60.ParameterName = "SNAMA"
        OracleParameter60.Size = 50
        OracleParameter60.SourceColumn = "SNAMA"
        OracleParameter61.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter61.ParameterName = "BUAT_PO"
        OracleParameter61.Precision = CType(38, Byte)
        OracleParameter61.SourceColumn = "BUAT_PO"
        OracleParameter62.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter62.ParameterName = "ADA_HARGA"
        OracleParameter62.Precision = CType(38, Byte)
        OracleParameter62.SourceColumn = "ADA_HARGA"
        OracleParameter63.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter63.ParameterName = "QTY"
        OracleParameter63.Precision = CType(38, Byte)
        OracleParameter63.SourceColumn = "QTY"
        OracleParameter64.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter64.ParameterName = "ITEM"
        OracleParameter64.Precision = CType(38, Byte)
        OracleParameter64.SourceColumn = "ITEM"
        OracleParameter65.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter65.ParameterName = "RUPIAH"
        OracleParameter65.Precision = CType(38, Byte)
        OracleParameter65.SourceColumn = "RUPIAH"
        OracleParameter66.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter66.ParameterName = "PPN"
        OracleParameter66.Precision = CType(38, Byte)
        OracleParameter66.SourceColumn = "PPN"
        OracleParameter67.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter67.ParameterName = "BPB_NO"
        OracleParameter67.Precision = CType(38, Byte)
        OracleParameter67.SourceColumn = "BPB_NO"
        OracleParameter68.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter68.ParameterName = "TGL_MULAI"
        OracleParameter68.SourceColumn = "TGL_MULAI"
        OracleParameter69.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter69.ParameterName = "JAM_MULAI"
        OracleParameter69.Size = 8
        OracleParameter69.SourceColumn = "JAM_MULAI"
        OracleParameter70.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter70.ParameterName = "TGL_AKHIR"
        OracleParameter70.SourceColumn = "TGL_AKHIR"
        OracleParameter71.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter71.ParameterName = "JAM_AKHIR"
        OracleParameter71.Size = 8
        OracleParameter71.SourceColumn = "JAM_AKHIR"
        OracleParameter72.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter72.ParameterName = "JML_MOBIL"
        OracleParameter72.Precision = CType(38, Byte)
        OracleParameter72.SourceColumn = "JML_MOBIL"
        OracleParameter73.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter73.ParameterName = "TGL_REVISI"
        OracleParameter73.SourceColumn = "TGL_REVISI"
        OracleParameter74.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter74.ParameterName = "JAM_REVISI"
        OracleParameter74.Size = 8
        OracleParameter74.SourceColumn = "JAM_REVISI"
        OracleParameter75.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter75.ParameterName = "USER_NAME"
        OracleParameter75.Size = 15
        OracleParameter75.SourceColumn = "USER_NAME"
        OracleParameter76.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter76.ParameterName = "MRBREAD"
        OracleParameter76.Size = 1
        OracleParameter76.SourceColumn = "MRBREAD"
        OracleParameter77.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter77.ParameterName = "UPDATE"
        OracleParameter77.SourceColumn = "UPDATE"
        OracleParameter78.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter78.ParameterName = "SUPID"
        OracleParameter78.Precision = CType(38, Byte)
        OracleParameter78.SourceColumn = "SUPID"
        OracleParameter79.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter79.ParameterName = "GUDANG_KODE"
        OracleParameter79.Size = 8
        OracleParameter79.SourceColumn = "GUDANG_KODE"
        OracleParameter80.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter80.ParameterName = "LOKASI_KODE"
        OracleParameter80.Size = 8
        OracleParameter80.SourceColumn = "LOKASI_KODE"
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter52)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter53)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter54)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter55)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter56)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter57)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter58)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter59)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter60)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter61)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter62)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter63)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter64)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter65)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter66)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter67)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter68)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter69)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter70)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter71)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter72)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter73)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter74)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter75)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter76)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter77)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter78)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter79)
        Me.OleDbInsertCommand2.Parameters.Add(OracleParameter80)
        Me.OleDbInsertCommand2.Transaction = Nothing
        '
        'OleDbSelectCommand2
        '
        Me.OleDbSelectCommand2.CommandText = resources.GetString("OleDbSelectCommand2.CommandText")
        Me.OleDbSelectCommand2.Connection = Me.olcon
        Me.OleDbSelectCommand2.Transaction = Nothing
        '
        'OleDbUpdateCommand2
        '
        Me.OleDbUpdateCommand2.CommandText = resources.GetString("OleDbUpdateCommand2.CommandText")
        Me.OleDbUpdateCommand2.Connection = Me.olcon
        OracleParameter81.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter81.ParameterName = "ID_DAFTARPO"
        OracleParameter81.Precision = CType(38, Byte)
        OracleParameter81.SourceColumn = "ID_DAFTARPO"
        OracleParameter82.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter82.ParameterName = "TANGGAL"
        OracleParameter82.SourceColumn = "TANGGAL"
        OracleParameter83.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter83.ParameterName = "RECID"
        OracleParameter83.Size = 1
        OracleParameter83.SourceColumn = "RECID"
        OracleParameter84.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter84.ParameterName = "ID_DAFTARJALUR"
        OracleParameter84.Precision = CType(38, Byte)
        OracleParameter84.SourceColumn = "ID_DAFTARJALUR"
        OracleParameter85.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter85.ParameterName = "NO_FAK"
        OracleParameter85.Size = 15
        OracleParameter85.SourceColumn = "NO_FAK"
        OracleParameter86.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter86.ParameterName = "TGL_FAK"
        OracleParameter86.SourceColumn = "TGL_FAK"
        OracleParameter87.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter87.ParameterName = "NOPO"
        OracleParameter87.Size = 9
        OracleParameter87.SourceColumn = "NOPO"
        OracleParameter88.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter88.ParameterName = "SUPCO"
        OracleParameter88.Size = 4
        OracleParameter88.SourceColumn = "SUPCO"
        OracleParameter89.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter89.ParameterName = "SNAMA"
        OracleParameter89.Size = 50
        OracleParameter89.SourceColumn = "SNAMA"
        OracleParameter90.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter90.ParameterName = "BUAT_PO"
        OracleParameter90.Precision = CType(38, Byte)
        OracleParameter90.SourceColumn = "BUAT_PO"
        OracleParameter91.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter91.ParameterName = "ADA_HARGA"
        OracleParameter91.Precision = CType(38, Byte)
        OracleParameter91.SourceColumn = "ADA_HARGA"
        OracleParameter92.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter92.ParameterName = "QTY"
        OracleParameter92.Precision = CType(38, Byte)
        OracleParameter92.SourceColumn = "QTY"
        OracleParameter93.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter93.ParameterName = "ITEM"
        OracleParameter93.Precision = CType(38, Byte)
        OracleParameter93.SourceColumn = "ITEM"
        OracleParameter94.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter94.ParameterName = "RUPIAH"
        OracleParameter94.Precision = CType(38, Byte)
        OracleParameter94.SourceColumn = "RUPIAH"
        OracleParameter95.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter95.ParameterName = "PPN"
        OracleParameter95.Precision = CType(38, Byte)
        OracleParameter95.SourceColumn = "PPN"
        OracleParameter96.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter96.ParameterName = "BPB_NO"
        OracleParameter96.Precision = CType(38, Byte)
        OracleParameter96.SourceColumn = "BPB_NO"
        OracleParameter97.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter97.ParameterName = "TGL_MULAI"
        OracleParameter97.SourceColumn = "TGL_MULAI"
        OracleParameter98.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter98.ParameterName = "JAM_MULAI"
        OracleParameter98.Size = 8
        OracleParameter98.SourceColumn = "JAM_MULAI"
        OracleParameter99.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter99.ParameterName = "TGL_AKHIR"
        OracleParameter99.SourceColumn = "TGL_AKHIR"
        OracleParameter100.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter100.ParameterName = "JAM_AKHIR"
        OracleParameter100.Size = 8
        OracleParameter100.SourceColumn = "JAM_AKHIR"
        OracleParameter101.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter101.ParameterName = "JML_MOBIL"
        OracleParameter101.Precision = CType(38, Byte)
        OracleParameter101.SourceColumn = "JML_MOBIL"
        OracleParameter102.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter102.ParameterName = "TGL_REVISI"
        OracleParameter102.SourceColumn = "TGL_REVISI"
        OracleParameter103.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter103.ParameterName = "JAM_REVISI"
        OracleParameter103.Size = 8
        OracleParameter103.SourceColumn = "JAM_REVISI"
        OracleParameter104.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter104.ParameterName = "USER_NAME"
        OracleParameter104.Size = 15
        OracleParameter104.SourceColumn = "USER_NAME"
        OracleParameter105.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter105.ParameterName = "MRBREAD"
        OracleParameter105.Size = 1
        OracleParameter105.SourceColumn = "MRBREAD"
        OracleParameter106.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter106.ParameterName = "UPDATE"
        OracleParameter106.SourceColumn = "UPDATE"
        OracleParameter107.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter107.ParameterName = "SUPID"
        OracleParameter107.Precision = CType(38, Byte)
        OracleParameter107.SourceColumn = "SUPID"
        OracleParameter108.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter108.ParameterName = "GUDANG_KODE"
        OracleParameter108.Size = 8
        OracleParameter108.SourceColumn = "GUDANG_KODE"
        OracleParameter109.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter109.ParameterName = "LOKASI_KODE"
        OracleParameter109.Size = 8
        OracleParameter109.SourceColumn = "LOKASI_KODE"
        OracleParameter110.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter110.ParameterName = "Original_ID_DAFTARPO"
        OracleParameter110.Precision = CType(38, Byte)
        OracleParameter110.SourceColumn = "ID_DAFTARPO"
        OracleParameter110.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter111.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter111.ParameterName = "Original_ADA_HARGA"
        OracleParameter111.Precision = CType(38, Byte)
        OracleParameter111.SourceColumn = "ADA_HARGA"
        OracleParameter111.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter112.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter112.ParameterName = "Original_ADA_HARGA1"
        OracleParameter112.Precision = CType(38, Byte)
        OracleParameter112.SourceColumn = "ADA_HARGA"
        OracleParameter112.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter113.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter113.ParameterName = "Original_BPB_NO"
        OracleParameter113.Precision = CType(38, Byte)
        OracleParameter113.SourceColumn = "BPB_NO"
        OracleParameter113.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter114.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter114.ParameterName = "Original_BPB_NO1"
        OracleParameter114.Precision = CType(38, Byte)
        OracleParameter114.SourceColumn = "BPB_NO"
        OracleParameter114.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter115.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter115.ParameterName = "Original_BUAT_PO"
        OracleParameter115.Precision = CType(38, Byte)
        OracleParameter115.SourceColumn = "BUAT_PO"
        OracleParameter115.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter116.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter116.ParameterName = "Original_BUAT_PO1"
        OracleParameter116.Precision = CType(38, Byte)
        OracleParameter116.SourceColumn = "BUAT_PO"
        OracleParameter116.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter117.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter117.ParameterName = "Original_GUDANG_KODE"
        OracleParameter117.Size = 8
        OracleParameter117.SourceColumn = "GUDANG_KODE"
        OracleParameter117.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter118.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter118.ParameterName = "Original_GUDANG_KODE1"
        OracleParameter118.Size = 8
        OracleParameter118.SourceColumn = "GUDANG_KODE"
        OracleParameter118.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter119.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter119.ParameterName = "Original_ID_DAFTARJALUR"
        OracleParameter119.Precision = CType(38, Byte)
        OracleParameter119.SourceColumn = "ID_DAFTARJALUR"
        OracleParameter119.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter120.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter120.ParameterName = "Original_ID_DAFTARJALUR1"
        OracleParameter120.Precision = CType(38, Byte)
        OracleParameter120.SourceColumn = "ID_DAFTARJALUR"
        OracleParameter120.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter121.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter121.ParameterName = "Original_ITEM"
        OracleParameter121.Precision = CType(38, Byte)
        OracleParameter121.SourceColumn = "ITEM"
        OracleParameter121.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter122.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter122.ParameterName = "Original_ITEM1"
        OracleParameter122.Precision = CType(38, Byte)
        OracleParameter122.SourceColumn = "ITEM"
        OracleParameter122.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter123.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter123.ParameterName = "Original_JAM_AKHIR"
        OracleParameter123.Size = 8
        OracleParameter123.SourceColumn = "JAM_AKHIR"
        OracleParameter123.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter124.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter124.ParameterName = "Original_JAM_AKHIR1"
        OracleParameter124.Size = 8
        OracleParameter124.SourceColumn = "JAM_AKHIR"
        OracleParameter124.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter125.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter125.ParameterName = "Original_JAM_MULAI"
        OracleParameter125.Size = 8
        OracleParameter125.SourceColumn = "JAM_MULAI"
        OracleParameter125.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter126.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter126.ParameterName = "Original_JAM_MULAI1"
        OracleParameter126.Size = 8
        OracleParameter126.SourceColumn = "JAM_MULAI"
        OracleParameter126.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter127.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter127.ParameterName = "Original_JAM_REVISI"
        OracleParameter127.Size = 8
        OracleParameter127.SourceColumn = "JAM_REVISI"
        OracleParameter127.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter128.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter128.ParameterName = "Original_JAM_REVISI1"
        OracleParameter128.Size = 8
        OracleParameter128.SourceColumn = "JAM_REVISI"
        OracleParameter128.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter129.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter129.ParameterName = "Original_JML_MOBIL"
        OracleParameter129.Precision = CType(38, Byte)
        OracleParameter129.SourceColumn = "JML_MOBIL"
        OracleParameter129.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter130.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter130.ParameterName = "Original_JML_MOBIL1"
        OracleParameter130.Precision = CType(38, Byte)
        OracleParameter130.SourceColumn = "JML_MOBIL"
        OracleParameter130.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter131.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter131.ParameterName = "Original_LOKASI_KODE"
        OracleParameter131.Size = 8
        OracleParameter131.SourceColumn = "LOKASI_KODE"
        OracleParameter131.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter132.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter132.ParameterName = "Original_LOKASI_KODE1"
        OracleParameter132.Size = 8
        OracleParameter132.SourceColumn = "LOKASI_KODE"
        OracleParameter132.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter133.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter133.ParameterName = "Original_MRBREAD"
        OracleParameter133.Size = 1
        OracleParameter133.SourceColumn = "MRBREAD"
        OracleParameter133.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter134.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter134.ParameterName = "Original_MRBREAD1"
        OracleParameter134.Size = 1
        OracleParameter134.SourceColumn = "MRBREAD"
        OracleParameter134.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter135.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter135.ParameterName = "Original_NOPO"
        OracleParameter135.Size = 9
        OracleParameter135.SourceColumn = "NOPO"
        OracleParameter135.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter136.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter136.ParameterName = "Original_NOPO1"
        OracleParameter136.Size = 9
        OracleParameter136.SourceColumn = "NOPO"
        OracleParameter136.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter137.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter137.ParameterName = "Original_NO_FAK"
        OracleParameter137.Size = 15
        OracleParameter137.SourceColumn = "NO_FAK"
        OracleParameter137.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter138.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter138.ParameterName = "Original_NO_FAK1"
        OracleParameter138.Size = 15
        OracleParameter138.SourceColumn = "NO_FAK"
        OracleParameter138.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter139.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter139.ParameterName = "Original_PPN"
        OracleParameter139.Precision = CType(38, Byte)
        OracleParameter139.SourceColumn = "PPN"
        OracleParameter139.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter140.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter140.ParameterName = "Original_PPN1"
        OracleParameter140.Precision = CType(38, Byte)
        OracleParameter140.SourceColumn = "PPN"
        OracleParameter140.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter141.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter141.ParameterName = "Original_QTY"
        OracleParameter141.Precision = CType(38, Byte)
        OracleParameter141.SourceColumn = "QTY"
        OracleParameter141.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter142.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter142.ParameterName = "Original_QTY1"
        OracleParameter142.Precision = CType(38, Byte)
        OracleParameter142.SourceColumn = "QTY"
        OracleParameter142.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter143.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter143.ParameterName = "Original_RECID"
        OracleParameter143.Size = 1
        OracleParameter143.SourceColumn = "RECID"
        OracleParameter143.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter144.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter144.ParameterName = "Original_RECID1"
        OracleParameter144.Size = 1
        OracleParameter144.SourceColumn = "RECID"
        OracleParameter144.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter145.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter145.ParameterName = "Original_RUPIAH"
        OracleParameter145.Precision = CType(38, Byte)
        OracleParameter145.SourceColumn = "RUPIAH"
        OracleParameter145.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter146.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter146.ParameterName = "Original_RUPIAH1"
        OracleParameter146.Precision = CType(38, Byte)
        OracleParameter146.SourceColumn = "RUPIAH"
        OracleParameter146.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter147.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter147.ParameterName = "Original_SNAMA"
        OracleParameter147.Size = 50
        OracleParameter147.SourceColumn = "SNAMA"
        OracleParameter147.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter148.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter148.ParameterName = "Original_SNAMA1"
        OracleParameter148.Size = 50
        OracleParameter148.SourceColumn = "SNAMA"
        OracleParameter148.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter149.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter149.ParameterName = "Original_SUPCO"
        OracleParameter149.Size = 4
        OracleParameter149.SourceColumn = "SUPCO"
        OracleParameter149.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter150.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter150.ParameterName = "Original_SUPID"
        OracleParameter150.Precision = CType(38, Byte)
        OracleParameter150.SourceColumn = "SUPID"
        OracleParameter150.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter151.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.[Decimal]
        OracleParameter151.ParameterName = "Original_SUPID1"
        OracleParameter151.Precision = CType(38, Byte)
        OracleParameter151.SourceColumn = "SUPID"
        OracleParameter151.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter152.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter152.ParameterName = "Original_TANGGAL"
        OracleParameter152.SourceColumn = "TANGGAL"
        OracleParameter152.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter153.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter153.ParameterName = "Original_TANGGAL1"
        OracleParameter153.SourceColumn = "TANGGAL"
        OracleParameter153.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter154.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter154.ParameterName = "Original_TGL_AKHIR"
        OracleParameter154.SourceColumn = "TGL_AKHIR"
        OracleParameter154.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter155.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter155.ParameterName = "Original_TGL_AKHIR1"
        OracleParameter155.SourceColumn = "TGL_AKHIR"
        OracleParameter155.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter156.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter156.ParameterName = "Original_TGL_FAK"
        OracleParameter156.SourceColumn = "TGL_FAK"
        OracleParameter156.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter157.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter157.ParameterName = "Original_TGL_FAK1"
        OracleParameter157.SourceColumn = "TGL_FAK"
        OracleParameter157.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter158.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter158.ParameterName = "Original_TGL_MULAI"
        OracleParameter158.SourceColumn = "TGL_MULAI"
        OracleParameter158.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter159.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter159.ParameterName = "Original_TGL_MULAI1"
        OracleParameter159.SourceColumn = "TGL_MULAI"
        OracleParameter159.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter160.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter160.ParameterName = "Original_TGL_REVISI"
        OracleParameter160.SourceColumn = "TGL_REVISI"
        OracleParameter160.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter161.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter161.ParameterName = "Original_TGL_REVISI1"
        OracleParameter161.SourceColumn = "TGL_REVISI"
        OracleParameter161.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter162.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter162.ParameterName = "Original_UPDATE"
        OracleParameter162.SourceColumn = "UPDATE"
        OracleParameter162.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter163.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.TimeStamp
        OracleParameter163.ParameterName = "Original_UPDATE1"
        OracleParameter163.SourceColumn = "UPDATE"
        OracleParameter163.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter164.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter164.ParameterName = "Original_USER_NAME"
        OracleParameter164.Size = 15
        OracleParameter164.SourceColumn = "USER_NAME"
        OracleParameter164.SourceVersion = System.Data.DataRowVersion.Original
        OracleParameter165.OracleDbType = Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2
        OracleParameter165.ParameterName = "Original_USER_NAME1"
        OracleParameter165.Size = 15
        OracleParameter165.SourceColumn = "USER_NAME"
        OracleParameter165.SourceVersion = System.Data.DataRowVersion.Original
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter81)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter82)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter83)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter84)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter85)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter86)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter87)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter88)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter89)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter90)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter91)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter92)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter93)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter94)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter95)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter96)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter97)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter98)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter99)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter100)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter101)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter102)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter103)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter104)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter105)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter106)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter107)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter108)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter109)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter110)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter111)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter112)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter113)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter114)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter115)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter116)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter117)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter118)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter119)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter120)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter121)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter122)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter123)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter124)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter125)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter126)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter127)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter128)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter129)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter130)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter131)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter132)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter133)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter134)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter135)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter136)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter137)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter138)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter139)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter140)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter141)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter142)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter143)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter144)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter145)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter146)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter147)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter148)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter149)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter150)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter151)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter152)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter153)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter154)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter155)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter156)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter157)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter158)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter159)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter160)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter161)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter162)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter163)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter164)
        Me.OleDbUpdateCommand2.Parameters.Add(OracleParameter165)
        Me.OleDbUpdateCommand2.Transaction = Nothing
        '
        'btnUpdate
        '
        Me.btnUpdate.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnUpdate.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdate.Location = New System.Drawing.Point(594, 247)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(75, 23)
        Me.btnUpdate.TabIndex = 1
        Me.btnUpdate.Text = "&Update"
        Me.btnUpdate.Visible = False
        '
        'btnCancelAll
        '
        Me.btnCancelAll.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCancelAll.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnCancelAll.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancelAll.Location = New System.Drawing.Point(594, 271)
        Me.btnCancelAll.Name = "btnCancelAll"
        Me.btnCancelAll.Size = New System.Drawing.Size(75, 23)
        Me.btnCancelAll.TabIndex = 2
        Me.btnCancelAll.Text = "Ca&ncel All"
        Me.btnCancelAll.Visible = False
        '
        'grpSup
        '
        Me.grpSup.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpSup.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.grpSup.Controls.Add(Me.txtNoAntrianPO)
        Me.grpSup.Controls.Add(Me.Label25)
        Me.grpSup.Controls.Add(Me.BtnPrintStck)
        Me.grpSup.Controls.Add(Me.btnPrintUlang)
        Me.grpSup.Controls.Add(Me.btnPrint)
        Me.grpSup.Controls.Add(Me.btnDraftRetur)
        Me.grpSup.Controls.Add(Me.btnCari)
        Me.grpSup.Controls.Add(Me.txtTglDaftar)
        Me.grpSup.Controls.Add(Me.txtNoAntrian)
        Me.grpSup.Controls.Add(Me.Label24)
        Me.grpSup.Controls.Add(Me.btnNext)
        Me.grpSup.Controls.Add(Me.btnPrev)
        Me.grpSup.Controls.Add(Me.btnDaftar)
        Me.grpSup.Controls.Add(Me.Label15)
        Me.grpSup.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpSup.Location = New System.Drawing.Point(7, 6)
        Me.grpSup.Name = "grpSup"
        Me.grpSup.Size = New System.Drawing.Size(675, 90)
        Me.grpSup.TabIndex = 5
        Me.grpSup.TabStop = False
        '
        'txtNoAntrianPO
        '
        Me.txtNoAntrianPO.Enabled = False
        Me.txtNoAntrianPO.Location = New System.Drawing.Point(79, 58)
        Me.txtNoAntrianPO.Name = "txtNoAntrianPO"
        Me.txtNoAntrianPO.Size = New System.Drawing.Size(95, 22)
        Me.txtNoAntrianPO.TabIndex = 75
        Me.txtNoAntrianPO.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label25
        '
        Me.Label25.BackColor = System.Drawing.Color.Transparent
        Me.Label25.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label25.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label25.Location = New System.Drawing.Point(6, 58)
        Me.Label25.Name = "Label25"
        Me.Label25.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label25.Size = New System.Drawing.Size(95, 19)
        Me.Label25.TabIndex = 76
        Me.Label25.Text = "No. Jalur:"
        '
        'BtnPrintStck
        '
        Me.BtnPrintStck.BackColor = System.Drawing.Color.Transparent
        Me.BtnPrintStck.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnPrintStck.Image = Global.PendaftaranPO.My.Resources.Resources.printer
        Me.BtnPrintStck.Location = New System.Drawing.Point(567, 29)
        Me.BtnPrintStck.Name = "BtnPrintStck"
        Me.BtnPrintStck.Size = New System.Drawing.Size(97, 28)
        Me.BtnPrintStck.TabIndex = 74
        Me.BtnPrintStck.Text = "Print Sticker"
        Me.BtnPrintStck.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnPrintStck.UseVisualStyleBackColor = False
        Me.BtnPrintStck.Visible = False
        '
        'btnPrintUlang
        '
        Me.btnPrintUlang.BackColor = System.Drawing.Color.Transparent
        Me.btnPrintUlang.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPrintUlang.Image = Global.PendaftaranPO.My.Resources.Resources.printer
        Me.btnPrintUlang.Location = New System.Drawing.Point(567, 3)
        Me.btnPrintUlang.Name = "btnPrintUlang"
        Me.btnPrintUlang.Size = New System.Drawing.Size(97, 28)
        Me.btnPrintUlang.TabIndex = 72
        Me.btnPrintUlang.Text = "Print No. Urut"
        Me.btnPrintUlang.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnPrintUlang.UseVisualStyleBackColor = False
        Me.btnPrintUlang.Visible = False
        '
        'btnPrint
        '
        Me.btnPrint.BackColor = System.Drawing.Color.Transparent
        Me.btnPrint.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPrint.Image = Global.PendaftaranPO.My.Resources.Resources.printer
        Me.btnPrint.Location = New System.Drawing.Point(264, 52)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.Size = New System.Drawing.Size(77, 28)
        Me.btnPrint.TabIndex = 9
        Me.btnPrint.Text = "Print"
        Me.btnPrint.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnPrint.UseVisualStyleBackColor = False
        '
        'btnDraftRetur
        '
        Me.btnDraftRetur.BackColor = System.Drawing.Color.Transparent
        Me.btnDraftRetur.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDraftRetur.Image = Global.PendaftaranPO.My.Resources.Resources.printer
        Me.btnDraftRetur.Location = New System.Drawing.Point(567, 58)
        Me.btnDraftRetur.Name = "btnDraftRetur"
        Me.btnDraftRetur.Size = New System.Drawing.Size(97, 28)
        Me.btnDraftRetur.TabIndex = 6
        Me.btnDraftRetur.Text = "&Draft Retur"
        Me.btnDraftRetur.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnDraftRetur.UseVisualStyleBackColor = False
        Me.btnDraftRetur.Visible = False
        '
        'btnCari
        '
        Me.btnCari.BackColor = System.Drawing.Color.Transparent
        Me.btnCari.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCari.Image = Global.PendaftaranPO.My.Resources.Resources.zoom
        Me.btnCari.Location = New System.Drawing.Point(180, 52)
        Me.btnCari.Name = "btnCari"
        Me.btnCari.Size = New System.Drawing.Size(78, 28)
        Me.btnCari.TabIndex = 5
        Me.btnCari.Text = "&Cari"
        Me.btnCari.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnCari.UseVisualStyleBackColor = False
        '
        'txtTglDaftar
        '
        Me.txtTglDaftar.CustomFormat = "dd-MM-yyyy"
        Me.txtTglDaftar.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.TANGGAL", True))
        Me.txtTglDaftar.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.txtTglDaftar.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.txtTglDaftar.Location = New System.Drawing.Point(79, 9)
        Me.txtTglDaftar.Name = "txtTglDaftar"
        Me.txtTglDaftar.Size = New System.Drawing.Size(95, 23)
        Me.txtTglDaftar.TabIndex = 3
        '
        'DsPO1
        '
        Me.DsPO1.DataSetName = "dsPO"
        Me.DsPO1.Locale = New System.Globalization.CultureInfo("en-US")
        Me.DsPO1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'txtNoAntrian
        '
        Me.txtNoAntrian.AcceptsReturn = True
        Me.txtNoAntrian.BackColor = System.Drawing.SystemColors.Window
        Me.txtNoAntrian.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtNoAntrian.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.NOURUT", True))
        Me.txtNoAntrian.Enabled = False
        Me.txtNoAntrian.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNoAntrian.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtNoAntrian.Location = New System.Drawing.Point(79, 33)
        Me.txtNoAntrian.Name = "txtNoAntrian"
        Me.txtNoAntrian.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtNoAntrian.Size = New System.Drawing.Size(95, 23)
        Me.txtNoAntrian.TabIndex = 5
        Me.txtNoAntrian.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label24
        '
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label24.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label24.Location = New System.Drawing.Point(10, 36)
        Me.Label24.Name = "Label24"
        Me.Label24.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label24.Size = New System.Drawing.Size(95, 19)
        Me.Label24.TabIndex = 4
        Me.Label24.Text = "No. Urut:"
        '
        'btnNext
        '
        Me.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnNext.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNext.Location = New System.Drawing.Point(228, 9)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(49, 37)
        Me.btnNext.TabIndex = 8
        Me.btnNext.Text = ">>"
        '
        'btnPrev
        '
        Me.btnPrev.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnPrev.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPrev.Location = New System.Drawing.Point(180, 8)
        Me.btnPrev.Name = "btnPrev"
        Me.btnPrev.Size = New System.Drawing.Size(47, 38)
        Me.btnPrev.TabIndex = 7
        Me.btnPrev.Text = "<<"
        '
        'btnDaftar
        '
        Me.btnDaftar.BackColor = System.Drawing.Color.Transparent
        Me.btnDaftar.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDaftar.Image = Global.PendaftaranPO.My.Resources.Resources.book_open
        Me.btnDaftar.Location = New System.Drawing.Point(298, 13)
        Me.btnDaftar.Name = "btnDaftar"
        Me.btnDaftar.Size = New System.Drawing.Size(72, 28)
        Me.btnDaftar.TabIndex = 0
        Me.btnDaftar.Text = "&Daftar"
        Me.btnDaftar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnDaftar.UseVisualStyleBackColor = False
        Me.btnDaftar.Visible = False
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label15.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label15.Location = New System.Drawing.Point(13, 12)
        Me.Label15.Name = "Label15"
        Me.Label15.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label15.Size = New System.Drawing.Size(95, 19)
        Me.Label15.TabIndex = 77
        Me.Label15.Text = "Tanggal:"
        '
        'grpHidden
        '
        Me.grpHidden.Controls.Add(Me.lblTglRevisi)
        Me.grpHidden.Controls.Add(Me.lblSUPID)
        Me.grpHidden.Controls.Add(Me.lblLokasiKode)
        Me.grpHidden.Controls.Add(Me.lblGudangKode)
        Me.grpHidden.Location = New System.Drawing.Point(477, 488)
        Me.grpHidden.Name = "grpHidden"
        Me.grpHidden.Size = New System.Drawing.Size(200, 14)
        Me.grpHidden.TabIndex = 18
        Me.grpHidden.TabStop = False
        '
        'lblTglRevisi
        '
        Me.lblTglRevisi.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.TGL_REVISI", True))
        Me.lblTglRevisi.Location = New System.Drawing.Point(22, 92)
        Me.lblTglRevisi.Name = "lblTglRevisi"
        Me.lblTglRevisi.Size = New System.Drawing.Size(100, 16)
        Me.lblTglRevisi.TabIndex = 23
        Me.lblTglRevisi.Text = "lblTglRevisi"
        '
        'lblSUPID
        '
        Me.lblSUPID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.SUPID", True))
        Me.lblSUPID.Location = New System.Drawing.Point(20, 63)
        Me.lblSUPID.Name = "lblSUPID"
        Me.lblSUPID.Size = New System.Drawing.Size(100, 16)
        Me.lblSUPID.TabIndex = 22
        Me.lblSUPID.Text = "lblSUPID"
        '
        'lblLokasiKode
        '
        Me.lblLokasiKode.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.LOKASI_KODE", True))
        Me.lblLokasiKode.Location = New System.Drawing.Point(20, 39)
        Me.lblLokasiKode.Name = "lblLokasiKode"
        Me.lblLokasiKode.Size = New System.Drawing.Size(100, 16)
        Me.lblLokasiKode.TabIndex = 17
        Me.lblLokasiKode.Text = "LokasiKode"
        '
        'lblGudangKode
        '
        Me.lblGudangKode.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.GUDANG_KODE", True))
        Me.lblGudangKode.Location = New System.Drawing.Point(20, 15)
        Me.lblGudangKode.Name = "lblGudangKode"
        Me.lblGudangKode.Size = New System.Drawing.Size(100, 16)
        Me.lblGudangKode.TabIndex = 16
        Me.lblGudangKode.Text = "GudangKode"
        '
        'btnTambahPO
        '
        Me.btnTambahPO.BackColor = System.Drawing.Color.Transparent
        Me.btnTambahPO.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTambahPO.Image = Global.PendaftaranPO.My.Resources.Resources.add
        Me.btnTambahPO.Location = New System.Drawing.Point(13, 12)
        Me.btnTambahPO.Name = "btnTambahPO"
        Me.btnTambahPO.Size = New System.Drawing.Size(87, 56)
        Me.btnTambahPO.TabIndex = 0
        Me.btnTambahPO.Text = "&Tambah PO"
        Me.btnTambahPO.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnTambahPO.UseVisualStyleBackColor = False
        '
        'grpDaftar
        '
        Me.grpDaftar.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpDaftar.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.grpDaftar.Controls.Add(Me.btnCancelAll)
        Me.grpDaftar.Controls.Add(Me.btnUpdate)
        Me.grpDaftar.Controls.Add(Me.Label17)
        Me.grpDaftar.Controls.Add(Me.Label7)
        Me.grpDaftar.Controls.Add(Me.Panel3)
        Me.grpDaftar.Controls.Add(Me.Panel2)
        Me.grpDaftar.Controls.Add(Me.Label26)
        Me.grpDaftar.Controls.Add(Me.txtUPDATE)
        Me.grpDaftar.Controls.Add(Me.Panel1)
        Me.grpDaftar.Controls.Add(Me.txtTGL_MULAI)
        Me.grpDaftar.Controls.Add(Me.Label23)
        Me.grpDaftar.Controls.Add(Me.Label21)
        Me.grpDaftar.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpDaftar.Location = New System.Drawing.Point(7, 102)
        Me.grpDaftar.Name = "grpDaftar"
        Me.grpDaftar.Size = New System.Drawing.Size(675, 306)
        Me.grpDaftar.TabIndex = 5
        Me.grpDaftar.TabStop = False
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label17.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label17.Location = New System.Drawing.Point(14, 6)
        Me.Label17.Name = "Label17"
        Me.Label17.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label17.Size = New System.Drawing.Size(56, 19)
        Me.Label17.TabIndex = 81
        Me.Label17.Text = "Faktur"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label7.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.Location = New System.Drawing.Point(14, 184)
        Me.Label7.Name = "Label7"
        Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label7.Size = New System.Drawing.Size(70, 19)
        Me.Label7.TabIndex = 79
        Me.Label7.Text = "Supplier"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.txtTglFaktur)
        Me.Panel3.Controls.Add(Me.txtNoFak)
        Me.Panel3.Controls.Add(Me.Label6)
        Me.Panel3.Controls.Add(Me.Label5)
        Me.Panel3.Location = New System.Drawing.Point(9, 15)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(656, 50)
        Me.Panel3.TabIndex = 80
        '
        'txtTglFaktur
        '
        Me.txtTglFaktur.BackColor = System.Drawing.SystemColors.Window
        Me.txtTglFaktur.CustomFormat = "dd-MM-yyyy"
        Me.txtTglFaktur.Enabled = False
        Me.txtTglFaktur.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTglFaktur.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTglFaktur.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.txtTglFaktur.Location = New System.Drawing.Point(280, 12)
        Me.txtTglFaktur.Name = "txtTglFaktur"
        Me.txtTglFaktur.Size = New System.Drawing.Size(100, 23)
        Me.txtTglFaktur.TabIndex = 62
        '
        'txtNoFak
        '
        Me.txtNoFak.AcceptsReturn = True
        Me.txtNoFak.BackColor = System.Drawing.SystemColors.Window
        Me.txtNoFak.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtNoFak.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtNoFak.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.NO_FAK", True))
        Me.txtNoFak.Enabled = False
        Me.txtNoFak.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNoFak.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtNoFak.Location = New System.Drawing.Point(95, 12)
        Me.txtNoFak.MaxLength = 7
        Me.txtNoFak.Name = "txtNoFak"
        Me.txtNoFak.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtNoFak.Size = New System.Drawing.Size(112, 23)
        Me.txtNoFak.TabIndex = 1
        Me.txtNoFak.Tag = "1"
        Me.txtNoFak.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label6.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(35, 15)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(81, 15)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Nomor :"
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label5.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(212, 15)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(81, 19)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Tanggal :"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.txtNamaSupp_)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.txtKodeSupp_)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Location = New System.Drawing.Point(9, 191)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(656, 51)
        Me.Panel2.TabIndex = 78
        '
        'txtNamaSupp_
        '
        Me.txtNamaSupp_.Enabled = False
        Me.txtNamaSupp_.Location = New System.Drawing.Point(280, 15)
        Me.txtNamaSupp_.Name = "txtNamaSupp_"
        Me.txtNamaSupp_.ReadOnly = True
        Me.txtNamaSupp_.Size = New System.Drawing.Size(370, 23)
        Me.txtNamaSupp_.TabIndex = 66
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label12.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label12.Location = New System.Drawing.Point(228, 17)
        Me.Label12.Name = "Label12"
        Me.Label12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label12.Size = New System.Drawing.Size(56, 15)
        Me.Label12.TabIndex = 65
        Me.Label12.Text = "Nama :"
        '
        'txtKodeSupp_
        '
        Me.txtKodeSupp_.Enabled = False
        Me.txtKodeSupp_.Location = New System.Drawing.Point(95, 15)
        Me.txtKodeSupp_.Name = "txtKodeSupp_"
        Me.txtKodeSupp_.ReadOnly = True
        Me.txtKodeSupp_.Size = New System.Drawing.Size(112, 23)
        Me.txtKodeSupp_.TabIndex = 64
        Me.txtKodeSupp_.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label11.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label11.Location = New System.Drawing.Point(43, 17)
        Me.Label11.Name = "Label11"
        Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label11.Size = New System.Drawing.Size(56, 15)
        Me.Label11.TabIndex = 63
        Me.Label11.Text = "Kode :"
        '
        'Label26
        '
        Me.Label26.BackColor = System.Drawing.Color.Transparent
        Me.Label26.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label26.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label26.Location = New System.Drawing.Point(14, 68)
        Me.Label26.Name = "Label26"
        Me.Label26.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label26.Size = New System.Drawing.Size(166, 19)
        Me.Label26.TabIndex = 77
        Me.Label26.Text = "PO (Purchasing Order)"
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtUPDATE
        '
        Me.txtUPDATE.AcceptsReturn = True
        Me.txtUPDATE.BackColor = System.Drawing.SystemColors.Window
        Me.txtUPDATE.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtUPDATE.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.UPDATE", True))
        Me.txtUPDATE.Enabled = False
        Me.txtUPDATE.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUPDATE.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtUPDATE.Location = New System.Drawing.Point(289, 248)
        Me.txtUPDATE.Name = "txtUPDATE"
        Me.txtUPDATE.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtUPDATE.Size = New System.Drawing.Size(100, 23)
        Me.txtUPDATE.TabIndex = 13
        Me.txtUPDATE.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtUPDATE.Visible = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.lblStatusKeterangan)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.lblStatus)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.chkADA_HARGA)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.txtPO_QTY)
        Me.Panel1.Controls.Add(Me.lblBPB_NO)
        Me.Panel1.Controls.Add(Me.txtTGL_AKHIR)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.txtNo_PO)
        Me.Panel1.Controls.Add(Me.chkBUAT_PO)
        Me.Panel1.Controls.Add(Me.txtTgl_PO)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.txtTot_Item)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Location = New System.Drawing.Point(9, 81)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(656, 100)
        Me.Panel1.TabIndex = 4
        '
        'lblStatusKeterangan
        '
        Me.lblStatusKeterangan.BackColor = System.Drawing.Color.Transparent
        Me.lblStatusKeterangan.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblStatusKeterangan.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.Status", True))
        Me.lblStatusKeterangan.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatusKeterangan.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblStatusKeterangan.Location = New System.Drawing.Point(373, 18)
        Me.lblStatusKeterangan.Name = "lblStatusKeterangan"
        Me.lblStatusKeterangan.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblStatusKeterangan.Size = New System.Drawing.Size(170, 14)
        Me.lblStatusKeterangan.TabIndex = 42
        Me.lblStatusKeterangan.Text = "lblStatus"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(291, 64)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(70, 15)
        Me.Label3.TabIndex = 48
        Me.Label3.Text = "Tgl BPB :"
        '
        'lblStatus
        '
        Me.lblStatus.BackColor = System.Drawing.Color.Transparent
        Me.lblStatus.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblStatus.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.RECID", True))
        Me.lblStatus.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblStatus.Location = New System.Drawing.Point(361, 17)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblStatus.Size = New System.Drawing.Size(15, 15)
        Me.lblStatus.TabIndex = 43
        Me.lblStatus.Text = "lblStatus"
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label9.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.Location = New System.Drawing.Point(564, 43)
        Me.Label9.Name = "Label9"
        Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label9.Size = New System.Drawing.Size(47, 18)
        Me.Label9.TabIndex = 10
        Me.Label9.Text = "Harga"
        Me.Label9.Visible = False
        '
        'chkADA_HARGA
        '
        Me.chkADA_HARGA.BackColor = System.Drawing.Color.Transparent
        Me.chkADA_HARGA.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkADA_HARGA.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.ADA_HARGA", True))
        Me.chkADA_HARGA.Enabled = False
        Me.chkADA_HARGA.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkADA_HARGA.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkADA_HARGA.Location = New System.Drawing.Point(551, 44)
        Me.chkADA_HARGA.Name = "chkADA_HARGA"
        Me.chkADA_HARGA.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkADA_HARGA.Size = New System.Drawing.Size(58, 18)
        Me.chkADA_HARGA.TabIndex = 11
        Me.chkADA_HARGA.UseVisualStyleBackColor = False
        Me.chkADA_HARGA.Visible = False
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label8.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(564, 20)
        Me.Label8.Name = "Label8"
        Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label8.Size = New System.Drawing.Size(86, 17)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "Dengan PO."
        Me.Label8.Visible = False
        '
        'txtPO_QTY
        '
        Me.txtPO_QTY.AcceptsReturn = True
        Me.txtPO_QTY.BackColor = System.Drawing.SystemColors.Window
        Me.txtPO_QTY.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPO_QTY.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.QTY", True))
        Me.txtPO_QTY.Enabled = False
        Me.txtPO_QTY.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.txtPO_QTY.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPO_QTY.Location = New System.Drawing.Point(210, 40)
        Me.txtPO_QTY.Name = "txtPO_QTY"
        Me.txtPO_QTY.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtPO_QTY.Size = New System.Drawing.Size(74, 23)
        Me.txtPO_QTY.TabIndex = 15
        Me.txtPO_QTY.Tag = "1"
        Me.txtPO_QTY.Text = "123"
        Me.txtPO_QTY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblBPB_NO
        '
        Me.lblBPB_NO.BackColor = System.Drawing.Color.Transparent
        Me.lblBPB_NO.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblBPB_NO.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.BPB_NO", True))
        Me.lblBPB_NO.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBPB_NO.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblBPB_NO.Location = New System.Drawing.Point(361, 43)
        Me.lblBPB_NO.Name = "lblBPB_NO"
        Me.lblBPB_NO.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblBPB_NO.Size = New System.Drawing.Size(167, 15)
        Me.lblBPB_NO.TabIndex = 47
        Me.lblBPB_NO.Text = "lblBPB_NO"
        '
        'txtTGL_AKHIR
        '
        Me.txtTGL_AKHIR.AcceptsReturn = True
        Me.txtTGL_AKHIR.BackColor = System.Drawing.SystemColors.Window
        Me.txtTGL_AKHIR.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTGL_AKHIR.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.TGL_AKHIR", True))
        Me.txtTGL_AKHIR.Enabled = False
        Me.txtTGL_AKHIR.FieldType = PendaftaranPO.FlexMaskEditBox._FieldType.DATE_
        Me.txtTGL_AKHIR.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTGL_AKHIR.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTGL_AKHIR.Location = New System.Drawing.Point(364, 64)
        Me.txtTGL_AKHIR.Name = "txtTGL_AKHIR"
        Me.txtTGL_AKHIR.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTGL_AKHIR.SetFormatString = "dd-MM-yyyy HH:mm"
        Me.txtTGL_AKHIR.Size = New System.Drawing.Size(112, 23)
        Me.txtTGL_AKHIR.TabIndex = 9
        Me.txtTGL_AKHIR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label16.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label16.Location = New System.Drawing.Point(291, 40)
        Me.Label16.Name = "Label16"
        Me.Label16.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label16.Size = New System.Drawing.Size(70, 15)
        Me.Label16.TabIndex = 46
        Me.Label16.Text = "No. BPB :"
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label10.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label10.Location = New System.Drawing.Point(173, 43)
        Me.Label10.Name = "Label10"
        Me.Label10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label10.Size = New System.Drawing.Size(81, 15)
        Me.Label10.TabIndex = 14
        Me.Label10.Text = "Qty :"
        '
        'txtNo_PO
        '
        Me.txtNo_PO.AcceptsReturn = True
        Me.txtNo_PO.BackColor = System.Drawing.SystemColors.Window
        Me.txtNo_PO.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtNo_PO.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtNo_PO.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.NOPO", True))
        Me.txtNo_PO.Enabled = False
        Me.txtNo_PO.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold)
        Me.txtNo_PO.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtNo_PO.Location = New System.Drawing.Point(95, 14)
        Me.txtNo_PO.MaxLength = 9
        Me.txtNo_PO.Name = "txtNo_PO"
        Me.txtNo_PO.Size = New System.Drawing.Size(74, 21)
        Me.txtNo_PO.TabIndex = 1
        Me.txtNo_PO.Tag = "1"
        '
        'chkBUAT_PO
        '
        Me.chkBUAT_PO.BackColor = System.Drawing.Color.Transparent
        Me.chkBUAT_PO.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkBUAT_PO.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.BUAT_PO", True))
        Me.chkBUAT_PO.Enabled = False
        Me.chkBUAT_PO.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkBUAT_PO.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkBUAT_PO.Location = New System.Drawing.Point(551, 20)
        Me.chkBUAT_PO.Name = "chkBUAT_PO"
        Me.chkBUAT_PO.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkBUAT_PO.Size = New System.Drawing.Size(48, 17)
        Me.chkBUAT_PO.TabIndex = 9
        Me.chkBUAT_PO.UseVisualStyleBackColor = False
        Me.chkBUAT_PO.Visible = False
        '
        'txtTgl_PO
        '
        Me.txtTgl_PO.AcceptsReturn = True
        Me.txtTgl_PO.BackColor = System.Drawing.SystemColors.Window
        Me.txtTgl_PO.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTgl_PO.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.TANGGAL", True))
        Me.txtTgl_PO.Enabled = False
        Me.txtTgl_PO.FieldType = PendaftaranPO.FlexMaskEditBox._FieldType.DATE_
        Me.txtTgl_PO.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.txtTgl_PO.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTgl_PO.Location = New System.Drawing.Point(95, 40)
        Me.txtTgl_PO.Name = "txtTgl_PO"
        Me.txtTgl_PO.SetFormatString = "dd-MM-yyyy"
        Me.txtTgl_PO.Size = New System.Drawing.Size(74, 23)
        Me.txtTgl_PO.TabIndex = 3
        Me.txtTgl_PO.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(2, 43)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(95, 20)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Tanggal PO :"
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label14.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label14.Location = New System.Drawing.Point(291, 17)
        Me.Label14.Name = "Label14"
        Me.Label14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label14.Size = New System.Drawing.Size(69, 15)
        Me.Label14.TabIndex = 44
        Me.Label14.Text = "STATUS :"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(11, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(81, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Nomor PO :"
        '
        'txtTot_Item
        '
        Me.txtTot_Item.AcceptsReturn = True
        Me.txtTot_Item.BackColor = System.Drawing.SystemColors.Window
        Me.txtTot_Item.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTot_Item.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.ITEMnya", True))
        Me.txtTot_Item.Enabled = False
        Me.txtTot_Item.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.txtTot_Item.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTot_Item.Location = New System.Drawing.Point(210, 14)
        Me.txtTot_Item.Name = "txtTot_Item"
        Me.txtTot_Item.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTot_Item.Size = New System.Drawing.Size(74, 23)
        Me.txtTot_Item.TabIndex = 13
        Me.txtTot_Item.Tag = "1"
        Me.txtTot_Item.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(168, 17)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(43, 15)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Item :"
        '
        'txtTGL_MULAI
        '
        Me.txtTGL_MULAI.BackColor = System.Drawing.SystemColors.Window
        Me.txtTGL_MULAI.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTGL_MULAI.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.TGL_MULAI", True))
        Me.txtTGL_MULAI.Enabled = False
        Me.txtTGL_MULAI.FieldType = PendaftaranPO.FlexMaskEditBox._FieldType.DATE_
        Me.txtTGL_MULAI.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTGL_MULAI.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTGL_MULAI.Location = New System.Drawing.Point(104, 248)
        Me.txtTGL_MULAI.Name = "txtTGL_MULAI"
        Me.txtTGL_MULAI.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTGL_MULAI.SetFormatString = "dd-MM-yyyy HH:mm"
        Me.txtTGL_MULAI.Size = New System.Drawing.Size(112, 23)
        Me.txtTGL_MULAI.TabIndex = 1
        Me.txtTGL_MULAI.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.Color.Transparent
        Me.Label23.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label23.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label23.Location = New System.Drawing.Point(14, 251)
        Me.Label23.Name = "Label23"
        Me.Label23.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label23.Size = New System.Drawing.Size(81, 19)
        Me.Label23.TabIndex = 0
        Me.Label23.Text = "Tgl. Daftar :"
        '
        'Label21
        '
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label21.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label21.Location = New System.Drawing.Point(224, 252)
        Me.Label21.Name = "Label21"
        Me.Label21.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label21.Size = New System.Drawing.Size(81, 15)
        Me.Label21.TabIndex = 12
        Me.Label21.Text = "Update :"
        Me.Label21.Visible = False
        '
        'lblIdDaftarPO
        '
        Me.lblIdDaftarPO.AutoSize = True
        Me.lblIdDaftarPO.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.ID_DAFTARPO", True))
        Me.lblIdDaftarPO.Location = New System.Drawing.Point(20, 176)
        Me.lblIdDaftarPO.Name = "lblIdDaftarPO"
        Me.lblIdDaftarPO.Size = New System.Drawing.Size(45, 13)
        Me.lblIdDaftarPO.TabIndex = 63
        Me.lblIdDaftarPO.Text = "Label25"
        '
        'cmbFilter
        '
        Me.cmbFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbFilter.Items.AddRange(New Object() {"Hari ini", "Tahun ini"})
        Me.cmbFilter.Location = New System.Drawing.Point(445, 30)
        Me.cmbFilter.Name = "cmbFilter"
        Me.cmbFilter.Size = New System.Drawing.Size(121, 21)
        Me.cmbFilter.TabIndex = 8
        '
        'btnHapusPO
        '
        Me.btnHapusPO.BackColor = System.Drawing.Color.Transparent
        Me.btnHapusPO.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHapusPO.Image = Global.PendaftaranPO.My.Resources.Resources.delete
        Me.btnHapusPO.Location = New System.Drawing.Point(101, 12)
        Me.btnHapusPO.Name = "btnHapusPO"
        Me.btnHapusPO.Size = New System.Drawing.Size(88, 28)
        Me.btnHapusPO.TabIndex = 1
        Me.btnHapusPO.Text = "&Hapus PO"
        Me.btnHapusPO.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnHapusPO.UseVisualStyleBackColor = False
        '
        'btnEditPO
        '
        Me.btnEditPO.BackColor = System.Drawing.Color.Transparent
        Me.btnEditPO.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEditPO.Image = Global.PendaftaranPO.My.Resources.Resources.pencil
        Me.btnEditPO.Location = New System.Drawing.Point(101, 40)
        Me.btnEditPO.Name = "btnEditPO"
        Me.btnEditPO.Size = New System.Drawing.Size(88, 28)
        Me.btnEditPO.TabIndex = 2
        Me.btnEditPO.Text = "&Edit PO"
        Me.btnEditPO.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnEditPO.UseVisualStyleBackColor = False
        '
        'btnNext2
        '
        Me.btnNext2.BackColor = System.Drawing.Color.Transparent
        Me.btnNext2.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnNext2.Image = Global.PendaftaranPO.My.Resources.Resources.go
        Me.btnNext2.Location = New System.Drawing.Point(357, 12)
        Me.btnNext2.Name = "btnNext2"
        Me.btnNext2.Size = New System.Drawing.Size(75, 56)
        Me.btnNext2.TabIndex = 6
        Me.btnNext2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnNext2.UseVisualStyleBackColor = False
        '
        'btnPrev2
        '
        Me.btnPrev2.BackColor = System.Drawing.Color.Transparent
        Me.btnPrev2.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnPrev2.Image = Global.PendaftaranPO.My.Resources.Resources.back
        Me.btnPrev2.Location = New System.Drawing.Point(276, 12)
        Me.btnPrev2.Name = "btnPrev2"
        Me.btnPrev2.Size = New System.Drawing.Size(75, 56)
        Me.btnPrev2.TabIndex = 5
        Me.btnPrev2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnPrev2.UseVisualStyleBackColor = False
        '
        'btnBatalPO
        '
        Me.btnBatalPO.BackColor = System.Drawing.Color.Transparent
        Me.btnBatalPO.Enabled = False
        Me.btnBatalPO.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBatalPO.Image = Global.PendaftaranPO.My.Resources.Resources.arrow_undo
        Me.btnBatalPO.Location = New System.Drawing.Point(195, 40)
        Me.btnBatalPO.Name = "btnBatalPO"
        Me.btnBatalPO.Size = New System.Drawing.Size(75, 28)
        Me.btnBatalPO.TabIndex = 4
        Me.btnBatalPO.Text = "&Batal"
        Me.btnBatalPO.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnBatalPO.UseVisualStyleBackColor = False
        '
        'btnSimpanPO
        '
        Me.btnSimpanPO.BackColor = System.Drawing.Color.Transparent
        Me.btnSimpanPO.Enabled = False
        Me.btnSimpanPO.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSimpanPO.Image = Global.PendaftaranPO.My.Resources.Resources.disk
        Me.btnSimpanPO.Location = New System.Drawing.Point(195, 12)
        Me.btnSimpanPO.Name = "btnSimpanPO"
        Me.btnSimpanPO.Size = New System.Drawing.Size(75, 28)
        Me.btnSimpanPO.TabIndex = 3
        Me.btnSimpanPO.Text = "&Load"
        Me.btnSimpanPO.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnSimpanPO.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.GroupBox1.Controls.Add(Me.btnKeluar)
        Me.GroupBox1.Controls.Add(Me.cmbFilter)
        Me.GroupBox1.Controls.Add(Me.btnSimpanPO)
        Me.GroupBox1.Controls.Add(Me.btnHapusPO)
        Me.GroupBox1.Controls.Add(Me.btnEditPO)
        Me.GroupBox1.Controls.Add(Me.btnNext2)
        Me.GroupBox1.Controls.Add(Me.btnPrev2)
        Me.GroupBox1.Controls.Add(Me.btnTambahPO)
        Me.GroupBox1.Controls.Add(Me.btnBatalPO)
        Me.GroupBox1.Location = New System.Drawing.Point(7, 415)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(675, 76)
        Me.GroupBox1.TabIndex = 15
        Me.GroupBox1.TabStop = False
        '
        'btnKeluar
        '
        Me.btnKeluar.BackColor = System.Drawing.Color.Transparent
        Me.btnKeluar.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnKeluar.Image = Global.PendaftaranPO.My.Resources.Resources.cross
        Me.btnKeluar.Location = New System.Drawing.Point(593, 12)
        Me.btnKeluar.Name = "btnKeluar"
        Me.btnKeluar.Size = New System.Drawing.Size(75, 56)
        Me.btnKeluar.TabIndex = 7
        Me.btnKeluar.Text = "&Keluar"
        Me.btnKeluar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnKeluar.UseVisualStyleBackColor = False
        '
        'frmDaftarPO
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.SeaGreen
        Me.ClientSize = New System.Drawing.Size(687, 501)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.grpSup)
        Me.Controls.Add(Me.grpDaftar)
        Me.Controls.Add(Me.lblIdDaftarPO)
        Me.Controls.Add(Me.grpHidden)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(698, 540)
        Me.Name = "frmDaftarPO"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.grpSup.ResumeLayout(False)
        Me.grpSup.PerformLayout()
        CType(Me.DsPO1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpHidden.ResumeLayout(False)
        Me.grpDaftar.ResumeLayout(False)
        Me.grpDaftar.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    Private SqlMobil As String, WhrMobil As String
    Private SqlDaftar As String, WhrDaftar As String
    Private ds As New DataSet
    Private dsSupp As New DataSet
    Private PO As Boolean
    Private vb As New vb
    Public Pointer As Integer
    Public sNoPo, CancelLoad As String
    Dim lbmobil_ As String

    Private Sub frmDaftarPO_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ConStrORA = getStrKoneksiODP()
        olcon.ConnectionString = ConStrORA
        Me.Text = "Form Pendaftaran - [" & Application.ProductName & " v" & Application.ProductVersion & " - " & USER_DATA(3) & "]"
        'AddHandler dsPo1.DC_JLR_DAFTARPO_T.ColumnChanging, AddressOf HandleColomPO
        'AddHandler dsPo1.DC_JLR_DAFTARPO_T.RowChanging, AddressOf HandleRowPo
        cmbFilter.Enabled = True
        'Dim aaa As String = 200000
        'Dim bbb As String = 300000
        'Dim ccc As String = 400000
        'Dim ddd As String = 500000
        'Dim eee As String = 600000
        'Dim kali As String = aaa * bbb
        'Dim tambah As String = aaa + bbb
        'Dim kurang As String = ccc - ddd
        'Dim bagi As String = ddd / aaa
        'If aaa > 0 Then
        '    aaa = 7
        'End If
        'SetTombol(True)
        For Each Tx As Control In Me.Controls
            If Tx.GetType Is GetType(GroupBox) Then

                For Each Tx2 As Control In Tx.Controls
                    If Tx2.GetType Is GetType(GroupBox) Then
                        For Each Tx3 As Control In Tx2.Controls
                            If Tx3.Tag = "1" Then
                                AddHandler Tx3.KeyDown, AddressOf txt_Keydown
                                AddHandler Tx3.Enter, AddressOf BlockAll
                            End If
                        Next
                    Else
                        If Tx2.Tag = "1" Then
                            AddHandler Tx2.KeyDown, AddressOf txt_Keydown
                            AddHandler Tx2.Enter, AddressOf BlockAll
                        End If
                    End If
                Next

            End If
        Next
        ''load
        'Dim Scon As New OleDb.OleDbConnection(ConStrORA)
        'Dim sdap As New OleDb.OleDbDataAdapter("Select * from dc_jlr_daftarjalur_t", Scon)
        'Scon.Open()
        'DsPO1.DC_JLR_DAFTARJALUR_T.Clear()
        'sdap.Fill(DsPO1.DC_JLR_DAFTARJALUR_T)
        'Scon.Close()
        ''coba
        SqlMobil = oldapMobil.SelectCommand.CommandText
        SqlDaftar = oldapPO.SelectCommand.CommandText
        cmbFilter.SelectedIndex = 0
        '  EnTambahPO()
        RECID()
        ''If CmbNama.Visible = False Then
        ''    grpSup.Enabled = False
        ''Else
        ''    grpSup.Enabled = True
        ''End If
        If txtNo_PO.Text <> "" Then
            '  btnTambahPO.Enabled = True
            btnEditPO.Enabled = True
            btnHapusPO.Enabled = True
        Else
            btnBatalPO.Enabled = False
            btnEditPO.Enabled = False
            btnHapusPO.Enabled = False
            '  btnTambahPO.Enabled = False
            btnSimpanPO.Enabled = False
            btnHapusPO.Enabled = False
        End If
        btnNext_Click(Nothing, Nothing)
        btnPrev_Click(Nothing, Nothing)
    End Sub
    Private Sub formatTextBox(ByVal sender As Object, ByVal e As System.Windows.Forms.ConvertEventArgs)
        Try
            'CType(sender, TextBox).Tag = ""
            e.Value = FormatNumber(e.Value, 2)
            'e.Value = FormatNumber(e.Value, 2).Replace(".", "A").Replace(",", ".").Replace("A", ",")
        Catch

        End Try
    End Sub

    Private Sub cmbFilter_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbFilter.SelectedIndexChanged
        Try
            'Attempt to load the dataset.
            Me.LoadDataSet()
            RECID()
            'mobil()
        Catch eLoad As System.Exception
            'Add your error handling code here.
            'Display error message, if any.
            MsgBox(eLoad.ToString)
            'System.Windows.Forms.MessageBox.Show(eLoad.Message)
        End Try
    End Sub
#Region "Handle Textbox"
    Private Sub txt_Keydown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
        If e.Control Then
            Exit Sub
        End If
        Select Case e.KeyCode
            Case Keys.Enter, Keys.Down
                SendKeys.Flush()
                SendKeys.SendWait("{TAB}")
            Case Keys.Up
                SendKeys.Send("+{TAB}")
        End Select
    End Sub
    Private Sub BlockAll(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            CType(sender, TextBox).SelectAll()
        Catch ex As Exception
            ex = Nothing
        End Try

    End Sub
#End Region
    Public Sub LoadDataSet()
        'Create a new dataset to hold the records returned from the call to FillDataSet.
        'A temporary dataset is used because filling the existing dataset would
        'require the databindings to be rebound.
        Dim objDataSetTemp As PendaftaranPO.DS_
        objDataSetTemp = New PendaftaranPO.DS_
        Try
            'Attempt to fill the temporary dataset.
            Me.FillDataSet(objDataSetTemp)
        Catch eFillDataSet As System.Exception
            'Add your error handling code here.
            Throw eFillDataSet
        End Try
        Try
            'grdDC_JLR_DAFTARPO_T.DataSource = Nothing
            'grdDC_JLR_DAFTARJALUR_T.DataSource = Nothing

            'Empty the old records from the dataset.
            DsPO1.Clear()
            'Merge the records into the main dataset.
            DsPO1.Merge(objDataSetTemp)

            'grdDC_JLR_DAFTARJALUR_T.SetDataBinding(dsPo1, "DC_JLR_DAFTARJALUR_T")
            'grdDC_JLR_DAFTARPO_T.SetDataBinding(dsPo1, "DC_JLR_DAFTARJALUR_T.Daf_PO")

            'Atur Default
            DsPO1.DC_JLR_DAFTARJALUR_T.TANGGALColumn.DefaultValue = GetOracleDate()
            DsPO1.DC_JLR_DAFTARJALUR_T.DC_IDColumn.DefaultValue = cDC_ID
            'dsPo1.DC_JLR_DAFTARJALUR_T.NOMOBILColumn.DefaultValue = ""
            'DsPO1.DC_JLR_DAFTARJALUR_T.ID_DAFTARJALURColumn.AutoIncrementSeed = GetIdDaftarJalur()

            'dsPo1.DC_JLR_DAFTARPO_T.TANGGALColumn.DefaultValue = Now.Date
            DsPO1.DC_JLR_DAFTARPO_T.TGL_FAKColumn.DefaultValue = GetOracleDate.Date
            'DsPO1.DC_JLR_DAFTARPO_T.ID_DAFTARPOColumn.AutoIncrementSeed = GetIdDaftarPO()

            DsPO1.DC_JLR_DAFTARPO_T.SUPCOColumn.DefaultValue = ""
        Catch eLoadMerge As System.Exception
            'Add your error handling code here.
            Throw eLoadMerge
        End Try

    End Sub
    Public Sub FillDataSet(ByVal dataSet As PendaftaranPO.DS_)
        'Turn off constraint checking before the dataset is filled.
        'This allows the adapters to fill the dataset without concern
        'for dependencies between the tables.
        dataSet.EnforceConstraints = False
        Try
            'Open the connection.

            Me.olcon.Open()
            'Attempt to fill the dataset through the oldapMobil.

            If cmbFilter.SelectedIndex = 0 Then
                'txtTglDaftar.Enabled = False
                WhrMobil = " WHERE TRUNC(TANGGAL)=TRUNC(SYSDATE)"
                WhrDaftar = " WHERE ID_DAFTARJALUR IN (SELECT ID_DAFTARJALUR FROM DC_JLR_DAFTARJALUR_T " & WhrMobil & ")"
            Else
                'txtTglDaftar.Enabled = False
                WhrMobil = " WHERE TO_CHAR(TANGGAL, 'yyyy')=TO_CHAR(SYSDATE, 'yyyy')"
                WhrDaftar = " WHERE ID_DAFTARJALUR IN (SELECT ID_DAFTARJALUR FROM DC_JLR_DAFTARJALUR_T " & WhrMobil & ")"
                'ElseIf cmbFilter.SelectedIndex = 2 Then
                '    txtTglDaftar.Enabled = True
                '    WhrMobil = " WHERE TO_DATE(TRUNC(TANGGAL),'dd-mm-yy')=TO_DATE('" & txtTglDaftar.Text & "','dd-mm-yy')"
                '    WhrDaftar = " WHERE ID_DAFTARJALUR IN (SELECT ID_DAFTARJALUR FROM DC_JLR_DAFTARJALUR_T " & WhrMobil & ")"
            End If

            oldapMobil.SelectCommand.CommandText = SqlMobil & WhrMobil & "  ORDER BY ID_DAFTARJALUR"
            oldapPO.SelectCommand.CommandText = SqlDaftar & WhrDaftar & " ORDER BY ID_DAFTARPO"
            Dim mobilhapstr As String = SqlMobil & WhrMobil & "  ORDER BY ID_DAFTARJALUR"
            Dim POhapstr As String = SqlDaftar & WhrDaftar & " ORDER BY ID_DAFTARPO"

            Dim dapMobil As DataSet = getDS(mobilhapstr.ToString.Replace(" & vbCrLf & ", " "), ConStrORA)
            Dim dapPO As DataSet = getDS(POhapstr.ToString.Replace(" & vbCrLf & ", " "), ConStrORA)
            'Dim abcd As DataTable = getDS(SqlDaftar & WhrDaftar & " ORDER BY ID_DAFTARPO", ConStrORA).Tables(0)

            Try
                Me.oldapMobil.Fill(dataSet)
                Me.oldapPO.Fill(dataSet)
            Catch ex As Exception
            End Try

        Catch fillException As System.Exception
            'Add your error handling code here.
            Throw fillException
        Finally
            'Turn constraint checking back on.
            dataSet.EnforceConstraints = True
            'Close the connection whether or not the exception was thrown.
            Me.olcon.Close()
        End Try

    End Sub
    Public Sub FillDataSetByDaftar(ByVal dataSet As PendaftaranPO.DS_)
        'Turn off constraint checking before the dataset is filled.
        'This allows the adapters to fill the dataset without concern
        'for dependencies between the tables.
        dataSet.EnforceConstraints = False
        Try
            'Open the connection.

            Me.olcon.Open()
            'Attempt to fill the dataset through the oldapMobil.

            'txtTglDaftar.Enabled = False
            WhrMobil = " WHERE TRUNC(TANGGAL)=TRUNC(to_date('" & txtTglDaftar.Text & "','dd/mm/yyyy'))"
            WhrDaftar = " WHERE ID_DAFTARJALUR IN (SELECT ID_DAFTARJALUR FROM DC_JLR_DAFTARJALUR_T " & WhrMobil & ")"


            oldapMobil.SelectCommand.CommandText = SqlMobil & WhrMobil & "  ORDER BY ID_DAFTARJALUR"
            oldapPO.SelectCommand.CommandText = SqlDaftar & WhrDaftar & " ORDER BY ID_DAFTARPO"
            Dim mobilhapstr As String = SqlMobil & WhrMobil & "  ORDER BY ID_DAFTARJALUR"
            Dim POhapstr As String = SqlDaftar & WhrDaftar & " ORDER BY ID_DAFTARPO"

            Dim dapMobil As DataSet = getDS(mobilhapstr.ToString.Replace(" & vbCrLf & ", " "), ConStrORA)
            Dim dapPO As DataSet = getDS(POhapstr.ToString.Replace(" & vbCrLf & ", " "), ConStrORA)
            'Dim abcd As DataTable = getDS(SqlDaftar & WhrDaftar & " ORDER BY ID_DAFTARPO", ConStrORA).Tables(0)

            Try
                Me.oldapMobil.Fill(dataSet)
                Me.oldapPO.Fill(dataSet)
            Catch ex As Exception
            End Try

        Catch fillException As System.Exception
            'Add your error handling code here.
            Throw fillException
        Finally
            'Turn constraint checking back on.
            dataSet.EnforceConstraints = True
            'Close the connection whether or not the exception was thrown.
            Me.olcon.Close()
        End Try

    End Sub
    Private Sub btnCancelAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelAll.Click
        Me.DsPO1.RejectChanges()
    End Sub
    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        Try
            'Attempt to update the datasource.
            Me.UpdateDataSet()
        Catch eUpdate As System.Exception
            'Add your error handling code here.
            'Display error message, if any.
            ShowError("Error Update", eUpdate)
        End Try

    End Sub

    Public Sub UpdateDataSet()
        'Create a new dataset to hold the changes that have been made to the main dataset.
        Dim objDataSetChanges As PendaftaranPO.DS_ = New PendaftaranPO.DS_
        'Stop any current edits.
        Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").EndCurrentEdit()
        Try
            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").EndCurrentEdit()
        Catch

        End Try

        'Get the changes that have been made to the main dataset.
        objDataSetChanges = CType(DsPO1.GetChanges, PendaftaranPO.DS_)
        'Check to see if any changes have been made.
        If (Not (objDataSetChanges) Is Nothing) Then
            Try
                'There are changes that need to be made, so attempt to update the datasource by
                'calling the update method and passing the dataset and any parameters.
                Me.UpdateDataSource(objDataSetChanges)
                DsPO1.Merge(objDataSetChanges)
                DsPO1.AcceptChanges()
            Catch eUpdate As System.Exception
                'Add your error handling code here.
                Throw eUpdate
            End Try
            'Add your code to check the returned dataset for any errors that may have been
            'pushed into the row object's error.
        End If

    End Sub
    Public Sub UpdateDataSource(ByVal ChangedRows As PendaftaranPO.DS_)
        Try
            'The data source only needs to be updated if there are changes pending.
            If (Not (ChangedRows) Is Nothing) Then
                'Open the connection.
                Me.olcon.Open()
                'Attempt to update the data source.
                Debug.WriteLine("Mobil: " & oldapMobil.Update(ChangedRows))
                Application.DoEvents()
                Debug.WriteLine("PO: " & oldapPO.Update(ChangedRows))

            End If
        Catch updateException As System.Exception
            'Add your error handling code here.
            Throw updateException
        Finally
            'Close the connection whether or not the exception was thrown.
            Me.olcon.Close()
        End Try

    End Sub

    Public Sub btnPrev_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrev.Click
        Try
            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position -= 1
            'lblSUPCO.Text = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.SUPCO").Current
            RECID()
            ' mobil()
            If txtNo_PO.Text <> "" And txtNo_PO.Text <> "" Then
                btnTambahPO.Enabled = True
            End If
            LoadNoAntrian()
        Catch ex As Exception

        End Try

    End Sub
    Public Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click
        Try


            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position += 1
            RECID()
            ' mobil()
            If txtNo_PO.Text <> "" And txtNo_PO.Text <> "" Then
                btnTambahPO.Enabled = True
            End If
            LoadNoAntrian()
        Catch ex As Exception

        End Try

    End Sub

    Public Sub JagaanLoad()

        txtNoAntrian.Text = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T,NOURUT").Current
        'lblSUPCO.Text = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T,SUPCO").Current
        'lblSNAMA.Text = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T,SNAMA").Current
        'If lblSUPCO.Text = "" Or lblSNAMA.Text = "" Then
        '    If btnPrintUlang.Visible = True Or txtNoAntrian.Text = "" Then
        '        btnTambahPO.Enabled = False
        '    Else
        '        btnTambahPO.Enabled = True
        '    End If
        'Else
        '    btnTambahPO.Enabled = True
        'End If
        LoadNoAntrian()
        'grpSup.Enabled = False

        'btnTambahPO.Enabled = True
        'btnHapusPO.Enabled = True
        'btnEditPO.Enabled = True

        'If txtNoAntrian.Text = "" Then
        '    btnPrint.Enabled = False
        '    btnPrintUlang.Visible = False
        '    'BtnPrintStck.Visible = False
        '    btnTambahPO.Enabled = False
        '    Exit Sub
        'End If
        ''Dim a As String = Format(txtTglDaftar.Value, "MM/dd/yyyy 00:00:00")
        ''Dim b As Date = Format(txtTglDaftar.Value, "MM/dd/yyyy 00:00:00")
        ''MessageBox.Show(Format(txtTglDaftar.Value, "MM/dd/yyyy 00:00:00"))
        'DsPO1.Tables("DC_JLR_DAFTARJALUR_T").DefaultView.RowFilter = _
        '"NOURUT= " & txtNoAntrian.Text & " and TANGGAL >= '" & Format(txtTglDaftar.Value, "MM/dd/yyyy 00:00:00") & _
        '                                "' and TANGGAL <= '" & Format(txtTglDaftar.Value, "MM/dd/yyyy 23:59:59") & "'"
        'If DsPO1.Tables("DC_JLR_DAFTARJALUR_T").DefaultView.Item(0).Item("PRINT_ID").ToString = "" Then
        '    btnPrint.Enabled = True
        '    btnPrintUlang.Visible = False
        '    'BtnPrintStck.Visible = False
        '    btnTambahPO.Enabled = True
        'Else
        '    btnPrint.Enabled = False
        '    btnPrintUlang.Visible = True
        '    'BtnPrintStck.Visible = True
        '    btnTambahPO.Enabled = False
        'End If
        'If lblBPB_NO.Text <> "" Then
        '    btnPrint.Enabled = False
        '    btnPrintUlang.Enabled = False
        '    btnHapusPO.Enabled = False
        '    btnEditPO.Enabled = False
        'Else
        '    btnHapusPO.Enabled = True
        '    btnEditPO.Enabled = True
        'End If
        'If txtTglDaftar.Value <> Now.Date And lblBPB_NO.Text <> "" Then
        '    btnTambahPO.Enabled = False
        'Else
        '    btnPrintUlang.Enabled = True
        'End If

        ''If txtPO_Total.Text = "" Then
        ''    btnPrint.Enabled = False
        ''Else
        ''    btnPrint.Enabled = True
        ''End If
    End Sub
    Private Sub RECID()
        If txtNoAntrian.Text = "" Then
            btnPrint.Enabled = False
            btnPrintUlang.Visible = False
            'BtnPrintStck.Visible = False
            'btnTambahPO.Enabled = False
            Exit Sub
        End If
        'Dim a As String = Format(txtTglDaftar.Value, "MM/dd/yyyy 00:00:00")
        'Dim b As Date = Format(txtTglDaftar.Value, "MM/dd/yyyy 00:00:00")
        'MessageBox.Show(Format(txtTglDaftar.Value, "MM/dd/yyyy 00:00:00"))


        'DsPO1.Tables("DC_JLR_DAFTARJALUR_T").DefaultView.RowFilter = _
        '"NOURUT= " & txtNoAntrian.Text & " and TANGGAL >= '" & Format(txtTglDaftar.Value, "MM/dd/yyyy 00:00:00") & _
        '                                "' and TANGGAL <= '" & Format(txtTglDaftar.Value, "MM/dd/yyyy 23:59:59") & "'"
        'If DsPO1.Tables("DC_JLR_DAFTARJALUR_T").DefaultView.Item(0).Item("PRINT_ID").ToString = "" Then


        Dim dt_getPRINTID As DataTable = getDS(" SELECT ID_DAFTARJALUR, DC_ID, TANGGAL, " &
 "   RECID, NOMOBIL, NOURUT, " &
 "   SUPCO, SNAMA, ITEM, " &
  "  TRUNC(RUPIAH, 8) As rupiah, TGLSTART, TGLEND, " &
  "  JALUR, PRINT_ID" &
"   FROM dc_jlr_daftarjalur_t" &
"  WHERE NOURUT= " & txtNoAntrian.Text & " And TANGGAL >= to_date('" & Format(txtTglDaftar.Value, "MM/dd/yyyy 00:00:00") & "', 'MM/dd/yyyy HH24:mi:ss') " &
                                        " and TANGGAL <= to_date('" & Format(txtTglDaftar.Value, "MM/dd/yyyy 23:59:59") & "', 'MM/dd/yyyy HH24:mi:ss')", ConStrORA).Tables(0)
        If dt_getPRINTID.Rows.Count > 0 Then
            If dt_getPRINTID.Rows(0)("PRINT_ID").ToString = "" Then
                btnPrint.Enabled = True
                btnPrintUlang.Visible = False
                'BtnPrintStck.Visible = False
                '12082022 btnTambahPO.Enabled = True 
            Else
                btnPrint.Enabled = False
                btnPrintUlang.Visible = True
                'BtnPrintStck.Visible = True
                '12082022 btnTambahPO.Enabled = False
            End If

            txtKodeSupp_.Text = dt_getPRINTID.Rows(0)("SUPCO").ToString
            txtNamaSupp_.Text = dt_getPRINTID.Rows(0)("SNAMA").ToString
        End If
        If lblBPB_NO.Text <> "" Then
            btnPrint.Enabled = False
            btnPrintUlang.Enabled = False
            btnHapusPO.Enabled = False
            btnEditPO.Enabled = False
        Else
            btnHapusPO.Enabled = True
            btnEditPO.Enabled = True
        End If
        If txtTglDaftar.Value <> Now.Date And lblBPB_NO.Text <> "" Then
            'btnTambahPO.Enabled = False
        Else
            btnPrintUlang.Enabled = True
        End If

        'If txtPO_Total.Text = "" Then
        '    btnPrint.Enabled = False
        'Else
        '    btnPrint.Enabled = True
        'End If
    End Sub

    Private Sub btnDaftar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDaftar.Click
        ' isiData() 

        Dim abc As String = txtTglDaftar.Text
        'Dim abc As String
        'abc = LBMobil.SelectedItem
        'abc = LBMobil.SelectedItems.ToString
        'abc = LBMobil.SelectedValue
        'abc = LBMobil.Items.ToString

        '        Dim dt_cekDAFTAR As DataTable = getDS("SELECT COUNT(*) FROM dc_jlr_daftarmobil_hdr_t WHERE nomobil = '" & LBMobil.Items.ToString & "' and supco = '" & lblSUPCO.Text & "'", ConStrORA).Tables(0)

        Dim m As String
        Dim d As String
        Dim tgl As String
        m = Date.Now.Month
        d = Date.Now.Day
        If m.Length < 2 And d.Length < 2 Then
            m = "0" & Date.Now.Month
            d = "0" & Date.Now.Day
        ElseIf m.Length < 2 Then
            m = "0" & Date.Now.Month
        ElseIf d.Length < 2 Then
            d = "0" & Date.Now.Day
        End If
        tgl = d & "/" & m & "/" & Date.Now.Year

        'Dim Qcon As New OracleConnection(ConStrORA)
        'Dim Qcom As New OracleCommand("", Qcon)
        'Dim Qdap As New OracleDataAdapter
        ''MsgBox(cDC_KODE)
        'Qcom.CommandText = "select distinct SUPCO,H.SUP_NAMA AS SNAMA,S.TGLMASUK " &
        '                    "from DC_JLR_DAFTARMOBIL_HDR_T S, DC_SUPPLIER_DC_V H " &
        '                    "where to_char(TRUNC(TGLMASUK),'dd/mm/yyyy')='" & tgl & "' and TGLKELUAR is null " &
        '                    "and S.supco=H.sup_supkode and H.TBL_DC_KODE='" & cDC_KODE & "' " &
        '                    "order by s.tglmasuk"
        ''"and nomobil not in(Select distinct nomobil from dc_jlr_daftarjalur_t D where to_char(TRUNC(tanggal),'dd/mm/yyyy')='" & tgl & "') " & _

        ''"select distinct SUPCO,H.SUP_NAMA AS SNAMA " & _
        ''"from DC_JLR_DAFTARMOBIL_HDR_T S, DC_SUPPLIER_DC_V H " & _
        ''"where to_char(TRUNC(TGLMASUK),'dd/mm/yyyy')='" & tgl & "' and TGLKELUAR is null " & _
        ''"and supco not in(Select distinct supco from dc_jlr_daftarjalur_t D " & _
        ''"where to_char(TRUNC(tanggal),'dd/mm/yyyy')='" & tgl & "' " & _
        ''"and id_daftarjalur in (select distinct id_daftarjalur from dc_jlr_daftarpo_t " & _
        ''"where to_char(TRUNC(tgl_fak),'dd/mm/yyyy')='" & tgl & "' " & _
        ''"and bpb_no is null)) " & _
        ''"and S.supco=H.sup_supkode and H.TBL_DC_KODE='" & cDC_KODE & "' " & _
        ''"order by snama"
        'Qdap.SelectCommand = Qcom
        'dsSupp.Clear()
        'Qcon.Open()

        ''LBMobil.DataSource = ds.Tables(0)
        ''LBMobil.DisplayMember = "NOMOBIL"
        ''If btnDaftar.Enabled = True And btnTambahPO.Enabled = True Then
        ''    LBMobil.ClearSelected()
        ''End If

        'Qdap.Fill(dsSupp)
        'If dsSupp.Tables(0).Rows.Count <> 0 Then
        '    CmbSUPCO.DisplayMember = "SUPCO"
        '    CmbSUPCO.DataSource = dsSupp.Tables(0)
        '    CmbNama.DisplayMember = "SNAMA"
        '    CmbNama.DataSource = dsSupp.Tables(0)
        '    CmbNama.ValueMember = "TGLMASUK"
        '    'LBMobil.DataSource = dsSupp.Tables(0)
        '    'LBMobil.DisplayMember = "NOMOBIL"
        'Else
        '    MsgBox("Tidak Bisa Daftar, Supplier Belum Ada Yang Datang", MsgBoxStyle.Information)
        '    RECID()
        '    GoTo out
        'End If
        'Qcon.Close()

        'CmbSUPCO.Visible = True
        'CmbNama.Visible = True

        'If CmbSUPCO.Text <> "" Then
        '    Dim sql As String
        '    Dim Qdar As OracleDataReader
        '    Qcon.Open()
        '    'Todo: Buat PO tidak ada Kolom
        '    sql = "Select S.SUP_NAMA AS SNAMA,H.SUP_FLAG_BUATPO AS BUAT_PO,s.SUP_SUPID AS SUPID from DC_SUPPLIER_DC_V H,DC_SUPPLIER_T S "
        '    sql &= "Where H.SUP_FK_SUPID=s.SUP_SUPID And "
        '    sql &= "TBL_DC_KODE='" & cDC_KODE
        '    sql &= "' AND H.SUP_SUPKODE='" & CmbSUPCO.Text & "'"
        '    Qcom.CommandText = sql
        '    Qdar = Qcom.ExecuteReader
        '    Qdar.Read()
        '    lblSUPCO.Text = CmbSUPCO.Text
        '    lblSNAMA.Text = IIf(IsDBNull(Qdar("SNAMA").ToString), "", Qdar("SNAMA"))
        '    Qdar.Close()
        '    Qcon.Close()
        'Else
        '    lblSNAMA.Text = ""
        'End If

        ''txtSUPCO.Visible = True
        ''txtNamaSupp.Visible = True
        ''txtSUPCO.Enabled = True

        'Dim NamaS As String
        'NamaS = lblSNAMA.Text
        Try
            ''DsPO1.DC_JLR_DAFTARJALUR_T.ID_DAFTARJALURColumn.AutoIncrementSeed = GetIdDaftarJalur()

            'DsPO1.DC_JLR_DAFTARJALUR_T.ID_DAFTARJALURColumn.DefaultValue = GetIdDaftarJalur()

            'DsPO1.DC_JLR_DAFTARJALUR_T.TANGGALColumn.DefaultValue = txtTglDaftar.Value.Date
            'DsPO1.DC_JLR_DAFTARJALUR_T.DC_IDColumn.DefaultValue = cDC_ID
            ''DsPO1.DC_JLR_DAFTARJALUR_T.NOMOBILColumn.DefaultValue = " "
            ''Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").EndCurrentEdit()

            LoadDataSetByDaftar()
            btnNext2_Click(Nothing, Nothing)
            txtKodeSupp_.Text = ""
            txtNamaSupp_.Text = ""
            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").AddNew()

            'txtNoMobil.Enabled = True
            'txtSUPCO.Enabled = True
            'txtTglDaftar.Enabled = True

            btnHapusPO.Enabled = False
            btnEditPO.Enabled = False

            btnNext.Enabled = False
            btnPrev.Enabled = False
            btnDaftar.Enabled = False
            btnCari.Enabled = False
            txtTglDaftar.Enabled = False

            'btnSimpan.Enabled = True
            'btnBatal.Enabled = True

            'Dim X As Integer
            'X = Me.BindingContext(dsPo1, "DC_JLR_DAFTARJALUR_T").Position

            'dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("ID_DAFTARJALUR") = GetIdDaftarJalur()

            Debug.WriteLine("Jumlah Record : " & DsPO1.DC_JLR_DAFTARJALUR_T.Rows.Count)

            ''txtNoMobil.Focus()
            'txtSUPCO.Focus()
            cmbFilter.Enabled = False
            btnTambahPO.Enabled = True
        Catch eEndEdit As System.Exception
            System.Windows.Forms.MessageBox.Show(eEndEdit.Message)
        End Try
        ' CmbSUPCO.Focus()
        ' lblSNAMA.Text = NamaS
        'LBMobil.Enabled = True
        'If LBMobil.SelectedIndex = -1 And LBMobil.Items.Count <> 0 Then
        '    LBMobil.SelectedIndex = 0
        'End If
        btnPrint.Enabled = False
        btnPrev2.Enabled = True
        btnNext2.Enabled = True

        'If LBMobil.SelectedIndex = -1 And LBMobil.Items.Count <> 0 Then
        '    LBMobil.SelectedIndex = 0
        'End If


out:

        ' LoadDataSetByDaftar()
        'EnTambahPO()
    End Sub

    Public Sub EnTambahPO()
        ' If lblSUPCO.Text = "" Or lblSNAMA.Text = "" Then

        If txtKodeSupp_.Text = "" Or txtNamaSupp_.Text = "" Then
            btnTambahPO.Enabled = True
        Else
            If btnPrintUlang.Visible = True Or txtNoAntrian.Text = "" Then
                btnTambahPO.Enabled = False
            Else
                btnTambahPO.Enabled = True
            End If
        End If
    End Sub

    Private Sub grpSupplier_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles grpSup.Leave
        Try
            If txtKodeSupp_.Text = "" And btnDaftar.Enabled = False Then
                Err.Raise(99)
            End If
            'Dim sup As String
            'Dim supnama As String
            'sup = txtSUPCO.Text
            'supnama = txtNamaSupp.Text
            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").EndCurrentEdit()
            'txtSUPCO.Text = sup
            'txtNamaSupp.Text = supnama


            'If Not btnDaftar.Enabled And btnTambahPO.Enabled Then
            '    btnTambahPO.PerformClick()
            'End If

        Catch ex As Exception
            'ShowError("Error Simpan Daftar Mobil", ex)
            ' ''Debug.WriteLine("Error Simpan Daftar SupCo" & ex.Message)
            ' ''ex = Nothing

            ' ''If MessageBox.Show("Kode Supplier Tidak Boleh Kosong." & vbCrLf & _
            ' ''    "     Edit Kode Supplier ?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Error) = Windows.Forms.DialogResult.Yes Then
            ' ''    txtNoMobil.Focus()
            ' ''Else
            ' ''    Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").CancelCurrentEdit()
            ' ''    btnNext.Focus()
            ' ''    SetTombol(False)
            ' ''End If

            'ShowError("Error Simpan Daftar Mobil", ex)
            ''Debug.WriteLine("Error Simpan Daftar Mobil" & ex.Message)
            ''ex = Nothing

            ''If MessageBox.Show("No Mobil Tidak Boleh Kosong." & vbCrLf & _
            ''    "     Edit No Mobil ?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Error) = Windows.Forms.DialogResult.Yes Then
            ''    txtNoMobil.Focus()
            ''Else
            ''    Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").CancelCurrentEdit()
            ''    btnNext.Focus()
            ''    SetTombol(False)
            ''End If
        End Try
    End Sub

    Private Sub btnTambahPO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTambahPO.Click

        'start buttondaftar
        Dim abc As String = txtTglDaftar.Text
        Dim m As String
        Dim d As String
        Dim tgl As String
        m = Date.Now.Month
        d = Date.Now.Day
        If m.Length < 2 And d.Length < 2 Then
            m = "0" & Date.Now.Month
            d = "0" & Date.Now.Day
        ElseIf m.Length < 2 Then
            m = "0" & Date.Now.Month
        ElseIf d.Length < 2 Then
            d = "0" & Date.Now.Day
        End If
        tgl = d & "/" & m & "/" & Date.Now.Year

        Try

            LoadDataSetByDaftar()
            btnNext2_Click(Nothing, Nothing)
            txtKodeSupp_.Text = ""
            txtNamaSupp_.Text = ""
            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").AddNew()


            btnHapusPO.Enabled = False
            btnEditPO.Enabled = False

            btnNext.Enabled = False
            btnPrev.Enabled = False
            btnDaftar.Enabled = False
            btnCari.Enabled = False
            txtTglDaftar.Enabled = False


            Debug.WriteLine("Jumlah Record : " & DsPO1.DC_JLR_DAFTARJALUR_T.Rows.Count)

            cmbFilter.Enabled = False
            ' btnTambahPO.Enabled = True
        Catch eEndEdit As System.Exception
            System.Windows.Forms.MessageBox.Show(eEndEdit.Message)
        End Try

        btnPrint.Enabled = False
        btnPrev2.Enabled = True
        btnNext2.Enabled = True


        'end buttondaftar----------------------------------------------------------------------------------------------------------------------------

        'DsPO1.DC_JLR_DAFTARPO_T.ID_DAFTARPOColumn.AutoIncrementSeed = GetIdDaftarPO()
        'Dim sup As String
        'sup = txtSUPCO.Text
        'Dim supnama As String
        'supnama = txtNamaSupp.Text

        ''If txtNoMobil.Text = "" Then
        ''    MessageBox.Show("Daftarkan Mobil Terlebih Dahulu", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
        ''    Exit Sub
        ''End If
        txtNo_PO.Text = ""
        txtKodeSupp_.Text = ""
        txtNamaSupp_.Text = ""
        txtNoAntrian.Text = ""
        'If LBMobil.SelectedIndex = -1 And LBMobil.Items.Count <> 0 Then
        '    LBMobil.SelectedIndex = 0
        'End If




        'PRPK : 775/06-23/E/PMO	Memo CPS :  424/CPS/23 (Mulai)
        '-Tombol [Tambah PO] tidak generate tetapi gunakan no urut yang sedang berjalan di hari tsb. 
        '   -Tombol tambah bisa berfungsi jika no urut tsb PO PO yang didaftarkan belum ada yang BPB supplier. 
        '   -Jika sudah ada yang BPB, maka muncul alert  �Sudah ada BPB, harus Daftar baru dengan nomor urut baru!� dan proses digagalkan. Beri komen pada code program MEMO 424 CPS 23 BUTIR 2 

        ' Select  TRUNC(a.tanggal), a.nourut, a.supco, a.snama, 
        'MIN(tgl_mulai) As tglmulai, COUNT(b.nopo) As tot_po, COUNT(b.bpb_no) As tot_bpb  
        'From DC_JLR_DAFTARJALUR_T a, DC_JLR_DAFTARPO_T b
        'Where TRUNC(a.tanggal) = TRUNC(SYSDATE) - -param
        'And a.SUPCO = 'S742' --param
        'And a.id_daftarjalur=b.id_daftarjalur
        'Group BY TRUNC(a.tanggal), a.nourut, a.supco, a.snama
        'ORDER BY nourut



        'Dim dt_cekNOURUT As DataTable = getDS(" SELECT nourut, nomobil" &
        '                                    "   FROM dc_jlr_daftarjalur_t" &
        '                                    "  WHERE  supco = '" & txtKodeSupp_.Text & "' " &
        '                                    " /*AND nomobil = ' & LBMobil.Text & '*/ and tanggal = trunc(sysdate)", ConStrORA).Tables(0)
        'If dt_cekNOURUT.Rows.Count > 0 And txtNoAntrian.Text = "" Then
        '    txtNoAntrian.Text = dt_cekNOURUT.Rows(0)(0).ToString
        '    lbmobil_ = dt_cekNOURUT.Rows(0)(1).ToString
        'ElseIf txtNoAntrian.Text = "" Then
        '    txtNoAntrian.Text = frmLoadPO.NextAntrian()
        'End If

        'If txtNoAntrian.Text = "" Then
        '    txtNoAntrian.Text = frmLoadPO.NextAntrian()
        'Else
        '    Dim queryCekNoUrut As String = " SELECT   TRUNC (a.tanggal), a.nourut, a.nomobil, a.supco, a.snama," &
        '        "          MIN (tgl_mulai) AS tglmulai, COUNT (b.nopo) AS tot_po," &
        '        "          COUNT (b.bpb_no) AS tot_bpb" &
        '        "     FROM dc_jlr_daftarjalur_t a, dc_jlr_daftarpo_t b" &
        '        "    WHERE TRUNC (a.tanggal) = TRUNC (SYSDATE)" &
        '        "      AND a.supco = '" & txtKodeSupp_.Text & "'  " &
        '        "      AND a.id_daftarjalur = b.id_daftarjalur" &
        '        "      AND  a.nourut =" & txtNoAntrian.Text.Trim &
        '        " GROUP BY TRUNC (a.tanggal), a.nourut, a.nomobil, a.supco, a.snama " &
        '        " ORDER BY nourut"
        '    Dim dt_cekNOURUT As DataTable = getDS(queryCekNoUrut, ConStrORA).Tables(0)
        '    Dim cekSudahBPB As String = dt_cekNOURUT.Rows(0)("tot_bpb").ToString
        '    If cekSudahBPB = 0 Then
        '        txtNoAntrian.Text = dt_cekNOURUT.Rows(0)(0).ToString
        '        lbmobil_ = dt_cekNOURUT.Rows(0)(1).ToString
        '    Else
        '        MsgBox("Sudah ada BPB, harus Daftar baru dengan nomor urut baru!", vbInformation)
        '        Exit Sub
        '    End If
        'End If



        'PRPK : 775/06-23/E/PMO	Memo CPS :  424/CPS/23 (Selesai)







        'If btnDaftar.Enabled = False Then
        '    If CmbSUPCO.Text = "" And lblSNAMA.Text = "" Then
        '        MessageBox.Show("Daftarkan Supplier Terlebih Dahulu", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
        '        Exit Sub
        '        'Else
        '        'txtSUPCO.Enabled = False
        '        'txtNamaSupp.Enabled = False
        '    End If

        '    'CmbSUPCO.Enabled = False
        '    'CmbNama.Enabled = False

        '    CmbSUPCO.Visible = False
        '    CmbNama.Visible = False
        '    lblSUPCO.Text = CmbSUPCO.Text
        '    lblSNAMA.Text = CmbNama.Text
        '    'If LBMobil.Text = "" Then
        '    '    MsgBox("No. Mobil belum dipilih", vbCritical)
        '    '    Exit Sub
        '    'End If

        '    'Else
        '    '    If lblSUPCO.Text = "" And lblSNAMA.Text = "" Then
        '    '        MessageBox.Show("Nama Atau Code Supplier Tidak Lengkap", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
        '    '        Exit Sub
        '    '    End If
        'End If

        Dim sql As String
        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Dim Sdar As OracleDataReader
        Try
            Scon.Open()
            'Todo: Buat PO tidak ada Kolom
            sql = "Select S.SUP_NAMA AS SNAMA,H.SUP_SUPKODE AS SUPCO,H.SUP_FLAG_BUATPO AS BUAT_PO,s.SUP_SUPID AS SUPID from DC_SUPPLIER_DC_V H,DC_SUPPLIER_T S "
            sql &= "Where H.SUP_FK_SUPID=s.SUP_SUPID And "
            sql &= "TBL_DC_KODE='" & cDC_KODE
            sql &= "' AND H.SUP_SUPKODE='" & txtKodeSupp_.Text & "'"
            Scom.CommandText = sql
            Sdar = Scom.ExecuteReader
            If Sdar.Read Then
                'Cek With PO
                If Not lWithPO Then
                    If "" & Sdar("BUAT_PO") = "Y" Then
                        'MsgBox("Supplier " & CmbSUPCO.Text & " Harus Pakai PO !!!", vbCritical)
                        'Sdar.Close()
                        'Scon.Close()
                        'Scon = Nothing
                        'Exit Sub
                        PO = True
                    Else
                        txtPO_QTY.Focus()
                    End If
                End If
            End If
            Sdar.Close()
        Catch ex As Exception
            ShowError("Error Baca Supplier", ex)
        Finally
            Scon.Close()
            Scon = Nothing
        End Try

        DsPO1.DC_JLR_DAFTARPO_T.ID_DAFTARPOColumn.DefaultValue = GetIdDaftarPO()

        Try
            Try
                Dim rw As Object
                rw = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DaF_PO").Current
                If CType(rw, DS_.DC_JLR_DAFTARPO_TRow).RowState <> DataRowState.Unchanged Then
                    Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DaF_PO").EndCurrentEdit()
                End If
            Catch
            End Try

            Try

                Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DaF_PO").AddNew()

            Catch ' ex As Exception

            End Try

            'txtSUPCO.Text = sup
            'txtNamaSupp.Text = supnama

            'Dim X As Integer
            'X = Me.BindingContext(dsPo1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Position
            'dsPo1.DC_JLR_DAFTARPO_T.Rows(X)("DC_JLR_DAFTARJALUR_T.DAF_PO") = GetIdDaftarJalur()



            'PO OBAT
            Dim cekObat As String = execScalar(" SELECT count(*)" &
                      "   FROM DC_PO_T a, DC_PODTL_T b" &
                      "  WHERE po_no_po = '" & txtNo_PO.Text & "'" &
                      "    AND po_no_po = podtl_fk_no_po" &
                      "    AND podtl_plu IN (SELECT DISTINCT mbr_fk_pluid" &
                      "                                 FROM DC_BARANG_DC_T" &
                      "                                WHERE mbr_tgl_plumati IS NULL" &
                      "                                  AND mbr_obat IS NOT NULL)", ConStrORA)
            If cekObat <> "0" Then
                MsgBox("Ini merupakan PO Obat", vbInformation)
                execQuery("update dc_trnbpb_hdr_t set PO_MRBREAD ='O' where no_po ='" & txtNo_PO.Text & "'", ConStrORA)
            End If

        Catch eEndEdit As System.Exception
            ShowError("Error Tambah PO", eEndEdit)
        End Try
        'Tombol
        SetTombol(True)

        txtNoFak.Focus()

    End Sub

    Private Sub grpDaftar_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles grpDaftar.Leave
        Try

            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").EndCurrentEdit()
        Catch ex As Exception
            'ShowError("Error Simpan Daftar PO", ex)

            'If MessageBox.Show("Kode Supplier Tidak Boleh Kosong." & vbCrLf & " Edit Kode Supplier ?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Error) = DialogResult.Yes Then
            '    txtSUPCO.Focus()
            'Else
            '    Me.BindingContext(dsPo1, "DC_JLR_DAFTARJALUR_T.DAF_PO").CancelCurrentEdit()
            '    SetTombol(False)
            'End If
            Debug.WriteLine("Error Simpan Daftar PO" & vbCrLf & ex.Message)
            ex = Nothing
        End Try

    End Sub



    Private Sub btnSimpanPO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimpanPO.Click
        'If txtNo_PO.Text = "" Then
        '    MessageBox.Show("Harap isi No PO", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
        '    Exit Sub
        'End If

        Dim abdbabd As String = txtNo_PO.Text
        If txtNoFak.Text = "" Then
            MessageBox.Show("Harap isi No Faktur", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub

        End If
        If txtNo_PO.Text = "" Then
            MsgBox("Tidak Bisa Edit Pendaftaran Tanpa PO.", vbCritical)
            Exit Sub
        End If
        'If Not lWithPO And PO = True And txtNo_PO.Text = "" Then
        '    MsgBox("Supplier " & CmbSUPCO.Text & " Harus Pakai PO !!!", vbCritical)
        '    Exit Sub
        'End If

        frmLoadPO.NOURUT = txtNoAntrian.Text
        'If Not lWithPO Then
        '    'Cek Faktur
        '    Try
        '        Dim olcom As New OracleCommand("", olcon)
        '        olcom.CommandText = "Select count(*) From DC_DAFTARJALUR"
        '        If olcom.ExecuteScalar > 0 Then
        '            MsgBox("No. Mobil tidak boleh kosong", vbCritical)
        '            txtNoFak.Focus()
        '            Exit Sub
        '        End If
        '    Catch ex As Exception
        '        Throw ex
        '    End Try
        'End If

        If Not lWithPO Then
            If txtPO_QTY.Text = "0" Then
                MessageBox.Show("Isi QTY  Pendaftaran.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
                txtPO_QTY.Focus()
                Exit Sub
            End If
        End If
        'If Not lWithPO Then
        '    If txtPO_GROSS.Text = "0" Or txtPO_QTY.Text = "0" Then
        '        MessageBox.Show("Isi QTY dan Gross Pendaftaran.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
        '        txtPO_QTY.Focus()
        '        Exit Sub
        '    End If
        'End If

        'If txtNoMobil.Text = "" Then
        '    MsgBox("No. Mobil tidak boleh kosong", vbCritical)
        '    txtNoMobil.Focus()
        '    Exit Sub
        'End If

        If txtNamaSupp_.Text = "" Then
            MsgBox("Nama Supplier tidak boleh kosong", vbCritical)
            'CmbSUPCO.Focus()
            Exit Sub
        End If

        'txtSUPCO.Text = CmbSUPCO.Text
        'txtSUPCO.Visible = True
        'txtNoMobil.Text = DGV.Item(0, 0).Value
        'txtNoMobil.Visible = True

        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Scon.Open()
        Scom.CommandText = "Select sysdate from dual"
        txtTGL_MULAI.Text = Scom.ExecuteScalar
        Scom.CommandText = ""
        Scon.Close()
        'Dim dr As Object
        'dr = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Current
        'dr.row("SUPCO") = CmbSUPCO.Text
        'dr.row("SNAMA") = txtNamaSupp.Text
        'dr.row("NOMOBIL") = DGV.Item(0, 0).Value
        'dr.row("GUDANG_KODE") = cGUDANG_KODE
        'dr.row("LOKASI_KODE") = cLOKASI_KODE
        'dr.row("SUPID") = lblSUPID.Text
        'Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").EndCurrentEdit()

        lblGudangKode.Text = cGUDANG_KODE
        lblLokasiKode.Text = cLOKASI_KODE
        ' txtSupID.Text = lblSUPID.Text


        'load datanya dulu baru save
        frmLoadPO.sNoPo = txtNo_PO.Text

        'If LBMobil.SelectedIndex = -1 And LBMobil.Items.Count <> 0 Then
        '    LBMobil.SelectedIndex = 0
        'End If
        frmLoadPO.NOMOBIL = lbmobil_
        frmLoadPO.SUPCO = txtKodeSupp_.Text
        frmLoadPO.SNAMA = txtNamaSupp_.Text
        frmLoadPO.ITEMnya = IIf(txtTot_Item.Text = "", 0, txtTot_Item.Text)
        ' frmLoadPO.RUPIAH = txtPO_GROSS.Text
        frmLoadPO.FAKTUR = txtNoFak.Text
        frmLoadPO.NoAntrian = txtNoAntrian.Text
        frmLoadPO.tglDaftar = txtTglDaftar.Value
        frmLoadPO.tglFaktur = txtTglFaktur.Value


        If chkBUAT_PO.Checked = True Then
            frmLoadPO.adaPO = "1"
        Else
            frmLoadPO.adaPO = "0"
        End If

        If chkADA_HARGA.Checked = True Then
            frmLoadPO.adaHarga = "1"
        Else
            frmLoadPO.adaHarga = "0"
        End If
        If frmLoadPO.ShowDialog = Windows.Forms.DialogResult.OK Then

            'CmbSUPCO.Visible = False
            'CmbNama.Visible = False
            'LBMobil.ClearSelected()
            'LBMobil.Enabled = False
            SetTombol(False)
            'lblSNAMA.Text = ""
            'lblSUPCO.Text = ""
            'Me.BindingContext(dsPo1, "DC_JLR_DAFTARJALUR_T.DAF_PO").CancelCurrentEdit()
            ' btnCancelAll_Click(sender, e)
            RECID()
            '  frmDaftarPO_Load(sender, e)
            ''load
            'Dim Scon1 As New OleDb.OleDbConnection(ConStrORA)
            'Dim sdap As New OleDb.OleDbDataAdapter("Select * from dc_jlr_daftarjalur_t", Scon1)
            'Dim sdap2 As New OleDb.OleDbDataAdapter("Select * from dc_jlr_daftarpo_t", Scon1)
            'Scon1.Open()
            'DsPO1.DC_JLR_DAFTARPO_T.Clear()
            'DsPO1.DC_JLR_DAFTARJALUR_T.Clear()
            'DsPO1.DC_JLR_DAFTARPO_T.AcceptChanges()
            'DsPO1.DC_JLR_DAFTARJALUR_T.AcceptChanges()
            'sdap.Fill(DsPO1.DC_JLR_DAFTARJALUR_T)
            'sdap2.Fill(DsPO1.DC_JLR_DAFTARPO_T)
            'Scon1.Close()
            'DsPO1.DC_JLR_DAFTARPO_T.AcceptChanges()
            'DsPO1.DC_JLR_DAFTARJALUR_T.AcceptChanges()
            'DsPO1.GetChanges()
            'cmbFilter_SelectedIndexChanged(sender, e)
            LoadDataSet()
            Dim loadnourut As String = frmLoadPO.NOURUT
            For i As Integer = 0 To DsPO1.DC_JLR_DAFTARJALUR_T.Rows.Count - 1
                If DsPO1.DC_JLR_DAFTARJALUR_T.Rows(i)("NOURUT").ToString = loadnourut Then
                    Exit For
                Else
                    Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position += 1
                End If
            Next

            'Dim loadnodaf As String = frmLoadPO.FAKTUR
            For i As Integer = 0 To DsPO1.DC_JLR_DAFTARPO_T.Rows.Count - 1

                Dim NOFAK1 As String = DsPO1.DC_JLR_DAFTARPO_T.Rows(i)("NO_FAK").ToString
                Dim NOFAK2 As String = frmLoadPO.FAKTUR
                Dim NoPO1 As String = DsPO1.DC_JLR_DAFTARPO_T.Rows(i)("NOPO").ToString
                Dim NOPO2 As String = frmLoadPO.sNoPo.ToString

                If DsPO1.DC_JLR_DAFTARPO_T.Rows(i)("NO_FAK").ToString = frmLoadPO.FAKTUR And DsPO1.DC_JLR_DAFTARPO_T.Rows(i)("NOPO").ToString = frmLoadPO.sNoPo Then
                    Exit For
                Else
                    Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Position += 1
                End If
            Next
            'mobil()
        End If
        'frmLoadPO.Show()
        'frmLoadPO.Visible = True
        'Dim cekObat As Integer = execScalar(" SELECT count(*)" &
        '                "   FROM DC_PO_T a, DC_PODTL_T b" &
        '                "  WHERE po_no_po = '" & txtNo_PO.Text & "'" &
        '                "    AND po_no_po = podtl_fk_no_po" &
        '                "    AND podtl_plu IN (SELECT DISTINCT mbr_fk_pluid" &
        '                "                                 FROM DC_BARANG_DC_T" &
        '                "                                WHERE mbr_tgl_plumati IS NULL" &
        '                "                                  AND mbr_obat IS NOT NULL)", ConStrORA)
        ''If cekObat <> "0" Then
        ''    dgvLoadPO.Enabled = False
        ''Else
        ''    dgvLoadPO.Enabled = False
        ''End If
        'If cekObat > 0 Then
        '    Dim HasilProc As String = runProcIns_Spobat(cDC_KODE, txtNo_PO.Text)
        '    If HasilProc = "Y" Then
        '        Dim cekCetak As String = execScalar("SELECT nvl(flag_cetak,'XXX') FROM DC_SPOBAT_HDR_T WHERE no_po ='" & txtNo_PO.Text & "'", ConStrORA)
        '        If cekCetak = "XXX" Then
        '            'cetak  Dim result_MSGCTK As MsgBoxResult =  
        '            MessageBox.Show("Cetak Form SP Obat Pre-Cursor, siapkan printer!", "Perhatian!", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        '            frmCetak.NOPO_Report = txtNo_PO.Text
        '            frmCetak.Show()
        '        End If
        '    Else
        '        MessageBox.Show("Error Procedure Ins_SPOBAT : " & vbNewLine & HasilProc, "Perhatian!", MessageBoxButtons.OK, MessageBoxIcon.Stop)

        '    End If
        'End If

batalLoad:
    End Sub
    'Public Sub showdialogLoadPO(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles frmLoadPO1.FormClosing
    '    btnBatalPO_Click(sender, e)
    '    'test dgvload bisa di access ga dari sini

    '    'datasetload = frmLoadPO.dgvLoadPO.DataSource TryCast(dgvMyMembers.DataSource, DataTable)
    '    'If frmLoadPO.Visible = False Then
    '    '    If CancelLoad = "" Then
    '    '        SetTombol(False)
    '    '    Else
    '    '        SetTombol(True)
    '    '    End If
    '    'End If

    'End Sub
    Public Sub btnBatalPO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBatalPO.Click ', frmLoadPO1.FormClosing
        'CmbSUPCO.Visible = False
        'CmbNama.Visible = False
        'LBMobil.ClearSelected()
        'LBMobil.Enabled = False 
        SetTombol(False)
        'lblSNAMA.Text = ""
        'lblSUPCO.Text = ""
        'Me.BindingContext(dsPo1, "DC_JLR_DAFTARJALUR_T.DAF_PO").CancelCurrentEdit()
        btnCancelAll_Click(sender, e)
        RECID()
        btn_Next(txtKodeSupp_.Text)
        'txtSUPCO.Visible = False
        'txtNamaSupp.Visible = False
        txtNo_PO.Text = ""
        txtTot_Item.Text = ""
        txtKodeSupp_.Text = ""
        txtNamaSupp_.Text = ""
        txtNoFak.Text = ""
        txtPO_QTY.Text = ""
        txtTgl_PO.Text = ""

        Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").CancelCurrentEdit()

    End Sub


    Private Sub grdDC_JLR_DAFTARPO_T_LostFocus(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'Me.BindingContext(dsPo1, "DC_JLR_DAFTARJALUR_T.Daf_PO").EndCurrentEdit()
        Debug.WriteLine("Grid PO Lost")
    End Sub

    Public Sub SetTombol(ByVal i As Boolean)
        'txtNoMobil.Enabled = i
        txtTglDaftar.Enabled = i

        txtNoFak.Enabled = i
        txtTglFaktur.Enabled = i
        txtNo_PO.Enabled = i
        txtPO_QTY.Enabled = i
        'txtPO_GROSS.Enabled = i
        'txtPO_PPN.Enabled = i
        'txtTgl_PO.Enabled = i
        'txtSUPCO.Enabled = i
        txtKodeSupp_.Enabled = i
        txtNamaSupp_.Enabled = i

        btnSimpanPO.Enabled = i
        btnBatalPO.Enabled = i

        btnNext.Enabled = Not i
        btnPrev.Enabled = Not i
        btnNext2.Enabled = Not i
        btnPrev2.Enabled = Not i
        btnEditPO.Enabled = Not i
        btnTambahPO.Enabled = Not i
        btnHapusPO.Enabled = Not i

        btnDaftar.Enabled = Not i
        btnCari.Enabled = Not i
        btnPrev.Enabled = Not i
        btnNext.Enabled = Not i
        btnPrev2.Enabled = Not i
        btnNext2.Enabled = Not i
        txtTglDaftar.Enabled = Not i



    End Sub

#Region "Validasi PO"
    Private NoPO As String

    Private lWithPO As Boolean
    Private Sub txtNo_PO_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNo_PO.Enter
        NoPO = txtNo_PO.Text.ToUpper

    End Sub

    Private Sub txtNo_PO_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtNo_PO.TextChanged

        If txtNo_PO.Enabled = False Then
            Exit Sub
        End If
        If txtNo_PO.Text.Length = 9 Then
            Dim cekDirectShipment As String = execScalar("SELECT  po_jenis_pb FROM DC_PO_T WHERE po_no_po = '" & txtNo_PO.Text & "' ", ConStrORA)
            If cekDirectShipment.Contains("DIRECT SHIPMENT") Then
                MsgBox("PO DIRECT SHIPMENT di proses pada aplikasi terpisah", vbInformation)
                txtNo_PO.Text = ""
                Exit Sub
            End If
            Dim Err_msg As String = ""

            'Tanpa PO
            If txtNo_PO.Text = "" Then
                lWithPO = False

                txtTgl_PO.Enabled = True
                'txtSUPCO.Enabled = True
                chkADA_HARGA.Enabled = True

                'txtTgl_PO.Text = Now.Date

                'chkADA_HARGA.Value = 1
                'chkBUAT_PO.Value = 0
                chkADA_HARGA.Checked = True
                chkBUAT_PO.Checked = False

                'txtPO_QTY.Text = Format(0, "#,##0")
                'txtPO_GROSS.Text = Format(0, "#,##.##############")
                'txtPO_PPN.Text = Format(0, "#,##.##############")
                'txtPO_Total.Text = Format(0, "#,##.##############")
                'txtTot_Item.Text = CInt("0")

                txtPO_QTY.Text = "0"
                'txtPO_GROSS.Text = "0"
                'txtPO_PPN.Text = "0"
                'txtPO_Total.Text = "0"
                'txtTot_Item.Text = "0"

                'DoEvents
                'txtTGL_PO.SetFocus
                'txtTGL_PO.SetFocus
                'SendKeys("{TAB}")

                Exit Sub
            End If
            lWithPO = True

            txtNo_PO.Text = txtNo_PO.Text.ToUpper
            If txtNo_PO.Text = NoPO Then
                Exit Sub
            End If

            If Len(txtNo_PO.Text) < 9 Then
                MsgBox("PO Tidak ada.", vbCritical)
                'txtNO_PO.Text = ""
                If NoPO <> "" Then
                    txtNo_PO.Text = NoPO
                End If
                'e.Cancel = True
                Exit Sub
            End If

            Dim sql As String
            Dim Scon As New OracleConnection(ConStrORA)
            Dim Scom As New OracleCommand("", Scon)
            Dim sdar As OracleDataReader
            Dim dt As New DataTable
            Dim da As New OracleDataAdapter("", Scon)
            Dim tampilTagN As String = "Di PO ini ada PLU yang tidak boleh diBPB :" & vbCrLf
            Try
                Scon.Open()

                sql = "Select COUNT(*) From DC_JLR_DaftarPO_T Where NoPO='" &
                    txtNo_PO.Text & "' "
                'sql &= "AND TRUNC(Tanggal)=TRUNC(sysdate) "
                sql &= "AND NO_FAK='" & txtNoFak.Text & "' "

                Scom.CommandText = sql
                If Scom.ExecuteScalar > 0 Then
                    Err_msg = "PO sudah pernah didaftar dengan faktur sama."
                    GoTo Batal
                End If

                sql = "Select COUNT(*) From DC_JLR_DaftarPO_T Where NoPO='" &
                    txtNo_PO.Text & "' and BPB_NO is null"
                Scom.CommandText = sql
                If Scom.ExecuteScalar > 0 Then
                    If MsgBox("PO sudah pernah didaftar. Daftarkan lagi ?", MsgBoxStyle.YesNo) = MsgBoxResult.No Then
                        GoTo Selesai
                    End If
                End If

                'MessageBox.Show(txtNo_PO.Text & vbCrLf & cDC_KODE)

                'cek PLU yg Tag N

                'sql = "SELECT PLU FROM (" & _
                '"SELECT b.mbr_plukode AS PLU, b.mbr_full_nama AS nama_sup, IsTag_BolehBPB(194,b.MBR_TAG) AS cek " & _
                '"FROM dc_barang_dc_v b, DC_PODTL_T a " & _
                '"WHERE(a.PODTL_PLUMD = b.MBR_FK_PLUID) " & _
                '"AND a.podtl_fk_no_po ='LH6B32194' " & _
                '"AND b.TBL_DC_KODE='G020' " & _
                '")WHERE cek=0 "

                sql = " SELECT PLU FROM ( " &
                "SELECT b.mbr_plukode AS PLU, b.mbr_full_nama AS nama, IsTag_BolehBPB(" & cDC_ID & ",b.MBR_TAG) AS cek " &
                "FROM dc_barang_dc_v b, DC_PODTL_T a  " &
                "WHERE(a.PODTL_PLUMD = b.MBR_FK_PLUID) " &
                "AND a.podtl_fk_no_po ='" & txtNo_PO.Text & "'  " &
                "AND b.TBL_DC_KODE = '" & cDC_KODE & "' " &
                ")WHERE cek=0"
                dt.Clear()
                da.SelectCommand.CommandText = sql
                da.Fill(dt)
                If dt.Rows.Count > 0 Then
                    For x As Integer = 0 To dt.Rows.Count - 1
                        If x = dt.Rows.Count - 1 Then
                            tampilTagN &= (dt.Rows(x)("PLU")) & "."
                        Else
                            tampilTagN &= (dt.Rows(x)("PLU")) & ", " '& " - " & (dt.Rows(x)("nama"))
                        End If

                    Next
                    MessageBox.Show(tampilTagN, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information)

                    ' Err_msg = tampilTagN
                    ' GoTo Batal
                End If
                'end Cek PLU
                'MessageBox.Show(dt.Rows.Count)

                ' kasus lombok jd harus matiin optimizer use feedback 14/3/2017 /*+OPT_PARAM(_'OPTIMIZER_USE_FEEDBACK' 'FALSE)*/

                sql = " SELECT    "
                sql &= "MAX(PO_RECID) AS RECIDx,MIN(PO_GUDANG) AS PO_GUDANG,PO.PO_NO_PO,PO.PO_EXPIRED, "
                sql &= "PO.PO_TGL_PO, PO.PO_SUPCO_MD AS SUPID, "
                sql &= "GET_SUPCO(PO.PO_SUPCO_MD)AS SUPCO, "
                sql &= "COUNT(*) AS TOT_ITEM "
                sql &= ",SUM(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*PODTL_QTYB*PODTL_ISI_SATB) AS PO_QTY "
                sql &= ",trunc(SUM( IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*(PODTL_QTYB*PODTL_ISI_SATB*PODTL_PRICE- "
                sql &= "   ((PODTL_QTYB*PODTL_ISI_SATB)/((PODTL_QTYB*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
                sql &= "   *NVL(TotDisc,0))) ),8) AS PO_GROSS "
                sql &= ",trunc(SUM(CASE WHEN PODTL_PPN > 0 THEN (IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)"
                sql &= "	*((PODTL_QTYB*PODTL_ISI_SATB*PODTL_PRICE-((PODTL_QTYB*PODTL_ISI_SATB)"
                sql &= "	/((PODTL_QTYB*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
                sql &= "	*NVL(TotDisc,0)))*(Nvl(podtl_ppn_persen,getppnnew(null)) / 100))) ELSE 0 END),8) AS PO_PPN "
                sql &= ",MIN(PO_UMUR) AS PO_UMUR,PO_TGL_KIRIM "
                sql &= ",trunc(SUM(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*NVL(PODTL_PPN_BTL,0)),8) AS PPN_BOTOL "
                sql &= "FROM DC_PO_T PO "
                sql &= "LEFT JOIN DC_PODTL_T DT ON PO.PO_NO_PO = DT.PODTL_FK_NO_PO "
                sql &= "LEFT JOIN ("
                sql &= "	SELECT MBR_FK_PLUID,(MBR_TAG) AS MBR_TAG "
                sql &= "	FROM DC_BARANG_DC_V WHERE TBL_DC_KODE='" & cDC_KODE & "') BRG ON DT.PODTL_PLUMD=BRG.MBR_FK_PLUID "
                sql &= "LEFT JOIN ( "
                sql &= "	SELECT podisc_fk_no_po,PODISC_FK_PLU, "
                sql &= "	SUM(NVL(podisc_nilai,0)) AS TotDisc "
                sql &= "	FROM DC_PODISC_T "
                sql &= "	GROUP BY podisc_fk_no_po,PODISC_FK_PLU) S ON PO.PO_NO_PO=S.podisc_fk_no_po "
                sql &= "	AND DT.PODTL_PLUMD=S.PODISC_FK_PLU "
                sql &= "WHERE ((PODTL_RECID IS NULL OR PODTL_RECID='') AND PODTL_NO_BPB IS NULL) "
                sql &= "AND PO_NO_PO='" & txtNo_PO.Text & "' "
                sql &= "GROUP BY PO.PO_NO_PO, PO.PO_TGL_PO, PO.PO_SUPCO_MD, PO.PO_EXPIRED,PO.PO_TGL_KIRIM "
                Scom.CommandText = sql

                sdar = Scom.ExecuteReader
                If sdar.Read = False Then
                    Err_msg = "PO tidak ada. Atau Sudah BPB"
                    GoTo Batal
                End If

                'If sdar("SUPCO") <> lblSUPCO.Text And lblSUPCO.Text <> "" Then
                'If sdar("SUPCO") <> lblSUPCO.Text Then
                '    Err_msg = "Supplier tidak punya PO " & txtNo_PO.Text & "."
                '    GoTo Batal
                'End If

                ''Cek Status PO
                'Dim abc As Date = CType(sdar("PO_TGL_KIRIM"), Date)

                If Not IsDBNull(sdar("PO_TGL_KIRIM")) Then
                    If CType(sdar("PO_TGL_KIRIM"), Date) <> Now.Date Then
                        Err_msg = "PO Tidak Sesuai Tanggal Kirim."
                        GoTo Batal
                    End If
                Else
                    If CType(sdar("PO_TGL_PO"), Date).AddDays(sdar("PO_UMUR")) < Now.Date Then
                        Err_msg = "PO Sudah Kadaluarsa."
                        If IsDBNull(sdar("PO_EXPIRED")) Then
                            Dim SconE As New OracleConnection(ConStrORA)
                            Dim ScomE As New OracleCommand("", SconE)
                            SconE.Open()
                            ScomE.CommandText = "update DC_PO_T set PO_EXPIRED='Y' where PO_NO_PO='" & txtNo_PO.Text & "' "
                            ScomE.ExecuteNonQuery()
                            SconE.Close()
                            ScomE = Nothing
                            SconE = Nothing
                        End If
                        GoTo Batal
                    End If
                End If

                Dim rc As String = sdar("RECIDx") & ""
                Select Case rc
                    Case "C"
                        Err_msg = "PO Di-Closing"
                    Case "B"
                        Err_msg = "PO Sudah ada BPB-nya"
                    Case "H"
                        Err_msg = "PO Hangus"
                    Case "A"
                        Err_msg = "PO Sedang dibuat BPB-nya"
                    Case "1"
                        Err_msg = "Item PO dihapus"
                    Case "2"
                        Err_msg = "PO Revisi"
                End Select
                If Err_msg <> "" Then GoTo Batal

                If IFNULL(sdar("PO_QTY"), 0) + IFNULL(sdar("PO_GROSS"), 0) + IFNULL(sdar("PO_PPN"), 0) = 0 Then
                    Err_msg = "Qty, Gross & PPN Kosong."
                    GoTo Batal
                End If

                txtKodeSupp_.Text = sdar("SUPCO")
                txtNamaSupp_.Text = execScalar("select sup_nama from dc_supplier_dc_v where sup_supkode = '" & sdar("SUPCO") & "'", ConStrORA)
                txtPO_QTY.Text = sdar("PO_QTY")
                txtTgl_PO.Text = sdar("PO_TGL_PO")
                txtTot_Item.Text = sdar("TOT_ITEM")


                ''Cek Supp. MrBread pindah ke setelah pengisian no faktur 221122
                ''CEK TBL ALOKASI DAN CEK SJ
                'Dim IsMBread As Boolean = IsMrBread(sdar("SUPCO") & "", cDC_KODE)
                'If IsMBread Then
                '    Dim Scon2 As New OracleConnection(ConStrORA)
                '    Dim Scom2 As New OracleCommand("", Scon2)

                '    Try
                '        Scon2.Open()
                '        Scom2.CommandType = CommandType.StoredProcedure
                '        Scom2.CommandText = "IMPORT_MBREAD('" & cDC_KODE & "')"
                '        Scom2.ExecuteNonQuery()

                '        Scom2.CommandType = CommandType.Text
                '        Scom2.CommandText = "select CEK_MRBREAD ( '" & txtNoFak.Text &
                '            "', TO_DATE('" & Format(txtTglFaktur.Value, "yyyyMMdd") & "','YYYYMMDD'), '" & txtNo_PO.Text & "') as x from dual"
                '        Err_msg = Scom2.ExecuteScalar & " "
                '        If Err_msg.Substring(0, 1) = "1" Or Err_msg.Substring(0, 1) = "3" Then
                '            '1;No. Faktur atau Tanggal Faktur Salah.
                '            '3;Jumlah Item Faktur > Jumlah Item PO.

                '            Err_msg = Err_msg.Substring(2)
                '            GoTo Batal
                '        Else
                '            '2;Total Faktur Dan PO Tidak Sama.
                '            If Err_msg.Substring(0, 1) = "2" Then
                '                Err_msg = Err_msg.Substring(2)
                '                MessageBox.Show(Err_msg, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
                '            End If
                '        End If
                '        Err_msg = ""
                '    Catch ex As Exception
                '        Throw ex
                '    Finally
                '        Scon2.Close()
                '    End Try

                'End If

                ''isi TextBOX
                'txtTgl_PO.Text = sdar("PO_TGL_PO")
                ''txtSUPCO.Text = sdar("SUPCO")
                'lblSUPID.Text = IFNULL(sdar("SUPID"), 0)
                ''If lblSUPCO.Text = "" Then
                ''    lblSUPCO.Text = sdar("SUPCO")
                ''End If

                ''Dim dr As Object
                ''dr = Me.BindingContext(dsPo1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Current
                ''dr.row("SUPID") = sdar("SUPID") & ""

                'chkBUAT_PO.Checked = True ''''''''
                'chkADA_HARGA.Checked = True ''''''

                'txtTot_Item.Enabled = False
                'txtPO_QTY.Enabled = False
                ''txtPO_GROSS.Enabled = False
                ''txtPO_PPN.Enabled = False

                'txtKodeSupp_.Text = sdar("SUPCO")

                'txtNamaSupp_.Text = execScalar("Select S.SUP_NAMA AS SNAMA,H.SUP_FLAG_BUATPO AS BUAT_PO,s.SUP_SUPID AS SUPID from DC_SUPPLIER_DC_V H,DC_SUPPLIER_T S " &
                '                         "Where H.SUP_FK_SUPID=s.SUP_SUPID And " &
                '                         "TBL_DC_KODE='" & cDC_KODE &
                '                         "' AND H.SUP_SUPKODE='" & sdar("SUPCO") & "'", ConStrORA)

                'If Not IsMBread Then
                '    txtPO_QTY.Text = Format(sdar("PO_QTY"), "#,##0")
                '    'txtPO_GROSS.Text = Format(CDbl(sdar("PO_GROSS")), "#,##.##############")
                '    'txtPO_PPN.Text = Format(CDbl(IFNULL(sdar("PO_PPN"), 0)), "#,##.##############")
                '    'txtPO_Total.Text = Format(CDbl(sdar("PO_GROSS")) + CDbl(IFNULL(sdar("PO_PPN"), 0)) + CDbl(IFNULL(sdar("PPN_BOTOL"), 0)), "#,##.##############")
                '    txtTot_Item.Text = CDbl("0" & sdar("TOT_ITEM"))
                'Else
                '    sdar.Close()

                '    ' kasus lombok jd harus matiin optimizer use feedback 14/3/2017
                '    sql = " SELECT    "
                '    sql &= "MAX(PO_RECID) AS RECIDx,MIN(PO_GUDANG) AS PO_GUDANG,PO.PO_NO_PO, "
                '    sql &= "PO.PO_TGL_PO, PO.PO_SUPCO_MD AS SUPID, "
                '    'sql &= "GET_SUPCO(PO.PO_SUPCO_MD)AS SUPCO, "
                '    sql &= "COUNT(*) AS TOT_ITEM "
                '    sql &= ",SUM(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*NVL(BREAD.JUM,0)*PODTL_ISI_SATB) AS PO_QTY "
                '    sql &= ",trunc(SUM( IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*(NVL(BREAD.JUM,0)*PODTL_ISI_SATB*PODTL_PRICE- "
                '    sql &= "   ((NVL(BREAD.JUM,0)*PODTL_ISI_SATB)/((NVL(BREAD.JUM,0)*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
                '    sql &= "   *NVL(TotDisc,0))) ),8) AS PO_GROSS "
                '    sql &= ",trunc(SUM(CASE WHEN PODTL_PPN > 0 THEN "
                '    sql &= "	(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*((NVL(BREAD.JUM,0)*PODTL_ISI_SATB*PODTL_PRICE- "
                '    sql &= "	((NVL(BREAD.JUM,0)*PODTL_ISI_SATB)/((NVL(BREAD.JUM,0)*PODTL_ISI_SATB)+PODTL_FRAC_QTYB) "
                '    sql &= "	*NVL(TotDisc,0)))*(Nvl(podtl_ppn_persen,getppnnew(null)) / 100))) ELSE 0 END),8) AS PO_PPN "
                '    sql &= ",MIN(PO_UMUR) AS PO_UMUR "
                '    sql &= ",trunc(SUM(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*NVL(PODTL_PPN_BTL,0)),8) AS PPN_BOTOL "
                '    sql &= "FROM DC_PO_T PO "
                '    sql &= "LEFT JOIN DC_PODTL_T DT ON PO.PO_NO_PO = DT.PODTL_FK_NO_PO "
                '    sql &= "LEFT JOIN ("
                '    sql &= "	SELECT MBR_FK_PLUID,(MBR_TAG) AS MBR_TAG "
                '    sql &= "	FROM DC_BARANG_DC_V "
                '    sql &= "	WHERE TBL_DC_KODE='" & cDC_KODE & "') BRG ON DT.PODTL_PLUMD=BRG.MBR_FK_PLUID "
                '    sql &= "LEFT JOIN ( "
                '    sql &= "	SELECT podisc_fk_no_po,PODISC_FK_PLU, "
                '    sql &= "	SUM(NVL(podisc_nilai,0)) AS TotDisc "
                '    sql &= "	FROM DC_PODISC_T "
                '    sql &= "	GROUP BY podisc_fk_no_po,PODISC_FK_PLU) S ON PO.PO_NO_PO=S.podisc_fk_no_po "
                '    sql &= "	AND DT.PODTL_PLUMD=S.PODISC_FK_PLU "
                '    sql &= "LEFT JOIN ( "
                '    sql &= "	 SELECT   a.pluid AS plumd, SUM (a.qty) AS Jum "
                '    sql &= "     FROM alokasi_tampung a "
                '    sql &= "	 WHERE (a.no_sj = '" & txtNoFak.Text & "') "
                '    sql &= "   	 GROUP BY a.no_sj, a.tgl_sj, a.pluid "
                '    sql &= "	 order by plumd) BREAD ON  DT.podtl_plumd=BREAD.PLUMD "
                '    sql &= "WHERE (PODTL_RECID IS NULL OR PODTL_RECID='') "
                '    sql &= "AND PO_NO_PO='" & txtNo_PO.Text & "' "
                '    sql &= "GROUP BY PO.PO_NO_PO, PO.PO_TGL_PO, PO.PO_SUPCO_MD "
                '    Scom.CommandText = sql
                '    sdar = Scom.ExecuteReader
                '    If sdar.Read Then
                '        txtNoFak.Enabled = False
                '        txtPO_QTY.Text = Format(sdar("PO_QTY"), "#,##0")
                '        'txtPO_GROSS.Text = Format(CDbl(sdar("PO_GROSS")), "#,##.##############")
                '        'txtPO_PPN.Text = Format(CDbl(IFNULL(sdar("PO_PPN"), 0)), "#,##.##############")
                '        'txtPO_Total.Text = Format(CDbl(sdar("PO_GROSS")) + CDbl(IFNULL(sdar("PO_PPN"), 0)) + CDbl(IFNULL(sdar("PPN_BOTOL"), 0)), "#,##.##############")
                '        txtTot_Item.Text = CDbl("0" & sdar("TOT_ITEM"))
                '    Else
                '        Err_msg = "Data Alokasi MBREAD Tidak ada."
                '        GoTo Batal
                '    End If
                'End If

                'sdar.Close()

                sdar = Nothing

                'sql = "Select S.SUP_NAMA AS SNAMA from DC_SUPPLIER_DC_V H,DC_SUPPLIER_T S " & _
                '    "Where H.SUP_FK_SUPID=s.SUP_SUPID And " & _
                '    "TBL_DC_KODE='" & cDC_KODE & _
                '    "' AND H.SUP_SUPKODE='" & cmbSUPCO.Text & "'"
                'Scom.CommandText = sql

                'txtNamaSupp.Text = "" & Scom.ExecuteScalar
                'If lblSNAMA.Text = "" Then
                '    lblSNAMA.Text = txtNamaSupp.Text
                'End If

                'txtSUPCO.Enabled = False
                txtTgl_PO.Enabled = False
                chkADA_HARGA.Enabled = False


                'double msg
                'Dim a As String = txtNo_PO.Text
                'btnSimpanPO.Focus()
                'txtNo_PO.Text = a


                'Name of Project : Program Obat Prekursor Farmasi
                'PRPK: 881/10-20/E/PMO	Memo CPS :  220/CPS/16
                'CREATE OR REPLACE PROCEDURE Ins_Spobat (p_dckode IN VARCHAR2, p_nopo IN VARCHAR2)
                'SELECT flag_cetak FROM DC_SPOBAT_HDR_T WHERE no_po ='FH4L32994'
                'cetak  rptSPTOBATPRECURSOR.rdlc
                'dc_trnbpb_hdr_t
                'update dc_trnbob_hdr_t set Tbl_alokasi_id ='-1' where no_po =''
                'frmEdit po obat tidak bisa edit qty
                'saat hapus po tambahkan hapus dc_trnbpb_dtlbatch_t.


                'Dim HasilProc As String = runProcIns_Spobat(cDC_KODE, txtNo_PO.Text)
                'If HasilProc <> "Y" Then
                '    Dim cekCetak As String = execScalar("SELECT nvl(flag_cetak,'XXX') FROM DC_SPOBAT_HDR_T WHERE no_po ='" & txtNo_PO.Text & "'", ConStrORA)
                '    If cekCetak = "XXX" Then
                '        'cetak  Dim result_MSGCTK As MsgBoxResult =  
                '        MessageBox.Show("Cetak Form SP Obat Pre-Cursor, siapkan printer!", "Perhatian!", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                '        frmCetak.NOPO_Report = txtNo_PO.Text
                '        frmCetak.Show()
                '    End If
                'End If

                ''''pindah ke ending button tambah po
                'Dim cekObat As String = execScalar(" SELECT count(*)" &
                '        "   FROM DC_PO_T a, DC_PODTL_T b" &
                '        "  WHERE po_no_po = '" & txtNo_PO.Text & "'" &
                '        "    AND po_no_po = podtl_fk_no_po" &
                '        "    AND podtl_plu IN (SELECT DISTINCT mbr_fk_pluid" &
                '        "                                 FROM DC_BARANG_DC_T" &
                '        "                                WHERE mbr_tgl_plumati IS NULL" &
                '        "                                  AND mbr_obat IS NOT NULL)", ConStrORA)
                'If cekObat <> "0" Then
                '    btnEditPO.Enabled = False
                '    'btnSimpanPO.Enabled = False
                '    'Else


                '    '    MsgBox("Ini merupakan PO Obat", vbInformation)
                '    '    execQuery("update dc_trnbpb_hdr_t set PO_MRBREAD ='O' where no_po ='" & txtNo_PO.Text & "'", ConStrORA)
                'End If


                '                Revisi program �PENDAFTARAN PO.EXE� untuk PO DS tidak bisa di proses sbb
                'Saat Input nomor PO di program 
                'jika NO PO di Dc_po_t.po_jenis_pb Like '%DIRECT SHIPMENT%' -> tidak bisa didaftarkan, 
                'berikan alert �PO DIRECT SHIPMENT di proses pada aplikasi terpisah�    &
                '         " AND po_jenis_pb LIKE '%DIRECT SHIPMENT%"


                Exit Try

Selesai:
                txtNo_PO.Text = ""
                txtTgl_PO.Text = ""
                txtTot_Item.Text = ""
                chkBUAT_PO.Checked = False
                chkADA_HARGA.Checked = False
                txtPO_QTY.Text = ""
                'txtPO_GROSS.Text = ""
                'txtPO_PPN.Text = ""
                'txtPO_Total.Text = ""
                txtKodeSupp_.Text = ""
                txtNamaSupp_.Text = ""
                NoPO = ""
                txtNo_PO.Focus()
                Exit Try

Batal:
                MessageBox.Show(Err_msg, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                If NoPO <> "" Then
                    txtNo_PO.Text = NoPO
                Else
                    txtNo_PO.Text = ""
                    NoPO = ""
                    txtNo_PO.Focus()
                End If

                'e.Cancel = True

            Catch ex As Exception
                ShowError("Error Baca PO", ex)
                'MsgBox("Error Baca PO : Data PO Salah", MsgBoxStyle.Critical)
                'txtNo_PO.Text = ""
            End Try


            'If txtNoAntrian.Text = "" Then
            '    txtNoAntrian.Text = frmLoadPO.NextAntrian()
            'Else


            'pecah faktur faktur baru harus ikut nourut pecahan yang sdauh terdaftar
            Dim dt_nourutPecahFaktur As DataTable = getDS("select nourut from dc_jlr_daftarjalur_t where id_daftarjalur = ( SELECT min(id_daftarjalur)" &
                                                               " FROM dc_jlr_daftarpo_t WHERE NOpo = '" & txtNo_PO.Text & "' AND supco ='" & txtKodeSupp_.Text & "') " &
                                                               "    and trunc(tanggal)=trunc(sysdate)", ConStrORA).Tables(0)
            For xy As Integer = 0 To dt_nourutPecahFaktur.Rows.Count - 1
                txtNoAntrian.Text = dt_nourutPecahFaktur.Rows(xy)("nourut").ToString
                GoTo NoUrutFinal
            Next
            'pecah faktur faktur baru harus ikut nourut pecahan yang sdauh terdaftar


            'tambahkan pengecekan recid.dc_jlr_daftarpo_t ='B' (sudah BPB)
            Dim queryCekNoUrut As String = " SELECT   TRUNC (a.tanggal), a.nourut, a.nomobil, a.supco, a.snama," &
                    "          MIN (tgl_mulai) AS tglmulai, COUNT (b.nopo) AS tot_po," &
                    "          COUNT (b.bpb_no) AS tot_bpb" &
                    "     FROM dc_jlr_daftarjalur_t a, dc_jlr_daftarpo_t b" &
                    "    WHERE TRUNC (a.tanggal) = TRUNC (SYSDATE)" &
                    "      AND a.supco = '" & txtKodeSupp_.Text & "'  " &
                    "      AND a.id_daftarjalur = b.id_daftarjalur" &
                    " GROUP BY TRUNC (a.tanggal), a.nourut, a.nomobil, a.supco, a.snama " &
                    " ORDER BY nourut"
            Dim dt_cekNOURUT As DataTable = getDS(queryCekNoUrut, ConStrORA).Tables(0)
            If dt_cekNOURUT.Rows.Count > 0 Then
                Dim cekSudahBPB As String = dt_cekNOURUT.Rows(0)("tot_bpb").ToString
                If cekSudahBPB = 0 Then

                    Dim MesRessult1 As DialogResult = MessageBox.Show("No Urut Sudah Terdaftar, Daftarkan PO dengan nomor urut baru?", "Perhatian!", MessageBoxButtons.YesNo)
                    If MesRessult1 = DialogResult.Yes Then 'belum bpb, no urut baru
                        txtNoAntrian.Text = frmLoadPO.NextAntrian()
                    Else 'belum bpb, no urut lama
                        txtNoAntrian.Text = dt_cekNOURUT.Rows(0)(1).ToString
                    End If
                    lbmobil_ = dt_cekNOURUT.Rows(0)(2).ToString
                Else

                    Dim cekurutnonBPB As String = ""
                    For x As Integer = 0 To dt_cekNOURUT.Rows.Count - 1

                        Dim cekSudahBPBloop As String = dt_cekNOURUT.Rows(x)("tot_bpb").ToString
                        If cekSudahBPBloop = 0 Then
                            cekurutnonBPB = x
                            Exit For
                        End If
                    Next
                    Dim MesRessult As DialogResult = MessageBox.Show("Sudah ada BPB, PO Akan Didaftarkan dengan No Urut Baru.", "Perhatian!", MessageBoxButtons.YesNo)
                    If MesRessult = DialogResult.Yes Then 'sudah bpb dan buat no urut baru
                        txtNoAntrian.Text = frmLoadPO.NextAntrian()
                    Else
                        If cekurutnonBPB <> "" Then 'sudah bpb dan ada nourut kosong
                            txtNoAntrian.Text = dt_cekNOURUT.Rows(cekurutnonBPB)(1).ToString
                        Else 'sudah bpb dan tidak ada nourut kosong
                            btnBatalPO_Click(Nothing, Nothing)
                            Exit Sub
                        End If
                    End If
                End If
            Else
                txtNoAntrian.Text = frmLoadPO.NextAntrian()
            End If
            '   End If
NoUrutFinal:
        End If
    End Sub


    'CREATE OR REPLACE PROCEDURE Ins_Spobat (p_dckode IN VARCHAR2, p_nopo IN VARCHAR2)   
    Public Function runProcIns_Spobat(ByVal p_dckode As String, ByVal p_nopo As String)
        Dim OraCon As New OracleConnection(STRKONEKSIODP)
        Dim OraAdapt As New OracleDataAdapter("", OraCon)
        Dim OraCom As New OracleCommand("", OraCon)
        Dim AdaError As Boolean = False

        Try
            'form1.Cursor = Cursors.WaitCursor
            OraCon.Open()
            OraCom.CommandType = CommandType.StoredProcedure
            OraCom.CommandText = "Ins_Spobat"
            OraCom.CommandType = System.Data.CommandType.StoredProcedure

            OraCom.Parameters.Clear()
            OraCom.Parameters.Add(New OracleParameter("P_DCKODE", OracleDbType.Varchar2, 2000))
            OraCom.Parameters.Add(New OracleParameter("P_NOPO", OracleDbType.Varchar2, 2000))
            'OraCom.Parameters.Add(New OracleParameter("P_TGLPIC", OracleDbType.Date, 2000))
            'OraCom.Parameters.Add(New OracleParameter("P_MSG", OracleDbType.Varchar2, 2000, System.Data.ParameterDirection.Output, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))

            OraCom.Parameters.Item(0).Value = p_dckode
            OraCom.Parameters.Item(1).Value = p_nopo
            ' OraCom.Parameters.Item(2).Value = TglPIC.Date
            OraCom.ExecuteNonQuery()
            OraCom.CommandType = CommandType.Text
            Return "Y"
            ' hasil = OraCom.Parameters.Item(3).Value.ToString
        Catch ex As Exception
            AdaError = True
            Return "Procedure - Procedure Ins_Spobat :   " & ex.Message
        Finally
            OraCom.Dispose()
            OraCom = Nothing
            OraCon.Close()
        End Try

        'If hasil <> "null" Or hasil <> "" Or hasil <> "Nothing" Or hasil <> Nothing Then
        '    Return ("Procedure - Procedure Ins_Spobat : " & hasil)
        'Else
        '    Return ("Y")
        'End If
    End Function

    '    Private Sub txtNo_PO_Validating(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtNo_PO.Validating
    '        'TODO: Cek Item2 yang tidak maen di DC aktif (Jika ada Tolak PO)

    '        Dim Err_msg As String = ""

    '        'Tanpa PO
    '        If txtNo_PO.Text = "" Then
    '            lWithPO = False

    '            txtTgl_PO.Enabled = True
    '            'txtSUPCO.Enabled = True
    '            chkADA_HARGA.Enabled = True

    '            'txtTgl_PO.Text = Now.Date

    '            'chkADA_HARGA.Value = 1
    '            'chkBUAT_PO.Value = 0
    '            chkADA_HARGA.Checked = True
    '            chkBUAT_PO.Checked = False

    '            'txtPO_QTY.Text = Format(0, "#,##0")
    '            'txtPO_GROSS.Text = Format(0, "#,##.##############")
    '            'txtPO_PPN.Text = Format(0, "#,##.##############")
    '            'txtPO_Total.Text = Format(0, "#,##.##############")
    '            'txtTot_Item.Text = CInt("0")

    '            txtPO_QTY.Text = "0"
    '            txtPO_GROSS.Text = "0"
    '            txtPO_PPN.Text = "0"
    '            txtPO_Total.Text = "0"
    '            txtTot_Item.Text = "0"

    '            'DoEvents
    '            'txtTGL_PO.SetFocus
    '            'txtTGL_PO.SetFocus
    '            'SendKeys("{TAB}")

    '            Exit Sub
    '        End If
    '        lWithPO = True

    '        txtNo_PO.Text = txtNo_PO.Text.ToUpper
    '        If txtNo_PO.Text = NoPO Then
    '            Exit Sub
    '        End If

    '        If Len(txtNo_PO.Text) < 9 Then
    '            MsgBox("PO Tidak ada.", vbCritical)
    '            'txtNO_PO.Text = ""
    '            If NoPO <> "" Then
    '                txtNo_PO.Text = NoPO
    '            End If
    '            e.Cancel = True
    '            Exit Sub
    '        End If

    '        Dim sql As String
    '        Dim Scon As New OleDb.OleDbConnection(ConStrORA)
    '        Dim Scom As New OleDb.OleDbCommand("", Scon)
    '        Dim sdar As OleDb.OleDbDataReader

    '        'hack: Test
    '        'Dim Scon As New OracleClient.OracleConnection("user id=DCSIM;data source=SIMULASIA;password=DCSIM")
    '        'Dim Scom As New OracleClient.OracleCommand("", Scon)
    '        'Dim sdar As OracleClient.OracleDataReader
    '        Try
    '            Scon.Open()

    '            sql = "Select COUNT(*) From DC_JLR_DaftarPO_T Where NoPO='" & _
    '                txtNo_PO.Text & "' "
    '            'sql &= "AND TRUNC(Tanggal)=TRUNC(sysdate) "
    '            sql &= "AND NO_FAK='" & txtNoFak.Text & "' "

    '            Scom.CommandText = sql
    '            If Scom.ExecuteScalar > 0 Then
    '                Err_msg = "PO sudah pernah didaftar dengan faktur sama."
    '                GoTo Batal
    '            End If

    '            'sql = "SELECT * "
    '            'sql &= "FROM JLR_GET_SUM_DAFTARPO_V "
    '            'sql &= "Where PO_NO_PO='" & txtNo_PO.Text & "' "
    '            'sql &= "AND PO_GUDANG='" & cDC_KODE & "' "

    '            sql = " SELECT "
    '            sql &= "MAX(PO_RECID) AS RECIDx,MIN(PO_GUDANG) AS PO_GUDANG,PO.PO_NO_PO, "
    '            sql &= "PO.PO_TGL_PO, PO.PO_SUPCO_MD AS SUPID, "
    '            sql &= "GET_SUPCO(PO.PO_SUPCO_MD)AS SUPCO, "
    '            sql &= "COUNT(*) AS TOT_ITEM "
    '            sql &= ",SUM(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*PODTL_QTYB*PODTL_ISI_SATB) AS PO_QTY "
    '            sql &= ",SUM( IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*(PODTL_QTYB*PODTL_ISI_SATB*PODTL_PRICE- "
    '            sql &= "   ((PODTL_QTYB*PODTL_ISI_SATB)/((PODTL_QTYB*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
    '            sql &= "   *NVL(TotDisc,0))) ) AS PO_GROSS "
    '            sql &= ",SUM(CASE WHEN PODTL_PPN > 0 THEN (IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)"
    '            sql &= "	*((PODTL_QTYB*PODTL_ISI_SATB*PODTL_PRICE-((PODTL_QTYB*PODTL_ISI_SATB)"
    '            sql &= "	/((PODTL_QTYB*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
    '            sql &= "	*NVL(TotDisc,0)))*.1)) ELSE 0 END) AS PO_PPN "
    '            sql &= ",MIN(PO_UMUR) AS PO_UMUR "
    '            sql &= ",SUM(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*NVL(PODTL_PPN_BTL,0)) AS PPN_BOTOL "
    '            sql &= "FROM DC_PO_T PO "
    '            sql &= "LEFT JOIN DC_PODTL_T DT ON PO.PO_NO_PO = DT.PODTL_FK_NO_PO "
    '            sql &= "LEFT JOIN ("
    '            sql &= "	SELECT MBR_FK_PLUID,(MBR_TAG) AS MBR_TAG "
    '            sql &= "	FROM DC_BARANG_DC_V WHERE TBL_DC_KODE='" & cDC_KODE & "') BRG ON DT.PODTL_PLUMD=BRG.MBR_FK_PLUID "
    '            sql &= "LEFT JOIN ( "
    '            sql &= "	SELECT podisc_fk_no_po,PODISC_FK_PLU, "
    '            sql &= "	SUM(NVL(podisc_nilai,0)) AS TotDisc "
    '            sql &= "	FROM DC_PODISC_T "
    '            sql &= "	GROUP BY podisc_fk_no_po,PODISC_FK_PLU) S ON PO.PO_NO_PO=S.podisc_fk_no_po "
    '            sql &= "	AND DT.PODTL_PLUMD=S.PODISC_FK_PLU "
    '            sql &= "WHERE (PODTL_RECID IS NULL OR PODTL_RECID='') "
    '            sql &= "AND PO_NO_PO='" & txtNo_PO.Text & "' "
    '            sql &= "GROUP BY PO.PO_NO_PO, PO.PO_TGL_PO, PO.PO_SUPCO_MD "
    '            Scom.CommandText = sql

    '            sdar = Scom.ExecuteReader
    '            If sdar.Read = False Then
    '                Err_msg = "PO tidak ada. Atau Sudah BPB"
    '                GoTo Batal
    '            End If

    '            If sdar("SUPCO") <> lblSUPCO.Text And lblSUPCO.Text <> "" Then
    '                Err_msg = "Supplier tidak punya PO " & txtNo_PO.Text & "."
    '                GoTo Batal
    '            End If



    '            ''Cek Status PO
    '            If CType(sdar("PO_TGL_PO"), Date).AddDays(IIf(sdar("PO_UMUR") <= 0, 7, sdar("PO_UMUR"))) < Now.Date Then
    '                Err_msg = "PO Sudah Kadaluarsa."
    '                GoTo Batal
    '            End If

    '            Dim rc As String = sdar("RECIDx") & ""
    '            Select Case rc
    '                Case "C"
    '                    Err_msg = "PO Di-Closing"
    '                Case "B"
    '                    Err_msg = "PO Sudah ada BPB-nya"
    '                Case "H"
    '                    Err_msg = "PO Hangus"
    '                Case "A"
    '                    Err_msg = "PO Sedang dibuat BPB-nya"
    '                Case "1"
    '                    Err_msg = "Item PO dihapus"
    '                Case "2"
    '                    Err_msg = "PO Revisi"
    '            End Select
    '            If Err_msg <> "" Then GoTo Batal

    '            If IFNULL(sdar("PO_QTY"), 0) + IFNULL(sdar("PO_GROSS"), 0) + IFNULL(sdar("PO_PPN"), 0) = 0 Then
    '                Err_msg = "Qty, Gross & PPN Kosong."
    '                GoTo Batal
    '            End If

    '            'Cek Supp. MrBread
    '            'CEK TBL ALOKASI DAN CEK SJ
    '            Dim IsMBread As Boolean = IsMrBread(sdar("SUPCO") & "", cDC_KODE)
    '            If IsMBread Then
    '                Dim Scon2 As New OracleConnection(ConStrORA)
    '                Dim Scom2 As New OracleCommand("", Scon2)

    '                Try
    '                    Scon2.Open()
    '                    Scom2.CommandType = CommandType.StoredProcedure
    '                    Scom2.CommandText = "IMPORT_MBREAD('" & cDC_KODE & "')"
    '                    Scom2.ExecuteNonQuery()

    '                    Scom2.CommandType = CommandType.Text
    '                    Scom2.CommandText = "select CEK_MRBREAD ( '" & txtNoFak.Text & _
    '                        "', TO_DATE('" & Format(txtTglFaktur.Value, "yyyyMMdd") & "','YYYYMMDD'), '" & txtNo_PO.Text & "') as x from dual"
    '                    Err_msg = Scom2.ExecuteScalar & " "
    '                    If Err_msg.Substring(0, 1) = "1" Or Err_msg.Substring(0, 1) = "3" Then
    '                        '1;No. Faktur atau Tanggal Faktur Salah.
    '                        '3;Jumlah Item Faktur > Jumlah Item PO.

    '                        Err_msg = Err_msg.Substring(2)
    '                        GoTo Batal
    '                    Else
    '                        '2;Total Faktur Dan PO Tidak Sama.
    '                        If Err_msg.Substring(0, 1) = "2" Then
    '                            Err_msg = Err_msg.Substring(2)
    '                            MessageBox.Show(Err_msg, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
    '                        End If
    '                    End If
    '                    Err_msg = ""
    '                Catch ex As Exception
    '                    Throw ex
    '                Finally
    '                    Scon2.Close()
    '                End Try

    '            End If

    '            'isi TextBOX
    '            txtTgl_PO.Text = sdar("PO_TGL_PO")
    '            'txtSUPCO.Text = sdar("SUPCO")
    '            lblSUPID.Text = IFNULL(sdar("SUPID"), 0)
    '            'If lblSUPCO.Text = "" Then
    '            '    lblSUPCO.Text = sdar("SUPCO")
    '            'End If

    '            'Dim dr As Object
    '            'dr = Me.BindingContext(dsPo1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Current
    '            'dr.row("SUPID") = sdar("SUPID") & ""

    '            chkBUAT_PO.Checked = True ''''''''
    '            chkADA_HARGA.Checked = True ''''''

    '            txtTot_Item.Enabled = False
    '            txtPO_QTY.Enabled = False
    '            txtPO_GROSS.Enabled = False
    '            txtPO_PPN.Enabled = False

    '            If Not IsMBread Then
    '                txtPO_QTY.Text = Format(sdar("PO_QTY"), "#,##0")
    '                txtPO_GROSS.Text = Format(CDbl(sdar("PO_GROSS")), "#,##.##############")
    '                txtPO_PPN.Text = Format(CDbl(IFNULL(sdar("PO_PPN"), 0)), "#,##.##############")
    '                txtPO_Total.Text = Format(CDbl(sdar("PO_GROSS")) + CDbl(IFNULL(sdar("PO_PPN"), 0)) + CDbl(IFNULL(sdar("PPN_BOTOL"), 0)), "#,##.##############")
    '                txtTot_Item.Text = CDbl("0" & sdar("TOT_ITEM"))
    '            Else
    '                sdar.Close()

    '                sql = " SELECT "
    '                sql &= "MAX(PO_RECID) AS RECIDx,MIN(PO_GUDANG) AS PO_GUDANG,PO.PO_NO_PO, "
    '                sql &= "PO.PO_TGL_PO, PO.PO_SUPCO_MD AS SUPID, "
    '                'sql &= "GET_SUPCO(PO.PO_SUPCO_MD)AS SUPCO, "
    '                sql &= "COUNT(*) AS TOT_ITEM "
    '                sql &= ",SUM(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*NVL(BREAD.JUM,0)*PODTL_ISI_SATB) AS PO_QTY "
    '                sql &= ",SUM( IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*(NVL(BREAD.JUM,0)*PODTL_ISI_SATB*PODTL_PRICE- "
    '                sql &= "   ((NVL(BREAD.JUM,0)*PODTL_ISI_SATB)/((NVL(BREAD.JUM,0)*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
    '                sql &= "   *NVL(TotDisc,0))) ) AS PO_GROSS "
    '                sql &= ",SUM(CASE WHEN PODTL_PPN > 0 THEN "
    '                sql &= "	(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*((NVL(BREAD.JUM,0)*PODTL_ISI_SATB*PODTL_PRICE- "
    '                sql &= "	((NVL(BREAD.JUM,0)*PODTL_ISI_SATB)/((NVL(BREAD.JUM,0)*PODTL_ISI_SATB)+PODTL_FRAC_QTYB) "
    '                sql &= "	*NVL(TotDisc,0)))*.1)) ELSE 0 END) AS PO_PPN "
    '                sql &= ",MIN(PO_UMUR) AS PO_UMUR "
    '                sql &= ",SUM(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*NVL(PODTL_PPN_BTL,0)) AS PPN_BOTOL "
    '                sql &= "FROM DC_PO_T PO "
    '                sql &= "LEFT JOIN DC_PODTL_T DT ON PO.PO_NO_PO = DT.PODTL_FK_NO_PO "
    '                sql &= "LEFT JOIN ("
    '                sql &= "	SELECT MBR_FK_PLUID,(MBR_TAG) AS MBR_TAG "
    '                sql &= "	FROM DC_BARANG_DC_V "
    '                sql &= "	WHERE TBL_DC_KODE='" & cDC_KODE & "') BRG ON DT.PODTL_PLUMD=BRG.MBR_FK_PLUID "
    '                sql &= "LEFT JOIN ( "
    '                sql &= "	SELECT podisc_fk_no_po,PODISC_FK_PLU, "
    '                sql &= "	SUM(NVL(podisc_nilai,0)) AS TotDisc "
    '                sql &= "	FROM DC_PODISC_T "
    '                sql &= "	GROUP BY podisc_fk_no_po,PODISC_FK_PLU) S ON PO.PO_NO_PO=S.podisc_fk_no_po "
    '                sql &= "	AND DT.PODTL_PLUMD=S.PODISC_FK_PLU "
    '                sql &= "LEFT JOIN ( "
    '                sql &= "	 SELECT   a.pluid AS plumd, SUM (a.qty) AS Jum "
    '                sql &= "     FROM alokasi_tampung a "
    '                sql &= "	 WHERE (a.no_sj = '" & txtNoFak.Text & "') "
    '                sql &= "   	 GROUP BY a.no_sj, a.tgl_sj, a.pluid "
    '                sql &= "	 order by plumd) BREAD ON  DT.podtl_plumd=BREAD.PLUMD "
    '                sql &= "WHERE (PODTL_RECID IS NULL OR PODTL_RECID='') "
    '                sql &= "AND PO_NO_PO='" & txtNo_PO.Text & "' "
    '                sql &= "GROUP BY PO.PO_NO_PO, PO.PO_TGL_PO, PO.PO_SUPCO_MD "
    '                Scom.CommandText = sql
    '                sdar = Scom.ExecuteReader
    '                If sdar.Read Then
    '                    txtPO_QTY.Text = Format(sdar("PO_QTY"), "#,##0")
    '                    txtPO_GROSS.Text = Format(CDbl(sdar("PO_GROSS")), "#,##.##############")
    '                    txtPO_PPN.Text = Format(CDbl(IFNULL(sdar("PO_PPN"), 0)), "#,##.##############")
    '                    txtPO_Total.Text = Format(CDbl(sdar("PO_GROSS")) + CDbl(IFNULL(sdar("PO_PPN"), 0)) + CDbl(IFNULL(sdar("PPN_BOTOL"), 0)), "#,##.##############")
    '                    txtTot_Item.Text = CDbl("0" & sdar("TOT_ITEM"))
    '                Else
    '                    Err_msg = "Data Alokasi MBREAD Tidak ada."
    '                    GoTo Batal
    '                End If
    '            End If

    '            sdar.Close()
    '            sdar = Nothing

    '            'sql = "Select S.SUP_NAMA AS SNAMA from DC_SUPPLIER_DC_V H,DC_SUPPLIER_T S " & _
    '            '    "Where H.SUP_FK_SUPID=s.SUP_SUPID And " & _
    '            '    "TBL_DC_KODE='" & cDC_KODE & _
    '            '    "' AND H.SUP_SUPKODE='" & cmbSUPCO.Text & "'"
    '            'Scom.CommandText = sql

    '            'txtNamaSupp.Text = "" & Scom.ExecuteScalar
    '            'If lblSNAMA.Text = "" Then
    '            '    lblSNAMA.Text = txtNamaSupp.Text
    '            'End If

    '            'txtSUPCO.Enabled = False
    '            txtTgl_PO.Enabled = False
    '            chkADA_HARGA.Enabled = False

    '            btnSimpanPO.Focus()

    '            Exit Try
    'Batal:
    '            MessageBox.Show(Err_msg, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
    '            If NoPO <> "" Then
    '                txtNo_PO.Text = NoPO
    '            Else
    '                txtNo_PO.Text = ""
    '                NoPO = ""
    '                txtNo_PO.Focus()
    '            End If

    '            e.Cancel = True
    '        Catch ex As Exception
    '            ShowError("Error Baca PO", ex)
    '        End Try
    '    End Sub

    '    Private Sub HandleColomPO(ByVal sender As Object, ByVal e As System.Data.DataColumnChangeEventArgs)
    '        If e.Column.ColumnName = "NOPO" Then
    '            'TODO: CEK TBL ALOKASI DAN CEK SJ
    '            'TODO: Cek Item2 yang tidak maen di DC aktif (Jika ada Tolak PO)

    '            Dim Err_msg As String

    '            'Tanpa PO
    '            If txtNo_PO.Text = "" Then
    '                lWithPO = False

    '                txtTgl_PO.Enabled = True
    '                txtSUPCO.Enabled = True
    '                chkADA_HARGA.Enabled = True

    '                txtTgl_PO.Text = Now.Date

    '                'chkADA_HARGA.Value = 1
    '                'chkBUAT_PO.Value = 0
    '                chkADA_HARGA.Checked = True
    '                chkBUAT_PO.Checked = False

    '                txtPO_QTY.Text = Format(0, "#,##0")
    '                txtPO_GROSS.Text = Format(0, "#,##.##############")
    '                txtPO_PPN.Text = Format(0, "#,##.##############")
    '                txtPO_Total.Text = Format(0, "#,##.##############")
    '                txtTot_Item.Text = CInt("0")

    '                'DoEvents
    '                'txtTGL_PO.SetFocus
    '                'txtTGL_PO.SetFocus
    '                'SendKeys("{TAB}")

    '                Exit Sub
    '            End If
    '            lWithPO = True

    '            txtNo_PO.Text = txtNo_PO.Text.ToUpper
    '            If txtNo_PO.Text = NoPO Then
    '                Exit Sub
    '            End If

    '            If Len(txtNo_PO.Text) < 9 Then
    '                MsgBox("PO Tidak ada.", vbCritical)
    '                'txtNO_PO.Text = ""
    '                'e.Cancel = True
    '                e.ProposedValue = e.Row(e.Column)
    '                Exit Sub
    '            End If

    '            Dim sql As String
    '            Dim Scon As New OleDb.OleDbConnection(ConStrORA)
    '            Dim Scom As New OleDb.OleDbCommand("", Scon)
    '            Try
    '                Scon.Open()
    '                sql = "Select COUNT(*) From DC_JLR_DaftarPO_T Where NoPO='" & _
    '                    txtNo_PO.Text & "' AND NO_FAK='" & txtNoFak.Text & "' To_Char(Tanggal)=To_Char(sysdate)"
    '                Scom.CommandText = sql
    '                If Scom.ExecuteScalar > 0 Then
    '                    Err_msg = "PO sudah pernah didaftar."
    '                    GoTo Batal
    '                End If

    '                sql = "SELECT MAX(PO_RECID) AS RECIDx,PO.PO_NO_PO, PO.PO_TGL_PO, PO.PO_SUPCO_MD as SUPID, GET_SUPCO(PO.PO_SUPCO_MD)AS SUPCO,"
    '                sql &= "COUNT(*) AS TOT_ITEM, SUM(DT.PODTL_QTYB) AS PO_QTY, "
    '                sql &= "SUM(((FLOOR(((PODTL_QTYB*PODTL_ISI_SATB)+ PODTL_FRAC_QTYB)/PODTL_ISI_SATB))*PODTL_ISI_SATB*PODTL_PRICE)-PODTL_DISC) AS PO_GROSS, "
    '                sql &= "SUM(CASE WHEN PODTL_PPN > 0 THEN (((FLOOR(((PODTL_QTYB*PODTL_ISI_SATB)+ PODTL_FRAC_QTYB)/PODTL_ISI_SATB))*PODTL_ISI_SATB*PODTL_PRICE)-PODTL_DISC)*.1 ELSE 0 END) AS PO_PPN, "
    '                sql &= "MAX(PO_UMUR) as PO_UMUR "
    '                sql &= "FROM DC_PO_T PO, DC_PODTL_T DT "
    '                sql &= "Where PO.PO_NO_PO = DT.PODTL_FK_NO_PO AND PO_NO_PO='" & txtNo_PO.Text & "' AND PO_GUDANG='" & cDC_KODE & "' "
    '                sql &= "GROUP BY PO.PO_NO_PO, PO.PO_TGL_PO, PO.PO_SUPCO_MD "
    '                Scom.CommandText = sql

    '                Dim sdar As OleDb.OleDbDataReader
    '                sdar = Scom.ExecuteReader
    '                If sdar.Read = False Then
    '                    Err_msg = "PO tidak ada."
    '                    GoTo Batal
    '                End If

    '                Dim sSupco As String
    '                Try
    '                    If sSupco = "" And dsPo1.DC_JLR_DAFTARJALUR_T.Rows(Me.BindingContext("DC_JLR_DAFTARJALUR_T").Position - 1)("SUPCO") <> "" Then
    '                        sSupco = dsPo1.DC_JLR_DAFTARJALUR_T.Rows(Me.BindingContext("DC_JLR_DAFTARJALUR_T").Position - 1)("SUPCO")
    '                    End If
    '                Catch

    '                End Try


    '                If sdar("SUPCO") <> sSupco And sSupco <> "" Then
    '                    Err_msg = "PO Harus dari Supplier yang Sama."
    '                    GoTo Batal
    '                End If
    '                Try
    '                    If sSupco = "" Then
    '                        dsPo1.DC_JLR_DAFTARJALUR_T.Rows(Me.BindingContext("DC_JLR_DAFTARJALUR_T").Position - 1)("SUPCO") = sdar("SUPCO")
    '                        sSupco = sdar("SUPCO")
    '                    End If
    '                Catch

    '                End Try

    '                ''Cek Status PO
    '                If CType(sdar("PO_TGL_PO"), Date).AddDays(IIf(sdar("PO_UMUR") <= 0, 7, sdar("PO_UMUR"))) < Now.Date Then
    '                    Err_msg = "PO Sudah Kadaluarsa."
    '                    GoTo Batal
    '                End If

    '                Select Case sdar("RECIDx") & ""
    '                    Case "C"
    '                        Err_msg = "PO Di-Closing"
    '                    Case "R"
    '                        Err_msg = "PO Sudah ada BPB-nya"
    '                    Case "H"
    '                        Err_msg = "PO Hangus"
    '                    Case "A"
    '                        Err_msg = "PO Sedang dibuat BPB-nya"
    '                    Case "1"
    '                        Err_msg = "Item PO dihapus"
    '                    Case "2"
    '                        Err_msg = "PO Revisi"
    '                End Select
    '                If Err_msg <> "" Then GoTo Batal

    '                If IFNULL(sdar("PO_QTY"), 0) + IFNULL(sdar("PO_GROSS"), 0) + IFNULL(sdar("PO_PPN"), 0) = 0 Then
    '                    Err_msg = "Qty, Gross & PPN Kosong."
    '                    GoTo Batal
    '                End If

    '                'isi TextBOX
    '                txtTgl_PO.Text = sdar("PO_TGL_PO")
    '                txtSUPCO.Text = sdar("SUPCO")
    '                lblSUPID.Text = IFNULL(sdar("SUPID"), 0)
    '                If lblSUPCO.Text = "" Then
    '                    lblSUPCO.Text = sdar("SUPCO")
    '                End If
    '                chkBUAT_PO.Checked = True ''''''''
    '                chkADA_HARGA.Checked = True ''''''
    '                txtPO_QTY.Text = Format(sdar("PO_QTY"), "#,##0")
    '                txtPO_GROSS.Text = Format(CDbl(sdar("PO_GROSS")), "#,##.##############")
    '                txtPO_PPN.Text = Format(CDbl(sdar("PO_PPN")), "#,##.##############")
    '                txtPO_Total.Text = Format(CDbl(sdar("PO_GROSS")) + CDbl(sdar("PO_PPN")), "#,##.##############")
    '                txtTot_Item.Text = CDbl("0" & sdar("TOT_ITEM"))


    '                sdar.Close()
    '                sdar = Nothing

    '                sql = "Select S.SUP_NAMA AS SNAMA from DC_SUPPLIER_DC_V H,DC_SUPPLIER_T S " & _
    '                    "Where H.SUP_FK_SUPID=s.SUP_SUPID And " & _
    '                    "TBL_DC_KODE='" & cDC_KODE & _
    '                    "' AND H.SUP_SUPKODE='" & txtSUPCO.Text & "'"
    '                Scom.CommandText = sql

    '                txtNamaSupp.Text = "" & Scom.ExecuteScalar
    '                If lblSNAMA.Text = "" Then
    '                    lblSNAMA.Text = txtNamaSupp.Text
    '                End If

    '                txtSUPCO.Enabled = False
    '                txtTgl_PO.Enabled = False
    '                chkADA_HARGA.Enabled = False

    '                Exit Try
    'Batal:
    '                MessageBox.Show(Err_msg, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
    '                txtNo_PO.Text = ""
    '                NoPO = ""
    '                txtNo_PO.Focus()
    '                e.ProposedValue = e.Row(e.Column)
    '            Catch ex As Exception
    '                ShowError("Error Baca PO", ex)
    '            End Try

    '            'If MessageBox.Show("Haloo", "aaa", MessageBoxButtons.YesNo) <> DialogResult.Yes Then
    '            '    e.ProposedValue = e.Row(e.Column)
    '            'End If
    '        End If
    '    End Sub
    '    Private Sub HandleRowPo(ByVal sender As Object, ByVal e As System.Data.DataRowChangeEventArgs)
    '        If e.Action = DataRowAction.Add Then
    '            If e.Row("SUPCO") = "" Then
    '                'MessageBox.Show("AAAAAAAAAAAAAAAAAAAAA")
    '                Debug.WriteLine("SUPCO Blank")
    '            End If
    '        End If
    '    End Sub
#End Region

    'Private Sub txtSUPCO_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs)
    '    'If txtSUPCO.Text = "" Then 'And Not lWithPO
    '    '    MessageBox.Show("KODE SUPPLIER HARUS DIISI", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
    '    '    e.Cancel = True
    '    '    Exit Sub
    '    'End If

    '    'If txtSUPCO.Text <> lblSUPCO.Text And lblSUPCO.Text <> "" Then
    '    '    MessageBox.Show("Pedaftaran Harus Dari Supplier yang Sama.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
    '    '    e.Cancel = True
    '    '    Exit Sub
    '    'End If

    '    If Len(txtSUPCO.Text) < 4 Then
    '        MessageBox.Show("Supplier " & txtSUPCO.Text & " tidak ada !!!", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
    '        e.Cancel = True
    '        Exit Sub
    '    End If

    '    ' '' ''        Dim sql As String
    '    ' '' ''        Dim Scon As New OracleConnection(ConStrORA)
    '    ' '' ''        Dim Scom As New OracleCommand("", Scon)
    '    ' '' ''        Dim Sdar As OleDbDataReader
    '    ' '' ''        Try
    '    ' '' ''            Scon.Open()
    '    ' '' ''            'Todo: Buat PO tidak ada Kolom
    '    ' '' ''            sql = "Select S.SUP_NAMA AS SNAMA,H.SUP_SUPKODE AS SUPCO,H.SUP_FLAG_BUATPO AS BUAT_PO,s.SUP_SUPID AS SUPID from DC_SUPPLIER_DC_V H,DC_SUPPLIER_T S "
    '    ' '' ''            sql &= "Where H.SUP_FK_SUPID=s.SUP_SUPID And "
    '    ' '' ''            sql &= "TBL_DC_KODE='" & cDC_KODE
    '    ' '' ''            sql &= "' AND H.SUP_SUPKODE='" & txtSUPCO.Text & "'"
    '    ' '' ''            Scom.CommandText = sql
    '    ' '' ''            Sdar = Scom.ExecuteReader
    '    ' '' ''            If Sdar.Read Then
    '    ' '' ''                'Cek With PO
    '    ' '' ''                If Not lWithPO Then
    '    ' '' ''                    If "" & Sdar("BUAT_PO") = "Y" Then
    '    ' '' ''                        MsgBox("Supplier " & txtSUPCO.Text & " Harus Pakai PO !!!", vbCritical)
    '    ' '' ''                        txtSUPCO.Text = ""
    '    ' '' ''                        txtNamaSupp.Text = ""
    '    ' '' ''                        e.Cancel = True
    '    ' '' ''                        GoTo ex
    '    ' '' ''                    Else
    '    ' '' ''                        txtPO_QTY.Focus()
    '    ' '' ''                    End If
    '    ' '' ''                End If
    '    ' '' ''                txtNamaSupp.Text = Sdar("SNAMA") & ""

    '    ' '' ''                lblSUPID.Text = IFNULL(Sdar("SUPID"), 0)

    '    ' '' ''                If lblSUPCO.Text = "" Then
    '    ' '' ''                    lblSUPCO.Text = Sdar("SUPCO")
    '    ' '' ''                End If
    '    ' '' ''                If lblSNAMA.Text = "" Then
    '    ' '' ''                    lblSNAMA.Text = txtNamaSupp.Text
    '    ' '' ''                End If
    '    ' '' ''            Else
    '    ' '' ''                MsgBox("Supplier " & txtSUPCO.Text & " tidak ada !!!", vbCritical)
    '    ' '' ''                e.Cancel = True
    '    ' '' ''            End If
    '    ' '' ''ex:         Sdar.Close()
    '    ' '' ''        Catch ex As Exception
    '    ' '' ''            ShowError("Error Baca Supplier", ex)
    '    ' '' ''        Finally
    '    ' '' ''            Scon.Close()
    '    ' '' ''            Scon = Nothing
    '    ' '' ''        End Try
    'End Sub
    'Private Sub txtNoMobil_Validate(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs)

    '    Dim Scon As New OracleConnection(ConStrORA)
    '    Dim Scom As New OracleCommand("", Scon)

    '    Scon.Open()
    '    Scom.CommandText = "Select COUNT(*) From DC_JLR_DaftarJalur_T Where NoMobil='" & _
    '        txtNoMobil.Text & "' AND TO_CHAR(Tanggal,'dd/mon/yyyy')=TO_CHAR(sysdate,'dd/mon/yyyy') AND DC_ID=" & cDC_ID
    '    If Scom.ExecuteScalar > 0 Then
    '        e.Cancel = True
    '        MsgBox("No Mobil sudah didaftarkan.", vbCritical)
    '    End If
    '    Scon.Close()
    'End Sub

    Private Sub btnPrev2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrev2.Click
        Try
            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Position -= 1
            'btn_Prev(lblSUPCO.Text)
            If lblBPB_NO.Text <> "" Then
                btnPrint.Enabled = False
                btnPrintUlang.Enabled = False
                btnHapusPO.Enabled = False
                btnEditPO.Enabled = False
            Else
                btnHapusPO.Enabled = True
                btnEditPO.Enabled = True
                txtNoAntrian.Text = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.NOURUT").Current
            End If
            LoadNoAntrian()
        Catch 'ex As Exception
            'Throw ex
        End Try
    End Sub
    Private Sub btnNext2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext2.Click

        Try
            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Position += 1
            'btn_Next(lblSUPCO.Text)
            If lblBPB_NO.Text <> "" Then
                btnPrint.Enabled = False
                btnPrintUlang.Enabled = False
                btnHapusPO.Enabled = False
                btnEditPO.Enabled = False
            Else
                btnHapusPO.Enabled = True
                btnEditPO.Enabled = True
                txtNoAntrian.Text = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.NOURUT").Current
            End If
            LoadNoAntrian()
        Catch 'ex As Exception
            'Throw ex
        End Try
    End Sub

    Private Function GetIdDaftarJalur() As Integer
        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Dim n As Integer


        Scon.Open()
        Scom.CommandText = "select DC_JLR_DaftarJalur_T_SEQ.nextval from dual"
        n = Scom.ExecuteScalar()
        Scon.Close()

        Return n
    End Function
    Private Function GetIdDaftarPO() As Integer
        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Dim n As Integer

        Scon.Open()
        Scom.CommandText = "select DC_JLR_DaftarPO_T_SEQ.nextval from dual"
        n = Scom.ExecuteScalar()
        Scon.Close()

        Return n
    End Function
    Private Function KasihNoAntrian() As Boolean

        Dim drMobil As Object
        drMobil = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Current


        Dim nNoUrut As Integer = NextAntrian()

        '        'ISI Booking Jalur
        '        Dim Scon As New OracleConnection(ConStrORA)
        '        Dim Scom As New OracleCommand("Select A.Jalur,S.Jam1,S.Jam2,S.ID_Antrian From DC_JLR_SUPP1ST_V S Left Join DC_JLR_Antrian_T A ON S.ID_Antrian=A.ID_Antrian " & _
        '            "Where S.SUPCO='" & txtSUPCO.Text & "' AND A.DC_ID=" & cDC_ID & _
        '            "", Scon)
        '        Dim Sdar As OleDbDataReader
        '        Dim Sdar2 As OleDbDataReader

        '        If Sdar.Read Then
        '            'Cek Supp BESAR langsung masuk (Jam Supp)
        '            If Not IsNothing(Sdar("jam1")) Then
        '                dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("Jalur") = Sdar("Jalur")

        '                'cek Boking Kosong
        '                Scom.CommandText = "Select Count(*) as Jum From DC_JLR_Antrian_T " & _
        '                    "Where Jalur='" & dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("Jalur") & _
        '                    "' AND  (Supplier ='' Or Supplier IS NULL) AND DC_ID=" & cDC_ID
        '                If Scom.ExecuteScalar > 0 Then
        '                    'cek Jam Booking
        '                    If Now.ToShortTimeString >= Sdar("jam1") And Now.ToShortTimeString <= Sdar("JAM2") Then
        'MasukinSupp:            'Masukkan Supplier
        '                        dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("Recid") = 2
        '                        dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("TglStart") = Now()
        '                        Scom.CommandText = _
        '                            "UPDATE DC_JLR_Antrian_T SET Supplier='" & txtSUPCO.Text & _
        '                            "', NoAntrian=" & nNoUrut & " Where Jalur='" & dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("Jalur") & "' AND DC_ID=" & cDC_ID
        '                        Scom.ExecuteNonQuery()

        '                        Scom.CommandText = "INSERT INTO DC_JLR_TempAntrian_T ( Jalur, SUPCO, SNAMA, NoMobil, NoAntrian,DC_ID) " & _
        '                                                    "VALUES('" & dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("Jalur") & "','" & txtSUPCO.Text & "','" & _
        '                                                    txtNamaSupp.Text & "','" & txtNoMobil.Text & "'," & nNoUrut & "," & cDC_ID & ")"
        '                        Scom.ExecuteNonQuery()
        '                    Else
        '                        'Todo:Cek Jam Bebas
        '                        Scom.CommandText = "Select Count(*) as Jum from DC_JLR_Supp1st_V where ID_ANTRIAN=" & Sdar("ID_Antrian") & _
        '                            " AND TO_CHAR(SYSDATE,'hh24:mi:ss') between TO_CHAR(jam1,'hh24:mi:ss') and " & _
        '                            "TO_CHAR(jam1+0.5/24,'hh:mi:ss')"
        '                        If Scom.ExecuteScalar = 0 Then
        '                            GoTo MasukinSupp
        '                        End If
        '                    End If
        '                End If
        '            Else
        '                'Supplier Kecil langsung Masuk Pada Jam Jalur -nya

        '                'Cek Jalurnya Masih Aktif
        '                Scom.CommandText = "Select Supplier,NoAntrian From DC_JLR_Antrian_T " & _
        '                    "Where Jalur='" & Sdar("Jalur") & _
        '                    "' AND TO_CHAR(SYSDATE,'hh24:mi:ss') BETWEEN TO_CHAR(jam1,'hh24:mi:ss') and TO_CHAR(jam2,'hh24:mi:ss') AND DC_ID=" & cDC_ID
        '                Sdar = Scom.ExecuteReader

        '                If Sdar.Read Then
        '                    dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("Jalur") = Sdar("Jalur")
        '                    If "" & Sdar("Supplier") = "" Then
        '                        GoTo MasukinSupp
        '                    End If
        '                End If
        '            End If
        '        End If
        '        Sdar.Close()

        drMobil.ROW("NOURUT") = nNoUrut
        'drMobil.ROW("SUPCO") = txtSUPCO.Text
        drMobil.ROW("SUPCO") = txtKodeSupp_.Text
        Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").EndCurrentEdit()
    End Function
    Private Function NextAntrian() As Integer
        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Dim n As Integer

        Scon.Open()
        Scom.CommandText = "Select COUNT(*) From DC_JLR_Setting_T WHERE DC_ID=" & cDC_ID
        If Scom.ExecuteScalar = 0 Then
            Scom.CommandText = "INSERT INTO VALUES(" & cDC_ID & ",2,TRUNC(SYSDATE())"
            Scom.ExecuteNonQuery()
            Return 1
        End If

        Scom.CommandText = "Select NextNoUrut From DC_JLR_Setting_T WHERE DC_ID=" & cDC_ID
        n = "0" & Scom.ExecuteScalar()
        If n = 0 Then
            n = 1
        End If

        Scom.CommandText = "UPDATE DC_JLR_Setting_T  SET NextNoUrut=" & n & "+1 WHERE DC_ID=" & cDC_ID
        Scom.ExecuteNonQuery()

        Scon.Close()

        Return n

    End Function

    Private Sub btnHapusPO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHapusPO.Click
        Dim HAPUSSLP As Boolean = False


        'tambahkan hapus dc_trnbpb_dtlbatch_t.

        If txtNo_PO.Text = "" Or txtNoFak.Text = "" Then
            MessageBox.Show("Tidak Bisa Hapus Pendaftaran Tanpa PO.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        Dim X As Integer
        Dim dr As Object
        '  Dim sisasatu As String
        If txtNoAntrian.Text = "" Then
            txtNoAntrian.Text = NoAntrian
        End If
        X = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Position
        dr = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Current
        'If LBMobil.SelectedIndex = -1 And LBMobil.Items.Count <> 0 Then
        '    LBMobil.SelectedIndex = 0
        'End If
        '        Dim dt_DAFTARJALUR As DataTable = getDS("    SELECT id_daftarjalur" & _
        '"   FROM dc_jlr_daftarjalur_t" & _
        '"  WHERE nomobil = '" & LBMobil.Text & "' AND nourut = '" & txtNoAntrian.Text & "' AND supco = '" & lblSUPCO.Text & "'", ConStrORA).Tables(0)

        Dim dt_DAFTARPO As DataTable = getDS(" SELECT id_daftarjalur, id_daftarpo, nopo, recid" &
                                                "   FROM dc_jlr_daftarpo_t" &
                                                "  WHERE supco = '" & txtKodeSupp_.Text & "'" &
                                                "    AND no_fak ='" & txtNoFak.Text & "'" &
                                                "    AND nopo = '" & txtNo_PO.Text & "'", ConStrORA).Tables(0)

        If dt_DAFTARPO.Rows.Count <= 0 Then
            MsgBox("Tidak Ada Data yang dihapus !", vbCritical)
            Exit Sub
        End If
        Dim id_po As String = dt_DAFTARPO.Rows(0)("ID_DAFTARPO").ToString
        Dim id_jlr As String = dt_DAFTARPO.Rows(0)("id_daftarjalur").ToString
        Dim nopo As String = IIf(IsDBNull(dt_DAFTARPO.Rows(0)("NOPO").ToString), "", dt_DAFTARPO.Rows(0)("nopo").ToString)
        Dim CEKSLP As String = execScalar("SELECT COUNT(*) From DC_PLANOGRAM_SLP_T Where slp_type_trans ='SLP SUPPLIER' And slp_fk_iddaftarpo= " & id_po, ConStrORA)
        Dim CEKPRESLP As String = execScalar("SELECT COUNT(*) From DC_PLANOGRAM_PRESLP_T Where    iddaftarpo= " & id_po & " and nopo = '" & txtNo_PO.Text & "'", ConStrORA)

        'frac_slp.dc_trnbpb_dtl_t
        If (CEKSLP > 0) Or (CEKPRESLP > 0) Then
            If FormPassHapusPO.ShowDialog = Windows.Forms.DialogResult.OK Then
                HAPUSSLP = True
            Else
                Exit Sub
            End If

        End If
        'Dim dt_Pointer As DataTable = getDS(" SELECT count(*)" &
        '                                    "   FROM dc_jlr_daftarpo_t" &
        '                                    "  WHERE supco = '" & lblSUPCO.Text & "'" &
        '                                    "    AND id_daftarjalur = '" & id_jlr & "'", ConStrORA).Tables(0)


        Dim CountPointer As String = vb.execScalar(ConStrORA, " SELECT count(*)" &
                                            "   FROM dc_jlr_daftarpo_t" &
                                            "  WHERE supco = '" & txtKodeSupp_.Text & "'" &
                                            "    AND id_daftarjalur = '" & id_jlr & "'")
        If CountPointer = 0 Then
            MsgBox("Tidak Ada Data yang dihapus !", vbCritical)
            Exit Sub
        End If

        If "" & dt_DAFTARPO.Rows(0)("RECID").ToString = "B" Then
            MsgBox("Tidak Bisa Hapus, Faktur sudah ada BPB-nya !", vbCritical)
            Exit Sub
        End If

        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Dim n As String = ""
        'Dim id_jlr As String = dr.row("ID_DAFTARJALUR")
        'Dim id_po As String = dr.row("ID_DAFTARPO")
        'Dim nopo As String = IIf(IsDBNull(dr.row("NOPO")), "", dr.row("NOPO"))

        If id_po <> "" And txtNoFak.Text <> "" Then
            Scon.Open()
            Scom.CommandText = "Select distinct ID_FK,NOPO From DC_HH_SCAN_T WHERE nopo ='" & nopo & "' and id_fk='" & id_jlr & "' and DC_ID=" & cDC_ID
            n = IIf(IsDBNull(Scom.ExecuteScalar), "", Scom.ExecuteScalar)
            Dim PO As String = ""
            If n <> "" Then
                Dim dread As OracleDataReader
                dread = Scom.ExecuteReader
                dread.Read()
                PO = "" + dread.Item("NOPO").ToString
                dread.Close()
            End If
            'If nopo = PO Then
            '    MsgBox("Tidak Bisa Hapus Pendaftaran, PO Sudah Di Periksa !", vbCritical)

            'End If


            'cek sudah ada yang di SLP blom?
            'Dim query As String = "SELECT COUNT(*) FROM dc_trnbpb_dtl_t a, dc_trnbpb_hdr_t b " &
            '"WHERE(a.NO_PO = b.NO_PO And a.hdr_fk_id = b.HDR_ID) " &
            '"AND a.frac_slp IS NOT NULL AND b.no_po='" & nopo & "' AND b.NO_FAKTUR='" & txtNoFak.Text & "' " &
            '"GROUP BY b.no_po, b.no_faktur"
            'If vb.execScalar(ConStrORA, query) > 0 And nopo = PO Then
            '    MsgBox("di faktur dan PO ini sudah ada PLU yang diSLP.. Data tidak dapat dihapus!!!")
            'Else
            Dim msg As String = ""
                If nopo = PO Then
                    msg = "PO sedang dipegang Handheld.. Yakin hapus faktur :" & txtNoFak.Text &
                                   " dengan No. PO : " & nopo & " dari pendaftaran?"
                Else
                    msg = "Yakin hapus faktur :" & txtNoFak.Text &
                                   " dengan No. PO : " & nopo & " dari pendaftaran?"
                End If
            If MessageBox.Show(msg, "Konfirmasi", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Dim lHapusMobil As Boolean
                lHapusMobil = False
                If CountPointer = 1 Then
                    If MsgBox("PO HANYA 1. Hapus PO Akan Menghapus Pendaftaran ini. LANJUTKAN?", vbExclamation Or vbYesNo Or vbDefaultButton2) = vbNo Then
                        ' btnDaftar_Click(sender, e)
                        Exit Sub
                    End If
                    lHapusMobil = True
                    'btnDaftar_Click(sender, e)

                End If
                Debug.WriteLine("Hapus PO ")
                'Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").RemoveAt(X)


                Scom.CommandText = "delete from dc_jlr_daftarpo_t where " &
                                       "id_daftarpo=" & id_po
                Scom.ExecuteNonQuery()
                Scon.Close()

                If lHapusMobil Then
                    Debug.WriteLine("Hapus Mobil ")
                    'X = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position
                    'Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").RemoveAt(X)
                    'If Scon.State = ConnectionState.Open Then
                    '    Scon.Close()
                    'End If
                    Scon.Open()
                    Scom.CommandText = "delete from dc_jlr_daftarjalur_t where " &
                                           "id_daftarjalur=" & id_jlr
                    Scom.ExecuteNonQuery()
                    Scon.Close()
                End If

                Try
                    ' unfixed20112022
                    Dim ch As dsPO
                    ch = DsPO1.GetChanges
                    If (Not (ch) Is Nothing) Then
                        Me.olcon.Open()
                        Debug.WriteLine("Delete Daftar Langsung: " & oldapPO.Update(ch))
                        Debug.WriteLine("Delete Mobil Langsung: " & oldapMobil.Update(ch))
                        'Dim Olcom As New OracleCommand("", olcon)
                        'Olcom.CommandText = "Delete From DC_JLR_DaftarPO_T where "
                        'Olcom.ExecuteNonQuery()
                    End If
                    DsPO1.DC_JLR_DAFTARJALUR_T.AcceptChanges()
                    DsPO1.DC_JLR_DAFTARPO_T.AcceptChanges()
                    Dim dt_getHDRID As DataTable = getDS("select hdr_id  from dc_trnbpb_hdr_t where id_daftarpo = '" & id_po & "'", ConStrORA).Tables(0)
                    Dim HDRIDHAPUS As String = ""
                    If dt_getHDRID.Rows.Count > 0 Then
                        HDRIDHAPUS = dt_getHDRID.Rows(0)(0).ToString

                        Scon.Open()

                        'tambahan hapus dc_trnbpb_dtlbatch_t untuk obat prekursor
                        Scom.CommandText = "DELETE FROM dc_trnbpb_dtlbatch_t WHERE no_po = '" & nopo & "'"
                        Scom.ExecuteNonQuery()


                        Scom.CommandText = "DELETE FROM dc_trnbpb_dtl_t WHERE hdr_fk_id = '" & HDRIDHAPUS & "'"
                        Scom.ExecuteNonQuery()

                        Scom.CommandText = "DELETE FROM dc_trnbpb_hdr_t WHERE id_daftarpo = '" & id_po & "'"
                        Scom.ExecuteNonQuery()

                        Scom.CommandText = "DELETE FROM dc_trnbpb_dtl_h WHERE hdr_fk_id = '" & HDRIDHAPUS & "'"
                        Scom.ExecuteNonQuery()

                        Scom.CommandText = "DELETE FROM dc_trnbpb_hdr_h WHERE id_daftarpo = '" & id_po & "'"
                        Scom.ExecuteNonQuery()

                        'hapus obat

                        Scom.CommandText = "DELETE FROM dc_spobat_dtl_t WHERE hdr_fk_id =(SELECT hdr_id FROM DC_SPOBAT_HDR_T  WHERE no_po = '" & nopo & "' AND ROWNUM = 1)"
                        Scom.ExecuteNonQuery()

                        Scom.CommandText = "DELETE FROM dc_spobat_hdr_t WHERE no_po = '" & nopo & "'"
                        Scom.ExecuteNonQuery()

                        'Scom.CommandText = "DELETE FROM dc_spobat_dtl_h WHERE hdr_fk_id =(SELECT hdr_id FROM DC_SPOBAT_HDR_T  WHERE no_po = '" & txtNo_PO.Text & "' AND ROWNUM = 1)"
                        'Scom.ExecuteNonQuery()

                        'Scom.CommandText = "DELETE FROM dc_spobat_hdr_h WHERE no_po = '" & txtNo_PO.Text & "'"
                        'Scom.ExecuteNonQuery()


                        Scon.Close()

                        ''tambahan hapus dc_trnbpb_dtlbatch_t untuk obat prekursor
                        'Scom.CommandText = "DELETE FROM dc_trnbpb_dtlbatch_t WHERE no_po = '" & txtNo_PO.Text & "'"
                        'Scom.ExecuteNonQuery()
                        'Scon.Close()

                        'SELECT hdr_id  FROM dc_trnbpb_hdr_t WHERE id_daftarpo = 1297809

                        'SELECT * FROM dc_trnbpb_dtl_t WHERE hdr_fk_id = 85
                    End If

                    Dim loadnourut As String = frmLoadPO.NOURUT
                    For i As Integer = 0 To DsPO1.DC_JLR_DAFTARJALUR_T.Rows.Count - 1
                        If DsPO1.DC_JLR_DAFTARJALUR_T.Rows(i)("NOURUT").ToString = loadnourut Then
                            Exit For
                        Else
                            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position += 1
                        End If
                    Next
                    '  mobil()

                    'HAPUS SLP
                    If HAPUSSLP = True Then
                        'hapus dc_planogram_preslp_t
                        execQuery(" delete From dc_planogram_preslp_t Where iddaftarpo= " & id_po & " and nopo = '" & nopo & "'", ConStrORA)
                        execQuery(" delete From DC_PLANOGRAM_SLP_T Where slp_type_trans ='SLP SUPPLIER' And slp_fk_iddaftarpo= " & id_po, ConStrORA)
                        execQuery(" delete From DC_PLANOGRAM_SLPCEK2_T Where  slp_fk_iddaftarpo= " & id_po, ConStrORA)
                    End If


                Catch updateException As System.Exception
                    'Add your error handling code here.
                    Throw updateException
                Finally
                    'Close the connection whether or not the exception was thrown.
                    Me.olcon.Close()
                End Try
                If lHapusMobil Then
                    Me.Close()
                Else
                    btn_Next(txtKodeSupp_.Text)
                End If
            End If
            'End If
            Scon.Close()
            LoadDataSet()

        End If
    End Sub
    'Private Sub btnHapusPO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHapusPO.Click
    '    Dim X As Integer
    '    Dim dr As Object
    '    X = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Position
    '    dr = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Current


    '    Dim dt_Pointer As DataTable = getDS("select no_faktur, hdr_id from dc_trnbpb_hdr_t where supco = '" & lblSUPCO.Text & "' ", ConStrORA).Tables(0)
    '    If dt_Pointer.Rows.Count <= 0 Then
    '        MsgBox("Tidak Ada Data yang dihapus !", vbCritical)
    '        Exit Sub
    '    End If

    '    If "" & dr.row("Recid") = "B" Then
    '        MsgBox("Tidak Bisa Hapus, Faktur sudah ada BPB-nya !", vbCritical)
    '        Exit Sub
    '    End If

    '    Dim Scon As New OracleConnection(ConStrORA)
    '    Dim Scom As New OracleCommand("", Scon)
    '    Dim n As String = ""
    '    Dim id_jlr As String = dr.row("ID_DAFTARJALUR")
    '    Dim id_po As String = dr.row("ID_DAFTARPO")
    '    Dim nopo As String = IIf(IsDBNull(dr.row("NOPO")), "", dr.row("NOPO"))

    '    If id_po <> "" And txtNoFak.Text <> "" Then
    '        Scon.Open()
    '        Scom.CommandText = "Select distinct ID_FK,NOPO From DC_HH_SCAN_T WHERE nopo ='" & nopo & "' and id_fk='" & dr.row("ID_DAFTARJALUR") & "' and DC_ID=" & cDC_ID
    '        n = IIf(IsDBNull(Scom.ExecuteScalar), "", Scom.ExecuteScalar)
    '        Dim PO As String = ""
    '        If n <> "" Then
    '            Dim dread As OleDbDataReader
    '            dread = Scom.ExecuteReader
    '            dread.Read()
    '            PO = "" + dread.Item("NOPO").ToString
    '            dread.Close()
    '        End If
    '        'If nopo = PO Then
    '        '    MsgBox("Tidak Bisa Hapus Pendaftaran, PO Sudah Di Periksa !", vbCritical)

    '        'End If
    '        'cek sudah ada yang di SLP blom?
    '        Dim query As String = "SELECT COUNT(*) FROM dc_trnbpb_dtl_t a, dc_trnbpb_hdr_t b " & _
    '        "WHERE(a.NO_PO = b.NO_PO And a.hdr_fk_id = b.HDR_ID) " & _
    '        "AND a.frac_slp IS NOT NULL AND b.no_po='" & nopo & "' AND b.NO_FAKTUR='" & txtNoFak.Text & "' " & _
    '        "GROUP BY b.no_po, b.no_faktur"
    '        If vb.execScalar(ConStrORA, query) > 0 And nopo = PO Then
    '            MsgBox("di faktur dan PO ini sudah ada PLU yang diSLP.. Data tidak dapat dihapus!!!")
    '        Else
    '            Dim msg As String = ""
    '            If nopo = PO Then
    '                msg = "PO sedang dipegang Handheld.. Yakin hapus faktur :" & txtNoFak.Text & _
    '                               " dengan No. PO : " & nopo & " dari pendaftaran?"
    '            Else
    '                msg = "Yakin hapus faktur :" & txtNoFak.Text & _
    '                               " dengan No. PO : " & nopo & " dari pendaftaran?"
    '            End If
    '            If MessageBox.Show(msg, "Konfirmasi", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
    '                Dim lHapusMobil As Boolean
    '                lHapusMobil = False
    '                If Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Count = 1 Then
    '                    If MsgBox("PO HANYA 1. Hapus PO Akan Menghapus Pendaftaran ini. LANJUTKAN?", vbExclamation Or vbYesNo Or vbDefaultButton2) = vbNo Then
    '                        Exit Sub
    '                    End If
    '                    lHapusMobil = True
    '                End If
    '                Debug.WriteLine("Hapus PO " & X)
    '                Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").RemoveAt(X)


    '                Scom.CommandText = "delete from dc_jlr_daftarpo_t where " & _
    '                                   "id_daftarpo=" & id_po
    '                Scom.ExecuteNonQuery()
    '                Scon.Close()

    '                If lHapusMobil Then
    '                    Debug.WriteLine("Hapus Mobil " & X)
    '                    X = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position
    '                    Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").RemoveAt(X)
    '                    If Scon.State = ConnectionState.Open Then
    '                        Scon.Close()
    '                    End If
    '                    Scon.Open()
    '                    Scom.CommandText = "delete from dc_jlr_daftarjalur_t where " & _
    '                                       "id_daftarjalur=" & id_jlr
    '                    Scom.ExecuteNonQuery()
    '                    Scon.Close()
    '                End If

    '                Try
    '                    Dim ch As dsPO
    '                    ch = DsPO1.GetChanges
    '                    If (Not (ch) Is Nothing) Then
    '                        Me.olcon.Open()
    '                        Debug.WriteLine("Delete Daftar Langsung: " & oldapPO.Update(ch))
    '                        Debug.WriteLine("Delete Mobil Langsung: " & oldapMobil.Update(ch))
    '                        'Dim Olcom As New OracleCommand("", olcon)
    '                        'Olcom.CommandText = "Delete From DC_JLR_DaftarPO_T where "
    '                        'Olcom.ExecuteNonQuery()
    '                    End If
    '                    DsPO1.DC_JLR_DAFTARJALUR_T.AcceptChanges()
    '                    DsPO1.DC_JLR_DAFTARPO_T.AcceptChanges()
    '                Catch updateException As System.Exception
    '                    'Add your error handling code here.
    '                    Throw updateException
    '                Finally
    '                    'Close the connection whether or not the exception was thrown.
    '                    Me.olcon.Close()
    '                End Try
    '            End If
    '        End If
    '        'End If
    '        Scon.Close()
    '    End If
    '    'If nopo <> "" Then
    '    '    Scon.Open()
    '    '    Scom.CommandText = "Select distinct ID_FK,NOPO From DC_HH_SCAN_T WHERE nopo ='" & nopo & "' and id_fk='" & dr.row("ID_DAFTARJALUR") & "' and DC_ID=" & cDC_ID
    '    '    n = IIf(IsDBNull(Scom.ExecuteScalar), "", Scom.ExecuteScalar)

    '    '    If n <> "" Then
    '    '        Dim dread As OleDbDataReader
    '    '        dread = Scom.ExecuteReader
    '    '        dread.Read()
    '    '        Dim PO As String = "" + dread.Item("NOPO").ToString
    '    '        If nopo = PO Then
    '    '            MsgBox("Tidak Bisa Hapus Pendaftaran, PO Sudah Di Periksa !", vbCritical)
    '    '            dread.Close()
    '    '            Scon.Close()
    '    '            Exit Sub
    '    '        End If
    '    '        dread.Close()
    '    '    End If
    '    '    Scon.Close()
    '    'End If

    '    'If MsgBox("Menghapus Faktur akan menghapus BPB bila BPB sudah diinput." & vbCrLf & _
    '    '    "Hapus Faktur No." & txtNoFak.Text & " ?", vbExclamation Or vbYesNo Or vbDefaultButton2) = vbNo Then
    '    '    Exit Sub
    '    'End If

    '    'Dim X As Integer
    '    'X = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Position


    '    'If X < 0 Then
    '    '    MsgBox("Tidak Ada Data yang dihapus !", vbCritical)
    '    '    Exit Sub
    '    'End If
    '    'Dim dr As Object
    '    'dr = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Current


    '    'If "" & dr.row("Recid") = "B" Then
    '    '    MsgBox("Tidak Bisa Hapus, Faktur sudah ada BPB-nya !", vbCritical)
    '    '    Exit Sub
    '    'End If

    '    'Dim Scon As New OracleConnection(ConStrORA)
    '    'Dim Scom As New OracleCommand("", Scon)
    '    'Dim n As String = ""
    '    'Dim id_jlr As String = dr.row("ID_DAFTARJALUR")
    '    'Dim id_po As String = dr.row("ID_DAFTARPO")
    '    'Dim nopo As String = IIf(IsDBNull(dr.row("NOPO")), "", dr.row("NOPO"))

    '    'If nopo <> "" Then
    '    '    Scon.Open()
    '    '    Scom.CommandText = "Select distinct ID_FK,NOPO From DC_HH_SCAN_T WHERE nopo ='" & nopo & "' and id_fk='" & dr.row("ID_DAFTARJALUR") & "' and DC_ID=" & cDC_ID
    '    '    n = IIf(IsDBNull(Scom.ExecuteScalar), "", Scom.ExecuteScalar)

    '    '    If n <> "" Then
    '    '        Dim dread As OleDbDataReader
    '    '        dread = Scom.ExecuteReader
    '    '        dread.Read()
    '    '        Dim PO As String = "" + dread.Item("NOPO").ToString
    '    '        If nopo = PO Then
    '    '            MsgBox("Tidak Bisa Hapus Pendaftaran, PO Sudah Di Periksa !", vbCritical)
    '    '            dread.Close()
    '    '            Scon.Close()
    '    '            Exit Sub
    '    '        End If
    '    '        dread.Close()
    '    '    End If
    '    '    Scon.Close()
    '    'End If

    '    ''If MsgBox("Menghapus Faktur akan menghapus BPB bila BPB sudah diinput." & vbCrLf & _
    '    ''    "Hapus Faktur No." & txtNoFak.Text & " ?", vbExclamation Or vbYesNo Or vbDefaultButton2) = vbNo Then
    '    ''    Exit Sub
    '    ''End If

    '    'Dim lHapusMobil As Boolean
    '    'lHapusMobil = False
    '    'If Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Count = 1 Then
    '    '    If MsgBox("PO HANYA 1. Hapus PO Akan Menghapus Pendaftaran ini. LANJUTKAN?", vbExclamation Or vbYesNo Or vbDefaultButton2) = vbNo Then
    '    '        Exit Sub
    '    '    End If
    '    '    lHapusMobil = True
    '    'End If
    '    'Debug.WriteLine("Hapus PO " & X)
    '    'Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").RemoveAt(X)

    '    'Scon.Open()
    '    'Scom.CommandText = "delete from dc_jlr_daftarpo_t where " & _
    '    '                   "id_daftarpo=" & id_po
    '    'Scom.ExecuteNonQuery()
    '    'Scon.Close()

    '    'If lHapusMobil Then
    '    '    Debug.WriteLine("Hapus Mobil " & X)
    '    '    X = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position
    '    '    Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").RemoveAt(X)
    '    '    If Scon.State = ConnectionState.Open Then
    '    '        Scon.Close()
    '    '    End If
    '    '    Scon.Open()
    '    '    Scom.CommandText = "delete from dc_jlr_daftarjalur_t where " & _
    '    '                       "id_daftarjalur=" & id_jlr
    '    '    Scom.ExecuteNonQuery()
    '    '    Scon.Close()
    '    'End If

    '    'Try
    '    '    Dim ch As dsPO
    '    '    ch = DsPO1.GetChanges
    '    '    If (Not (ch) Is Nothing) Then
    '    '        Me.olcon.Open()
    '    '        Debug.WriteLine("Delete Daftar Langsung: " & oldapPO.Update(ch))
    '    '        Debug.WriteLine("Delete Mobil Langsung: " & oldapMobil.Update(ch))
    '    '        'Dim Olcom As New OracleCommand("", olcon)
    '    '        'Olcom.CommandText = "Delete From DC_JLR_DaftarPO_T where "
    '    '        'Olcom.ExecuteNonQuery()
    '    '    End If


    '    '    DsPO1.DC_JLR_DAFTARJALUR_T.AcceptChanges()
    '    '    DsPO1.DC_JLR_DAFTARPO_T.AcceptChanges()
    '    'Catch updateException As System.Exception
    '    '    'Add your error handling code here.
    '    '    Throw updateException
    '    'Finally
    '    '    'Close the connection whether or not the exception was thrown.
    '    '    Me.olcon.Close()
    '    'End Try
    'End Sub

    Private Sub btnEditPO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEditPO.Click
        'PO Obat tidak bisa di edit
        'PO Obat, Qty BPB harus 100%, jika tidak Batal. 
        'PO OBAT GA BISA DI EDIT 
        Dim cekObat1 As String = execScalar(" select PO_MBREAD from dc_trnbpb_hdr_t  where no_po ='" & txtNo_PO.Text & "'", ConStrORA)

        Dim cekObat As String = execScalar(" SELECT count(*)" &
                        "   FROM DC_PO_T a, DC_PODTL_T b" &
                        "  WHERE po_no_po = '" & txtNo_PO.Text & "'" &
                        "    AND po_no_po = podtl_fk_no_po" &
                        "    AND podtl_plu IN (SELECT DISTINCT mbr_fk_pluid" &
                        "                                 FROM DC_BARANG_DC_T" &
                        "                                WHERE mbr_tgl_plumati IS NULL" &
                        "                                  AND mbr_obat IS NOT NULL)", ConStrORA)
        If cekObat <> "0" Or cekObat1 = "O" Then
            MsgBox("PO Obat, Qty BPB harus 100%.", vbCritical)
            Exit Sub
        End If

        'If txtNo_PO.Text = "" Then
        '    MsgBox("Tidak Bisa Edit Pendaftaran Tanpa PO.", vbCritical)
        '    Exit Sub
        'End If
        'load datanya dulu baru save
        'If LBMobil.SelectedIndex = -1 And LBMobil.Items.Count <> 0 Then
        '    LBMobil.SelectedIndex = 0
        'End If
        frmLoadPO.sNoPo = txtNo_PO.Text
        frmLoadPO.NOMOBIL = lbmobil_
        frmLoadPO.SUPCO = txtKodeSupp_.Text
        frmLoadPO.SNAMA = txtNamaSupp_.Text
        frmLoadPO.ITEMnya = IIf(txtTot_Item.Text = "", 0, txtTot_Item.Text)
        ' frmLoadPO.RUPIAH = txtPO_GROSS.Text
        frmLoadPO.FAKTUR = txtNoFak.Text
        frmLoadPO.NoAntrian = txtNoAntrian.Text
        frmLoadPO.tglDaftar = txtTglDaftar.Value
        frmLoadPO.tglFaktur = txtTglFaktur.Value


        ''EnableInput
        'txtNoFak.Enabled = True
        'txtTglFaktur.Enabled = True


        'txtNo_PO.Enabled = True
        'txtPO_QTY.Enabled = True
        'txtPO_GROSS.Enabled = True
        'txtPO_PPN.Enabled = True

        'txtNoFak.Focus()

        ''UnBindData
        'btnSimpanPO.Enabled = True
        'btnBatalPO.Enabled = True


        Dim sqlpo As String
        Dim skon As New OracleConnection(ConStrORA)
        Dim skom As New OracleCommand("", skon)
        skon.Open()
        sqlpo = "Select COUNT(*) From DC_TRN_PREBPB_T Where NoPO='" & txtNo_PO.Text & "' " &
        " AND NO_FAKTUR='" & txtNoFak.Text & "' AND SUP_KODE = '" & txtKodeSupp_.Text & "' " &
        " AND TBL_DC_KODE = '" & cDC_KODE & "' "
        skom.CommandText = sqlpo
        If skom.ExecuteScalar > 0 Then
            MessageBox.Show("BPB sudah diposting, Tidak Bisa Edit PO.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            skon.Close()
            skom = Nothing
            skon = Nothing
            Exit Sub
        End If

        If lblStatus.Text <> "" Then
            MessageBox.Show("Tidak Bisa Edit PO. " & lblStatusKeterangan.Text & "", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        If lblBPB_NO.Text <> "" Then

        End If

        If txtNo_PO.Text = "" Then
            MessageBox.Show("Tidak Bisa Edit Pendaftaran Tanpa PO.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If



        Dim LastQTY As Double
        ' Dim LastGross As Double
        LastQTY = IFNULL(txtPO_QTY.Text, 0)
        ' LastGross = IFNULL(txtPO_GROSS.Text, 0)

        NoPO = txtNo_PO.Text

        Dim fe As New frmEditPO

        fe.sNoPo = txtNo_PO.Text
        fe.nIdDaftarPO = lblIdDaftarPO.Text
        fe.sNoPo = txtNo_PO.Text
        fe.eNOMOBIL = lbmobil_
        fe.eSUPCO = txtKodeSupp_.Text
        fe.eSNAMA = txtNamaSupp_.Text
        fe.eITEMnya = IIf(txtTot_Item.Text = "", 0, txtTot_Item.Text)
        '  fe.eRUPIAH = txtPO_GROSS.Text
        fe.eFAKTUR = txtNoFak.Text
        fe.eNoAntrian = txtNoAntrian.Text
        fe.etglDaftar = txtTglDaftar.Value
        fe.etglFaktur = txtTglFaktur.Value
        'If IsMrBread(txtSUPCO.Text, cDC_KODE) Then
        If IsMrBread(txtKodeSupp_.Text, cDC_KODE) Then
            fe.FakturMBread = txtNoFak.Text
            fe.IsMrBread = True

            MessageBox.Show("Tidak Bisa Edit Pendaftaran Mr.Bread.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub

        Else
            fe.IsMrBread = False
        End If

        'If fe.CekItemPO = True Then

        'fe.Top += Me.Height - fe.Height

        If fe.ShowDialog = Windows.Forms.DialogResult.OK Then
            'MsgBox("1")
            txtPO_QTY.Text = Format(fe.nQTY, "#,##0")
            txtTot_Item.Text = Format(fe.nItem, "#,##0")
            ' txtPO_GROSS.Text = Format(fe.nGROSS, "#,##.########")

            'txtPO_PPN.Text = Format(fe.nPPN, "#,##.########")
            'txtPO_Total.Text = Format(fe.nGROSS + fe.nPPN, "#,##.########")
            'MsgBox("2")
            'txtPO_PPN.Text = Format(fe.nGROSS * 0.1, "#,##.##############")
            'txtPO_Total.Text = Format(fe.nGROSS + (fe.nGROSS * 0.1), "#,##.##############")
            lblTglRevisi.Text = GetOracleDate()
            'MsgBox("3")
            Dim getPO_ As String = "select qty, item, trunc(rupiah,8) as rupiah, trunc(ppn,8) as ppn from dc_jlr_daftarpo_t where nopo= '" & txtNo_PO.Text & "'"
            Dim dt_getPO As DataTable = getDS(getPO_, ConStrORA).Tables(0)
            Dim drEDIT As Object
            drEDIT = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Current
            drEDIT.row("QTY") = dt_getPO.Rows(0)("QTY").ToString 'Format(fe.nQTY, "#,##0")
            drEDIT.row("ITEMNYA") = dt_getPO.Rows(0)("ITEM").ToString 'Format(fe.nItem, "#,##0")
            drEDIT.row("RUPIAH") = dt_getPO.Rows(0)("RUPIAH").ToString 'CType(IIf(Format(fe.nGROSS, "#,##.##############") = "", 0, Format(fe.nGROSS, "#,##.##############")), Double)
            drEDIT.row("PPN") = dt_getPO.Rows(0)("PPN").ToString 'CType(IIf(Format(fe.nPPN, "#,##.##############") = "", 0, Format(fe.nPPN, "#,##.##############")), Double)
            drEDIT.row("TOTAL") = CType(IIf(Format(dt_getPO.Rows(0)("RUPIAH") + dt_getPO.Rows(0)("PPN"), "#,##.##############") = "", 0, Format(dt_getPO.Rows(0)("RUPIAH") + dt_getPO.Rows(0)("PPN"), "#,##.##############")), Double)
            'CType(IIf(Format(fe.nGROSS + fe.nPPN, "#,##.##############") = "", 0, Format(fe.nGROSS + fe.nPPN, "#,##.##############")), Double)
            'drEDIT.row("TGL_REVISI") = IIf(lblTglRevisi.Text = "", 0, Now.Date)
            'MsgBox("4")
            'Simpan Langsung
            Try
                'Dim ch1 As dsPO.DC_JLR_DAFTARPO_TDataTable
                'ch1 = dsPO.DC_JLR_DAFTARPO_TRow

                Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").EndCurrentEdit()
                Dim ch As DS_.DC_JLR_DAFTARPO_TDataTable
                ch = DsPO1.DC_JLR_DAFTARPO_T.GetChanges
                If (Not (ch) Is Nothing) Then ' Or tgl_rev <> lblTglRevisi.Text
                    Dim Scon As New OracleConnection(ConStrORA)
                    Dim Scom As New OracleCommand("", Scon)

                    For i As Integer = 0 To ch.Rows.Count - 1
                        'update tgl_revisi ada jam. sebelumnya error karena tidak ada jamnya!
                        Dim waktu As DateTime
                        Dim tgl_revisi As String = ""
                        Try
                            waktu = Format(CType(ch.Rows(i)("tgl_revisi"), DateTime), "G")
                        Catch ex As Exception
                            tgl_revisi = "sysdate"
                            waktu = Date.Now
                        End Try
                        'Dim sql As String = "update dc_jlr_daftarpo_t set tgl_revisi=" & IIf(tgl_revisi = "sysdate", "sysdate", "to_date('" & Format(CType(dt.Rows(0)("tgl_revisi"), DateTime), "G") & "','MM/dd/yyyy hh:mi:ss AM')") & " where nopo='TH1828173'"
                        Scon.Open()
                        Scom.CommandText = "Update dc_jlr_daftarpo_t " &
                                           "set qty=qty" &
                                               " where " &
                                               " id_daftarjalur=" & ch.Rows(i)("id_daftarjalur") &
                                               " and id_daftarpo=" & ch.Rows(i)("id_daftarpo") &
                                               " and no_fak='" & ch.Rows(i)("no_fak") & "'" &
                                               " and nopo" & IIf(IsDBNull(ch.Rows(i)("nopo")), " is null ", "='" & ch.Rows(i)("nopo") & "' ") &
                                               " and supco='" & ch.Rows(i)("supco") & "'"
                        Scom.ExecuteNonQuery()
                        Scon.Close()
                    Next
                    Me.olcon.Open()
                    ' dikomen saat test directshipment special cast failed Debug.WriteLine("PO Langsung PERUBAHAN: " & oldapPO.Update(ch))
                    'Debug.WriteLine("PO Langsung: " & oldapPO.Update(Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").Current))
                    'Debug.WriteLine("PO Langsung: " & oracledataadapter1.Update(ch))
                Else
                    Dim dr As Object
                    dr = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Current
                    Dim id_jlr As String = dr.row("ID_DAFTARJALUR")
                    Dim id_po As String = dr.row("ID_DAFTARPO")
                    Dim no_fak As String = dr.row("NO_FAK")
                    Dim nopo As String = dr.row("NOPO")
                    MsgBox("Tidak Update ke Tabel Daftar PO !! ID Daftar PO = " & id_po & "," & id_jlr & "," & no_fak & "," & nopo, MsgBoxStyle.Information)
                End If
                DsPO1.DC_JLR_DAFTARPO_T.AcceptChanges()

            Catch updateException As System.Exception
                'Add your error handling code here.
                Throw updateException
            Finally
                'Close the connection whether or not the exception was thrown.
                Me.olcon.Close()
            End Try
            'LoadDataSet()
            'Dim loadnourut As String = txtNoAntrian.Text
            'For i As Integer = 0 To DsPO1.DC_JLR_DAFTARJALUR_T.Rows.Count - 1
            '    If DsPO1.DC_JLR_DAFTARJALUR_T.Rows(i)("NOURUT").ToString = loadnourut Then
            '        Exit For
            '    Else
            '        Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position += 1
            '    End If
            'Next

            'Dim NOFAKTUR_ = txtNoFak.Text
            'Dim NOPO_ = txtNo_PO.Text
            ''Dim loadnodaf As String = frmLoadPO.FAKTUR
            'For i As Integer = 0 To DsPO1.DC_JLR_DAFTARPO_T.Rows.Count - 1

            '    Dim NOFAK1 As String = DsPO1.DC_JLR_DAFTARPO_T.Rows(i)("NO_FAK").ToString
            '    Dim NOFAK2 As String = frmLoadPO.FAKTUR
            '    Dim NoPO1 As String = DsPO1.DC_JLR_DAFTARPO_T.Rows(i)("NOPO").ToString
            '    Dim NOPO2 As String = frmLoadPO.sNoPo.ToString
            '    If DsPO1.DC_JLR_DAFTARPO_T.Rows(i)("NO_FAK").ToString = NOFAKTUR_ And DsPO1.DC_JLR_DAFTARPO_T.Rows(i)("NOPO").ToString = NOPO_ Then
            '        Exit For
            '    Else
            '        Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Position += 1
            '    End If
            'Next
            'mobil()
        End If
        fe.Dispose()

    End Sub

    Private Sub btnKeluar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKeluar.Click
        Me.Close()
    End Sub

    Private Sub txtPO_GROSS_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs)
        'If Not IsNumeric(txtPO_GROSS.Text) Then
        '    MessageBox.Show("Masukkan Nilai Rupiah", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
        '    e.Cancel = True
        'End If
        'If Not lWithPO Then
        '    Dim x As Double
        '    'x = CType(txtPO_GROSS.Text, Double) * 0.11
        '    'txtPO_PPN.Text = x
        '    txtPO_Total.Text = CType(txtPO_GROSS.Text, Double) + txtPO_PPN.Text


        '    'x = CType(txtPO_GROSS.Text, Double) * 0.11
        '    'txtPO_PPN.Text = x
        '    'txtPO_Total.Text = CType(txtPO_GROSS.Text, Double) + x
        'End If
    End Sub

    Private Sub TXTPO_PPN_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs)
        'If Not IsNumeric(txtPO_PPN.Text) Then
        '    MessageBox.Show("Masukkan Nilai Rupiah", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
        '    e.Cancel = True
        'End If
        'If Not lWithPO Then
        '    Dim x As Double
        '    x = CType(IIf(txtPO_PPN.Text = "", 0, txtPO_PPN.Text), Double)
        '    txtPO_Total.Text = CType(IIf(txtPO_GROSS.Text = "", 0, txtPO_GROSS.Text), Double) + x
        'End If
    End Sub

    Private Sub btnCari_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCari.Click
        ' Me.DsPO1.RejectChanges()
        ' Me.DsPO1.AcceptChanges()
        '  Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.ID_DAFTARJALUR").Position = 0
        Dim f As New frmCariPO
        f.DataGrid1.DataSource = DsPO1.DC_JLR_DAFTARPO_T
        If f.ShowDialog <> Windows.Forms.DialogResult.OK Then
            Exit Sub
        End If

        Dim IdDaftarJalur As Integer
        Dim IdDaftar As Integer

        IdDaftar = f.idDaftar
        Dim rw As DataRow = DsPO1.DC_JLR_DAFTARPO_T.FindByID_DAFTARPO(IdDaftar)
        If IsNothing(rw) Then
            Exit Sub
        End If

        IdDaftarJalur = "0" & rw("ID_DAFTARJALUR")
        Dim rwMobil As DataRow = DsPO1.DC_JLR_DAFTARJALUR_T.FindByID_DAFTARJALUR(IdDaftarJalur)
        txtNoAntrianPO.Text = txtNoAntrianPO.Text
        For j As Integer = 0 To DsPO1.DC_JLR_DAFTARJALUR_T.Rows.Count - 1
            If rwMobil.Equals(DsPO1.DC_JLR_DAFTARJALUR_T.Rows(j)) Then
                Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position = j
                Exit For
            End If
        Next


        For i As Integer = 0 To Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").Count - 1
            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").Position = i
            If CType(Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").Current, DataRowView).Row.Equals(rw) Then
                Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").Position = i
                Exit For
            End If
        Next
        RECID()
        'mobil()

        LoadNoAntrian()

    End Sub


    Private Function GetOracleDate() As Date
        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Try
            Scon.Open()
            Scom.CommandText = "Select sysdate from dual"
            Return Scom.ExecuteScalar

        Catch ex As Exception
            ShowError("error Baca Jam", ex)
        Finally
            Scon.Close()
        End Try

    End Function

    Private Sub btnDaftar_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDaftar.EnabledChanged
        btnDraftRetur.Enabled = CType(sender, Button).Enabled
    End Sub

    Private Sub btnDraftRetur_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDraftRetur.Click
        subDraft(txtKodeSupp_.Text, cDC_KODE, cDC_ID)
    End Sub

    Public Sub subDraft(ByVal sd_supco As String, ByVal sd_dckode As String, ByVal sd_dcid As String)
        If sd_supco = "" Then
            MessageBox.Show("Tidak Ada Data Supplier.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        Dim sd_supnama As String = ""
        Dim dt_getSUPNAMA As DataTable = getDS("SELECT sup_nama FROM dc_supplier_dc_v WHERE sup_supkode = '" & sd_supco & "'", ConStrORA).Tables(0)
        If dt_getSUPNAMA.Rows.Count > 0 Then
            sd_supnama = dt_getSUPNAMA.Rows(0)(0).ToString
        End If

        'Dim f As New frmDraftRetur
        Dim nBulan As Integer = 12
        'If f.ShowDialog = Windows.Forms.DialogResult.OK Then
        '    nBulan = f.nBulan
        'Else
        '    Exit Sub
        'End If

        Dim RunProc As String = JLR_Create_Draft_Retur(sd_supco, sd_dckode, nBulan)
        If RunProc <> "Y" Then
            MessageBox.Show("Procedure JLR_Create_Draft_Retur Error" & vbNewLine & RunProc, "Error Procedure!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Dim Sdap As New OracleDataAdapter("", Scon)
        Dim dt As New DataTable
        Try
            Scon.Open()
            'Scom.CommandText = "JLR_Create_Draft_Retur('" & sd_supco & "','" & sd_dckode & "'," & nBulan & ")"
            'Scom.CommandType = CommandType.StoredProcedure
            'Scom.ExecuteNonQuery()
            Scom.CommandType = CommandType.Text

            dt.Clear()

            Scom.CommandText = "Select D.*,PRDCD,NAMA,SINGKAT from dc_jlr_draft_retur_t d, "
            Scom.CommandText &= "(SELECT MBR_FK_PLUID,mbr_plukode PRDCD,MBR_FULL_NAMA NAMA,MBR_SINGKATAN SINGKAT FROM DC_BARANG_DC_V WHERE MBR_FK_DCID=" & sd_dcid & ") brg "
            Scom.CommandText &= "WHERE(SUPCO = '" & sd_supco & "') "
            Scom.CommandText &= "AND Tanggal=TRUNC(SYSDATE) "
            Scom.CommandText &= "AND D.PLUID=BRG.MBR_FK_PLUID "
            Scom.CommandText &= "ORDER BY  PRDCD "
            Sdap.SelectCommand = Scom
            Sdap.Fill(dt)

            Scom.CommandText = "select alamat from dc_printer_t where printer='RETUR' and DC_ID='" & sd_dcid & "'"
            Dim almt As String = IIf(IsNothing(Scom.ExecuteScalar) Or IsDBNull(Scom.ExecuteScalar), "", Scom.ExecuteScalar)
            If almt = "" Then
                MsgBox("Tidak Ada Alamat Printer Draft Retur")
            End If
            If dt.Rows.Count > 0 Then
                Cetak_DrafRetur(dt, almt, sd_supco, sd_supnama)
                MessageBox.Show("Draft Retur Selesai.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("Tidak Ada Data Untuk Draft Retur.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        Catch ex As Exception
            ShowError("error Create Draft Retur", ex)
        Finally
            Scon.Close()
        End Try
    End Sub


    Public Function JLR_Create_Draft_Retur(ByVal sd_supco As String, ByVal sd_dckode As String, ByVal nBulan As Integer) As String
        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Dim Hasil As String = ""
        Try
            If Scon.State = ConnectionState.Open Then
                Scon.Close()

            End If
            Scon.Open()
            If Scon.State = ConnectionState.Open Then
                Scom.CommandType = CommandType.StoredProcedure
                Scom.CommandText = "JLR_CREATE_DRAFT_RETUR"
                Scom.CommandType = System.Data.CommandType.StoredProcedure
                Scom.Parameters.Clear()
                Scom.Parameters.Add(New OracleParameter("P_SUPCO", OracleDbType.Varchar2)).Value = sd_supco
                Scom.Parameters.Add(New OracleParameter("P_DCKODE", OracleDbType.Varchar2)).Value = sd_dckode
                Scom.Parameters.Add(New OracleParameter("P_BULAN", OracleDbType.Int32)).Value = nBulan
                Scom.ExecuteNonQuery()
            End If
            Return "Y"
        Catch ex As Exception
            Return ex.Message
        Finally
            Scom.Dispose()
            Scom = Nothing
            Scon.Close()
        End Try
    End Function
    'Private Sub Cetak_DrafRetur(ByVal dt As DataTable, ByVal nmPrinter As String)
    '    'Cetak PB BKL
    '    Dim nProw As Integer = 0
    '    Dim nHal As Integer = 0
    '    Dim NoUrut As Integer = 0
    '    Dim mDIV As String = ""
    '    Dim sw As New IO.StreamWriter(Application.StartupPath & "\TempCetakDraftRetur.TXT", False)

    '    sw.WriteLine(Chr(27) & "x" & "0" & Chr(27) & "M" + Chr(15))

    '    'SETENGAH PLY
    '    sw.Write(Chr(27) & "C" & Chr(33))
    '    For i As Short = 0 To dt.Rows.Count - 1
    '        If nProw = 0 Then
    '            nHal += 1
    '            If nHal < 2 Then
    '                sw.WriteLine(Chr(27) & "W" & "0")
    '                sw.WriteLine((cDC_KODE & "-" & cDC_NAMA).PadRight(104) & Format(Now, "dd/MM/yyyy"))
    '                'sw.WriteLine(Chr(14) & Chr(27) & "W" & "1")
    '                sw.Write(Chr(14) + (Chr(27) + "W" + "1"))
    '                sw.WriteLine(strCenter("DRAFT RETUR SUPPLIER", 65))
    '                'sw.WriteLine(Chr(20) & Chr(27) & "W" & "0")
    '                sw.WriteLine(Chr(20) + (Chr(27) + "W" + "0"))
    '                sw.WriteLine(strCenter("Supplier : " & lblSUPCO.Text & "-" & lblSNAMA.Text, 120))
    '                'sw.WriteLine(strCenter("Nomor PB BKL : " & nDocno & "/Tgl. : " & Format(Now, "dd/MM/yyyy"), 120))
    '                sw.WriteLine(("Halaman: " & CType(nHal, String).PadLeft(2)).PadLeft(108))
    '                nProw += 7
    '            Else
    '                'sw.WriteLine(("PB Kirim Langsung No. : " & nDocno).PadRight(108) & "Halaman: " & CType(nHal, String).PadLeft(2))
    '                sw.WriteLine((" ").PadRight(108) & "Halaman: " & CType(nHal, String).PadLeft(2))
    '                nProw += 1
    '            End If

    '            sw.WriteLine("-".PadRight(120, "-"))
    '            sw.WriteLine("|  No. |  PLU |  Nama Barang dan Spesifikasi                                  | Kuantitas |  Aktual  |    Keterangan    |")
    '            sw.WriteLine("|-----------------------------------------------------------------------------|-----------|----------|------------------|")
    '            nProw += 3
    '        End If
    '        NoUrut += 1
    '        sw.Write("| " & CType(NoUrut, String).PadLeft(3) & ". | ")
    '        sw.Write(dt.Rows(i)("PRDCD") & " |  ")
    '        sw.Write(CType("" & dt.Rows(i)("NAMA"), String).PadRight(50).Substring(0, 50) & "   ")
    '        sw.Write(CType(" ", String).PadRight(6).Substring(0, 6) & "  | ")
    '        sw.WriteLine(CType(Format(dt.Rows(i)("QTY"), "#,##0"), String).PadLeft(9) & " | " & "".PadRight(8) & " | " & "".PadRight(17) & "|")
    '        nProw += 1
    '        If nProw >= 28 Then
    '            sw.WriteLine("|" & "-".PadRight(119, "-") & "|")
    '            nProw = 0
    '            'EJECT
    '            sw.Write(Chr(12) + Chr(13))
    '        End If
    '    Next
    '    'sw.WriteLine("|" & "-".PadRight(119, "-") & "|")
    '    'sw.WriteLine(("|".PadRight(16) & ("Disetujui :").PadRight(93 - 16) & "Dicetak :").PadRight(120) & "|")
    '    'sw.WriteLine("|" & " ".PadRight(119) & "|")
    '    'sw.WriteLine("|" & " ".PadRight(119) & "|")
    '    'sw.WriteLine("|" & " ".PadRight(119) & "|")
    '    'sw.WriteLine(("|".PadRight(16) & ("___________").PadRight(93 - 16) & "_________").PadRight(120) & "|")
    '    'sw.WriteLine(("|".PadRight(12) & ("Chief of Store/Asst").PadRight(93 - 12) & "         ").PadRight(120) & "|")
    '    sw.WriteLine("-" & "-".PadRight(119, "-") & "-")
    '    sw.Write(Chr(12) + Chr(13))
    '    sw.Write(Chr(18))
    '    sw.Flush()
    '    sw.Close()

    '    ''''''''''''
    '    Dim sr As New IO.StreamReader(Application.StartupPath & "\TempCetakDraftRetur.TXT")
    '    DoPr(sr.ReadToEnd, nmPrinter)
    '    sr.Close()
    'End Sub
    Private Sub Cetak_DrafRetur(ByVal dt As DataTable, ByVal nmPrinter As String, ByVal supkode As String, ByVal supnama As String)
        'Cetak PB BKL
        Dim nProw As Integer = 0
        Dim nHal As Integer = 0
        Dim NoUrut As Integer = 0
        Dim mDIV As String = ""
        Dim sw As New IO.StreamWriter(Application.StartupPath & "\TempCetakDraftRetur.TXT", False)

        sw.WriteLine(Chr(27) & "x" & "0" & Chr(27) & "M" + Chr(15))

        'SETENGAH PLY
        sw.Write(Chr(27) & "C" & Chr(33))
        For i As Short = 0 To dt.Rows.Count - 1
            If nProw = 0 Then
                nHal += 1
                If nHal < 2 Then
                    sw.WriteLine(Chr(27) & "W" & "0")
                    sw.WriteLine((cDC_KODE & "-" & cDC_NAMA).PadRight(104) & Format(Now, "dd/MM/yyyy"))
                    'sw.WriteLine(Chr(14) & Chr(27) & "W" & "1")
                    sw.Write(Chr(14) + (Chr(27) + "W" + "1"))
                    sw.WriteLine(strCenter("DRAFT RETUR SUPPLIER", 65))
                    'sw.WriteLine(Chr(20) & Chr(27) & "W" & "0")
                    sw.WriteLine(Chr(20) + (Chr(27) + "W" + "0"))
                    sw.WriteLine(strCenter("Supplier : " & supkode & "-" & supnama, 120))
                    'sw.WriteLine(strCenter("Supplier : " & lblSUPCO.Text & "-" & lblSNAMA.Text, 120))
                    'sw.WriteLine(strCenter("Nomor PB BKL : " & nDocno & "/Tgl. : " & Format(Now, "dd/MM/yyyy"), 120))
                    sw.WriteLine(("Halaman: " & CType(nHal, String).PadLeft(2)).PadLeft(108))
                    nProw += 7
                Else
                    'sw.WriteLine(("PB Kirim Langsung No. : " & nDocno).PadRight(108) & "Halaman: " & CType(nHal, String).PadLeft(2))
                    sw.WriteLine((" ").PadRight(108) & "Halaman: " & CType(nHal, String).PadLeft(2))
                    nProw += 1
                End If

                sw.WriteLine("-".PadRight(120, "-"))
                sw.WriteLine("|  No. |   PLU    | Nama Barang dan Spesifikasi                               | Kuantitas |  Aktual  |    Keterangan    |")
                sw.WriteLine("|-----------------------------------------------------------------------------|-----------|----------|------------------|")
                nProw += 3
            End If
            NoUrut += 1
            sw.Write("| " & CType(NoUrut, String).PadLeft(3) & ". | ")
            sw.Write(IIf(dt.Rows(i)("PRDCD").Length = 4, "  " & dt.Rows(i)("PRDCD") & "   | ", dt.Rows(i)("PRDCD") & " | "))
            'sw.Write(dt.Rows(i)("PRDCD") & " |  ")
            sw.Write(CType("" & dt.Rows(i)("NAMA"), String).PadRight(55).Substring(0, 50) & "")
            sw.Write(CType(" ", String).PadRight(6).Substring(0, 6) & "  | ")
            sw.WriteLine(CType(Format(dt.Rows(i)("QTY"), "#,##0"), String).PadLeft(9) & " | " & "".PadRight(8) & " | " & "".PadRight(17) & "|")
            nProw += 1
            If nProw >= 28 Then
                sw.WriteLine("|" & "-".PadRight(119, "-") & "|")
                nProw = 0
                'EJECT
                sw.Write(Chr(12) + Chr(13))
            End If
        Next
        'sw.WriteLine("|" & "-".PadRight(119, "-") & "|")
        'sw.WriteLine(("|".PadRight(16) & ("Disetujui :").PadRight(93 - 16) & "Dicetak :").PadRight(120) & "|")
        'sw.WriteLine("|" & " ".PadRight(119) & "|")
        'sw.WriteLine("|" & " ".PadRight(119) & "|")
        'sw.WriteLine("|" & " ".PadRight(119) & "|")
        'sw.WriteLine(("|".PadRight(16) & ("___________").PadRight(93 - 16) & "_________").PadRight(120) & "|")
        'sw.WriteLine(("|".PadRight(12) & ("Chief of Store/Asst").PadRight(93 - 12) & "         ").PadRight(120) & "|")
        sw.WriteLine("-" & "-".PadRight(119, "-") & "-")
        sw.Write(Chr(12) + Chr(13))
        sw.Write(Chr(18))
        sw.Flush()
        sw.Close()

        ''''''''''''
        Dim sr As New IO.StreamReader(Application.StartupPath & "\TempCetakDraftRetur.TXT")
        DoPr(sr.ReadToEnd, nmPrinter)
        sr.Close()
    End Sub
    '    Private Sub CmbSUPCO_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs)
    '        If Len(txtKodeSupp_.Text) = 4 Then
    '            txtKodeSupp_.Text = txtKodeSupp_.Text.ToUpper
    '            'If CmbSUPCO.Text = lblSUPCO.Text Then
    '            '    Exit Sub
    '            'End If
    '            Dim i As Integer
    '            For i = 0 To CmbSUPCO.Items.Count - 1
    '                If CmbSUPCO.Text = dsSupp.Tables(0).Rows(i).Item(0) Then
    '                    GoTo lanjut
    '                End If
    '            Next
    '            MsgBox("Supplier tidak terdaftar")
    '            CmbSUPCO.Text = dsSupp.Tables(0).Rows(0).Item(0)
    '            Exit Sub

    'lanjut:     Dim sql As String
    '            Dim Scon As New OracleConnection(ConStrORA)
    '            Dim Scom As New OracleCommand("", Scon)
    '            Dim Sdar As OracleDataReader
    '            Dim Sdap As New OracleDataAdapter
    '            Try
    '                Scon.Open()
    '                'Todo: Buat PO tidak ada Kolom
    '                sql = "Select S.SUP_NAMA AS SNAMA,s.SUP_SUPID AS SUPID from DC_SUPPLIER_DC_V H,DC_SUPPLIER_T S "
    '                sql &= "Where H.SUP_FK_SUPID=s.SUP_SUPID And "
    '                sql &= "TBL_DC_KODE='" & cDC_KODE
    '                sql &= "' AND H.SUP_SUPKODE='" & txtKodeSupp_.Text.ToUpper & "'"
    '                Scom.CommandText = sql
    '                Sdar = Scom.ExecuteReader


    '                If Sdar.Read Then
    '                    'Cek With PO
    '                    If Not lWithPO Then
    '                        txtPO_QTY.Focus()
    '                    End If

    '                    lblSNAMA.Text = IIf(IsDBNull(Sdar("SNAMA")), "", Sdar("SNAMA"))
    '                    lblSUPID.Text = IFNULL(Sdar("SUPID"), 0)

    '                    If lblSNAMA.Text = "" Then
    '                        GoTo ex
    '                    End If

    '                Else
    '                    MsgBox("Supplier " & CmbSUPCO.Text & " tidak ada !!!", vbCritical)
    '                    lblSNAMA.Text = ""
    '                    Sdar.Close()
    '                    CmbSUPCO.Focus()
    '                    GoTo ex
    '                End If
    '                Sdar.Close()

    '                Dim m As String
    '                Dim d As String
    '                Dim tgl As String
    '                m = Date.Now.Month
    '                d = Date.Now.Day
    '                If m.Length < 2 And d.Length < 2 Then
    '                    m = "0" & Date.Now.Month
    '                    d = "0" & Date.Now.Day
    '                ElseIf m.Length < 2 Then
    '                    m = "0" & Date.Now.Month
    '                ElseIf d.Length < 2 Then
    '                    d = "0" & Date.Now.Day
    '                End If
    '                tgl = d & "/" & m & "/" & Date.Now.Year
    '                'Scom.CommandText = "select NOMOBIL from DC_JLR_DAFTARMOBIL_HDR_T where to_char(TRUNC(TGLMASUK),'dd/mm/yyyy')='" & tgl & "' and supco='" & CmbSUPCO.Text & "'"

    '                Scom.CommandText = "select NOMOBIL from DC_JLR_DAFTARMOBIL_HDR_T where TGLMASUK=to_date('" & Convert.ToDateTime(CmbNama.SelectedValue).ToString("MM/dd/yyyy hh:mm:ss tt") & "', 'MM/dd/yyyy hh:mi:ss am') and supco='" & CmbSUPCO.Text & "'"
    '                Sdap.SelectCommand = Scom
    '                ds.Clear()
    '                Sdap.Fill(ds)
    '                If ds.Tables(0).Rows.Count <= 0 Then
    '                    Scom.CommandText = " SELECT NOMOBIL FROM dc_jlr_daftarjalur_t" &
    '                        "  WHERE supco = '" & lblSUPCO.Text & "'" &
    '                        "    AND nourut = '" & txtNoAntrian.Text & "'" &
    '                        "    AND TO_CHAR (TRUNC (tanggal), 'dd/MM/yyyy') = '" & Format(txtTglDaftar.Value, "dd/MM/yyyy") & "'"
    '                    Sdap.SelectCommand = Scom
    '                    ds.Clear()
    '                    Sdap.Fill(ds)
    '                End If
    '                LBMobil.DataSource = ds.Tables(0)
    '                LBMobil.DisplayMember = "NOMOBIL"
    'ex:             If lblSNAMA.Text = "" Then
    '                    ds.Clear()
    '                    CmbSUPCO.Focus()
    '                End If
    '            Catch ex As Exception
    '                ShowError("Error Baca Supplier", ex)
    '            Finally
    '                Scon.Close()
    '                Scon = Nothing
    '            End Try
    '            lblSUPCO.Text = CmbSUPCO.Text
    '        End If
    '    End Sub

    'Private Sub CmbSUPCO_TextUpdate(ByVal sender As Object, ByVal e As System.EventArgs) Handles CmbSUPCO.TextUpdate

    'End Sub

    ' ''    Private Sub txtSUPCO_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    ' ''        If Len(txtSUPCO.Text) = 4 Then
    ' ''            If txtSUPCO.Text = lblSUPCO.Text Then
    ' ''                Exit Sub
    ' ''            End If

    ' ''            Dim sql As String
    ' ''            Dim Scon As New OracleConnection(ConStrORA)
    ' ''            Dim Scom As New OracleCommand("", Scon)
    ' ''            Dim Sdar As OleDbDataReader
    ' ''            Try
    ' ''                Scon.Open()
    ' ''                'Todo: Buat PO tidak ada Kolom
    ' ''                sql = "Select S.SUP_NAMA AS SNAMA,H.SUP_SUPKODE AS SUPCO,H.SUP_FLAG_BUATPO AS BUAT_PO,s.SUP_SUPID AS SUPID from DC_SUPPLIER_DC_V H,DC_SUPPLIER_T S "
    ' ''                sql &= "Where H.SUP_FK_SUPID=s.SUP_SUPID And "
    ' ''                sql &= "TBL_DC_KODE='" & cDC_KODE
    ' ''                sql &= "' AND H.SUP_SUPKODE='" & txtSUPCO.Text & "'"
    ' ''                Scom.CommandText = sql
    ' ''                Sdar = Scom.ExecuteReader


    ' ''                If Sdar.Read Then
    ' ''                    'Cek With PO
    ' ''                    If Not lWithPO Then
    ' ''                        If "" & Sdar("BUAT_PO") = "Y" Then
    ' ''                            'MsgBox("Supplier " & txtSUPCO.Text & " Harus Pakai PO !!!", vbCritical)
    ' ''                            'txtSUPCO.Text = ""
    ' ''                            'txtNamaSupp.Text = ""
    ' ''                            'GoTo ex
    ' ''                        Else
    ' ''                            txtPO_QTY.Focus()
    ' ''                        End If
    ' ''                    End If
    ' ''                    txtNamaSupp.Text = Sdar("SNAMA") & ""

    ' ''                    lblSUPID.Text = IFNULL(Sdar("SUPID"), 0)

    ' ''                    If lblSUPCO.Text = "" Then
    ' ''                        lblSUPCO.Text = Sdar("SUPCO")
    ' ''                    End If
    ' ''                    If lblSNAMA.Text = "" Then
    ' ''                        lblSNAMA.Text = txtNamaSupp.Text
    ' ''                    End If
    ' ''                Else
    ' ''                    MsgBox("Supplier " & txtSUPCO.Text & " tidak ada !!!", vbCritical)
    ' ''                End If
    ' ''ex:             Sdar.Close()
    ' ''            Catch ex As Exception
    ' ''                ShowError("Error Baca Supplier", ex)
    ' ''            Finally
    ' ''                Scon.Close()
    ' ''                Scon = Nothing
    ' ''            End Try
    ' ''        End If
    ' ''    End Sub

    Private Sub lblSUPCO_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        isiData()
    End Sub

    Private Sub isiData()
        'If CmbSUPCO.Visible = True Then
        '    lblSUPCO.Text = CmbSUPCO.Text
        'End If
        Dim m As String
        Dim d As String
        Dim tgl As String
        m = Date.Now.Month
        d = Date.Now.Day
        If m.Length < 2 And d.Length < 2 Then
            m = "0" & Date.Now.Month
            d = "0" & Date.Now.Day
        ElseIf m.Length < 2 Then
            m = "0" & Date.Now.Month
        ElseIf d.Length < 2 Then
            d = "0" & Date.Now.Day
        End If
        tgl = d & "/" & m & "/" & Date.Now.Year

        If tgl <> Format(txtTglDaftar.Value, "dd/MM/yyyy") Then
            ' mobil()
            MessageBox.Show("Tanggal daftar tidak sesuai")
            Exit Sub
        End If

        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Dim Sdap As New OracleDataAdapter
        Try
            Scon.Open()
            'Scom.CommandText = "select NOMOBIL from DC_JLR_DAFTARMOBIL_HDR_T where TGLMASUK =to_date('" & CmbNama.SelectedValue & "', 'MM/dd/yyyy hh:mi:ss am') and supco='" & lblSUPCO.Text & "' and TGLKELUAR is null"
            'Sdap.SelectCommand = Scom
            'ds.Clear()
            'Sdap.Fill(ds)

            'If ds.Tables(0).Rows.Count <= 0 Then
            Scom.CommandText = " SELECT NOMOBIL FROM dc_jlr_daftarjalur_t" &
                    "  WHERE supco = '" & txtKodeSupp_.Text & "'" &
                    "    AND nourut = '" & txtNoAntrian.Text & "'" &
                    "    AND TO_CHAR (TRUNC (tanggal), 'dd/MM/yyyy') = '" & Format(txtTglDaftar.Value, "dd/MM/yyyy") & "'"
            Sdap.SelectCommand = Scom
                ds.Clear()
                Sdap.Fill(ds)
            'End If
            'LBMobil.DataSource = ds.Tables(0)
            'LBMobil.DisplayMember = "NOMOBIL"
            'If btnDaftar.Enabled = True And btnTambahPO.Enabled = True Then
            '    LBMobil.ClearSelected()
            'End If
        Catch ex As Exception

        Finally
            Scon.Close()
            Scon = Nothing
        End Try
    End Sub

#Region " com calls "
    ''' <summary> 
    ''' 
    ''' </summary> 
    ''' <param name="lpFileName"></param> 
    ''' <param name="dwDesiredAccess"></param> 
    ''' <param name="dwShareMode"></param> 
    ''' <param name="lpSecurityAttributes"></param> 
    ''' <param name="dwCreationDisposition"></param> 
    ''' <param name="dwFlagsAndAttributes"></param> 
    ''' <param name="hTemplateFile"></param> 
    ''' <returns></returns> 
    ''' <remarks></remarks> 
    Private Declare Function CreateFile Lib "kernel32" Alias "CreateFileA" (ByVal lpFileName As String, ByVal dwDesiredAccess As Integer, ByVal dwShareMode As Integer, <MarshalAs(UnmanagedType.Struct)> ByRef lpSecurityAttributes As SECURITY_ATTRIBUTES, ByVal dwCreationDisposition As Integer, ByVal dwFlagsAndAttributes As Integer, ByVal hTemplateFile As Integer) As Microsoft.Win32.SafeHandles.SafeFileHandle
#End Region
#Region " Private constants "
    Private Const GENERIC_WRITE As Integer = &H40000000
    Private Const OPEN_EXISTING As Integer = 3
#End Region
#Region " private structures "
    ''' <summary> 
    ''' Structure for CreateFile.  Used only to fill requirement 
    ''' </summary> 
    <StructLayout(LayoutKind.Sequential)>
    Public Structure SECURITY_ATTRIBUTES
        Private nLength As Integer
        Private lpSecurityDescriptor As Integer
        Private bInheritHandle As Integer
    End Structure
#End Region

    Private Sub btnPrint_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        Dim NoUrut As String
        Dim Ps As New Printing.PrinterSettings
        Dim drSup As Object
        drSup = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Current
        drSup.row("PRINT_ID") = "1"
        Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").EndCurrentEdit()
        NoUrut = drSup.row("NOURUT")

        Dim ID_JLR As String = drSup.row("ID_DAFTARJALUR")
        Dim DC_ID As String = drSup.row("DC_ID")
        'Dim ID_PO As String = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").Current.row("ID_DAFTARPO")

        If NoUrut.Length = 2 Then
            NoUrut = "0" & NoUrut
        ElseIf NoUrut.Length = 1 Then
            NoUrut = "00" & NoUrut
        ElseIf NoUrut.Length = 0 Or NoUrut.Length > 3 Then
            MsgBox("No Urut Error, Tidak Bisa Print")
            Exit Sub
        End If
        Dim Tgl As String
        Dim m As String
        Dim d As String
        Dim day As String
        Tgl = Format(drSup.row("TANGGAL"), "MM/dd/yyyy")

        m = Tgl.Substring(0, 2)
        d = Tgl.Substring(3, 2)
        Tgl = Tgl.Substring(8, 2)
        If m.Length < 2 And d.Length < 2 Then
            m = "0" & m
            d = "0" & d
        ElseIf m.Length < 2 Then
            m = "0" & m
        ElseIf d.Length < 2 Then
            d = "0" & d
        End If
        day = d & m & Tgl
        NoUrut = "*" & NoUrut & day & "*"
        Try
            Dim ch As DS_.DC_JLR_DAFTARJALUR_TDataTable
            ch = DsPO1.DC_JLR_DAFTARJALUR_T.GetChanges
            If (Not (ch) Is Nothing) Then
                If Me.olcon.State = ConnectionState.Open Then
                    Me.olcon.Close()
                End If
                Me.olcon.Open()
                '  Debug.WriteLine("Mobil Langsung: " & oldapMobil.Update(ch))
            End If
            Print(drSup.row("PRINT_ID"), drSup.row("ID_DAFTARJALUR"))
        Catch updateException As System.Exception
            'Add your error handling code here.
            Throw updateException
            MsgBox("Update Error")
        Finally
            'Close the connection whether or not the exception was thrown.
            Me.olcon.Close()
        End Try

        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Dim Sdap As New OracleDataAdapter
        Dim drpt As New DataSet

        Dim dsPlt As New DataSet
        Dim namaPrt As String = ""

        Try
            Scon.Open()
            Scom.CommandText = "select a.nourut,trunc(a.tanggal) as tgl,a.SUPCO,a.SNAMA,b.TBL_DC_KODE,b.TBL_DC_NAMA " &
                               "from dc_jlr_daftarjalur_t a," &
                                    "dc_tabel_dc_t b " &
                               "where id_daftarjalur='" & ID_JLR & "' " &
                                     "and a.dc_id=b.TBL_DCID"
            Sdap.SelectCommand = Scom
            drpt.Clear()
            Sdap.Fill(drpt)
            drpt.Tables(0).Columns.Add("barcode")
            drpt.Tables(0).Rows(0).Item("barcode") = NoUrut
            drpt.WriteXml(Application.StartupPath & "PrintD.xml", XmlWriteMode.WriteSchema)

            Scom.CommandText = "select alamat from dc_printer_t where Printer='DAFTAR'"
            namaPrt = Scom.ExecuteScalar()


        Catch ex As Exception

        Finally
            Scon.Close()
            Scon = Nothing
        End Try

        If namaPrt = "" Then
            MsgBox("Alamat Printer Tidak Diketahui")
            Exit Sub
        End If

        'prSticker(DC_ID, ID_JLR)

        Dim Rpt As New CrystalDecisions.CrystalReports.Engine.ReportDocument
        Try
            Rpt = New CRpt

            'Rpt.PrintOptions.PrinterName = namaPrt
            'Rpt.PrintOptions.PaperSize = CrystalDecisions.Shared.PaperSize.PaperEnvelopePersonal
            Rpt.SetDataSource(drpt)
            'Rpt.PrintOptions.
            Rpt.PrintOptions.PrinterName = namaPrt

            'Dim doctoprint As New System.Drawing.Printing.PrintDocument
            'doctoprint.PrinterSettings.PrinterName = namaPrt '"192.168.5.41\EpsonLQ"
            'Dim rawKind As Integer = 0
            'For i As Integer = 0 To doctoprint.PrinterSettings.PaperSizes.Count - 1
            '    If doctoprint.PrinterSettings.PaperSizes(i).PaperName = "DAFTAR" Then
            '        rawKind = CInt(doctoprint.PrinterSettings.PaperSizes(i).GetType().GetField("kind", System.Reflection.BindingFlags.Instance Or System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes(i)))
            '        Exit For
            '    End If
            'Next

            'Rpt.PrintOptions.PaperSize = CrystalDecisions.Shared.PaperSize.PaperEnvelope10

            'Dim pixelX As Integer = cm / 2.54 * dpi
            'Dim pixelY = scaleY(35, vbcentimeters, vbpixels)
            'Dim pkPaperSize As New Printing.PaperSize("sdfgsfdg", 850, 1100)
            'Rpt.PrintOptions.PaperSize = CrystalDecisions.Shared.PaperSize.PaperEnvelopePersonal
            'Rpt.PrintOptions.PaperOrientation = CrystalDecisions.Shared.PaperOrientation.Portrait

            ''Rpt.PrintOptions.PaperSize = paper_size()
            ''CrystalDecisions.Shared.PaperSize.DefaultPaperSize()
            'MsgBox(Rpt.PrintOptions.PageContentWidth & "," & Rpt.PrintOptions.PageContentHeight)
            'Exit Try


            ' ''Dim _outFile As FileStream
            ' ''Dim _fileWriter As StreamWriter
            ' ''Dim SA As SECURITY_ATTRIBUTES
            ' '' ''Try
            ' '' ''    _outFile = New FileStream(CreateFile(namaPrt, GENERIC_WRITE, 0, SA, OPEN_EXISTING, 0, 0), FileAccess.Write)
            ' '' ''    _fileWriter = New StreamWriter(_outFile)
            ' '' ''Catch ex As Exception
            ' '' ''    MsgBox("Printer Tidak Dapat Ditemukan", MsgBoxStyle.Critical)
            ' '' ''    Exit Sub
            ' '' ''End Try

            Rpt.PrintToPrinter(1, True, 1, 1)
        Catch ex As Exception
            MsgBox("Tidak Bisa Print No. Urut - " & ex.ToString)
        Finally
            Rpt.Dispose()
        End Try

        'RawPrinterHelper.SendStringToPrinter(Ps.PrinterName, Chr(27) & "M" & Chr(15))
        'RawPrinterHelper.SendStringToPrinter(Ps.PrinterName, (Chr(27) + Chr(40) + Chr(66) + Chr(15) + Chr(0) + Chr(5) + Chr(2) + Chr(0) + Chr(80) + Chr(0) + Chr(2)) & NoUrut & vbCrLf)
        'RawPrinterHelper.SendStringToPrinter(Ps.PrinterName, "" & vbCrLf)
        'RawPrinterHelper.SendStringToPrinter(Ps.PrinterName, "" & vbCrLf)

selesai: RECID()
    End Sub

    Private Sub prSticker(ByVal DC_ID As String, ByVal ID_JLR As String)
        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Dim Sdap As New OracleDataAdapter
        Dim dsSt As New DataSet
        Dim dsPal As New DataSet
        Dim StkP As String = ""
        Dim bar As String = ""
        If lblBPB_NO.Text <> "" Then
            MsgBox("Sudah Selesai BPB,Tidak Bisa cetak")
            Exit Sub
        End If

        Try
            Scon.Open()
            Scom.CommandText = "select id_daftarpo " &
                               "from dc_jlr_daftarjalur_t a," &
                                    "dc_jlr_daftarpo_t b " &
                               "where a.id_daftarjalur = " & ID_JLR & " " &
                                     "and a.id_daftarjalur=b.id_daftarjalur " &
                                     "and dc_id=" & DC_ID
            Sdap.SelectCommand = Scom
            dsSt.Clear()
            Sdap.Fill(dsSt)

            Scom.CommandText = "select alamat from dc_printer_t where Printer='STICKER' and dc_id='" & DC_ID & "' and no_hh=0"
            StkP = IIf(IsNothing(Scom.ExecuteScalar) Or IsDBNull(Scom.ExecuteScalar), "", Scom.ExecuteScalar)
            If dsSt.Tables(0).Rows.Count > 0 Then
                Dim i As Integer
                Dim jumlah As Integer
                Dim palet As Integer
                Dim tumpuk As Integer
                Dim jml As Double
                Dim stk As Double
                Dim qty As Integer = 0
                For i = 0 To dsSt.Tables(0).Rows.Count - 1
                    '' ''Scom.CommandText = "select d.PLU_KODE,e.MBR_QTY_PALET,e.MBR_PALET_TOTAL," & _
                    '' ''                          "sum(nvl(d.FRAC_HH,0)) as FRAC_HH,sum(nvl(d.FRAC,0)) as FRAC,d.plu_id " & _
                    '' ''                   "from dc_trnbpb_hdr_t c," & _
                    '' ''                        "dc_trnbpb_dtl_t d," & _
                    '' ''                        "dc_barang_dc_t e" & _
                    '' ''                   "where c.id_daftarpo = " & dsSt.Tables(0).Rows(i).Item(0) & " " & _
                    '' ''                         "and e.mbr_fk_dcid=" & DC_ID & " " & _
                    '' ''                         "and c.HDR_ID=d.HDR_FK_ID " & _
                    '' ''                         "and d.PLU_ID=e.MBR_FK_PLUID " & _
                    '' ''                         "and e.MBR_TGL_PLUMATI is null " & _
                    '' ''                   "group by d.plu_id,d.plu_kode,e.mbr_qty_palet,e.mbr_palet_total"
                    Scom.CommandText = "select nvl(c.plu_id,0) as PLUID,nvl(c.plu_kode,0) as KODE," &
                                              "nvl(c.frac_hh,0) as FRAC_HH,nvl(c.frac,0)as FRAC," &
                                              "nvl(d.MBR_QTY_PALET,0) as MBR_QTY_PALET,nvl(d.MBR_PALET_TOTAL,0) as MBR_PALET_TOTAL," &
                                              "nvl(e.PODTL_QTYB,0) as PRCD,nvl(e.PODTL_ISI_SATB,0) as SATPO " &
                                       "from dc_trnbpb_hdr_t b," &
                                             "dc_trnbpb_dtl_t c," &
                                             "dc_barang_dc_t d," &
                                             "dc_podtl_t e " &
                                       "where b.id_daftarpo = " & dsSt.Tables(0).Rows(i).Item(0) & " " &
                                              "and b.hdr_id=c.hdr_fk_id " &
                                              "and c.plu_id=d.mbr_fk_pluid " &
                                              "and c.plu_id=e.podtl_plumd " &
                                              "and c.no_po=e.podtl_fk_no_po " &
                                              "and d.mbr_tgl_plumati is null"
                    Sdap = New OracleDataAdapter
                    Sdap.SelectCommand = Scom
                    dsPal.Clear()
                    Sdap.Fill(dsPal)

                    If dsPal.Tables(0).Rows.Count = 0 Then
                        MsgBox("Tidak Ada Data")
                        Exit Try
                    End If
                    Dim k As Integer
                    Dim prcd, SatPO, pcsJual As Integer

                    For k = 0 To dsPal.Tables(0).Rows.Count - 1
                        prcd = dsPal.Tables(0).Rows(k)("PRCD")
                        SatPO = dsPal.Tables(0).Rows(k)("SATPO")
                        If dsPal.Tables(0).Rows(k)("FRAC") = 0 Then
                            GoTo selesai
                        End If

                        Scom.CommandText = "select mbr_pcs_jual " &
                               "from dc_brg_dimensi_t " &
                               "where mbr_fk_pluid=" & IFNULL(dsPal.Tables(0).Rows(k)("PLUID"), 0) & " " &
                                     "and mbr_flag_ctn='Y' "
                        pcsJual = IIf(IsNothing(Scom.ExecuteScalar) Or IsDBNull(Scom.ExecuteScalar), 0, Scom.ExecuteScalar)

                        If pcsJual = 0 Then
                            pcsJual = SatPO
                        End If

                        jumlah = dsPal.Tables(0).Rows(k)("PRCD")
                        palet = IFNULL(dsPal.Tables(0).Rows(k)("MBR_QTY_PALET"), 0)
                        tumpuk = IFNULL(dsPal.Tables(0).Rows(k)("MBR_PALET_TOTAL"), 0)

                        If palet = 0 Or tumpuk = 0 Then
                            MsgBox("PLU " & dsPal.Tables(0).Rows(k).Item("KODE") & " Qty Palet Atau Tir Per Cell Tidak Ada")
                            GoTo selesai
                        End If

                        jml = (prcd * SatPO) / pcsJual 'jumlah / palet
                        jml = IIf((Int(jml) - jml) < 0, Int(jml) + 1, jml)

                        stk = (jumlah / palet) / tumpuk
                        stk = IIf((Int(stk) - stk) < 0, Int(stk) + 1, stk)

                        Scom.CommandText = "Select mbr_barcode " &
                                           "from dc_brg_barcode_t " &
                                           "where mbr_fk_pluid=" & IFNULL(dsPal.Tables(0).Rows(k)("PLUID"), 0) & " " &
                                             "and rownum <=1 "
                        Dim Barcode As String = IIf(IsNothing(Scom.ExecuteScalar) Or IsDBNull(Scom.ExecuteScalar), 0, Scom.ExecuteScalar)

                        Dim r As Integer
                        For r = 0 To stk - 1
                            If jumlah > (palet * tumpuk) Then
                                PrintSticker(Barcode,
                                         dsPal.Tables(0).Rows(k).Item("KODE"),
                                         (palet * tumpuk), StkP, palet & "/" & jml & "/" & tumpuk)
                                jumlah = jumlah - (palet * tumpuk)
                            Else
                                PrintSticker(Barcode,
                                             dsPal.Tables(0).Rows(k).Item("KODE"),
                                             jumlah, StkP, palet & "/" & jml & "/" & tumpuk)
                            End If
                        Next
selesai:
                    Next
                Next
            End If
        Catch ex As Exception
            MsgBox("Tidak Bisa Print Sticker")
        Finally
            Scon.Close()
        End Try
    End Sub

    Private Function Print(ByVal Pr As String, ByVal Id As String) As String
        Dim _t As String = "-1"
        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)

        Try
            If Scon.State = ConnectionState.Open Then
                Scon.Close()
                Scon.Dispose()
            End If

            Scon.Open()
            If Scon.State = ConnectionState.Open Then
                Dim _t2 As String = "UPDATE DC_JLR_DAFTARJALUR_T SET PRINT_ID=" & Pr & " where ID_DAFTARJALUR=" & Id
                Scom = New OracleCommand(_t2, Scon)
                Scom.ExecuteNonQuery()
                _t = "0"
                Scom.Dispose()
                Scom = Nothing
            End If
        Catch ex As Exception
            _t = ex.Message
        End Try

        Return _t
    End Function

    Private Sub btnPrintUlang_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnPrintUlang.Click
        Dim NoUrut As String
        Dim Ps As New Printing.PrinterSettings
        Dim drSup As Object
        drSup = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Current
        Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").EndCurrentEdit()
        NoUrut = drSup.row("NOURUT")

        'Dim DC_ID As String = drSup.row("DC_ID")
        'Dim ID_PO As String = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").Current.row("ID_DAFTARPO")

        If NoUrut.Length = 2 Then
            NoUrut = "0" & NoUrut
        ElseIf NoUrut.Length = 1 Then
            NoUrut = "00" & NoUrut
        ElseIf NoUrut.Length = 0 Or NoUrut.Length > 3 Then
            MsgBox("No Urut Error, Tidak Bisa Print")
            Exit Sub
        End If
        Dim Tgl As String
        Dim m As String
        Dim d As String
        Dim day As String
        Tgl = Format(drSup.row("TANGGAL"), "MM/dd/yyyy")

        m = Tgl.Substring(0, 2)
        d = Tgl.Substring(3, 2)
        Tgl = Tgl.Substring(8, 2)
        If m.Length < 2 And d.Length < 2 Then
            m = "0" & m
            d = "0" & d
        ElseIf m.Length < 2 Then
            m = "0" & m
        ElseIf d.Length < 2 Then
            d = "0" & d
        End If
        day = d & m & Tgl
        NoUrut = "*" & NoUrut & day & "*"

        Dim Scon As New OracleConnection(ConStrORA)
        Dim Scom As New OracleCommand("", Scon)
        Dim Sdap As New OracleDataAdapter
        Dim drpt As New DataSet
        Dim namaPrt As String = ""

        Try
            Scon.Open()
            Scom.CommandText = "select a.nourut,trunc(a.tanggal) as tgl,a.SUPCO,a.SNAMA,b.TBL_DC_KODE,b.TBL_DC_NAMA " &
                               "from dc_jlr_daftarjalur_t a," &
                                    "dc_tabel_dc_t b " &
                               "where nourut='" & txtNoAntrian.Text & "' and to_char(tanggal,'dd-mm-yyyy')='" & txtTglDaftar.Text & "' " &
                                     "and a.dc_id=b.TBL_DCID"
            Sdap.SelectCommand = Scom
            drpt.Clear()
            Sdap.Fill(drpt)
            drpt.Tables(0).Columns.Add("barcode")
            drpt.Tables(0).Rows(0).Item("barcode") = NoUrut
            drpt.WriteXml(Application.StartupPath & "PrintD.xml", XmlWriteMode.WriteSchema)

            Scom.CommandText = "select alamat from dc_printer_t where Printer='DAFTAR'"
            namaPrt = Scom.ExecuteScalar()

        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            Scon.Close()
            Scon = Nothing
        End Try

        If namaPrt = "" Then
            MsgBox("Alamat Printer Nomor Urut Tidak Diketahui !!")
            Exit Sub
        End If

        'prSticker(DC_ID, ID_PO)
        Dim KtsRpt As New CrystalDecisions.CrystalReports.Engine.ReportDocument
        'ktsrpt.PrintOptions.PaperSize=
        Dim Rpt As New CrystalDecisions.CrystalReports.Engine.ReportDocument
        Try
            Rpt = New CRpt

            Rpt.SetDataSource(drpt)
            Rpt.PrintOptions.PrinterName = namaPrt
            'Rpt.PrintOptions.PaperSize = CrystalDecisions.Shared.PaperSize.PaperEnvelopePersonal
            'Rpt.PrintOptions.PaperSize = CrystalDecisions.Shared.PaperSize.DefaultPaperSize
            'Rpt.PrintOptions.PaperOrientation = CrystalDecisions.Shared.PaperOrientation.DefaultPaperOrientation
            ''Rpt.PrintOptions.PaperSize = paper_size()
            ''CrystalDecisions.Shared.PaperSize.DefaultPaperSize()
            'MsgBox(Rpt.PrintOptions.PageContentWidth & "," & Rpt.PrintOptions.PageContentHeight & "," & Rpt.PrintOptions.PageMargins.topMargin & "," & Rpt.PrintOptions.PageMargins.bottomMargin)
            'Exit Try

            ' '' ''Dim _outFile As FileStream
            ' '' ''Dim _fileWriter As StreamWriter
            ' '' ''Dim SA As SECURITY_ATTRIBUTES
            ' '' ''Try
            ' '' ''    _outFile = New FileStream(CreateFile(namaPrt, GENERIC_WRITE, 0, SA, OPEN_EXISTING, 0, 0), FileAccess.Write)
            ' '' ''    _fileWriter = New StreamWriter(_outFile)
            ' '' ''Catch ex As Exception
            ' '' ''    MsgBox("Printer Tidak Dapat Ditemukan", MsgBoxStyle.Critical)
            ' '' ''    Exit Sub
            ' '' ''End Try

            Rpt.PrintToPrinter(1, True, 0, 0)
        Catch ex As Exception
            MsgBox("Tidak Bisa Print No. Urut - " & ex.ToString)
        End Try
        Rpt.Dispose()


        'RawPrinterHelper.SendStringToPrinter(Ps.PrinterName, Chr(27) & "M" & Chr(15))
        'RawPrinterHelper.SendStringToPrinter(Ps.PrinterName, (Chr(27) + Chr(40) + Chr(66) + Chr(15) + Chr(0) + Chr(5) + Chr(2) + Chr(0) + Chr(80) + Chr(0) + Chr(2)) & NoUrut & vbCrLf)
        'RawPrinterHelper.SendStringToPrinter(Ps.PrinterName, "" & vbCrLf)
        'RawPrinterHelper.SendStringToPrinter(Ps.PrinterName, "" & vbCrLf)
        RECID()
    End Sub

    Dim brs_papersize As Integer
    Dim PgSetting As New Printing.PageSettings
    'Dim defPrinter As String 'menampung nama default Printer di comp 
    Dim ctk_rpt As New System.Drawing.Printing.PrintDocument

    Public Function paper_size() As Integer
        For i As Integer = 0 To ctk_rpt.PrinterSettings.PaperSizes.Count - 1
            'MsgBox(ctk_rpt.PrinterSettings.PaperSizes(i).PaperName)
            If ctk_rpt.PrinterSettings.PaperSizes(i).PaperName = "Card 148 x 105 mm" Then
                brs_papersize = CInt(ctk_rpt.PrinterSettings.PaperSizes(i).GetType().GetField("kind", Reflection.BindingFlags.Instance Or Reflection.BindingFlags.NonPublic).GetValue(ctk_rpt.PrinterSettings.PaperSizes(i)))
                paper_size = brs_papersize
                Exit For
            End If
        Next
        Return paper_size
    End Function

    Private Sub PrintSticker(ByVal bar As String, ByVal plu As String, ByVal qty As String, ByVal stk As String, ByVal tabcell As String)

        Dim _print As New ZebraLabels.ZebraPrint

        '_print.StartWrite("//192.168.9.104//ZebraZM4")
        _print.StartWrite(stk)
        _print.Write("^XA")  ''-->start code

        _print.Write("^FO90,40^BY4")  ''-->FO:posisi text yg akan diprint, BY:lebar barcode
        _print.Write("^BEN,100,Y,N,N")  ''-->BC:membuat barcode kode 128
        _print.Write("^FD" & bar & "^FS")  ''-->data diapit oleh FD & FS

        _print.Write("^CF0,150")
        _print.Write("^FO150,190")
        _print.Write("^FD" & plu & "^FS")

        _print.Write("^CF0,50")
        _print.Write("^FO80,320")
        _print.Write("^FDQty^FS")
        _print.Write("^FO150,320")
        _print.Write("^FD:" & qty & "^FS")
        _print.Write("^FO320,320")
        _print.Write("^FD" & tabcell & "^FS")

        _print.Write("^XZ")  ''-->end code
        _print.EndWrite()

    End Sub

    '    Public Sub mobil()
    '        If lblSUPCO.Text = "" Or lblSUPCO.Text = "lblSUPCO" Then
    '            Exit Sub
    '        End If
    '        Dim Scon As New OracleConnection(ConStrORA)
    '        Dim Scom As New OracleCommand("", Scon)
    '        Dim Sdap As New OracleDataAdapter
    '        Try
    '            Dim dt_NOMOBIL As DataTable = getDS(" SELECT nomobil FROM dc_jlr_daftarjalur_t" &
    '"  WHERE to_char(TRUNC(tanggal),'dd/mm/yyyy')='" & Format(txtTglDaftar.Value, "dd/MM/yyyy") & "' and SUPCO='" & lblSUPCO.Text & "' AND nourut = " & txtNoAntrian.Text, ConStrORA).Tables(0)

    '            If dt_NOMOBIL.Rows.Count > 0 Then
    '                LBMobil.DataSource = dt_NOMOBIL
    '                LBMobil.DisplayMember = "NOMOBIL"
    '                If btnDaftar.Enabled = True And btnTambahPO.Enabled = True Then
    '                    LBMobil.ClearSelected()
    '                End If
    '            Else
    '                Scon.Open()
    '                'Scom.CommandText = "select NOMOBIL from DC_JLR_DAFTARMOBIL_HDR_T where to_char(TRUNC(TGLMASUK),'dd/mm/yyyy')='" & Format(txtTglDaftar.Value, "dd/MM/yyyy") & "' and SUPCO='" & lblSUPCO.Text & "'"
    '                'Scom.CommandText = "select NOMOBIL from DC_JLR_DAFTARMOBIL_HDR_T where TGLMASUK=to_date('" & CmbNama.SelectedValue & "', 'MM/dd/yyyy hh:mi:ss am') and SUPCO='" & lblSUPCO.Text & "'"
    '                Scom.CommandText = "select NOMOBIL from DC_JLR_DAFTARMOBIL_HDR_T where TGLMASUK=to_date('" & Convert.ToDateTime(CmbNama.SelectedValue).ToString("MM/dd/yyyy hh:mm:ss tt") & "', 'MM/dd/yyyy hh:mi:ss am') and SUPCO='" & lblSUPCO.Text & "'"
    '                Sdap.SelectCommand = Scom
    '                ds.Clear()
    '                Sdap.Fill(ds)
    '                If ds.Tables(0).Rows.Count > 0 Then
    '                    LBMobil.DataSource = ds.Tables(0)
    '                    LBMobil.DisplayMember = "NOMOBIL"
    '                    If btnDaftar.Enabled = True And btnTambahPO.Enabled = True Then
    '                        LBMobil.ClearSelected()
    '                    End If
    '                Else
    '                    Scom.CommandText = " SELECT NOMOBIL FROM dc_jlr_daftarjalur_t" &
    '                        "  WHERE supco = '" & lblSUPCO.Text & "'" &
    '                        "    AND nourut = '" & txtNoAntrian.Text & "'" &
    '                        "    AND TO_CHAR (TRUNC (tanggal), 'dd/MM/yyyy') = '" & Format(txtTglDaftar.Value, "dd/MM/yyyy") & "'"
    '                    Sdap.SelectCommand = Scom
    '                    ds.Clear()
    '                    Sdap.Fill(ds)
    '                    LBMobil.DataSource = ds.Tables(0)
    '                    LBMobil.DisplayMember = "NOMOBIL"
    '                    If btnDaftar.Enabled = True And btnTambahPO.Enabled = True Then
    '                        LBMobil.ClearSelected()
    '                    End If
    '                End If
    '            End If
    '        Catch ex As Exception

    '        Finally
    '            Scon.Close()
    '            Scon = Nothing
    '        End Try
    '    End Sub

    Private Sub BtnPrintStck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnPrintStck.Click
        Dim drSup As Object
        drSup = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Current
        Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").EndCurrentEdit()

        Dim DC_ID As String = drSup.row("DC_ID")
        Dim ID_JLR As String = drSup.row("ID_DAFTARJALUR")
        'Dim ID_PO As String = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").Current.row("ID_DAFTARPO")
        prSticker(DC_ID, ID_JLR)
    End Sub

    Private Sub txtNoFak_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtNoFak.KeyDown
        'MsgBox(e.KeyCode)
        'Dim a As Integer = txtNoFak.Text.Length - 1
        'Dim arr = txtNoFak.Text.ToCharArray
        'Dim txt = ""
        'For i As Int16 = 0 To a
        '    If Char.IsDigit(arr(i)) = True Then
        '        txt &= arr(i)
        '    End If
        'Next
        'txtNoFak.Text = txt
    End Sub

    Private Sub txtNoFak_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNoFak.TextChanged
        Dim arr = txtNoFak.Text.ToCharArray
        Dim txt = ""
        For i As Int16 = 0 To txtNoFak.Text.Length - 1
            If Char.IsDigit(arr(i)) = True Then
                txt &= arr(i)
            End If
        Next
        txtNoFak.Text = txt
        txtNoFak.SelectionStart = txtNoFak.TextLength
    End Sub
    Public Sub btn_Next(ByVal supco As String) 'fungsi next per faktur
        Dim dt_noFaktur As New DataTable

        'If LBMobil.SelectedIndex = -1 And LBMobil.Items.Count <> 0 Then
        '    LBMobil.SelectedIndex = 0
        'End If
        'dt_noFaktur = getDS("select no_faktur, hdr_id from dc_trnbpb_hdr_t where supco = '" & supco & "' ", ConStrORA).Tables(0)
        '        dt_noFaktur = getDS(" SELECT no_faktur, hdr_id FROM dc_trnbpb_hdr_t WHERE no_faktur IN" &
        '" (SELECT no_fak FROM dc_jlr_daftarpo_t WHERE id_daftarjalur IN" &
        '" (SELECT id_daftarjalur FROM dc_jlr_daftarjalur_t WHERE supco = '" & supco & "' AND nomobil = '" & LBMobil.Text & "' )) and supco = '" & supco & "'", ConStrORA).Tables(0)
        dt_noFaktur = getDS(" SELECT no_faktur, hdr_id FROM dc_trnbpb_hdr_t WHERE no_faktur IN" &
            " (SELECT no_fak FROM dc_jlr_daftarpo_t WHERE id_daftarjalur IN" &
            " (SELECT id_daftarjalur FROM dc_jlr_daftarjalur_t WHERE supco = '" & supco & "'  )) and supco = '" & supco & "'", ConStrORA).Tables(0)
        If dt_noFaktur.Rows.Count <> 0 Then
            Pointer += 1
            If Pointer > dt_noFaktur.Rows.Count - 1 Then
                Pointer = 0 'disini coy
            End If
            txtNoFak.Text = dt_noFaktur.Rows(Pointer)(0).ToString
            Dim dt_loadPerFaktur As New DataTable
            Dim testabs As String = "  SELECT   a.no_po, b.tot_item, b.tgl_PO, SUM (a.qty) AS qty, trunc(SUM (a.nilai),8) AS nilai," &
                       "   trunc(SUM (a.ppnrp + (a.tot_disc / DECODE(NVL(ppn_persen,Getppnnew(NULL)),0,1,NVL(ppn_persen,Getppnnew(NULL))))),8) AS ppn," &
                       "   trunc(SUM (a.nilai + a.ppnrp),8) AS total" &
                   "  FROM dc_trnbpb_dtl_t a, dc_trnbpb_hdr_t b" &
                   "      WHERE a.hdr_fk_id = b.hdr_id AND a.hdr_fk_id = '" & dt_noFaktur.Rows(Pointer)(1).ToString & "'" &
                " GROUP BY a.no_po, b.tgl_po, a.hdr_fk_id, b.tot_item"
            ' dt_loadPerFaktur = getDS("SELECT SUM(qty) as qty, SUM(nilai) as nilai, SUM(ppnrp + (tot_disc/10)) as ppn, SUM(nilai+ppnrp) as total FROM dc_trnbpb_dtl_t  WHERE hdr_fk_id = " & dt_noFaktur.Rows(Pointer)(1).ToString, ConStrORA).Tables(0)
            dt_loadPerFaktur = getDS(testabs, ConStrORA).Tables(0)
            '  Dim dt_gettglpo As DataTable
            txtPO_QTY.Text = dt_loadPerFaktur.Rows(0)(3).ToString
            'txtPO_GROSS.Text = dt_loadPerFaktur.Rows(0)(4).ToString
            'txtPO_PPN.Text = dt_loadPerFaktur.Rows(0)(5).ToString
            'txtPO_Total.Text = dt_loadPerFaktur.Rows(0)(6).ToString
            txtNo_PO.Text = dt_loadPerFaktur.Rows(0)(0).ToString
            txtTgl_PO.Text = dt_loadPerFaktur.Rows(0)(2).ToString
            txtTot_Item.Text = dt_loadPerFaktur.Rows(0)(1).ToString
            'Dim 
        Else
            txtPO_QTY.Text = ""
            'txtPO_GROSS.Text = ""
            'txtPO_PPN.Text = ""
            'txtPO_Total.Text = ""
            txtNo_PO.Text = ""
            txtTgl_PO.Text = ""
            txtTot_Item.Text = ""
            txtNoFak.Text = ""
            txtTGL_MULAI.Text = ""
            txtTglFaktur.Text = ""
        End If
    End Sub

    Private Sub btn_Prev(ByVal supco As String) 'fungsi next per faktur
        Dim dt_noFaktur As New DataTable

        'If LBMobil.SelectedIndex = -1 And LBMobil.Items.Count <> 0 Then
        '    LBMobil.SelectedIndex = 0
        'End If
        'dt_noFaktur = getDS("select no_faktur, hdr_id from dc_trnbpb_hdr_t where supco = '" & supco & "' ", ConStrORA).Tables(0)
        '        dt_noFaktur = getDS(" SELECT no_faktur, hdr_id FROM dc_trnbpb_hdr_t WHERE no_faktur IN" &
        '" (SELECT no_fak FROM dc_jlr_daftarpo_t WHERE id_daftarjalur IN" &
        '" (SELECT id_daftarjalur FROM dc_jlr_daftarjalur_t WHERE supco = '" & supco & "' AND nomobil = '" & LBMobil.Text & "' )) and supco = '" & supco & "'", ConStrORA).Tables(0)
        dt_noFaktur = getDS(" SELECT no_faktur, hdr_id FROM dc_trnbpb_hdr_t WHERE no_faktur IN" &
" (SELECT no_fak FROM dc_jlr_daftarpo_t WHERE id_daftarjalur IN" &
" (SELECT id_daftarjalur FROM dc_jlr_daftarjalur_t WHERE supco = '" & supco & "'  )) and supco = '" & supco & "'", ConStrORA).Tables(0)
        If dt_noFaktur.Rows.Count <> 0 Then
            Pointer -= 1
            If Pointer < 0 Then
                Pointer = dt_noFaktur.Rows.Count - 1
            End If
            txtNoFak.Text = dt_noFaktur.Rows(Pointer)(0).ToString
            Dim dt_loadPerFaktur As New DataTable
            Dim testabs As String = "  SELECT   a.no_po, b.tot_item, b.tgl_PO, SUM (a.qty) AS qty, trunc(SUM (a.nilai),8) AS nilai," &
                "  trunc( SUM (a.ppnrp + (a.tot_disc / ppn_persen)),8) AS ppn," &
                "  trunc( SUM (a.nilai + a.ppnrp),8) AS total" &
            "  FROM dc_trnbpb_dtl_t a, dc_trnbpb_hdr_t b" &
            "      WHERE a.hdr_fk_id = b.hdr_id AND a.hdr_fk_id = '" & dt_noFaktur.Rows(Pointer)("hdr_id").ToString & "'" &
         " GROUP BY a.no_po, b.tgl_po, a.hdr_fk_id, b.tot_item"
            ' dt_loadPerFaktur = getDS("SELECT SUM(qty) as qty, SUM(nilai) as nilai, SUM(ppnrp + (tot_disc/10)) as ppn, SUM(nilai+ppnrp) as total FROM dc_trnbpb_dtl_t  WHERE hdr_fk_id = " & dt_noFaktur.Rows(Pointer)(1).ToString, ConStrORA).Tables(0)
            dt_loadPerFaktur = getDS(testabs, ConStrORA).Tables(0)
            txtPO_QTY.Text = dt_loadPerFaktur.Rows(0)(3).ToString
            'txtPO_GROSS.Text = dt_loadPerFaktur.Rows(0)(4).ToString
            'txtPO_PPN.Text = dt_loadPerFaktur.Rows(0)(5).ToString
            'txtPO_Total.Text = dt_loadPerFaktur.Rows(0)(6).ToString
            txtNo_PO.Text = dt_loadPerFaktur.Rows(0)(0).ToString
            txtTgl_PO.Text = dt_loadPerFaktur.Rows(0)(2).ToString
            txtTot_Item.Text = dt_loadPerFaktur.Rows(0)(1).ToString
            'Dim queryget As String = "SELECT nourut FROM dc_jlr_daftarjalur_t WHERE id_daftarjalur =" & _
            '" (SELECT id_daftarjalur FROM dc_jlr_daftarpo_t WHERE supco = '" & dt_noFaktur.Rows(Pointer)("supco").ToString & "' AND no_fak = '" & dt_noFaktur.Rows(Pointer)("no_fak").ToString & "' )"

            'Dim dt_getnourut As DataTable = getDS(queryget, ConStrORA).Tables(0)
            'If dt_getnourut.Rows.Count > 0 Then
            '    Dim loadnourut As String = dt_getnourut.Rows(0)(0).ToString
            '    For i As Integer = 0 To DsPO1.DC_JLR_DAFTARJALUR_T.Rows.Count - 1
            '        If DsPO1.DC_JLR_DAFTARJALUR_T.Rows(i)("NOURUT").ToString = loadnourut Then
            '            Exit For
            '        Else
            '            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position += 1
            '        End If
            '    Next
            'End If
        Else
            txtPO_QTY.Text = ""
            'txtPO_GROSS.Text = ""
            'txtPO_PPN.Text = ""
            'txtPO_Total.Text = ""
            txtNo_PO.Text = ""
            txtTgl_PO.Text = ""
            txtTot_Item.Text = ""
            txtNoFak.Text = ""
            txtTGL_MULAI.Text = ""
            txtTglFaktur.Text = ""
        End If
    End Sub
    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs) _
                              Handles txtNo_PO.KeyPress

        If Not (Asc(e.KeyChar) = 8) Then
            If Char.IsLetterOrDigit(e.KeyChar) = False Then
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub btnTambahPO_EnabledChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTambahPO.EnabledChanged
        If btnTambahPO.Enabled = True Then
            btnSimpanPO.Enabled = False
            btnBatalPO.Enabled = False
        Else
            btnSimpanPO.Enabled = True
            btnBatalPO.Enabled = True
        End If
    End Sub


    Public Sub LoadNoAntrian() Handles Me.BindingContextChanged
        Dim queryNOPO As String = ""
        If txtNo_PO.Text <> "" Then
            queryNOPO = "" '" and nopo = '" & txtNo_PO.Text & "'"
        End If
        txtNoAntrianPO.Text = execScalar(" select nvl((SELECT max(nourut_jalur) " &
                                        "   FROM DC_JLR_DAFTARPO_T " &
                                        "  WHERE id_daftarjalur = " &
                                        "           (SELECT max(id_daftarjalur) " &
                                        "              FROM DC_JLR_DAFTARJALUR_T " &
                                        "             WHERE nourut = '" & txtNoAntrian.Text & "' " &
                                        "               AND TRUNC (tanggal) = TRUNC (TO_DATE ('" & txtTglDaftar.Text & "', 'dd/mm/yyyy'))) " & queryNOPO &
                                        "  ), ' ') as nourut_jalur FROM dual", ConStrORA)

        txtKodeSupp_.Text = execScalar(" select nvl((SELECT max(supco) " &
                                        "   FROM DC_JLR_DAFTARPO_T " &
                                        "  WHERE id_daftarjalur = " &
                                        "           (SELECT max(id_daftarjalur) " &
                                        "              FROM DC_JLR_DAFTARJALUR_T " &
                                        "             WHERE nourut = '" & txtNoAntrian.Text & "' " &
                                        "               AND TRUNC (tanggal) = TRUNC (TO_DATE ('" & txtTglDaftar.Text & "', 'dd/mm/yyyy'))) " & queryNOPO &
                                        "  ), ' ') as nourut_jalur FROM dual", ConStrORA)
        txtNamaSupp_.Text = execScalar(" select nvl((SELECT max(SNAMA) " &
                                        "   FROM DC_JLR_DAFTARPO_T " &
                                        "  WHERE id_daftarjalur = " &
                                        "           (SELECT max(id_daftarjalur) " &
                                        "              FROM DC_JLR_DAFTARJALUR_T " &
                                        "             WHERE nourut = '" & txtNoAntrian.Text & "' " &
                                        "               AND TRUNC (tanggal) = TRUNC (TO_DATE ('" & txtTglDaftar.Text & "', 'dd/mm/yyyy'))) " & queryNOPO &
                                        "  ), ' ') as nourut_jalur FROM dual", ConStrORA)

    End Sub


    Public Sub LoadDataSetByDaftar()
        'Create a new dataset to hold the records returned from the call to FillDataSet.
        'A temporary dataset is used because filling the existing dataset would
        'require the databindings to be rebound.
        Dim objDataSetTemp As PendaftaranPO.DS_
        objDataSetTemp = New PendaftaranPO.DS_
        Try
            'Attempt to fill the temporary dataset.
            Me.FillDataSetByDaftar(objDataSetTemp)
        Catch eFillDataSet As System.Exception
            'Add your error handling code here.
            Throw eFillDataSet
        End Try
        Try
            'grdDC_JLR_DAFTARPO_T.DataSource = Nothing
            'grdDC_JLR_DAFTARJALUR_T.DataSource = Nothing

            'Empty the old records from the dataset.
            DsPO1.Clear()
            'Merge the records into the main dataset.
            DsPO1.Merge(objDataSetTemp)

            'grdDC_JLR_DAFTARJALUR_T.SetDataBinding(dsPo1, "DC_JLR_DAFTARJALUR_T")
            'grdDC_JLR_DAFTARPO_T.SetDataBinding(dsPo1, "DC_JLR_DAFTARJALUR_T.Daf_PO")

            'Atur Default
            DsPO1.DC_JLR_DAFTARJALUR_T.TANGGALColumn.DefaultValue = txtTglDaftar.Value.Date
            DsPO1.DC_JLR_DAFTARJALUR_T.DC_IDColumn.DefaultValue = cDC_ID
            'dsPo1.DC_JLR_DAFTARJALUR_T.NOMOBILColumn.DefaultValue = ""
            'DsPO1.DC_JLR_DAFTARJALUR_T.ID_DAFTARJALURColumn.AutoIncrementSeed = GetIdDaftarJalur()

            'dsPo1.DC_JLR_DAFTARPO_T.TANGGALColumn.DefaultValue = Now.Date
            DsPO1.DC_JLR_DAFTARPO_T.TGL_FAKColumn.DefaultValue = GetOracleDate.Date
            'DsPO1.DC_JLR_DAFTARPO_T.ID_DAFTARPOColumn.AutoIncrementSeed = GetIdDaftarPO()

            DsPO1.DC_JLR_DAFTARPO_T.SUPCOColumn.DefaultValue = ""
        Catch eLoadMerge As System.Exception
            'Add your error handling code here.
            Throw eLoadMerge
        End Try

    End Sub
    Public Sub Cari_LoadNoAntrian()  
        Dim queryNOPO As String = ""
        If Cari_NOPO <> "" Then
            queryNOPO = " and nopo = '" & Cari_NOPO & "'"
        End If
        txtNoAntrianPO.Text = execScalar(" SELECT nourut_jalur " & _
                                        "   FROM DC_JLR_DAFTARPO_T " & _
                                        "  WHERE id_daftarpo = " & Cari_ID_DAFTARPO & _
                                        "   and supco = '" & Cari_SUPCO & "'" & _
                                        "   AND TRUNC (tanggal) = TRUNC (TO_DATE ('" & Cari_TANGGAL & "', 'mm/dd/yyyy')) " & queryNOPO _
                                         , ConStrORA)
        Cari_NOURUT_JALUR = txtNoAntrianPO.Text
        txtKodeSupp_.Text = Cari_KODESUPP
        txtNamaSupp_.Text = Cari_NAMASUPP


    End Sub
    Public Function execScalar(ByVal Query As String, ByVal conStr As String) As String
        Dim connection As New OracleConnection(conStr)
        Dim cmd As New OracleCommand("", connection)
        Dim adapter As New OracleDataAdapter
        Try
            If connection.State = ConnectionState.Open Then
                connection.Close()
            End If
            connection.Open()
            'Buat data adapter
            cmd = New OracleCommand(Query, connection)
            execScalar = cmd.ExecuteScalar() 'IIf(IsDBNull(cmd.ExecuteScalar()), 0, cmd.ExecuteScalar())
            Return execScalar
        Catch ex As Exception
            Return "-_GAGAL_-" & ex.Message
        Finally
            connection.Close()
        End Try
    End Function
End Class



