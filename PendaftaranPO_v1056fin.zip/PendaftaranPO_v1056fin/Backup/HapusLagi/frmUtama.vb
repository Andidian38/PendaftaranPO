Imports IDM.Fungsi
'Imports System.Data.OracleClient

Public Class frmUtama
    Inherits System.Windows.Forms.Form

    Private _NIK As String
    Dim Jam As String
    Friend WithEvents btnDraftRetur As System.Windows.Forms.Button
    Dim Tgl As String

    Protected Overrides Sub OnHandleCreated(ByVal e As System.EventArgs)
        Dim CurrentProcesses() As Process
        CurrentProcesses = Process.GetProcessesByName _
                           (Process.GetCurrentProcess.ProcessName)
        If CurrentProcesses.GetUpperBound(0) <= 0 Then
            Exit Sub
        End If
        Dim i As Integer
        Dim ProcessHandle As Long
        For i = 0 To CurrentProcesses.GetUpperBound(0)
            ProcessHandle = CurrentProcesses(i).MainWindowHandle.ToInt32
        Next
        End

    End Sub

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnDaftar As System.Windows.Forms.Button
    Friend WithEvents picIDM As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents lblUser As System.Windows.Forms.Label
    Friend WithEvents lblDC As System.Windows.Forms.Label
    Friend WithEvents lblGudang As System.Windows.Forms.Label
    Friend WithEvents lblLok As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents btnKeluar As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmUtama))
        Me.btnDaftar = New System.Windows.Forms.Button
        Me.picIDM = New System.Windows.Forms.PictureBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.lblLok = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.lblGudang = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.lblDC = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.lblUser = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.btnKeluar = New System.Windows.Forms.Button
        Me.btnDraftRetur = New System.Windows.Forms.Button
        CType(Me.picIDM, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnDaftar
        '
        Me.btnDaftar.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnDaftar.Location = New System.Drawing.Point(18, 136)
        Me.btnDaftar.Name = "btnDaftar"
        Me.btnDaftar.Size = New System.Drawing.Size(91, 28)
        Me.btnDaftar.TabIndex = 5
        Me.btnDaftar.Text = "&Daftar"
        '
        'picIDM
        '
        Me.picIDM.Image = CType(resources.GetObject("picIDM.Image"), System.Drawing.Image)
        Me.picIDM.Location = New System.Drawing.Point(293, 9)
        Me.picIDM.Name = "picIDM"
        Me.picIDM.Size = New System.Drawing.Size(176, 80)
        Me.picIDM.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.picIDM.TabIndex = 26
        Me.picIDM.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.lblLok)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.lblGudang)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.lblDC)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.lblUser)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 8)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(255, 116)
        Me.GroupBox1.TabIndex = 31
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "&Info User"
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(80, 92)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(15, 14)
        Me.Label9.TabIndex = 11
        Me.Label9.Text = ":"
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(80, 69)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(15, 14)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = ":"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(80, 46)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(15, 14)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = ":"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(80, 23)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(15, 14)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = ":"
        '
        'lblLok
        '
        Me.lblLok.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLok.Location = New System.Drawing.Point(95, 92)
        Me.lblLok.Name = "lblLok"
        Me.lblLok.Size = New System.Drawing.Size(150, 16)
        Me.lblLok.TabIndex = 7
        Me.lblLok.Text = "lblLokasi"
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(14, 92)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(63, 16)
        Me.Label8.TabIndex = 6
        Me.Label8.Text = "Lokasi"
        '
        'lblGudang
        '
        Me.lblGudang.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGudang.Location = New System.Drawing.Point(95, 69)
        Me.lblGudang.Name = "lblGudang"
        Me.lblGudang.Size = New System.Drawing.Size(150, 16)
        Me.lblGudang.TabIndex = 5
        Me.lblGudang.Text = "lblGudang"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(14, 69)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(63, 16)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Gudang"
        '
        'lblDC
        '
        Me.lblDC.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDC.Location = New System.Drawing.Point(95, 46)
        Me.lblDC.Name = "lblDC"
        Me.lblDC.Size = New System.Drawing.Size(150, 16)
        Me.lblDC.TabIndex = 3
        Me.lblDC.Text = "lblDC"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(14, 46)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(63, 16)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "DC"
        '
        'lblUser
        '
        Me.lblUser.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUser.Location = New System.Drawing.Point(95, 23)
        Me.lblUser.Name = "lblUser"
        Me.lblUser.Size = New System.Drawing.Size(150, 16)
        Me.lblUser.TabIndex = 1
        Me.lblUser.Text = "lblUser"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(14, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(83, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Nama User"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(277, 99)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(223, 23)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "PT. INDOMARCO PRISMATAMA"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnKeluar
        '
        Me.btnKeluar.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnKeluar.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnKeluar.Location = New System.Drawing.Point(389, 136)
        Me.btnKeluar.Name = "btnKeluar"
        Me.btnKeluar.Size = New System.Drawing.Size(91, 28)
        Me.btnKeluar.TabIndex = 33
        Me.btnKeluar.Text = "&Keluar"
        '
        'btnDraftRetur
        '
        Me.btnDraftRetur.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnDraftRetur.Location = New System.Drawing.Point(140, 136)
        Me.btnDraftRetur.Name = "btnDraftRetur"
        Me.btnDraftRetur.Size = New System.Drawing.Size(117, 28)
        Me.btnDraftRetur.TabIndex = 34
        Me.btnDraftRetur.Text = "&Cetak Draft Retur"
        '
        'frmUtama
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.CancelButton = Me.btnKeluar
        Me.ClientSize = New System.Drawing.Size(504, 176)
        Me.Controls.Add(Me.btnDraftRetur)
        Me.Controls.Add(Me.btnKeluar)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.picIDM)
        Me.Controls.Add(Me.btnDaftar)
        Me.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "frmUtama"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Antrian DC"
        CType(Me.picIDM, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub frmUtama_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = Application.ProductName & " v" & Application.ProductVersion
        'Dim Scon As New OracleConnection(ConStrORA)
        'Dim Scom As New OracleCommand("", Scon)
        'Dim Sdap As New OracleDataAdapter("", Scon)

        'Dim Scon As New OleDb.OleDbConnection(ConStrORA)
        'Dim Scom As New OleDb.OleDbCommand("", Scon)
        'Dim Sdap As New OleDb.OleDbDataAdapter("", Scon)
        'Dim dt As New DataTable
        'Try
        '    Scon.Open()
        '    Sdap.SelectCommand.CommandText = "SELECT * FROM DC_JLR_ANTRIAN_T"
        '    Sdap.Fill(dt)
        '    DataGrid1.DataSource = dt

        'Catch ex As Exception
        '    ShowError("Error Load Form Utama", ex)
        'Finally
        '    Scon.Close()
        'End Try

        'MAIN
        'ConStrORA = "user id=DCSIM;data source=SIMULASIA;password=DCSIM"
        'Dim Scon As New OracleConnection(ConStrORA)
        'Dim Scom As New OracleCommand("", Scon)
        'Dim Sdar As OracleDataReader

        Dim cUsrOra As String = GetSetting("Indomaret\AntrianDC", "Setup", "U")
        Dim cPassOra As String = GetSetting("Indomaret\AntrianDC", "Setup", "P")
        Dim cTnsOra As String = GetSetting("Indomaret\AntrianDC", "Setup", "S")

        If cTnsOra = "" Then
            MessageBox.Show("Setting Server Oracle Kurang.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            SaveSetting("Indomaret\AntrianDC", "Setup", "U", "DCSIM")
            SaveSetting("Indomaret\AntrianDC", "Setup", "P", "DCSIM")
            SaveSetting("Indomaret\AntrianDC", "Setup", "S", "SIMULASIA")
            Exit Sub
        End If

        ConStrORA = "Provider=MSDAORA.1;User ID=" & cUsrOra & ";password=" & cPassOra & ";Data Source=" & cTnsOra & ""

        Me.Text = Application.ProductName & " v" & Application.ProductVersion & " [" & cTnsOra & "]"

        Dim Scon As New OleDb.OleDbConnection(ConStrORA)
        Dim Scom As New OleDb.OleDbCommand("", Scon)
        Dim Sdar As OleDb.OleDbDataReader

        Dim Sql As String

        'If GetSetting("Indomaret\JalurDC ORA", "Setup", "OraData") <> "1" Then
        '    Call SetUpDbOra()
        '    Call SaveSetting("Indomaret\JalurDC ORA", "Setup", "OraData", "1")
        'End If

        Dim f As New FormLogin
        f.Text = "Login - [" & Application.ProductName & " v" & Application.ProductVersion & "]"
        Dim lcount As Integer = 0
        Try
            Scon.Open()

Pass:
            If f.ShowDialog() <> Windows.Forms.DialogResult.OK Then
                Me.Close()
                Exit Sub
            End If

            Dim cUser As String, cPass As String
            cUser = f.txtUser.Text.Replace("'", "")
            cPass = f.txtPass.Text
            'Todo: Hilangkan Password
            'If cUser = "" Then
            '    cUser = "BPO1"
            '    cPass = "7670"
            'End If
            cUser = cUser.ToUpper
            cPass = cPass.ToUpper
            Scom.CommandText = "Select Count(*) as JUM from DC_USER_T " & _
                "Where UPPER(USER_NAME)='" & cUser & "' AND UPPER(USER_PASSWORD)='" & cPass & "'"
            If Scom.ExecuteScalar = 0 Then
                MsgBox("NAMA USER ATAU PASSWORD SALAH.", vbCritical)
                If lcount = 2 Then
                    Me.Close()
                    Exit Sub
                End If
                lcount += 1
                GoTo Pass
            End If
            f.Dispose()

            'Cek HAK
            Sql = " SELECT U.USER_NAME,DC.TBL_DCID,DC.TBL_DC_KODE,DC.TBL_DC_NAMA,"
            Sql &= "U.USER_FK_TBL_DEPOID,G.TBL_GUDANG_KODE,"
            Sql &= "G.TBL_GUDANG_NAMA,U.USER_FK_TBL_LOKASIID,L.TBL_LOKASI_KODE,"
            Sql &= "L.TBL_LOKASIID,L.TBL_LOKASI_NAMA,L.TBL_LOKASI_TYPE "
            Sql &= "from DC_USER_T U "
            Sql &= "LEFT JOIN DC_TABEL_DC_T DC ON U.USER_FK_TBL_DCID = DC.TBL_DCID "
            Sql &= "LEFT JOIN DC_TABEL_GUDANG_T G ON U.USER_FK_TBL_DEPOID=G.TBL_GUDANGID "
            Sql &= "LEFT JOIN DC_TABEL_LOKASI_T L ON U.USER_FK_TBL_LOKASIID=L.TBL_LOKASIID "
            Sql &= "WHERE 1=1 "
            Sql &= "AND USER_NAME='" & cUser & "' "
            'Sql &= "AND L.TBL_LOKASI_TYPE='BAIK' "
            Scom.CommandText = Sql
            Dim ds As New DataSet
            Dim da As New OleDb.OleDbDataAdapter
            da.SelectCommand = Scom
            da.Fill(ds)
            Sdar = Scom.ExecuteReader

            Sdar.Read()
            cDC_ID = "" & Sdar("TBL_DCID")
            cDC_KODE = "" & Sdar("TBL_DC_KODE")
            cDC_NAMA = "" & Sdar("TBL_DC_NAMA")

            cGUDANG_ID = "" & Sdar("USER_FK_TBL_DEPOID")
            cGUDANG_KODE = "" & Sdar("TBL_GUDANG_KODE")
            cGUDANG_NAMA = "" & Sdar("TBL_GUDANG_NAMA")

            cLOKASI_KODE = "" & Sdar("TBL_LOKASIID")
            cLOKASI_TYPE = "" & Sdar("TBL_LOKASI_TYPE")
            Sdar.Close()

            'Cek DC
            'Scom.CommandText = "SELECT USER_FK_TBL_DCID from DC_USER_T " & _
            '    "Where USER_NAME='" & cUser & "' AND USER_PASSWORD='" & cPass & "'"
            'cDC_ID = "" & Scom.ExecuteScalar
            If cDC_ID = "" Then
                'Pilih DC Sendiri
                Dim fp As New frmPilih
                fp.Text = "PILIH KODE DC - " & Application.ProductName

                Scom.CommandText = "Select TBL_DCID,TBL_DC_KODE,TBL_DC_NAMA FROM DC_TABEL_DC_T ORDER BY TBL_DC_KODE"
                Sdar = Scom.ExecuteReader
                Dim ls As New Collection

                fp.ListBox1.Items.Clear()
                Do While Sdar.Read
                    'ls.Add(Sdar("TBL_DC_KODE") & " - " & Sdar("TBL_DC_NAMA"), Sdar("TBL_DCID"))
                    ls.Add(Sdar("TBL_DCID"))

                    fp.ListBox1.Items.Add(Sdar("TBL_DC_KODE") & " - " & Sdar("TBL_DC_NAMA"))
                    'fp.ListBox1.Items.Add(ls)
                Loop
                Sdar.Close()
                fp.ListBox1.SelectedIndex = 0

                If fp.ShowDialog <> Windows.Forms.DialogResult.OK Then
                    Exit Sub
                End If
                cDC_ID = ls(fp.ListBox1.SelectedIndex + 1)
                cDC_KODE = fp.ListBox1.SelectedItem

                cDC_NAMA = cDC_KODE.Substring(cDC_KODE.IndexOf("-") + 2)
                cDC_KODE = cDC_KODE.Substring(0, cDC_KODE.IndexOf("-") - 1)

                fp.Dispose()
                ls = Nothing

            Else
                ''PUNYA DC
                'Scom.CommandText = "Select TBL_DCID,TBL_DC_KODE,TBL_DC_NAMA FROM DC_TABEL_DC_T " & _
                '    "WHERE TBL_DC_ID='" & cDC_ID & "'"
                'Sdar = Scom.ExecuteReader
                'Do While Sdar.Read
                '    cDC_KODE = Sdar("TBL_DC_KODE")
                '    cDC_NAMA = Sdar("TBL_DC_NAMA")
                'Loop
                'Sdar.Close()
            End If

            'Cek DEPO
            If cGUDANG_KODE = "" Then
                'Pilih DC Sendiri
                Dim fp As New frmPilih
                fp.Text = "PILIH DEPO - " & Application.ProductName

                Scom.CommandText = "Select TBL_GUDANGID,TBL_GUDANG_KODE,TBL_GUDANG_NAMA " & _
                    "FROM DC_TABEL_GUDANG_T " & _
                    "WHERE TBL_FK_DCID='" & cDC_ID & "' ORDER BY TBL_GUDANG_KODE"
                Sdar = Scom.ExecuteReader
                Dim ls As New Collection

                fp.ListBox1.Items.Clear()
                Do While Sdar.Read
                    'ls.Add(Sdar("TBL_DC_KODE") & " - " & Sdar("TBL_DC_NAMA"), Sdar("TBL_DCID"))
                    ls.Add(Sdar("TBL_GUDANGID"))

                    fp.ListBox1.Items.Add(Sdar("TBL_GUDANG_KODE") & " - " & Sdar("TBL_GUDANG_NAMA"))
                    'fp.ListBox1.Items.Add(ls)
                Loop
                Sdar.Close()
                Try
                    fp.ListBox1.SelectedIndex = 0
                Catch
                    MessageBox.Show("Tidak Ada Data Gudang.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End Try


                If fp.ShowDialog <> Windows.Forms.DialogResult.OK Then
                    Exit Sub
                End If
                cGUDANG_ID = ls(fp.ListBox1.SelectedIndex + 1)
                cGUDANG_KODE = fp.ListBox1.SelectedItem

                cGUDANG_NAMA = cGUDANG_KODE.Substring(cGUDANG_KODE.IndexOf("-") + 2)
                cGUDANG_KODE = cGUDANG_KODE.Substring(0, cGUDANG_KODE.IndexOf("-") - 1)

                fp.Dispose()
                ls = Nothing

                'Cek Lokasinya
                Scom.CommandText = "SELECT TBL_LOKASIID,TBL_LOKASI_TYPE FROM DC_TABEL_LOKASI_T " & _
                    "WHERE TBL_FK_GUDANGID='" & cGUDANG_ID & "' " & _
                    "AND TBL_LOKASI_TYPE='BAIK'"
                Sdar = Scom.ExecuteReader
                If Sdar.Read Then
                    cLOKASI_KODE = "" & Sdar("TBL_LOKASIID")
                    cLOKASI_TYPE = "" & Sdar("TBL_LOKASI_TYPE")
                End If
                Sdar.Close()
            End If


            'Cek Lokasi
            If cLOKASI_TYPE <> "BAIK" Then
                MsgBox("User Bukan Untuk Lokasi Barang Baik.", vbCritical)
                Me.Close()
                Exit Sub
            End If


            Scom.CommandText = "Select COUNT(*) From DC_JLR_Setting_T WHERE DC_ID=" & cDC_ID
            If Scom.ExecuteScalar = 0 Then
                Scom.CommandText = "INSERT INTO DC_JLR_SETTING_T(DC_ID,NEXTNOURUT,LASTDATE) VALUES(" & cDC_ID & ",1,TRUNC(SYSDATE))"
                Scom.ExecuteNonQuery()
                GoTo UPD
            End If

            Scom.CommandText = "Select Trunc(LastDate) as LastDate From DC_JLR_Setting_T WHERE DC_ID=" & cDC_ID
            If Scom.ExecuteScalar <> Now.Date Then
UPD:            Sql = "UPDATE DC_JLR_Antrian_T Set Recid='O',Supplier=NULL,NoAntrian=Null Where DC_ID=" & cDC_ID & ""
                Scom.CommandText = Sql
                Scom.ExecuteNonQuery()

                Sql = "UPDATE DC_JLR_Setting_T Set NextNoUrut=1,LastDate=Trunc(sysdate) Where DC_ID=" & cDC_ID & ""
                Scom.CommandText = Sql
                Scom.ExecuteNonQuery()

                Sql = "Delete from DC_JLR_TempAntrian_T Where DC_ID=" & cDC_ID & ""
                Scom.CommandText = Sql
                Scom.ExecuteNonQuery()
            End If

            If Scom.ExecuteScalar > Now.Date Then
                MessageBox.Show("Program tidak bisa Mundur Tanggal", Application.ProductName, MessageBoxButtons.OK)
                Exit Try
            End If

            If ds.Tables(0).Rows.Count > 1 Then
                lblDC.Visible = False
                lblGudang.Visible = False
                lblLok.Visible = False
            End If
            'Dim fu As New frmUtama
            lblUser.Text = cUser
            lblDC.Text = cDC_KODE & " - " & cDC_NAMA
            lblGudang.Text = cGUDANG_NAMA
            lblLok.Text = cLOKASI_TYPE
            'Dim fu As New DataForm1
            SignIn(lblUser.Text, cDC_ID)
        Catch ex As Exception
            ShowError("Error Initial Data.", ex)
            Me.Close()
        Finally
            Scon.Close()
        End Try
    End Sub

    Private Sub btnDaftar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDaftar.Click
        Me.Visible = False
        Dim f As New frmDaftarPOEdit
        f.ShowDialog()

        Me.Visible = True
    End Sub
    Private Sub btnKeluar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKeluar.Click
        Me.Close()
    End Sub
    Private Sub frmUtama_Leave(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles MyBase.FormClosed
        SignOut(cDC_ID)
    End Sub

    Private Function SignIn(ByVal _Usr As String, ByVal GD_ID As String) As String
        Dim _t As String = "-1"
        Dim Scon As New OleDb.OleDbConnection(ConStrORA)
        Dim Scom As New OleDb.OleDbCommand("", Scon)

        Try
            If Scon.State = ConnectionState.Open Then
                Scon.Close()
                Scon.Dispose()
            End If

            Scom.CommandText = "select USER_NIK from dc_user_t where user_name='" & _Usr & "'"
            Scon.Open()
            _NIK = Scom.ExecuteScalar.ToString
            Scon.Close()

            If _NIK = "" Then
                MsgBox("NIK User " & _Usr & " tidak ada, User tidak dapat melakukan presensi")
                _t = "-1"
                Return _t
                Exit Function
            End If

            Scon.Open()
            If Scon.State = ConnectionState.Open Then
                Jam = Now.Hour & ":" & Now.Minute & ":" & Now.Second
                Tgl = Now.Day & "/" & Now.Month & "/" & Now.Year
                Dim _t2 As String = "INSERT INTO DC_ADMIN_ABSEN_T (NIK,TGL_LOGIN,JAM_LOGIN,DCID) VALUES" & _
                                    "('" & _NIK & "',to_date('" & Tgl & "','dd/mm/yy'),'" & Jam & "'," & GD_ID & ")"
                Scom = New OleDb.OleDbCommand(_t2, Scon)
                Scom.ExecuteNonQuery()
                _t = "0"
                Scom.Dispose()
                Scom = Nothing
            End If
        Catch ex As Exception
            _t = ex.Message
        End Try

        Return _t
    End Function

    Private Function SignOut(ByVal GD_ID As String) As String
        Dim _t As String = "-1"
        Dim Scon As New OleDb.OleDbConnection(ConStrORA)
        Dim Scom As New OleDb.OleDbCommand("", Scon)
        Dim Jam_kluar As String
        Dim Tgl_kluar As String

        Try
            If Scon.State = ConnectionState.Open Then
                Scon.Close()
            End If

            If _NIK = "" Then
                _t = "-1"
                Return _t
                Exit Function
            End If

            Scon.Open()
            If Scon.State = ConnectionState.Open Then
                Jam_kluar = Now.Hour & ":" & Now.Minute & ":" & Now.Second
                Tgl_kluar = Now.Day & "/" & Now.Month & "/" & Now.Year
                Dim _t2 As String = "UPDATE DC_ADMIN_ABSEN_T SET TGL_LOGOUT=to_date('" & Tgl_kluar & "','dd/mm/yy'),JAM_LOGOUT='" & Jam_kluar & "' " & _
                                    "where NIK='" & _NIK & "' and TGL_LOGIN=to_date('" & Tgl & "','dd/mm/yy') and JAM_LOGIN='" & Jam & "' and DCID=" & GD_ID
                Scom = New OleDb.OleDbCommand(_t2, Scon)
                Scom.ExecuteNonQuery()
                _t = "0"
                Scom.Dispose()
                Scom = Nothing
            End If
        Catch ex As Exception
            _t = ex.Message
        End Try

        Return _t
    End Function

    Private Sub btnDraftRetur_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDraftRetur.Click
        Me.Visible = False
        Dim f As New frmDraftRSupp
        f.ShowDialog()

        Me.Visible = True
    End Sub
End Class
