﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("JalurOracleBaru")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("intraco")> 
<Assembly: AssemblyProduct("JalurOracleBaru")> 
<Assembly: AssemblyCopyright("Copyright © intraco 2009")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("1581102b-b9ec-4a3c-8710-8722acfd2a7f")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.1.5")> 
<Assembly: AssemblyFileVersion("1.0.1.5")> 
