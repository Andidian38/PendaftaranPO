<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDraftRSupp
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpSup = New System.Windows.Forms.GroupBox
        Me.CmbSupco = New System.Windows.Forms.ComboBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.btnBatal = New System.Windows.Forms.Button
        Me.CmbNama = New System.Windows.Forms.ComboBox
        Me.grpHidden = New System.Windows.Forms.GroupBox
        Me.lblTglRevisi = New System.Windows.Forms.Label
        Me.lblSUPID = New System.Windows.Forms.Label
        Me.lblLokasiKode = New System.Windows.Forms.Label
        Me.lblGudangKode = New System.Windows.Forms.Label
        Me.btnDraftRetur = New System.Windows.Forms.Button
        Me.Label7 = New System.Windows.Forms.Label
        Me.grpSup.SuspendLayout()
        Me.grpHidden.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpSup
        '
        Me.grpSup.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpSup.BackColor = System.Drawing.Color.Goldenrod
        Me.grpSup.Controls.Add(Me.CmbSupco)
        Me.grpSup.Controls.Add(Me.Label1)
        Me.grpSup.Controls.Add(Me.btnBatal)
        Me.grpSup.Controls.Add(Me.CmbNama)
        Me.grpSup.Controls.Add(Me.grpHidden)
        Me.grpSup.Controls.Add(Me.btnDraftRetur)
        Me.grpSup.Controls.Add(Me.Label7)
        Me.grpSup.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpSup.Location = New System.Drawing.Point(2, 2)
        Me.grpSup.Name = "grpSup"
        Me.grpSup.Size = New System.Drawing.Size(536, 129)
        Me.grpSup.TabIndex = 6
        Me.grpSup.TabStop = False
        Me.grpSup.Text = " &Supplier"
        '
        'CmbSupco
        '
        Me.CmbSupco.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.CmbSupco.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.CmbSupco.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.CmbSupco.FormattingEnabled = True
        Me.CmbSupco.Location = New System.Drawing.Point(59, 22)
        Me.CmbSupco.Name = "CmbSupco"
        Me.CmbSupco.Size = New System.Drawing.Size(75, 24)
        Me.CmbSupco.TabIndex = 76
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(5, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(60, 20)
        Me.Label1.TabIndex = 75
        Me.Label1.Text = "Kode  :"
        '
        'btnBatal
        '
        Me.btnBatal.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnBatal.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnBatal.Location = New System.Drawing.Point(291, 78)
        Me.btnBatal.Name = "btnBatal"
        Me.btnBatal.Size = New System.Drawing.Size(86, 37)
        Me.btnBatal.TabIndex = 74
        Me.btnBatal.Text = "&Batal"
        '
        'CmbNama
        '
        Me.CmbNama.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.CmbNama.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.CmbNama.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.CmbNama.FormattingEnabled = True
        Me.CmbNama.Location = New System.Drawing.Point(59, 48)
        Me.CmbNama.Name = "CmbNama"
        Me.CmbNama.Size = New System.Drawing.Size(468, 24)
        Me.CmbNama.TabIndex = 73
        '
        'grpHidden
        '
        Me.grpHidden.Controls.Add(Me.lblTglRevisi)
        Me.grpHidden.Controls.Add(Me.lblSUPID)
        Me.grpHidden.Controls.Add(Me.lblLokasiKode)
        Me.grpHidden.Controls.Add(Me.lblGudangKode)
        Me.grpHidden.Location = New System.Drawing.Point(478, 135)
        Me.grpHidden.Name = "grpHidden"
        Me.grpHidden.Size = New System.Drawing.Size(200, 149)
        Me.grpHidden.TabIndex = 18
        Me.grpHidden.TabStop = False
        '
        'lblTglRevisi
        '
        Me.lblTglRevisi.Location = New System.Drawing.Point(22, 92)
        Me.lblTglRevisi.Name = "lblTglRevisi"
        Me.lblTglRevisi.Size = New System.Drawing.Size(100, 16)
        Me.lblTglRevisi.TabIndex = 23
        Me.lblTglRevisi.Text = "lblTglRevisi"
        '
        'lblSUPID
        '
        Me.lblSUPID.Location = New System.Drawing.Point(20, 63)
        Me.lblSUPID.Name = "lblSUPID"
        Me.lblSUPID.Size = New System.Drawing.Size(100, 16)
        Me.lblSUPID.TabIndex = 22
        Me.lblSUPID.Text = "lblSUPID"
        '
        'lblLokasiKode
        '
        Me.lblLokasiKode.Location = New System.Drawing.Point(20, 39)
        Me.lblLokasiKode.Name = "lblLokasiKode"
        Me.lblLokasiKode.Size = New System.Drawing.Size(100, 16)
        Me.lblLokasiKode.TabIndex = 17
        Me.lblLokasiKode.Text = "LokasiKode"
        '
        'lblGudangKode
        '
        Me.lblGudangKode.Location = New System.Drawing.Point(20, 15)
        Me.lblGudangKode.Name = "lblGudangKode"
        Me.lblGudangKode.Size = New System.Drawing.Size(100, 16)
        Me.lblGudangKode.TabIndex = 16
        Me.lblGudangKode.Text = "GudangKode"
        '
        'btnDraftRetur
        '
        Me.btnDraftRetur.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnDraftRetur.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnDraftRetur.Location = New System.Drawing.Point(133, 78)
        Me.btnDraftRetur.Name = "btnDraftRetur"
        Me.btnDraftRetur.Size = New System.Drawing.Size(86, 37)
        Me.btnDraftRetur.TabIndex = 6
        Me.btnDraftRetur.Text = "&Draft Retur"
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label7.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.Location = New System.Drawing.Point(5, 51)
        Me.Label7.Name = "Label7"
        Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label7.Size = New System.Drawing.Size(60, 20)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Nama  :"
        '
        'frmDraftRSupp
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BackColor = System.Drawing.Color.Goldenrod
        Me.ClientSize = New System.Drawing.Size(540, 133)
        Me.Controls.Add(Me.grpSup)
        Me.MaximizeBox = False
        Me.Name = "frmDraftRSupp"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmDraftRSupp"
        Me.grpSup.ResumeLayout(False)
        Me.grpHidden.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents grpSup As System.Windows.Forms.GroupBox
    Friend WithEvents CmbNama As System.Windows.Forms.ComboBox
    Friend WithEvents grpHidden As System.Windows.Forms.GroupBox
    Friend WithEvents lblTglRevisi As System.Windows.Forms.Label
    Friend WithEvents lblSUPID As System.Windows.Forms.Label
    Friend WithEvents lblLokasiKode As System.Windows.Forms.Label
    Friend WithEvents lblGudangKode As System.Windows.Forms.Label
    Friend WithEvents btnDraftRetur As System.Windows.Forms.Button
    Public WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents btnBatal As System.Windows.Forms.Button
    Friend WithEvents CmbSupco As System.Windows.Forms.ComboBox
    Public WithEvents Label1 As System.Windows.Forms.Label
End Class
