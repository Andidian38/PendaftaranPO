﻿Partial Class dsPO
    Partial Class DC_JLR_DAFTARPO_TDataTable

        Private Sub DC_JLR_DAFTARPO_TDataTable_ColumnChanging(ByVal sender As System.Object, ByVal e As System.Data.DataColumnChangeEventArgs) Handles Me.ColumnChanging
            If (e.Column.ColumnName = Me.TotalColumn.ColumnName) Then
                'Add user code here
            End If

        End Sub

    End Class

    Partial Class DC_JLR_DAFTARJALUR_TDataTable

        Private Sub DC_JLR_DAFTARJALUR_TDataTable_DC_JLR_DAFTARJALUR_TRowChanging(ByVal sender As System.Object, ByVal e As DC_JLR_DAFTARJALUR_TRowChangeEvent) Handles Me.DC_JLR_DAFTARJALUR_TRowChanging

        End Sub

    End Class

End Class
