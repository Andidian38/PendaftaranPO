Imports IDM.Fungsi
Imports System.Data.OleDb

Public Class frmDaftarPO
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        Me.txtTglFaktur.BackColor = System.Drawing.SystemColors.Window
        Me.txtTglFaktur.ForeColor = System.Drawing.SystemColors.WindowText

        'Format Textbox
        Dim bd As Binding
        bd = txtPO_GROSS.DataBindings("Text")
        AddHandler bd.Format, AddressOf formatTextBox
        AddHandler bd.Parse, AddressOf formatTextBox

        'bd = txtPO_QTY.DataBindings("Text")
        'AddHandler bd.Format, AddressOf formatTextBox
        'AddHandler bd.Parse, AddressOf formatTextBox

        bd = txtPO_PPN.DataBindings("Text")
        AddHandler bd.Format, AddressOf formatTextBox
        AddHandler bd.Parse, AddressOf formatTextBox

        bd = txtPO_Total.DataBindings("Text")
        AddHandler bd.Format, AddressOf formatTextBox
        AddHandler bd.Parse, AddressOf formatTextBox
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents btnCancelAll As System.Windows.Forms.Button
    Friend WithEvents oldapMobil As System.Data.OleDb.OleDbDataAdapter
    Friend WithEvents oldapPO As System.Data.OleDb.OleDbDataAdapter
    Friend WithEvents olcon As System.Data.OleDb.OleDbConnection
    Public WithEvents txtNoAntrian As System.Windows.Forms.TextBox
    Public WithEvents Label17 As System.Windows.Forms.Label
    Public WithEvents Label26 As System.Windows.Forms.Label
    Public WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents btnNext As System.Windows.Forms.Button
    Friend WithEvents btnPrev As System.Windows.Forms.Button
    Friend WithEvents btnDaftar As System.Windows.Forms.Button
    Friend WithEvents grpMobil As System.Windows.Forms.GroupBox
    Friend WithEvents btnTambahPO As System.Windows.Forms.Button
    Public WithEvents Frame4 As System.Windows.Forms.GroupBox
    Public WithEvents lblBPB_NO As System.Windows.Forms.Label
    Public WithEvents Label16 As System.Windows.Forms.Label
    Public WithEvents Label15 As System.Windows.Forms.Label
    Public WithEvents Label14 As System.Windows.Forms.Label
    Public WithEvents lblStatus As System.Windows.Forms.Label
    Public WithEvents lblStatusKeterangan As System.Windows.Forms.Label
    Public WithEvents Frame1 As System.Windows.Forms.GroupBox
    Public WithEvents txtTgl_PO As FlexMaskEditBox
    Public WithEvents txtNo_PO As System.Windows.Forms.TextBox
    Public WithEvents txtSUPCO As System.Windows.Forms.TextBox
    Public WithEvents txtNamaSupp As System.Windows.Forms.TextBox
    Public WithEvents txtPO_QTY As System.Windows.Forms.TextBox
    Public WithEvents txtPO_GROSS As System.Windows.Forms.TextBox
    Public WithEvents txtPO_PPN As System.Windows.Forms.TextBox
    Public WithEvents txtPO_Total As System.Windows.Forms.TextBox
    Public WithEvents chkBUAT_PO As System.Windows.Forms.CheckBox
    Public WithEvents chkADA_HARGA As System.Windows.Forms.CheckBox
    Public WithEvents txtTot_Item As System.Windows.Forms.TextBox
    Public WithEvents Label1 As System.Windows.Forms.Label
    Public WithEvents Label2 As System.Windows.Forms.Label
    Public WithEvents Label3 As System.Windows.Forms.Label
    Public WithEvents Label7 As System.Windows.Forms.Label
    Public WithEvents Label10 As System.Windows.Forms.Label
    Public WithEvents Label11 As System.Windows.Forms.Label
    Public WithEvents Label12 As System.Windows.Forms.Label
    Public WithEvents Label13 As System.Windows.Forms.Label
    Public WithEvents Label8 As System.Windows.Forms.Label
    Public WithEvents Label9 As System.Windows.Forms.Label
    Public WithEvents Label4 As System.Windows.Forms.Label
    Public WithEvents Frame2 As System.Windows.Forms.GroupBox
    Public WithEvents txtNoFak As System.Windows.Forms.TextBox
    Public WithEvents Label5 As System.Windows.Forms.Label
    Public WithEvents Label6 As System.Windows.Forms.Label
    Public WithEvents Frame3 As System.Windows.Forms.GroupBox
    Public WithEvents txtUPDATE As System.Windows.Forms.TextBox
    Public WithEvents txtTGL_AKHIR As FlexMaskEditBox
    Public WithEvents txtTGL_MULAI As FlexMaskEditBox
    Public WithEvents Label18 As System.Windows.Forms.Label
    Public WithEvents Label19 As System.Windows.Forms.Label
    Public WithEvents Label20 As System.Windows.Forms.Label
    Public WithEvents Label21 As System.Windows.Forms.Label
    Public WithEvents Label22 As System.Windows.Forms.Label
    Public WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents grpDaftar As System.Windows.Forms.GroupBox
    Friend WithEvents btnSimpanPO As System.Windows.Forms.Button
    Friend WithEvents btnBatalPO As System.Windows.Forms.Button
    Friend WithEvents btnNext2 As System.Windows.Forms.Button
    Friend WithEvents btnPrev2 As System.Windows.Forms.Button
    Friend WithEvents btnEditPO As System.Windows.Forms.Button
    Friend WithEvents btnHapusPO As System.Windows.Forms.Button
    Friend WithEvents cmbFilter As System.Windows.Forms.ComboBox
    Friend WithEvents txtTglFaktur As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtTglDaftar As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblSUPID As System.Windows.Forms.Label
    Friend WithEvents lblSUPCO As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents lblSNAMA As System.Windows.Forms.Label
    Friend WithEvents OleDbSelectCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbInsertCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbUpdateCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbDeleteCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents DsPO1 As AntrianDC.dsPO
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents OleDbSelectCommand2 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbInsertCommand2 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbUpdateCommand2 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbDeleteCommand2 As System.Data.OleDb.OleDbCommand
    Friend WithEvents lblLokasiKode As System.Windows.Forms.Label
    Friend WithEvents lblGudangKode As System.Windows.Forms.Label
    Public WithEvents txtSupID As System.Windows.Forms.TextBox
    Public WithEvents txtLokasiKode As System.Windows.Forms.TextBox
    Public WithEvents txtGudangkode As System.Windows.Forms.TextBox
    Friend WithEvents grpHidden As System.Windows.Forms.GroupBox
    Friend WithEvents btnKeluar As System.Windows.Forms.Button
    Friend WithEvents lblTglRevisi As System.Windows.Forms.Label
    Friend WithEvents lblIdDaftarPO As System.Windows.Forms.Label
    Friend WithEvents btnDraftRetur As System.Windows.Forms.Button
    Public WithEvents txtNoMobil As System.Windows.Forms.TextBox
    Friend WithEvents btnCari As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDaftarPO))
        Me.olcon = New System.Data.OleDb.OleDbConnection
        Me.oldapMobil = New System.Data.OleDb.OleDbDataAdapter
        Me.OleDbDeleteCommand1 = New System.Data.OleDb.OleDbCommand
        Me.OleDbInsertCommand1 = New System.Data.OleDb.OleDbCommand
        Me.OleDbSelectCommand1 = New System.Data.OleDb.OleDbCommand
        Me.OleDbUpdateCommand1 = New System.Data.OleDb.OleDbCommand
        Me.oldapPO = New System.Data.OleDb.OleDbDataAdapter
        Me.OleDbDeleteCommand2 = New System.Data.OleDb.OleDbCommand
        Me.OleDbInsertCommand2 = New System.Data.OleDb.OleDbCommand
        Me.OleDbSelectCommand2 = New System.Data.OleDb.OleDbCommand
        Me.OleDbUpdateCommand2 = New System.Data.OleDb.OleDbCommand
        Me.btnUpdate = New System.Windows.Forms.Button
        Me.btnCancelAll = New System.Windows.Forms.Button
        Me.grpMobil = New System.Windows.Forms.GroupBox
        Me.btnDraftRetur = New System.Windows.Forms.Button
        Me.btnCari = New System.Windows.Forms.Button
        Me.Label27 = New System.Windows.Forms.Label
        Me.lblSNAMA = New System.Windows.Forms.Label
        Me.DsPO1 = New AntrianDC.dsPO
        Me.lblSUPCO = New System.Windows.Forms.Label
        Me.txtTglDaftar = New System.Windows.Forms.DateTimePicker
        Me.txtNoMobil = New System.Windows.Forms.TextBox
        Me.txtNoAntrian = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.btnNext = New System.Windows.Forms.Button
        Me.btnPrev = New System.Windows.Forms.Button
        Me.btnDaftar = New System.Windows.Forms.Button
        Me.btnTambahPO = New System.Windows.Forms.Button
        Me.grpDaftar = New System.Windows.Forms.GroupBox
        Me.Frame4 = New System.Windows.Forms.GroupBox
        Me.lblBPB_NO = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.lblStatus = New System.Windows.Forms.Label
        Me.lblStatusKeterangan = New System.Windows.Forms.Label
        Me.Frame1 = New System.Windows.Forms.GroupBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.txtTgl_PO = New AntrianDC.FlexMaskEditBox
        Me.txtNo_PO = New System.Windows.Forms.TextBox
        Me.txtSUPCO = New System.Windows.Forms.TextBox
        Me.txtNamaSupp = New System.Windows.Forms.TextBox
        Me.txtPO_QTY = New System.Windows.Forms.TextBox
        Me.txtPO_GROSS = New System.Windows.Forms.TextBox
        Me.txtPO_PPN = New System.Windows.Forms.TextBox
        Me.txtPO_Total = New System.Windows.Forms.TextBox
        Me.chkBUAT_PO = New System.Windows.Forms.CheckBox
        Me.chkADA_HARGA = New System.Windows.Forms.CheckBox
        Me.txtTot_Item = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Frame2 = New System.Windows.Forms.GroupBox
        Me.txtTglFaktur = New System.Windows.Forms.DateTimePicker
        Me.txtNoFak = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Frame3 = New System.Windows.Forms.GroupBox
        Me.txtSupID = New System.Windows.Forms.TextBox
        Me.txtLokasiKode = New System.Windows.Forms.TextBox
        Me.txtGudangkode = New System.Windows.Forms.TextBox
        Me.txtUPDATE = New System.Windows.Forms.TextBox
        Me.txtTGL_AKHIR = New AntrianDC.FlexMaskEditBox
        Me.txtTGL_MULAI = New AntrianDC.FlexMaskEditBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.lblIdDaftarPO = New System.Windows.Forms.Label
        Me.lblSUPID = New System.Windows.Forms.Label
        Me.lblLokasiKode = New System.Windows.Forms.Label
        Me.lblGudangKode = New System.Windows.Forms.Label
        Me.cmbFilter = New System.Windows.Forms.ComboBox
        Me.btnHapusPO = New System.Windows.Forms.Button
        Me.btnEditPO = New System.Windows.Forms.Button
        Me.btnNext2 = New System.Windows.Forms.Button
        Me.btnPrev2 = New System.Windows.Forms.Button
        Me.btnBatalPO = New System.Windows.Forms.Button
        Me.btnSimpanPO = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.btnKeluar = New System.Windows.Forms.Button
        Me.grpHidden = New System.Windows.Forms.GroupBox
        Me.lblTglRevisi = New System.Windows.Forms.Label
        Me.grpMobil.SuspendLayout()
        CType(Me.DsPO1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpDaftar.SuspendLayout()
        Me.Frame4.SuspendLayout()
        Me.Frame1.SuspendLayout()
        Me.Frame2.SuspendLayout()
        Me.Frame3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.grpHidden.SuspendLayout()
        Me.SuspendLayout()
        '
        'olcon
        '
        Me.olcon.ConnectionString = "Provider=""MSDAORA.1"";User ID=DCSIM;Data Source=SIMULASIA;Password=dcsim"
        '
        'oldapMobil
        '
        Me.oldapMobil.DeleteCommand = Me.OleDbDeleteCommand1
        Me.oldapMobil.InsertCommand = Me.OleDbInsertCommand1
        Me.oldapMobil.SelectCommand = Me.OleDbSelectCommand1
        Me.oldapMobil.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "DC_JLR_DAFTARJALUR_T", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("ID_DAFTARJALUR", "ID_DAFTARJALUR"), New System.Data.Common.DataColumnMapping("DC_ID", "DC_ID"), New System.Data.Common.DataColumnMapping("TANGGAL", "TANGGAL"), New System.Data.Common.DataColumnMapping("RECID", "RECID"), New System.Data.Common.DataColumnMapping("NOMOBIL", "NOMOBIL"), New System.Data.Common.DataColumnMapping("NOURUT", "NOURUT"), New System.Data.Common.DataColumnMapping("SUPCO", "SUPCO"), New System.Data.Common.DataColumnMapping("SNAMA", "SNAMA"), New System.Data.Common.DataColumnMapping("ITEM", "ITEMnya"), New System.Data.Common.DataColumnMapping("RUPIAH", "RUPIAH"), New System.Data.Common.DataColumnMapping("TGLSTART", "TGLSTART"), New System.Data.Common.DataColumnMapping("TGLEND", "TGLEND"), New System.Data.Common.DataColumnMapping("JALUR", "JALUR")})})
        Me.oldapMobil.UpdateCommand = Me.OleDbUpdateCommand1
        '
        'OleDbDeleteCommand1
        '
        Me.OleDbDeleteCommand1.CommandText = "DELETE FROM DC_JLR_DAFTARJALUR_T WHERE (ID_DAFTARJALUR = ?)"
        Me.OleDbDeleteCommand1.Connection = Me.olcon
        Me.OleDbDeleteCommand1.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("ID_DAFTARJALUR", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Original, Nothing)})
        '
        'OleDbInsertCommand1
        '
        Me.OleDbInsertCommand1.CommandText = "INSERT INTO DC_JLR_DAFTARJALUR_T(ID_DAFTARJALUR, DC_ID, TANGGAL, RECID, NOMOBIL, " & _
            "NOURUT, SUPCO, SNAMA, ITEM, RUPIAH, TGLSTART, TGLEND, JALUR) VALUES (?, ?, ?, ?," & _
            " ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        Me.OleDbInsertCommand1.Connection = Me.olcon
        Me.OleDbInsertCommand1.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("ID_DAFTARJALUR", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("DC_ID", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "DC_ID", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TANGGAL", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TANGGAL"), New System.Data.OleDb.OleDbParameter("RECID", System.Data.OleDb.OleDbType.VarChar, 1, "RECID"), New System.Data.OleDb.OleDbParameter("NOMOBIL", System.Data.OleDb.OleDbType.VarChar, 11, "NOMOBIL"), New System.Data.OleDb.OleDbParameter("NOURUT", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "NOURUT", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("SUPCO", System.Data.OleDb.OleDbType.VarChar, 4, "SUPCO"), New System.Data.OleDb.OleDbParameter("SNAMA", System.Data.OleDb.OleDbType.VarChar, 50, "SNAMA"), New System.Data.OleDb.OleDbParameter("ITEM", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("RUPIAH", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TGLSTART", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGLSTART"), New System.Data.OleDb.OleDbParameter("TGLEND", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGLEND"), New System.Data.OleDb.OleDbParameter("JALUR", System.Data.OleDb.OleDbType.VarChar, 50, "JALUR")})
        '
        'OleDbSelectCommand1
        '
        Me.OleDbSelectCommand1.CommandText = "SELECT ID_DAFTARJALUR, DC_ID, TANGGAL, RECID, NOMOBIL, NOURUT, SUPCO, SNAMA, ITEM" & _
            ", RUPIAH, TGLSTART, TGLEND, JALUR FROM DC_JLR_DAFTARJALUR_T "
        Me.OleDbSelectCommand1.Connection = Me.olcon
        '
        'OleDbUpdateCommand1
        '
        Me.OleDbUpdateCommand1.CommandText = resources.GetString("OleDbUpdateCommand1.CommandText")
        Me.OleDbUpdateCommand1.Connection = Me.olcon
        Me.OleDbUpdateCommand1.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("ID_DAFTARJALUR", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("DC_ID", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "DC_ID", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TANGGAL", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TANGGAL"), New System.Data.OleDb.OleDbParameter("RECID", System.Data.OleDb.OleDbType.VarChar, 1, "RECID"), New System.Data.OleDb.OleDbParameter("NOMOBIL", System.Data.OleDb.OleDbType.VarChar, 11, "NOMOBIL"), New System.Data.OleDb.OleDbParameter("NOURUT", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "NOURUT", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("SUPCO", System.Data.OleDb.OleDbType.VarChar, 4, "SUPCO"), New System.Data.OleDb.OleDbParameter("SNAMA", System.Data.OleDb.OleDbType.VarChar, 50, "SNAMA"), New System.Data.OleDb.OleDbParameter("ITEM", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("RUPIAH", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TGLSTART", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGLSTART"), New System.Data.OleDb.OleDbParameter("TGLEND", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGLEND"), New System.Data.OleDb.OleDbParameter("JALUR", System.Data.OleDb.OleDbType.VarChar, 50, "JALUR"), New System.Data.OleDb.OleDbParameter("Original_ID_DAFTARJALUR", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_DC_ID", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "DC_ID", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ITEM", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ITEM1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JALUR", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JALUR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JALUR1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JALUR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_NOMOBIL", System.Data.OleDb.OleDbType.VarChar, 11, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "NOMOBIL", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_NOURUT", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "NOURUT", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_NOURUT1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "NOURUT", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RECID", System.Data.OleDb.OleDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "RECID", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RECID1", System.Data.OleDb.OleDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "RECID", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RUPIAH", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RUPIAH1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SNAMA", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SNAMA", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SNAMA1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SNAMA", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SUPCO", System.Data.OleDb.OleDbType.VarChar, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SUPCO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SUPCO1", System.Data.OleDb.OleDbType.VarChar, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SUPCO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TANGGAL", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TANGGAL", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TANGGAL1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TANGGAL", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGLEND", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGLEND", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGLEND1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGLEND", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGLSTART", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGLSTART", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGLSTART1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGLSTART", System.Data.DataRowVersion.Original, Nothing)})
        '
        'oldapPO
        '
        Me.oldapPO.DeleteCommand = Me.OleDbDeleteCommand2
        Me.oldapPO.InsertCommand = Me.OleDbInsertCommand2
        Me.oldapPO.SelectCommand = Me.OleDbSelectCommand2
        Me.oldapPO.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "DC_JLR_DAFTARPO_T", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("ID_DAFTARPO", "ID_DAFTARPO"), New System.Data.Common.DataColumnMapping("TANGGAL", "TANGGAL"), New System.Data.Common.DataColumnMapping("RECID", "RECID"), New System.Data.Common.DataColumnMapping("ID_DAFTARJALUR", "ID_DAFTARJALUR"), New System.Data.Common.DataColumnMapping("NO_FAK", "NO_FAK"), New System.Data.Common.DataColumnMapping("TGL_FAK", "TGL_FAK"), New System.Data.Common.DataColumnMapping("NOPO", "NOPO"), New System.Data.Common.DataColumnMapping("SUPCO", "SUPCO"), New System.Data.Common.DataColumnMapping("SNAMA", "SNAMA"), New System.Data.Common.DataColumnMapping("BUAT_PO", "BUAT_PO"), New System.Data.Common.DataColumnMapping("ADA_HARGA", "ADA_HARGA"), New System.Data.Common.DataColumnMapping("QTY", "QTY"), New System.Data.Common.DataColumnMapping("ITEM", "ITEMnya"), New System.Data.Common.DataColumnMapping("RUPIAH", "RUPIAH"), New System.Data.Common.DataColumnMapping("PPN", "PPN"), New System.Data.Common.DataColumnMapping("BPB_NO", "BPB_NO"), New System.Data.Common.DataColumnMapping("TGL_MULAI", "TGL_MULAI"), New System.Data.Common.DataColumnMapping("JAM_MULAI", "JAM_MULAI"), New System.Data.Common.DataColumnMapping("TGL_AKHIR", "TGL_AKHIR"), New System.Data.Common.DataColumnMapping("JAM_AKHIR", "JAM_AKHIR"), New System.Data.Common.DataColumnMapping("JML_MOBIL", "JML_MOBIL"), New System.Data.Common.DataColumnMapping("TGL_REVISI", "TGL_REVISI"), New System.Data.Common.DataColumnMapping("JAM_REVISI", "JAM_REVISI"), New System.Data.Common.DataColumnMapping("USER_NAME", "USER_NAME"), New System.Data.Common.DataColumnMapping("MRBREAD", "MRBREAD"), New System.Data.Common.DataColumnMapping("UPDATE", "UPDATE"), New System.Data.Common.DataColumnMapping("SUPID", "SUPID"), New System.Data.Common.DataColumnMapping("GUDANG_KODE", "GUDANG_KODE"), New System.Data.Common.DataColumnMapping("LOKASI_KODE", "LOKASI_KODE"), New System.Data.Common.DataColumnMapping("TOTAL", "Total"), New System.Data.Common.DataColumnMapping("STATUS", "Status")})})
        Me.oldapPO.UpdateCommand = Me.OleDbUpdateCommand2
        '
        'OleDbDeleteCommand2
        '
        Me.OleDbDeleteCommand2.CommandText = "DELETE FROM DC_JLR_DAFTARPO_T WHERE (ID_DAFTARPO = ?)"
        Me.OleDbDeleteCommand2.Connection = Me.olcon
        Me.OleDbDeleteCommand2.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("ID_DAFTARPO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARPO", System.Data.DataRowVersion.Original, Nothing)})
        '
        'OleDbInsertCommand2
        '
        Me.OleDbInsertCommand2.CommandText = resources.GetString("OleDbInsertCommand2.CommandText")
        Me.OleDbInsertCommand2.Connection = Me.olcon
        Me.OleDbInsertCommand2.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("ID_DAFTARPO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARPO", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TANGGAL", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TANGGAL"), New System.Data.OleDb.OleDbParameter("RECID", System.Data.OleDb.OleDbType.VarChar, 1, "RECID"), New System.Data.OleDb.OleDbParameter("ID_DAFTARJALUR", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("NO_FAK", System.Data.OleDb.OleDbType.VarChar, 15, "NO_FAK"), New System.Data.OleDb.OleDbParameter("TGL_FAK", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_FAK"), New System.Data.OleDb.OleDbParameter("NOPO", System.Data.OleDb.OleDbType.VarChar, 9, "NOPO"), New System.Data.OleDb.OleDbParameter("SUPCO", System.Data.OleDb.OleDbType.VarChar, 4, "SUPCO"), New System.Data.OleDb.OleDbParameter("SNAMA", System.Data.OleDb.OleDbType.VarChar, 50, "SNAMA"), New System.Data.OleDb.OleDbParameter("BUAT_PO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BUAT_PO", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("ADA_HARGA", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ADA_HARGA", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("QTY", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "QTY", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("ITEM", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("RUPIAH", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("PPN", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "PPN", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("BPB_NO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BPB_NO", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TGL_MULAI", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_MULAI"), New System.Data.OleDb.OleDbParameter("JAM_MULAI", System.Data.OleDb.OleDbType.VarChar, 8, "JAM_MULAI"), New System.Data.OleDb.OleDbParameter("TGL_AKHIR", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_AKHIR"), New System.Data.OleDb.OleDbParameter("JAM_AKHIR", System.Data.OleDb.OleDbType.VarChar, 8, "JAM_AKHIR"), New System.Data.OleDb.OleDbParameter("JML_MOBIL", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "JML_MOBIL", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TGL_REVISI", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_REVISI"), New System.Data.OleDb.OleDbParameter("JAM_REVISI", System.Data.OleDb.OleDbType.VarChar, 8, "JAM_REVISI"), New System.Data.OleDb.OleDbParameter("USER_NAME", System.Data.OleDb.OleDbType.VarChar, 15, "USER_NAME"), New System.Data.OleDb.OleDbParameter("MRBREAD", System.Data.OleDb.OleDbType.VarChar, 1, "MRBREAD"), New System.Data.OleDb.OleDbParameter("UPDATE", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "UPDATE"), New System.Data.OleDb.OleDbParameter("SUPID", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "SUPID", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("GUDANG_KODE", System.Data.OleDb.OleDbType.VarChar, 8, "GUDANG_KODE"), New System.Data.OleDb.OleDbParameter("LOKASI_KODE", System.Data.OleDb.OleDbType.VarChar, 8, "LOKASI_KODE")})
        '
        'OleDbSelectCommand2
        '
        Me.OleDbSelectCommand2.CommandText = resources.GetString("OleDbSelectCommand2.CommandText")
        Me.OleDbSelectCommand2.Connection = Me.olcon
        '
        'OleDbUpdateCommand2
        '
        Me.OleDbUpdateCommand2.CommandText = resources.GetString("OleDbUpdateCommand2.CommandText")
        Me.OleDbUpdateCommand2.Connection = Me.olcon
        Me.OleDbUpdateCommand2.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("ID_DAFTARPO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARPO", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TANGGAL", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TANGGAL"), New System.Data.OleDb.OleDbParameter("RECID", System.Data.OleDb.OleDbType.VarChar, 1, "RECID"), New System.Data.OleDb.OleDbParameter("ID_DAFTARJALUR", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("NO_FAK", System.Data.OleDb.OleDbType.VarChar, 15, "NO_FAK"), New System.Data.OleDb.OleDbParameter("TGL_FAK", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_FAK"), New System.Data.OleDb.OleDbParameter("NOPO", System.Data.OleDb.OleDbType.VarChar, 9, "NOPO"), New System.Data.OleDb.OleDbParameter("SUPCO", System.Data.OleDb.OleDbType.VarChar, 4, "SUPCO"), New System.Data.OleDb.OleDbParameter("SNAMA", System.Data.OleDb.OleDbType.VarChar, 50, "SNAMA"), New System.Data.OleDb.OleDbParameter("BUAT_PO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BUAT_PO", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("ADA_HARGA", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ADA_HARGA", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("QTY", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "QTY", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("ITEM", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("RUPIAH", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("PPN", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "PPN", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("BPB_NO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BPB_NO", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TGL_MULAI", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_MULAI"), New System.Data.OleDb.OleDbParameter("JAM_MULAI", System.Data.OleDb.OleDbType.VarChar, 8, "JAM_MULAI"), New System.Data.OleDb.OleDbParameter("TGL_AKHIR", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_AKHIR"), New System.Data.OleDb.OleDbParameter("JAM_AKHIR", System.Data.OleDb.OleDbType.VarChar, 8, "JAM_AKHIR"), New System.Data.OleDb.OleDbParameter("JML_MOBIL", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "JML_MOBIL", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TGL_REVISI", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_REVISI"), New System.Data.OleDb.OleDbParameter("JAM_REVISI", System.Data.OleDb.OleDbType.VarChar, 8, "JAM_REVISI"), New System.Data.OleDb.OleDbParameter("USER_NAME", System.Data.OleDb.OleDbType.VarChar, 15, "USER_NAME"), New System.Data.OleDb.OleDbParameter("MRBREAD", System.Data.OleDb.OleDbType.VarChar, 1, "MRBREAD"), New System.Data.OleDb.OleDbParameter("UPDATE", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "UPDATE"), New System.Data.OleDb.OleDbParameter("SUPID", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "SUPID", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("GUDANG_KODE", System.Data.OleDb.OleDbType.VarChar, 8, "GUDANG_KODE"), New System.Data.OleDb.OleDbParameter("LOKASI_KODE", System.Data.OleDb.OleDbType.VarChar, 8, "LOKASI_KODE"), New System.Data.OleDb.OleDbParameter("Original_ID_DAFTARPO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARPO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ADA_HARGA", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ADA_HARGA", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ADA_HARGA1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ADA_HARGA", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_BPB_NO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BPB_NO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_BPB_NO1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BPB_NO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_BUAT_PO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BUAT_PO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_BUAT_PO1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BUAT_PO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_GUDANG_KODE", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "GUDANG_KODE", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_GUDANG_KODE1", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "GUDANG_KODE", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ID_DAFTARJALUR", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ID_DAFTARJALUR1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ITEM", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ITEM1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JAM_AKHIR", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JAM_AKHIR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JAM_AKHIR1", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JAM_AKHIR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JAM_MULAI", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JAM_MULAI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JAM_MULAI1", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JAM_MULAI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JAM_REVISI", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JAM_REVISI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JAM_REVISI1", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JAM_REVISI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JML_MOBIL", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "JML_MOBIL", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JML_MOBIL1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "JML_MOBIL", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_LOKASI_KODE", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LOKASI_KODE", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_LOKASI_KODE1", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LOKASI_KODE", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_MRBREAD", System.Data.OleDb.OleDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "MRBREAD", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_MRBREAD1", System.Data.OleDb.OleDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "MRBREAD", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_NOPO", System.Data.OleDb.OleDbType.VarChar, 9, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "NOPO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_NOPO1", System.Data.OleDb.OleDbType.VarChar, 9, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "NOPO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_NO_FAK", System.Data.OleDb.OleDbType.VarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "NO_FAK", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_NO_FAK1", System.Data.OleDb.OleDbType.VarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "NO_FAK", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_PPN", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "PPN", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_PPN1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "PPN", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_QTY", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "QTY", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_QTY1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "QTY", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RECID", System.Data.OleDb.OleDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "RECID", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RECID1", System.Data.OleDb.OleDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "RECID", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RUPIAH", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RUPIAH1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SNAMA", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SNAMA", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SNAMA1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SNAMA", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SUPCO", System.Data.OleDb.OleDbType.VarChar, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SUPCO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SUPID", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "SUPID", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SUPID1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "SUPID", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TANGGAL", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TANGGAL", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TANGGAL1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TANGGAL", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_AKHIR", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_AKHIR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_AKHIR1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_AKHIR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_FAK", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_FAK", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_FAK1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_FAK", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_MULAI", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_MULAI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_MULAI1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_MULAI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_REVISI", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_REVISI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_REVISI1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_REVISI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_UPDATE", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UPDATE", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_UPDATE1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UPDATE", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_USER_NAME", System.Data.OleDb.OleDbType.VarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "USER_NAME", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_USER_NAME1", System.Data.OleDb.OleDbType.VarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "USER_NAME", System.Data.DataRowVersion.Original, Nothing)})
        '
        'btnUpdate
        '
        Me.btnUpdate.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnUpdate.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnUpdate.Location = New System.Drawing.Point(576, 16)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(75, 23)
        Me.btnUpdate.TabIndex = 1
        Me.btnUpdate.Text = "&Update"
        Me.btnUpdate.Visible = False
        '
        'btnCancelAll
        '
        Me.btnCancelAll.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCancelAll.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnCancelAll.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnCancelAll.Location = New System.Drawing.Point(576, 48)
        Me.btnCancelAll.Name = "btnCancelAll"
        Me.btnCancelAll.Size = New System.Drawing.Size(75, 23)
        Me.btnCancelAll.TabIndex = 2
        Me.btnCancelAll.Text = "Ca&ncel All"
        Me.btnCancelAll.Visible = False
        '
        'grpMobil
        '
        Me.grpMobil.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpMobil.BackColor = System.Drawing.Color.Goldenrod
        Me.grpMobil.Controls.Add(Me.btnDraftRetur)
        Me.grpMobil.Controls.Add(Me.btnCari)
        Me.grpMobil.Controls.Add(Me.Label27)
        Me.grpMobil.Controls.Add(Me.lblSNAMA)
        Me.grpMobil.Controls.Add(Me.lblSUPCO)
        Me.grpMobil.Controls.Add(Me.txtTglDaftar)
        Me.grpMobil.Controls.Add(Me.txtNoMobil)
        Me.grpMobil.Controls.Add(Me.txtNoAntrian)
        Me.grpMobil.Controls.Add(Me.Label17)
        Me.grpMobil.Controls.Add(Me.Label26)
        Me.grpMobil.Controls.Add(Me.Label24)
        Me.grpMobil.Controls.Add(Me.btnNext)
        Me.grpMobil.Controls.Add(Me.btnPrev)
        Me.grpMobil.Controls.Add(Me.btnDaftar)
        Me.grpMobil.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpMobil.Location = New System.Drawing.Point(7, 6)
        Me.grpMobil.Name = "grpMobil"
        Me.grpMobil.Size = New System.Drawing.Size(678, 84)
        Me.grpMobil.TabIndex = 5
        Me.grpMobil.TabStop = False
        Me.grpMobil.Text = " &Kendaraan"
        '
        'btnDraftRetur
        '
        Me.btnDraftRetur.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnDraftRetur.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnDraftRetur.Location = New System.Drawing.Point(501, 21)
        Me.btnDraftRetur.Name = "btnDraftRetur"
        Me.btnDraftRetur.Size = New System.Drawing.Size(82, 23)
        Me.btnDraftRetur.TabIndex = 6
        Me.btnDraftRetur.Text = "&Draft Retur"
        '
        'btnCari
        '
        Me.btnCari.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnCari.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnCari.Location = New System.Drawing.Point(108, 54)
        Me.btnCari.Name = "btnCari"
        Me.btnCari.Size = New System.Drawing.Size(82, 23)
        Me.btnCari.TabIndex = 5
        Me.btnCari.Text = "&Cari"
        '
        'Label27
        '
        Me.Label27.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(200, 59)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(98, 15)
        Me.Label27.TabIndex = 66
        Me.Label27.Text = "Kode Supplier :"
        '
        'lblSNAMA
        '
        Me.lblSNAMA.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.SNAMA", True))
        Me.lblSNAMA.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSNAMA.Location = New System.Drawing.Point(353, 59)
        Me.lblSNAMA.Name = "lblSNAMA"
        Me.lblSNAMA.Size = New System.Drawing.Size(327, 15)
        Me.lblSNAMA.TabIndex = 65
        Me.lblSNAMA.Text = "lblSNAMA"
        '
        'DsPO1
        '
        Me.DsPO1.DataSetName = "dsPO"
        Me.DsPO1.Locale = New System.Globalization.CultureInfo("en-US")
        Me.DsPO1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'lblSUPCO
        '
        Me.lblSUPCO.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.SUPCO", True))
        Me.lblSUPCO.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSUPCO.Location = New System.Drawing.Point(298, 59)
        Me.lblSUPCO.Name = "lblSUPCO"
        Me.lblSUPCO.Size = New System.Drawing.Size(58, 15)
        Me.lblSUPCO.TabIndex = 64
        Me.lblSUPCO.Text = "lblSUPCO"
        '
        'txtTglDaftar
        '
        Me.txtTglDaftar.CustomFormat = "dd-MM-yyyy"
        Me.txtTglDaftar.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.TANGGAL", True))
        Me.txtTglDaftar.Enabled = False
        Me.txtTglDaftar.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.txtTglDaftar.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.txtTglDaftar.Location = New System.Drawing.Point(242, 23)
        Me.txtTglDaftar.Name = "txtTglDaftar"
        Me.txtTglDaftar.Size = New System.Drawing.Size(95, 23)
        Me.txtTglDaftar.TabIndex = 3
        '
        'txtNoMobil
        '
        Me.txtNoMobil.AcceptsReturn = True
        Me.txtNoMobil.BackColor = System.Drawing.SystemColors.Window
        Me.txtNoMobil.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtNoMobil.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtNoMobil.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.NOMOBIL", True))
        Me.txtNoMobil.Enabled = False
        Me.txtNoMobil.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNoMobil.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtNoMobil.Location = New System.Drawing.Point(82, 23)
        Me.txtNoMobil.MaxLength = 10
        Me.txtNoMobil.Name = "txtNoMobil"
        Me.txtNoMobil.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtNoMobil.Size = New System.Drawing.Size(81, 23)
        Me.txtNoMobil.TabIndex = 1
        Me.txtNoMobil.Tag = "1"
        '
        'txtNoAntrian
        '
        Me.txtNoAntrian.AcceptsReturn = True
        Me.txtNoAntrian.BackColor = System.Drawing.SystemColors.Window
        Me.txtNoAntrian.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtNoAntrian.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.NOURUT", True))
        Me.txtNoAntrian.Enabled = False
        Me.txtNoAntrian.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNoAntrian.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtNoAntrian.Location = New System.Drawing.Point(442, 22)
        Me.txtNoAntrian.Name = "txtNoAntrian"
        Me.txtNoAntrian.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtNoAntrian.Size = New System.Drawing.Size(46, 23)
        Me.txtNoAntrian.TabIndex = 5
        Me.txtNoAntrian.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label17.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label17.Location = New System.Drawing.Point(10, 27)
        Me.Label17.Name = "Label17"
        Me.Label17.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label17.Size = New System.Drawing.Size(78, 19)
        Me.Label17.TabIndex = 0
        Me.Label17.Text = "No. Mobil :"
        '
        'Label26
        '
        Me.Label26.BackColor = System.Drawing.Color.Transparent
        Me.Label26.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label26.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label26.Location = New System.Drawing.Point(169, 27)
        Me.Label26.Name = "Label26"
        Me.Label26.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label26.Size = New System.Drawing.Size(80, 19)
        Me.Label26.TabIndex = 2
        Me.Label26.Text = "Tanggal :"
        '
        'Label24
        '
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label24.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label24.Location = New System.Drawing.Point(360, 25)
        Me.Label24.Name = "Label24"
        Me.Label24.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label24.Size = New System.Drawing.Size(95, 19)
        Me.Label24.TabIndex = 4
        Me.Label24.Text = "No. Antrian :"
        '
        'btnNext
        '
        Me.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnNext.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnNext.Location = New System.Drawing.Point(633, 22)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(38, 23)
        Me.btnNext.TabIndex = 8
        Me.btnNext.Text = ">>"
        '
        'btnPrev
        '
        Me.btnPrev.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnPrev.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnPrev.Location = New System.Drawing.Point(589, 22)
        Me.btnPrev.Name = "btnPrev"
        Me.btnPrev.Size = New System.Drawing.Size(38, 23)
        Me.btnPrev.TabIndex = 7
        Me.btnPrev.Text = "<<"
        '
        'btnDaftar
        '
        Me.btnDaftar.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnDaftar.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnDaftar.Location = New System.Drawing.Point(14, 54)
        Me.btnDaftar.Name = "btnDaftar"
        Me.btnDaftar.Size = New System.Drawing.Size(82, 23)
        Me.btnDaftar.TabIndex = 0
        Me.btnDaftar.Text = "&Daftar"
        '
        'btnTambahPO
        '
        Me.btnTambahPO.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnTambahPO.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnTambahPO.Location = New System.Drawing.Point(13, 12)
        Me.btnTambahPO.Name = "btnTambahPO"
        Me.btnTambahPO.Size = New System.Drawing.Size(75, 47)
        Me.btnTambahPO.TabIndex = 0
        Me.btnTambahPO.Text = "&Tambah PO"
        '
        'grpDaftar
        '
        Me.grpDaftar.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpDaftar.BackColor = System.Drawing.Color.Goldenrod
        Me.grpDaftar.Controls.Add(Me.Frame4)
        Me.grpDaftar.Controls.Add(Me.Frame1)
        Me.grpDaftar.Controls.Add(Me.Frame2)
        Me.grpDaftar.Controls.Add(Me.Frame3)
        Me.grpDaftar.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpDaftar.Location = New System.Drawing.Point(7, 97)
        Me.grpDaftar.Name = "grpDaftar"
        Me.grpDaftar.Size = New System.Drawing.Size(678, 382)
        Me.grpDaftar.TabIndex = 5
        Me.grpDaftar.TabStop = False
        Me.grpDaftar.Text = " &Daftar PO"
        '
        'Frame4
        '
        Me.Frame4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Frame4.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.Frame4.Controls.Add(Me.lblBPB_NO)
        Me.Frame4.Controls.Add(Me.Label16)
        Me.Frame4.Controls.Add(Me.Label15)
        Me.Frame4.Controls.Add(Me.Label14)
        Me.Frame4.Controls.Add(Me.lblStatus)
        Me.Frame4.Controls.Add(Me.lblStatusKeterangan)
        Me.Frame4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame4.Location = New System.Drawing.Point(8, 16)
        Me.Frame4.Name = "Frame4"
        Me.Frame4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame4.Size = New System.Drawing.Size(660, 33)
        Me.Frame4.TabIndex = 0
        Me.Frame4.TabStop = False
        '
        'lblBPB_NO
        '
        Me.lblBPB_NO.BackColor = System.Drawing.Color.Transparent
        Me.lblBPB_NO.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblBPB_NO.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.BPB_NO", True))
        Me.lblBPB_NO.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBPB_NO.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblBPB_NO.Location = New System.Drawing.Point(366, 14)
        Me.lblBPB_NO.Name = "lblBPB_NO"
        Me.lblBPB_NO.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblBPB_NO.Size = New System.Drawing.Size(167, 15)
        Me.lblBPB_NO.TabIndex = 47
        Me.lblBPB_NO.Text = "lblBPB_NO"
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label16.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label16.Location = New System.Drawing.Point(290, 14)
        Me.Label16.Name = "Label16"
        Me.Label16.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label16.Size = New System.Drawing.Size(70, 15)
        Me.Label16.TabIndex = 46
        Me.Label16.Text = "No. BPB :"
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label15.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label15.Location = New System.Drawing.Point(86, 13)
        Me.Label15.Name = "Label15"
        Me.Label15.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label15.Size = New System.Drawing.Size(3, 15)
        Me.Label15.TabIndex = 45
        Me.Label15.Text = "-"
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label14.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label14.Location = New System.Drawing.Point(10, 13)
        Me.Label14.Name = "Label14"
        Me.Label14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label14.Size = New System.Drawing.Size(78, 15)
        Me.Label14.TabIndex = 44
        Me.Label14.Text = "STATUS :"
        '
        'lblStatus
        '
        Me.lblStatus.BackColor = System.Drawing.Color.Transparent
        Me.lblStatus.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblStatus.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.RECID", True))
        Me.lblStatus.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblStatus.Location = New System.Drawing.Point(89, 13)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblStatus.Size = New System.Drawing.Size(15, 15)
        Me.lblStatus.TabIndex = 43
        Me.lblStatus.Text = "lblStatus"
        '
        'lblStatusKeterangan
        '
        Me.lblStatusKeterangan.BackColor = System.Drawing.Color.Transparent
        Me.lblStatusKeterangan.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblStatusKeterangan.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.Status", True))
        Me.lblStatusKeterangan.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatusKeterangan.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblStatusKeterangan.Location = New System.Drawing.Point(110, 13)
        Me.lblStatusKeterangan.Name = "lblStatusKeterangan"
        Me.lblStatusKeterangan.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblStatusKeterangan.Size = New System.Drawing.Size(167, 15)
        Me.lblStatusKeterangan.TabIndex = 42
        Me.lblStatusKeterangan.Text = "lblStatus"
        '
        'Frame1
        '
        Me.Frame1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Frame1.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.Frame1.Controls.Add(Me.Label9)
        Me.Frame1.Controls.Add(Me.txtTgl_PO)
        Me.Frame1.Controls.Add(Me.txtNo_PO)
        Me.Frame1.Controls.Add(Me.txtSUPCO)
        Me.Frame1.Controls.Add(Me.txtNamaSupp)
        Me.Frame1.Controls.Add(Me.txtPO_QTY)
        Me.Frame1.Controls.Add(Me.txtPO_GROSS)
        Me.Frame1.Controls.Add(Me.txtPO_PPN)
        Me.Frame1.Controls.Add(Me.txtPO_Total)
        Me.Frame1.Controls.Add(Me.chkBUAT_PO)
        Me.Frame1.Controls.Add(Me.chkADA_HARGA)
        Me.Frame1.Controls.Add(Me.txtTot_Item)
        Me.Frame1.Controls.Add(Me.Label1)
        Me.Frame1.Controls.Add(Me.Label2)
        Me.Frame1.Controls.Add(Me.Label3)
        Me.Frame1.Controls.Add(Me.Label7)
        Me.Frame1.Controls.Add(Me.Label10)
        Me.Frame1.Controls.Add(Me.Label11)
        Me.Frame1.Controls.Add(Me.Label12)
        Me.Frame1.Controls.Add(Me.Label13)
        Me.Frame1.Controls.Add(Me.Label8)
        Me.Frame1.Controls.Add(Me.Label4)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(8, 112)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(660, 155)
        Me.Frame1.TabIndex = 2
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "Dengan PO."
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label9.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.Location = New System.Drawing.Point(153, 127)
        Me.Label9.Name = "Label9"
        Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label9.Size = New System.Drawing.Size(47, 18)
        Me.Label9.TabIndex = 10
        Me.Label9.Text = "Harga"
        '
        'txtTgl_PO
        '
        Me.txtTgl_PO.AcceptsReturn = True
        Me.txtTgl_PO.BackColor = System.Drawing.SystemColors.Window
        Me.txtTgl_PO.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTgl_PO.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.TANGGAL", True))
        Me.txtTgl_PO.Enabled = False
        Me.txtTgl_PO.FieldType = AntrianDC.FlexMaskEditBox._FieldType.DATE_
        Me.txtTgl_PO.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.txtTgl_PO.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTgl_PO.Location = New System.Drawing.Point(98, 41)
        Me.txtTgl_PO.Name = "txtTgl_PO"
        Me.txtTgl_PO.SetFormatString = "dd-MM-yyyy"
        Me.txtTgl_PO.Size = New System.Drawing.Size(72, 23)
        Me.txtTgl_PO.TabIndex = 3
        '
        'txtNo_PO
        '
        Me.txtNo_PO.AcceptsReturn = True
        Me.txtNo_PO.BackColor = System.Drawing.SystemColors.Window
        Me.txtNo_PO.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtNo_PO.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtNo_PO.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.NOPO", True))
        Me.txtNo_PO.Enabled = False
        Me.txtNo_PO.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.txtNo_PO.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtNo_PO.Location = New System.Drawing.Point(98, 15)
        Me.txtNo_PO.MaxLength = 9
        Me.txtNo_PO.Name = "txtNo_PO"
        Me.txtNo_PO.Size = New System.Drawing.Size(84, 23)
        Me.txtNo_PO.TabIndex = 1
        Me.txtNo_PO.Tag = "1"
        '
        'txtSUPCO
        '
        Me.txtSUPCO.AcceptsReturn = True
        Me.txtSUPCO.BackColor = System.Drawing.SystemColors.Window
        Me.txtSUPCO.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtSUPCO.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSUPCO.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.SUPCO", True))
        Me.txtSUPCO.Enabled = False
        Me.txtSUPCO.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.txtSUPCO.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSUPCO.Location = New System.Drawing.Point(98, 67)
        Me.txtSUPCO.MaxLength = 4
        Me.txtSUPCO.Name = "txtSUPCO"
        Me.txtSUPCO.Size = New System.Drawing.Size(50, 23)
        Me.txtSUPCO.TabIndex = 5
        Me.txtSUPCO.Tag = "1"
        '
        'txtNamaSupp
        '
        Me.txtNamaSupp.AcceptsReturn = True
        Me.txtNamaSupp.BackColor = System.Drawing.SystemColors.Window
        Me.txtNamaSupp.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtNamaSupp.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.SNAMA", True))
        Me.txtNamaSupp.Enabled = False
        Me.txtNamaSupp.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.txtNamaSupp.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtNamaSupp.Location = New System.Drawing.Point(98, 93)
        Me.txtNamaSupp.Name = "txtNamaSupp"
        Me.txtNamaSupp.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtNamaSupp.Size = New System.Drawing.Size(276, 23)
        Me.txtNamaSupp.TabIndex = 7
        '
        'txtPO_QTY
        '
        Me.txtPO_QTY.AcceptsReturn = True
        Me.txtPO_QTY.BackColor = System.Drawing.SystemColors.Window
        Me.txtPO_QTY.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPO_QTY.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.QTY", True))
        Me.txtPO_QTY.Enabled = False
        Me.txtPO_QTY.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.txtPO_QTY.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPO_QTY.Location = New System.Drawing.Point(465, 43)
        Me.txtPO_QTY.Name = "txtPO_QTY"
        Me.txtPO_QTY.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtPO_QTY.Size = New System.Drawing.Size(119, 23)
        Me.txtPO_QTY.TabIndex = 15
        Me.txtPO_QTY.Tag = "1"
        Me.txtPO_QTY.Text = "123"
        Me.txtPO_QTY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtPO_GROSS
        '
        Me.txtPO_GROSS.AcceptsReturn = True
        Me.txtPO_GROSS.BackColor = System.Drawing.SystemColors.Window
        Me.txtPO_GROSS.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPO_GROSS.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.RUPIAH", True))
        Me.txtPO_GROSS.Enabled = False
        Me.txtPO_GROSS.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.txtPO_GROSS.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPO_GROSS.Location = New System.Drawing.Point(465, 71)
        Me.txtPO_GROSS.Name = "txtPO_GROSS"
        Me.txtPO_GROSS.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtPO_GROSS.Size = New System.Drawing.Size(148, 23)
        Me.txtPO_GROSS.TabIndex = 17
        Me.txtPO_GROSS.Tag = "1"
        Me.txtPO_GROSS.Text = "123"
        Me.txtPO_GROSS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtPO_PPN
        '
        Me.txtPO_PPN.AcceptsReturn = True
        Me.txtPO_PPN.BackColor = System.Drawing.SystemColors.Window
        Me.txtPO_PPN.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPO_PPN.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.PPN", True))
        Me.txtPO_PPN.Enabled = False
        Me.txtPO_PPN.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.txtPO_PPN.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPO_PPN.Location = New System.Drawing.Point(465, 99)
        Me.txtPO_PPN.Name = "txtPO_PPN"
        Me.txtPO_PPN.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtPO_PPN.Size = New System.Drawing.Size(148, 23)
        Me.txtPO_PPN.TabIndex = 19
        Me.txtPO_PPN.Tag = "1"
        Me.txtPO_PPN.Text = "123"
        Me.txtPO_PPN.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtPO_Total
        '
        Me.txtPO_Total.AcceptsReturn = True
        Me.txtPO_Total.BackColor = System.Drawing.SystemColors.Window
        Me.txtPO_Total.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPO_Total.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.Total", True))
        Me.txtPO_Total.Enabled = False
        Me.txtPO_Total.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.txtPO_Total.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPO_Total.Location = New System.Drawing.Point(465, 127)
        Me.txtPO_Total.Name = "txtPO_Total"
        Me.txtPO_Total.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtPO_Total.Size = New System.Drawing.Size(150, 23)
        Me.txtPO_Total.TabIndex = 21
        Me.txtPO_Total.Text = "123"
        Me.txtPO_Total.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'chkBUAT_PO
        '
        Me.chkBUAT_PO.BackColor = System.Drawing.Color.Transparent
        Me.chkBUAT_PO.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkBUAT_PO.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.BUAT_PO", True))
        Me.chkBUAT_PO.Enabled = False
        Me.chkBUAT_PO.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkBUAT_PO.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkBUAT_PO.Location = New System.Drawing.Point(98, 128)
        Me.chkBUAT_PO.Name = "chkBUAT_PO"
        Me.chkBUAT_PO.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkBUAT_PO.Size = New System.Drawing.Size(48, 17)
        Me.chkBUAT_PO.TabIndex = 9
        Me.chkBUAT_PO.UseVisualStyleBackColor = False
        '
        'chkADA_HARGA
        '
        Me.chkADA_HARGA.BackColor = System.Drawing.Color.Transparent
        Me.chkADA_HARGA.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkADA_HARGA.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.ADA_HARGA", True))
        Me.chkADA_HARGA.Enabled = False
        Me.chkADA_HARGA.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkADA_HARGA.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkADA_HARGA.Location = New System.Drawing.Point(202, 127)
        Me.chkADA_HARGA.Name = "chkADA_HARGA"
        Me.chkADA_HARGA.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkADA_HARGA.Size = New System.Drawing.Size(58, 18)
        Me.chkADA_HARGA.TabIndex = 11
        Me.chkADA_HARGA.UseVisualStyleBackColor = False
        '
        'txtTot_Item
        '
        Me.txtTot_Item.AcceptsReturn = True
        Me.txtTot_Item.BackColor = System.Drawing.SystemColors.Window
        Me.txtTot_Item.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTot_Item.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.ITEMnya", True))
        Me.txtTot_Item.Enabled = False
        Me.txtTot_Item.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.txtTot_Item.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTot_Item.Location = New System.Drawing.Point(465, 15)
        Me.txtTot_Item.Name = "txtTot_Item"
        Me.txtTot_Item.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTot_Item.Size = New System.Drawing.Size(45, 23)
        Me.txtTot_Item.TabIndex = 13
        Me.txtTot_Item.Tag = "1"
        Me.txtTot_Item.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(7, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(81, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Nomor "
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(6, 44)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(81, 20)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Tanggal"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(6, 72)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(81, 15)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Kode Supp."
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label7.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.Location = New System.Drawing.Point(6, 98)
        Me.Label7.Name = "Label7"
        Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label7.Size = New System.Drawing.Size(81, 15)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Nama Supp."
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label10.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label10.Location = New System.Drawing.Point(392, 49)
        Me.Label10.Name = "Label10"
        Me.Label10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label10.Size = New System.Drawing.Size(81, 15)
        Me.Label10.TabIndex = 14
        Me.Label10.Text = "Qty."
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label11.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label11.Location = New System.Drawing.Point(392, 76)
        Me.Label11.Name = "Label11"
        Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label11.Size = New System.Drawing.Size(81, 15)
        Me.Label11.TabIndex = 16
        Me.Label11.Text = "Gross."
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label12.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label12.Location = New System.Drawing.Point(392, 104)
        Me.Label12.Name = "Label12"
        Me.Label12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label12.Size = New System.Drawing.Size(81, 15)
        Me.Label12.TabIndex = 18
        Me.Label12.Text = "Ppn."
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label13.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label13.Location = New System.Drawing.Point(392, 135)
        Me.Label13.Name = "Label13"
        Me.Label13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label13.Size = New System.Drawing.Size(81, 15)
        Me.Label13.TabIndex = 20
        Me.Label13.Text = "Total"
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label8.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(6, 127)
        Me.Label8.Name = "Label8"
        Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label8.Size = New System.Drawing.Size(86, 17)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "Dengan PO."
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(392, 20)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(43, 15)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Item "
        '
        'Frame2
        '
        Me.Frame2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Frame2.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.Frame2.Controls.Add(Me.txtTglFaktur)
        Me.Frame2.Controls.Add(Me.txtNoFak)
        Me.Frame2.Controls.Add(Me.Label5)
        Me.Frame2.Controls.Add(Me.Label6)
        Me.Frame2.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame2.Location = New System.Drawing.Point(8, 56)
        Me.Frame2.Name = "Frame2"
        Me.Frame2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame2.Size = New System.Drawing.Size(660, 46)
        Me.Frame2.TabIndex = 1
        Me.Frame2.TabStop = False
        Me.Frame2.Text = " &FAKTUR "
        '
        'txtTglFaktur
        '
        Me.txtTglFaktur.BackColor = System.Drawing.SystemColors.Window
        Me.txtTglFaktur.CustomFormat = "dd-MM-yyyy"
        Me.txtTglFaktur.Enabled = False
        Me.txtTglFaktur.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTglFaktur.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTglFaktur.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.txtTglFaktur.Location = New System.Drawing.Point(279, 15)
        Me.txtTglFaktur.Name = "txtTglFaktur"
        Me.txtTglFaktur.Size = New System.Drawing.Size(95, 23)
        Me.txtTglFaktur.TabIndex = 62
        '
        'txtNoFak
        '
        Me.txtNoFak.AcceptsReturn = True
        Me.txtNoFak.BackColor = System.Drawing.SystemColors.Window
        Me.txtNoFak.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtNoFak.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtNoFak.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.NO_FAK", True))
        Me.txtNoFak.Enabled = False
        Me.txtNoFak.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNoFak.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtNoFak.Location = New System.Drawing.Point(69, 16)
        Me.txtNoFak.MaxLength = 7
        Me.txtNoFak.Name = "txtNoFak"
        Me.txtNoFak.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtNoFak.Size = New System.Drawing.Size(81, 23)
        Me.txtNoFak.TabIndex = 1
        Me.txtNoFak.Tag = "1"
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label5.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(192, 20)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(81, 19)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Tanggal"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label6.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(11, 20)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(81, 15)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Nomor "
        '
        'Frame3
        '
        Me.Frame3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Frame3.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.Frame3.Controls.Add(Me.btnUpdate)
        Me.Frame3.Controls.Add(Me.btnCancelAll)
        Me.Frame3.Controls.Add(Me.txtSupID)
        Me.Frame3.Controls.Add(Me.txtLokasiKode)
        Me.Frame3.Controls.Add(Me.txtGudangkode)
        Me.Frame3.Controls.Add(Me.txtUPDATE)
        Me.Frame3.Controls.Add(Me.txtTGL_AKHIR)
        Me.Frame3.Controls.Add(Me.txtTGL_MULAI)
        Me.Frame3.Controls.Add(Me.Label18)
        Me.Frame3.Controls.Add(Me.Label19)
        Me.Frame3.Controls.Add(Me.Label20)
        Me.Frame3.Controls.Add(Me.Label21)
        Me.Frame3.Controls.Add(Me.Label22)
        Me.Frame3.Controls.Add(Me.Label23)
        Me.Frame3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame3.Location = New System.Drawing.Point(8, 275)
        Me.Frame3.Name = "Frame3"
        Me.Frame3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame3.Size = New System.Drawing.Size(660, 96)
        Me.Frame3.TabIndex = 3
        Me.Frame3.TabStop = False
        Me.Frame3.Text = " &DAFTAR "
        '
        'txtSupID
        '
        Me.txtSupID.AcceptsReturn = True
        Me.txtSupID.BackColor = System.Drawing.SystemColors.Window
        Me.txtSupID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSupID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.SUPID", True))
        Me.txtSupID.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSupID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSupID.Location = New System.Drawing.Point(328, 63)
        Me.txtSupID.Name = "txtSupID"
        Me.txtSupID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSupID.Size = New System.Drawing.Size(100, 23)
        Me.txtSupID.TabIndex = 15
        Me.txtSupID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtSupID.Visible = False
        '
        'txtLokasiKode
        '
        Me.txtLokasiKode.AcceptsReturn = True
        Me.txtLokasiKode.BackColor = System.Drawing.SystemColors.Window
        Me.txtLokasiKode.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtLokasiKode.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.LOKASI_KODE", True))
        Me.txtLokasiKode.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLokasiKode.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtLokasiKode.Location = New System.Drawing.Point(328, 39)
        Me.txtLokasiKode.Name = "txtLokasiKode"
        Me.txtLokasiKode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtLokasiKode.Size = New System.Drawing.Size(100, 23)
        Me.txtLokasiKode.TabIndex = 11
        Me.txtLokasiKode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtLokasiKode.Visible = False
        '
        'txtGudangkode
        '
        Me.txtGudangkode.AcceptsReturn = True
        Me.txtGudangkode.BackColor = System.Drawing.SystemColors.Window
        Me.txtGudangkode.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtGudangkode.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.GUDANG_KODE", True))
        Me.txtGudangkode.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGudangkode.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtGudangkode.Location = New System.Drawing.Point(328, 13)
        Me.txtGudangkode.Name = "txtGudangkode"
        Me.txtGudangkode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtGudangkode.Size = New System.Drawing.Size(100, 23)
        Me.txtGudangkode.TabIndex = 7
        Me.txtGudangkode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtGudangkode.Visible = False
        '
        'txtUPDATE
        '
        Me.txtUPDATE.AcceptsReturn = True
        Me.txtUPDATE.BackColor = System.Drawing.SystemColors.Window
        Me.txtUPDATE.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtUPDATE.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.UPDATE", True))
        Me.txtUPDATE.Enabled = False
        Me.txtUPDATE.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUPDATE.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtUPDATE.Location = New System.Drawing.Point(96, 65)
        Me.txtUPDATE.Name = "txtUPDATE"
        Me.txtUPDATE.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtUPDATE.Size = New System.Drawing.Size(100, 23)
        Me.txtUPDATE.TabIndex = 13
        Me.txtUPDATE.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtTGL_AKHIR
        '
        Me.txtTGL_AKHIR.AcceptsReturn = True
        Me.txtTGL_AKHIR.BackColor = System.Drawing.SystemColors.Window
        Me.txtTGL_AKHIR.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTGL_AKHIR.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.TGL_AKHIR", True))
        Me.txtTGL_AKHIR.Enabled = False
        Me.txtTGL_AKHIR.FieldType = AntrianDC.FlexMaskEditBox._FieldType.DATE_
        Me.txtTGL_AKHIR.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTGL_AKHIR.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTGL_AKHIR.Location = New System.Drawing.Point(96, 41)
        Me.txtTGL_AKHIR.Name = "txtTGL_AKHIR"
        Me.txtTGL_AKHIR.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTGL_AKHIR.SetFormatString = "dd-MM-yyyy HH:mm"
        Me.txtTGL_AKHIR.Size = New System.Drawing.Size(112, 23)
        Me.txtTGL_AKHIR.TabIndex = 9
        Me.txtTGL_AKHIR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtTGL_MULAI
        '
        Me.txtTGL_MULAI.AcceptsReturn = True
        Me.txtTGL_MULAI.BackColor = System.Drawing.SystemColors.Window
        Me.txtTGL_MULAI.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTGL_MULAI.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.TGL_MULAI", True))
        Me.txtTGL_MULAI.Enabled = False
        Me.txtTGL_MULAI.FieldType = AntrianDC.FlexMaskEditBox._FieldType.DATE_
        Me.txtTGL_MULAI.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTGL_MULAI.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTGL_MULAI.Location = New System.Drawing.Point(96, 16)
        Me.txtTGL_MULAI.Name = "txtTGL_MULAI"
        Me.txtTGL_MULAI.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTGL_MULAI.SetFormatString = "dd-MM-yyyy HH:mm"
        Me.txtTGL_MULAI.Size = New System.Drawing.Size(112, 23)
        Me.txtTGL_MULAI.TabIndex = 1
        Me.txtTGL_MULAI.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label18.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label18.Location = New System.Drawing.Point(248, 66)
        Me.Label18.Name = "Label18"
        Me.Label18.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label18.Size = New System.Drawing.Size(81, 15)
        Me.Label18.TabIndex = 14
        Me.Label18.Text = "Lamanya"
        Me.Label18.Visible = False
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label19.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label19.Location = New System.Drawing.Point(248, 43)
        Me.Label19.Name = "Label19"
        Me.Label19.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label19.Size = New System.Drawing.Size(81, 15)
        Me.Label19.TabIndex = 10
        Me.Label19.Text = "Jam BPB"
        Me.Label19.Visible = False
        '
        'Label20
        '
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label20.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label20.Location = New System.Drawing.Point(248, 16)
        Me.Label20.Name = "Label20"
        Me.Label20.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label20.Size = New System.Drawing.Size(81, 15)
        Me.Label20.TabIndex = 6
        Me.Label20.Text = "Jam Daftar"
        Me.Label20.Visible = False
        '
        'Label21
        '
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label21.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label21.Location = New System.Drawing.Point(7, 68)
        Me.Label21.Name = "Label21"
        Me.Label21.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label21.Size = New System.Drawing.Size(81, 15)
        Me.Label21.TabIndex = 12
        Me.Label21.Text = "Update."
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label22.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label22.Location = New System.Drawing.Point(6, 44)
        Me.Label22.Name = "Label22"
        Me.Label22.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label22.Size = New System.Drawing.Size(81, 21)
        Me.Label22.TabIndex = 8
        Me.Label22.Text = "Tgl. BPB"
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.Color.Transparent
        Me.Label23.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label23.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label23.Location = New System.Drawing.Point(6, 19)
        Me.Label23.Name = "Label23"
        Me.Label23.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label23.Size = New System.Drawing.Size(81, 19)
        Me.Label23.TabIndex = 0
        Me.Label23.Text = "Tgl. Daftar"
        '
        'lblIdDaftarPO
        '
        Me.lblIdDaftarPO.AutoSize = True
        Me.lblIdDaftarPO.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.ID_DAFTARPO", True))
        Me.lblIdDaftarPO.Location = New System.Drawing.Point(20, 176)
        Me.lblIdDaftarPO.Name = "lblIdDaftarPO"
        Me.lblIdDaftarPO.Size = New System.Drawing.Size(45, 13)
        Me.lblIdDaftarPO.TabIndex = 63
        Me.lblIdDaftarPO.Text = "Label25"
        '
        'lblSUPID
        '
        Me.lblSUPID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.SUPID", True))
        Me.lblSUPID.Location = New System.Drawing.Point(20, 63)
        Me.lblSUPID.Name = "lblSUPID"
        Me.lblSUPID.Size = New System.Drawing.Size(100, 16)
        Me.lblSUPID.TabIndex = 22
        Me.lblSUPID.Text = "lblSUPID"
        '
        'lblLokasiKode
        '
        Me.lblLokasiKode.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.LOKASI_KODE", True))
        Me.lblLokasiKode.Location = New System.Drawing.Point(20, 39)
        Me.lblLokasiKode.Name = "lblLokasiKode"
        Me.lblLokasiKode.Size = New System.Drawing.Size(100, 16)
        Me.lblLokasiKode.TabIndex = 17
        Me.lblLokasiKode.Text = "LokasiKode"
        '
        'lblGudangKode
        '
        Me.lblGudangKode.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.GUDANG_KODE", True))
        Me.lblGudangKode.Location = New System.Drawing.Point(20, 15)
        Me.lblGudangKode.Name = "lblGudangKode"
        Me.lblGudangKode.Size = New System.Drawing.Size(100, 16)
        Me.lblGudangKode.TabIndex = 16
        Me.lblGudangKode.Text = "GudangKode"
        '
        'cmbFilter
        '
        Me.cmbFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbFilter.Items.AddRange(New Object() {"Hari ini", "Semua"})
        Me.cmbFilter.Location = New System.Drawing.Point(540, 24)
        Me.cmbFilter.Name = "cmbFilter"
        Me.cmbFilter.Size = New System.Drawing.Size(121, 21)
        Me.cmbFilter.TabIndex = 8
        '
        'btnHapusPO
        '
        Me.btnHapusPO.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnHapusPO.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnHapusPO.Location = New System.Drawing.Point(100, 12)
        Me.btnHapusPO.Name = "btnHapusPO"
        Me.btnHapusPO.Size = New System.Drawing.Size(75, 23)
        Me.btnHapusPO.TabIndex = 1
        Me.btnHapusPO.Text = "&Hapus PO"
        '
        'btnEditPO
        '
        Me.btnEditPO.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnEditPO.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnEditPO.Location = New System.Drawing.Point(100, 36)
        Me.btnEditPO.Name = "btnEditPO"
        Me.btnEditPO.Size = New System.Drawing.Size(75, 23)
        Me.btnEditPO.TabIndex = 2
        Me.btnEditPO.Text = "&Edit PO"
        '
        'btnNext2
        '
        Me.btnNext2.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnNext2.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnNext2.Location = New System.Drawing.Point(356, 24)
        Me.btnNext2.Name = "btnNext2"
        Me.btnNext2.Size = New System.Drawing.Size(75, 23)
        Me.btnNext2.TabIndex = 6
        Me.btnNext2.Text = ">>"
        '
        'btnPrev2
        '
        Me.btnPrev2.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnPrev2.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnPrev2.Location = New System.Drawing.Point(275, 24)
        Me.btnPrev2.Name = "btnPrev2"
        Me.btnPrev2.Size = New System.Drawing.Size(75, 23)
        Me.btnPrev2.TabIndex = 5
        Me.btnPrev2.Text = "<<"
        '
        'btnBatalPO
        '
        Me.btnBatalPO.Enabled = False
        Me.btnBatalPO.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnBatalPO.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnBatalPO.Location = New System.Drawing.Point(188, 36)
        Me.btnBatalPO.Name = "btnBatalPO"
        Me.btnBatalPO.Size = New System.Drawing.Size(75, 23)
        Me.btnBatalPO.TabIndex = 4
        Me.btnBatalPO.Text = "&Batal"
        '
        'btnSimpanPO
        '
        Me.btnSimpanPO.Enabled = False
        Me.btnSimpanPO.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnSimpanPO.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnSimpanPO.Location = New System.Drawing.Point(188, 12)
        Me.btnSimpanPO.Name = "btnSimpanPO"
        Me.btnSimpanPO.Size = New System.Drawing.Size(75, 23)
        Me.btnSimpanPO.TabIndex = 3
        Me.btnSimpanPO.Text = "&Simpan"
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.BackColor = System.Drawing.Color.Goldenrod
        Me.GroupBox1.Controls.Add(Me.btnKeluar)
        Me.GroupBox1.Controls.Add(Me.cmbFilter)
        Me.GroupBox1.Controls.Add(Me.btnSimpanPO)
        Me.GroupBox1.Controls.Add(Me.btnHapusPO)
        Me.GroupBox1.Controls.Add(Me.btnEditPO)
        Me.GroupBox1.Controls.Add(Me.btnNext2)
        Me.GroupBox1.Controls.Add(Me.btnPrev2)
        Me.GroupBox1.Controls.Add(Me.btnTambahPO)
        Me.GroupBox1.Controls.Add(Me.btnBatalPO)
        Me.GroupBox1.Location = New System.Drawing.Point(7, 485)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(678, 65)
        Me.GroupBox1.TabIndex = 15
        Me.GroupBox1.TabStop = False
        '
        'btnKeluar
        '
        Me.btnKeluar.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnKeluar.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnKeluar.Location = New System.Drawing.Point(447, 24)
        Me.btnKeluar.Name = "btnKeluar"
        Me.btnKeluar.Size = New System.Drawing.Size(75, 23)
        Me.btnKeluar.TabIndex = 7
        Me.btnKeluar.Text = "&Keluar"
        '
        'grpHidden
        '
        Me.grpHidden.Controls.Add(Me.lblTglRevisi)
        Me.grpHidden.Controls.Add(Me.lblSUPID)
        Me.grpHidden.Controls.Add(Me.lblLokasiKode)
        Me.grpHidden.Controls.Add(Me.lblGudangKode)
        Me.grpHidden.Location = New System.Drawing.Point(348, 118)
        Me.grpHidden.Name = "grpHidden"
        Me.grpHidden.Size = New System.Drawing.Size(200, 149)
        Me.grpHidden.TabIndex = 18
        Me.grpHidden.TabStop = False
        '
        'lblTglRevisi
        '
        Me.lblTglRevisi.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.TGL_REVISI", True))
        Me.lblTglRevisi.Location = New System.Drawing.Point(22, 92)
        Me.lblTglRevisi.Name = "lblTglRevisi"
        Me.lblTglRevisi.Size = New System.Drawing.Size(100, 16)
        Me.lblTglRevisi.TabIndex = 23
        Me.lblTglRevisi.Text = "lblTglRevisi"
        '
        'frmDaftarPO
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.Moccasin
        Me.ClientSize = New System.Drawing.Size(690, 563)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.grpMobil)
        Me.Controls.Add(Me.grpDaftar)
        Me.Controls.Add(Me.grpHidden)
        Me.Controls.Add(Me.lblIdDaftarPO)
        Me.MinimumSize = New System.Drawing.Size(698, 590)
        Me.Name = "frmDaftarPO"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "FORM PENDAFTARAN"
        Me.grpMobil.ResumeLayout(False)
        Me.grpMobil.PerformLayout()
        CType(Me.DsPO1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpDaftar.ResumeLayout(False)
        Me.Frame4.ResumeLayout(False)
        Me.Frame1.ResumeLayout(False)
        Me.Frame1.PerformLayout()
        Me.Frame2.ResumeLayout(False)
        Me.Frame2.PerformLayout()
        Me.Frame3.ResumeLayout(False)
        Me.Frame3.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.grpHidden.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    Private SqlMobil As String, WhrMobil As String
    Private SqlDaftar As String, WhrDaftar As String
    Private Sub frmDaftarPO_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        olcon.ConnectionString = ConStrORA
        Me.Text = "Form Pendaftaran - [" & Application.ProductName & " v" & Application.ProductVersion & "]"
        'AddHandler dsPo1.DC_JLR_DAFTARPO_T.ColumnChanging, AddressOf HandleColomPO
        'AddHandler dsPo1.DC_JLR_DAFTARPO_T.RowChanging, AddressOf HandleRowPo

        'SetTombol(True)
        For Each Tx As Control In Me.Controls
            If Tx.GetType Is GetType(GroupBox) Then

                For Each Tx2 As Control In Tx.Controls
                    If Tx2.GetType Is GetType(GroupBox) Then
                        For Each Tx3 As Control In Tx2.Controls
                            If Tx3.Tag = "1" Then
                                AddHandler Tx3.KeyDown, AddressOf txt_Keydown
                                AddHandler Tx3.Enter, AddressOf BlockAll
                            End If
                        Next
                    Else
                        If Tx2.Tag = "1" Then
                            AddHandler Tx2.KeyDown, AddressOf txt_Keydown
                            AddHandler Tx2.Enter, AddressOf BlockAll
                        End If
                    End If
                Next

            End If
        Next
        SqlMobil = oldapMobil.SelectCommand.CommandText
        SqlDaftar = oldapPO.SelectCommand.CommandText
        cmbFilter.SelectedIndex = 0


    End Sub
    Private Sub formatTextBox(ByVal sender As Object, ByVal e As System.Windows.Forms.ConvertEventArgs)
        Try
            'CType(sender, TextBox).Tag = ""
            e.Value = FormatNumber(e.Value, 2)
            'e.Value = FormatNumber(e.Value, 2).Replace(".", "A").Replace(",", ".").Replace("A", ",")
        Catch

        End Try
    End Sub

    Private Sub cmbFilter_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbFilter.SelectedIndexChanged
        Try
            'Attempt to load the dataset.
            Me.LoadDataSet()
        Catch eLoad As System.Exception
            'Add your error handling code here.
            'Display error message, if any.
            System.Windows.Forms.MessageBox.Show(eLoad.Message)
        End Try
    End Sub
#Region "Handle Textbox"
    Private Sub txt_Keydown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
        If e.Control Then
            Exit Sub
        End If
        Select Case e.KeyCode
            Case Keys.Enter, Keys.Down
                SendKeys.Flush()
                SendKeys.SendWait("{TAB}")
            Case Keys.Up
                SendKeys.Send("+{TAB}")
        End Select
    End Sub
    Private Sub BlockAll(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            CType(sender, TextBox).SelectAll()
        Catch ex As Exception
            ex = Nothing
        End Try

    End Sub
#End Region
    Public Sub LoadDataSet()
        'Create a new dataset to hold the records returned from the call to FillDataSet.
        'A temporary dataset is used because filling the existing dataset would
        'require the databindings to be rebound.
        Dim objDataSetTemp As AntrianDC.dsPO
        objDataSetTemp = New AntrianDC.dsPO
        Try
            'Attempt to fill the temporary dataset.
            Me.FillDataSet(objDataSetTemp)
        Catch eFillDataSet As System.Exception
            'Add your error handling code here.
            Throw eFillDataSet
        End Try
        Try
            'grdDC_JLR_DAFTARPO_T.DataSource = Nothing
            'grdDC_JLR_DAFTARJALUR_T.DataSource = Nothing

            'Empty the old records from the dataset.
            DsPO1.Clear()
            'Merge the records into the main dataset.
            DsPO1.Merge(objDataSetTemp)

            'grdDC_JLR_DAFTARJALUR_T.SetDataBinding(dsPo1, "DC_JLR_DAFTARJALUR_T")
            'grdDC_JLR_DAFTARPO_T.SetDataBinding(dsPo1, "DC_JLR_DAFTARJALUR_T.Daf_PO")

            'Atur Default
            DsPO1.DC_JLR_DAFTARJALUR_T.TANGGALColumn.DefaultValue = GetOracleDate()
            DsPO1.DC_JLR_DAFTARJALUR_T.DC_IDColumn.DefaultValue = cDC_ID
            'dsPo1.DC_JLR_DAFTARJALUR_T.NOMOBILColumn.DefaultValue = ""
            'DsPO1.DC_JLR_DAFTARJALUR_T.ID_DAFTARJALURColumn.AutoIncrementSeed = GetIdDaftarJalur()

            'dsPo1.DC_JLR_DAFTARPO_T.TANGGALColumn.DefaultValue = Now.Date
            DsPO1.DC_JLR_DAFTARPO_T.TGL_FAKColumn.DefaultValue = GetOracleDate.Date
            'DsPO1.DC_JLR_DAFTARPO_T.ID_DAFTARPOColumn.AutoIncrementSeed = GetIdDaftarPO()

            DsPO1.DC_JLR_DAFTARPO_T.SUPCOColumn.DefaultValue = ""
        Catch eLoadMerge As System.Exception
            'Add your error handling code here.
            Throw eLoadMerge
        End Try

    End Sub
    Public Sub FillDataSet(ByVal dataSet As AntrianDC.dsPO)
        'Turn off constraint checking before the dataset is filled.
        'This allows the adapters to fill the dataset without concern
        'for dependencies between the tables.
        dataSet.EnforceConstraints = False
        Try
            'Open the connection.

            Me.olcon.Open()
            'Attempt to fill the dataset through the oldapMobil.

            If cmbFilter.SelectedIndex = 0 Then
                WhrMobil = " WHERE TRUNC(TANGGAL)=TRUNC(SYSDATE)"
                WhrDaftar = " WHERE ID_DAFTARJALUR IN (SELECT ID_DAFTARJALUR FROM DC_JLR_DAFTARJALUR_T " & WhrMobil & ")"
            Else
                WhrMobil = ""
                WhrDaftar = ""
            End If

            oldapMobil.SelectCommand.CommandText = SqlMobil & WhrMobil & "  ORDER BY ID_DAFTARJALUR"
            oldapPO.SelectCommand.CommandText = SqlDaftar & WhrDaftar & " ORDER BY ID_DAFTARPO"

            Try
                Me.oldapMobil.Fill(dataSet)
                Me.oldapPO.Fill(dataSet)
            Catch
            End Try

        Catch fillException As System.Exception
            'Add your error handling code here.
            Throw fillException
        Finally
            'Turn constraint checking back on.
            dataSet.EnforceConstraints = True
            'Close the connection whether or not the exception was thrown.
            Me.olcon.Close()
        End Try

    End Sub
    Private Sub btnCancelAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelAll.Click
        Me.DsPO1.RejectChanges()
    End Sub
    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        Try
            'Attempt to update the datasource.
            Me.UpdateDataSet()
        Catch eUpdate As System.Exception
            'Add your error handling code here.
            'Display error message, if any.
            ShowError("Error Update", eUpdate)
        End Try

    End Sub

    Public Sub UpdateDataSet()
        'Create a new dataset to hold the changes that have been made to the main dataset.
        Dim objDataSetChanges As AntrianDC.dsPO = New AntrianDC.dsPO
        'Stop any current edits.
        Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").EndCurrentEdit()
        Try
            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").EndCurrentEdit()
        Catch

        End Try

        'Get the changes that have been made to the main dataset.
        objDataSetChanges = CType(DsPO1.GetChanges, AntrianDC.dsPO)
        'Check to see if any changes have been made.
        If (Not (objDataSetChanges) Is Nothing) Then
            Try
                'There are changes that need to be made, so attempt to update the datasource by
                'calling the update method and passing the dataset and any parameters.
                Me.UpdateDataSource(objDataSetChanges)
                DsPO1.Merge(objDataSetChanges)
                DsPO1.AcceptChanges()
            Catch eUpdate As System.Exception
                'Add your error handling code here.
                Throw eUpdate
            End Try
            'Add your code to check the returned dataset for any errors that may have been
            'pushed into the row object's error.
        End If

    End Sub
    Public Sub UpdateDataSource(ByVal ChangedRows As AntrianDC.dsPO)
        Try
            'The data source only needs to be updated if there are changes pending.
            If (Not (ChangedRows) Is Nothing) Then
                'Open the connection.
                Me.olcon.Open()
                'Attempt to update the data source.
                Debug.WriteLine("Mobil: " & oldapMobil.Update(ChangedRows))
                Application.DoEvents()
                Debug.WriteLine("PO: " & oldapPO.Update(ChangedRows))

            End If
        Catch updateException As System.Exception
            'Add your error handling code here.
            Throw updateException
        Finally
            'Close the connection whether or not the exception was thrown.
            Me.olcon.Close()
        End Try

    End Sub

    Private Sub btnPrev_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrev.Click
        Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position -= 1
    End Sub
    Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click
        Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position += 1
    End Sub

    Private Sub btnDaftar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDaftar.Click
        Try
            'DsPO1.DC_JLR_DAFTARJALUR_T.ID_DAFTARJALURColumn.AutoIncrementSeed = GetIdDaftarJalur()
            DsPO1.DC_JLR_DAFTARJALUR_T.ID_DAFTARJALURColumn.DefaultValue = GetIdDaftarJalur()


            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").EndCurrentEdit()
            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").AddNew()



            txtNoMobil.Enabled = True
            txtTglDaftar.Enabled = True

            btnHapusPO.Enabled = False
            btnEditPO.Enabled = False

            btnNext.Enabled = False
            btnPrev.Enabled = False
            btnDaftar.Enabled = False
            btnCari.Enabled = False



            'btnSimpan.Enabled = True
            'btnBatal.Enabled = True

            'Dim X As Integer
            'X = Me.BindingContext(dsPo1, "DC_JLR_DAFTARJALUR_T").Position

            'dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("ID_DAFTARJALUR") = GetIdDaftarJalur()
            Debug.WriteLine("jUMLAH rECORD : " & DsPO1.DC_JLR_DAFTARJALUR_T.Rows.Count)

            txtNoMobil.Focus()
        Catch eEndEdit As System.Exception
            System.Windows.Forms.MessageBox.Show(eEndEdit.Message)
        End Try
    End Sub
    Private Sub grpMobil_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles grpMobil.Leave
        Try
            If txtNoMobil.Text = "" And btnDaftar.Enabled = False Then
                Err.Raise(99)
            End If
            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").EndCurrentEdit()




            If Not btnDaftar.Enabled And btnTambahPO.Enabled Then
                btnTambahPO.PerformClick()
            End If

        Catch ex As Exception
            'ShowError("Error Simpan Daftar Mobil", ex)
            Debug.WriteLine("Error Simpan Daftar Mobil" & ex.Message)
            ex = Nothing

            If MessageBox.Show("No Mobil Tidak Boleh Kosong." & vbCrLf & _
                "     Edit No Mobil ?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Error) = Windows.Forms.DialogResult.Yes Then
                txtNoMobil.Focus()
            Else
                Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").CancelCurrentEdit()
                btnNext.Focus()
                SetTombol(False)
            End If
        End Try
    End Sub

    Private Sub btnTambahPO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTambahPO.Click
        'DsPO1.DC_JLR_DAFTARPO_T.ID_DAFTARPOColumn.AutoIncrementSeed = GetIdDaftarPO()
        DsPO1.DC_JLR_DAFTARPO_T.ID_DAFTARPOColumn.DefaultValue = GetIdDaftarPO()

        If txtNoMobil.Text = "" Then
            MessageBox.Show("Daftarkan Mobil Terlebih Dahulu", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        Try
            Try
                Dim rw As Object
                rw = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DaF_PO").Current
                If CType(rw, dsPO.DC_JLR_DAFTARPO_TRow).RowState <> DataRowState.Unchanged Then
                    Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DaF_PO").EndCurrentEdit()
                End If
            Catch
            End Try

            Try

                Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DaF_PO").AddNew()



            Catch ' ex As Exception

            End Try


            'Dim X As Integer
            'X = Me.BindingContext(dsPo1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Position
            'dsPo1.DC_JLR_DAFTARPO_T.Rows(X)("DC_JLR_DAFTARJALUR_T.DAF_PO") = GetIdDaftarJalur()

        Catch eEndEdit As System.Exception
            ShowError("Error Tambah PO", eEndEdit)
        End Try
        'Tombol
        SetTombol(True)
        txtNoFak.Focus()
    End Sub

    Private Sub grpDaftar_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles grpDaftar.Leave
        Try

            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").EndCurrentEdit()
        Catch ex As Exception
            'ShowError("Error Simpan Daftar PO", ex)

            'If MessageBox.Show("Kode Supplier Tidak Boleh Kosong." & vbCrLf & " Edit Kode Supplier ?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Error) = DialogResult.Yes Then
            '    txtSUPCO.Focus()
            'Else
            '    Me.BindingContext(dsPo1, "DC_JLR_DAFTARJALUR_T.DAF_PO").CancelCurrentEdit()
            '    SetTombol(False)
            'End If
            Debug.WriteLine("Error Simpan Daftar PO" & vbCrLf & ex.Message)
            ex = Nothing
        End Try

    End Sub


    Private Sub btnSimpanPO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimpanPO.Click
        'If Not lWithPO Then
        '    'Cek Faktur
        '    Try
        '        Dim olcom As New OleDbCommand("", olcon)
        '        olcom.CommandText = "Select count(*) From DC_DAFTARJALUR"
        '        If olcom.ExecuteScalar > 0 Then
        '            MsgBox("No. Mobil tidak boleh kosong", vbCritical)
        '            txtNoFak.Focus()
        '            Exit Sub
        '        End If
        '    Catch ex As Exception
        '        Throw ex
        '    End Try
        'End If
        If Not lWithPO Then
            If txtPO_GROSS.Text = "0" Or txtPO_QTY.Text = "0" Then
                MessageBox.Show("Isi QTY dan Gross Pendaftaran.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
                txtPO_QTY.Focus()
                Exit Sub
            End If
        End If

        If txtNoMobil.Text = "" Then
            MsgBox("No. Mobil tidak boleh kosong", vbCritical)
            txtNoMobil.Focus()
            Exit Sub
        End If

        If txtSUPCO.Text = "" Then
            MsgBox("Kode Supplier tidak boleh kosong", vbCritical)
            txtSUPCO.Focus()
            Exit Sub
        End If


        Dim Scon As New OleDbConnection(ConStrORA)
        Dim Scom As New OleDbCommand("", Scon)
        Scon.Open()
        Scom.CommandText = "Select sysdate from dual"
        txtTGL_MULAI.Text = Scom.ExecuteScalar
        Scon.Close()
        'Dim dr As Object
        'dr = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Current
        'dr.row("GUDANG_KODE") = cGUDANG_KODE
        'dr.row("LOKASI_KODE") = cLOKASI_KODE
        'dr.row("SUPID") = lblSUPID.Text
        'Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").EndCurrentEdit()

        lblGudangKode.Text = cGUDANG_KODE
        lblLokasiKode.Text = cLOKASI_KODE
        txtSupID.Text = lblSUPID.Text

        Dim lDaftarBaru As Boolean = False

        Dim drMobil As Object
        Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").EndCurrentEdit()
        drMobil = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Current
        If CType(drMobil.Row, dsPO.DC_JLR_DAFTARJALUR_TRow).RowState = DataRowState.Added Then
            KasihNoAntrian()
            lDaftarBaru = True
            'Simpan Langsung
            Try
                Dim ch As dsPO.DC_JLR_DAFTARJALUR_TDataTable
                ch = DsPO1.DC_JLR_DAFTARJALUR_T.GetChanges
                If (Not (ch) Is Nothing) Then
                    Me.olcon.Open()
                    Debug.WriteLine("Mobil Langsung: " & oldapMobil.Update(ch))
                End If
                DsPO1.DC_JLR_DAFTARJALUR_T.AcceptChanges()
            Catch updateException As System.Exception
                'Add your error handling code here.
                Throw updateException
            Finally
                'Close the connection whether or not the exception was thrown.
                Me.olcon.Close()
            End Try
        End If

        'btnUpdate_Click(sender, New System.EventArgs)
        'Simpan Langsung
        Try
            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").EndCurrentEdit()
            Dim ch As dsPO.DC_JLR_DAFTARPO_TDataTable
            ch = DsPO1.DC_JLR_DAFTARPO_T.GetChanges
            If (Not (ch) Is Nothing) Then
                Me.olcon.Open()
                Debug.WriteLine("PO Langsung: " & oldapPO.Update(ch))
                'Debug.WriteLine("PO Langsung: " & oldapPO.Update(Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").Current))
                'Debug.WriteLine("PO Langsung: " & OleDbDataAdapter1.Update(ch))
            End If
            DsPO1.DC_JLR_DAFTARPO_T.AcceptChanges()
        Catch ex1 As OleDbException
            Debug.WriteLine(ex1.Message)
            If ex1.Message.IndexOf("unique constraint") > 0 Then
                MessageBox.Show("Pendaftaran Sudah Pernah Diinput. Cek Nomor Faktur.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
                txtNoFak.Focus()
            Else
                ShowError("Error Update PO", ex1)
            End If
            Exit Sub
        Catch updateException As System.Exception
            ShowError("Error Update PO", updateException)
            Exit Sub
        Finally
            'Close the connection whether or not the exception was thrown.
            Me.olcon.Close()
        End Try

        'CEK 
        SetTombol(False)
        If lWithPO = False Then
            txtTgl_PO.Enabled = False
            txtSUPCO.Enabled = False
            chkADA_HARGA.Enabled = False
            chkBUAT_PO.Enabled = False

            txtPO_QTY.Enabled = False
            txtPO_GROSS.Enabled = False
            txtPO_PPN.Enabled = False
        End If

        If lDaftarBaru AndAlso MessageBox.Show("Apakah Anda Akan Buat Draft Retur ?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.Yes Then
            btnDraftRetur.PerformClick()
        End If
    End Sub
    Private Sub btnBatalPO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBatalPO.Click
        SetTombol(False)
        'Me.BindingContext(dsPo1, "DC_JLR_DAFTARJALUR_T.DAF_PO").CancelCurrentEdit()
        btnCancelAll_Click(sender, e)
    End Sub


    Private Sub grdDC_JLR_DAFTARPO_T_LostFocus(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'Me.BindingContext(dsPo1, "DC_JLR_DAFTARJALUR_T.Daf_PO").EndCurrentEdit()
        Debug.WriteLine("Grid PO Lost")
    End Sub

    Private Sub SetTombol(ByVal i As Boolean)
        txtNoMobil.Enabled = i
        txtTglDaftar.Enabled = i

        txtNoFak.Enabled = i
        txtTglFaktur.Enabled = i
        txtNo_PO.Enabled = i
        txtPO_QTY.Enabled = i
        txtPO_GROSS.Enabled = i
        txtPO_PPN.Enabled = i
        'txtTgl_PO.Enabled = i
        txtSUPCO.Enabled = i

        btnSimpanPO.Enabled = i
        btnBatalPO.Enabled = i

        btnNext.Enabled = Not i
        btnPrev.Enabled = Not i
        btnNext2.Enabled = Not i
        btnPrev2.Enabled = Not i
        btnEditPO.Enabled = Not i
        btnTambahPO.Enabled = Not i
        btnHapusPO.Enabled = Not i

        btnDaftar.Enabled = Not i
        btnCari.Enabled = Not i
        btnPrev.Enabled = Not i
        btnNext.Enabled = Not i
        btnPrev2.Enabled = Not i
        btnNext2.Enabled = Not i



    End Sub

#Region "Validasi PO"
    Private NoPO As String

    Private lWithPO As Boolean
    Private Sub txtNo_PO_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNo_PO.Enter
        NoPO = txtNo_PO.Text.ToUpper
    End Sub
    Private Sub txtNo_PO_Validating(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtNo_PO.Validating

        'TODO: Cek Item2 yang tidak maen di DC aktif (Jika ada Tolak PO)

        Dim Err_msg As String = ""

        'Tanpa PO
        If txtNo_PO.Text = "" Then
            lWithPO = False

            txtTgl_PO.Enabled = True
            txtSUPCO.Enabled = True
            chkADA_HARGA.Enabled = True

            'txtTgl_PO.Text = Now.Date

            'chkADA_HARGA.Value = 1
            'chkBUAT_PO.Value = 0
            chkADA_HARGA.Checked = True
            chkBUAT_PO.Checked = False

            'txtPO_QTY.Text = Format(0, "#,##0")
            'txtPO_GROSS.Text = Format(0, "#,##.##############")
            'txtPO_PPN.Text = Format(0, "#,##.##############")
            'txtPO_Total.Text = Format(0, "#,##.##############")
            'txtTot_Item.Text = CInt("0")

            txtPO_QTY.Text = "0"
            txtPO_GROSS.Text = "0"
            txtPO_PPN.Text = "0"
            txtPO_Total.Text = "0"
            txtTot_Item.Text = "0"

            'DoEvents
            'txtTGL_PO.SetFocus
            'txtTGL_PO.SetFocus
            'SendKeys("{TAB}")

            Exit Sub
        End If
        lWithPO = True

        txtNo_PO.Text = txtNo_PO.Text.ToUpper
        If txtNo_PO.Text = NoPO Then
            Exit Sub
        End If

        If Len(txtNo_PO.Text) < 9 Then
            MsgBox("PO Tidak ada.", vbCritical)
            'txtNO_PO.Text = ""
            If NoPO <> "" Then
                txtNo_PO.Text = NoPO
            End If
            e.Cancel = True
            Exit Sub
        End If

        Dim sql As String
        Dim Scon As New OleDb.OleDbConnection(ConStrORA)
        Dim Scom As New OleDb.OleDbCommand("", Scon)
        Dim sdar As OleDb.OleDbDataReader

        'hack: Test
        'Dim Scon As New OracleClient.OracleConnection("user id=DCSIM;data source=SIMULASIA;password=DCSIM")
        'Dim Scom As New OracleClient.OracleCommand("", Scon)
        'Dim sdar As OracleClient.OracleDataReader
        Try
            Scon.Open()

            sql = "Select COUNT(*) From DC_JLR_DaftarPO_T Where NoPO='" & _
                txtNo_PO.Text & "' "
            'sql &= "AND TRUNC(Tanggal)=TRUNC(sysdate) "
            sql &= "AND NO_FAK='" & txtNoFak.Text & "' "

            Scom.CommandText = sql
            If Scom.ExecuteScalar > 0 Then
                Err_msg = "PO sudah pernah didaftar dengan faktur sama."
                GoTo Batal
            End If

            'sql = "SELECT * "
            'sql &= "FROM JLR_GET_SUM_DAFTARPO_V "
            'sql &= "Where PO_NO_PO='" & txtNo_PO.Text & "' "
            'sql &= "AND PO_GUDANG='" & cDC_KODE & "' "

            sql = " SELECT "
            sql &= "MAX(PO_RECID) AS RECIDx,MIN(PO_GUDANG) AS PO_GUDANG,PO.PO_NO_PO, "
            sql &= "PO.PO_TGL_PO, PO.PO_SUPCO_MD AS SUPID, "
            sql &= "GET_SUPCO(PO.PO_SUPCO_MD)AS SUPCO, "
            sql &= "COUNT(*) AS TOT_ITEM "
            sql &= ",SUM(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*PODTL_QTYB*PODTL_ISI_SATB) AS PO_QTY "
            sql &= ",SUM( IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*(PODTL_QTYB*PODTL_ISI_SATB*PODTL_PRICE- "
            sql &= "   ((PODTL_QTYB*PODTL_ISI_SATB)/((PODTL_QTYB*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
            sql &= "   *NVL(TotDisc,0))) ) AS PO_GROSS "
            sql &= ",SUM(CASE WHEN PODTL_PPN > 0 THEN (IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)"
            sql &= "	*((PODTL_QTYB*PODTL_ISI_SATB*PODTL_PRICE-((PODTL_QTYB*PODTL_ISI_SATB)"
            sql &= "	/((PODTL_QTYB*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
            sql &= "	*NVL(TotDisc,0)))*.1)) ELSE 0 END) AS PO_PPN "
            sql &= ",MIN(PO_UMUR) AS PO_UMUR "
            sql &= ",SUM(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*NVL(PODTL_PPN_BTL,0)) AS PPN_BOTOL "
            sql &= "FROM DC_PO_T PO "
            sql &= "LEFT JOIN DC_PODTL_T DT ON PO.PO_NO_PO = DT.PODTL_FK_NO_PO "
            sql &= "LEFT JOIN ("
            sql &= "	SELECT MBR_FK_PLUID,(MBR_TAG) AS MBR_TAG "
            sql &= "	FROM DC_BARANG_DC_V WHERE TBL_DC_KODE='" & cDC_KODE & "') BRG ON DT.PODTL_PLUMD=BRG.MBR_FK_PLUID "
            sql &= "LEFT JOIN ( "
            sql &= "	SELECT podisc_fk_no_po,PODISC_FK_PLU, "
            sql &= "	SUM(NVL(podisc_nilai,0)) AS TotDisc "
            sql &= "	FROM DC_PODISC_T "
            sql &= "	GROUP BY podisc_fk_no_po,PODISC_FK_PLU) S ON PO.PO_NO_PO=S.podisc_fk_no_po "
            sql &= "	AND DT.PODTL_PLUMD=S.PODISC_FK_PLU "
            sql &= "WHERE (PODTL_RECID IS NULL OR PODTL_RECID='') "
            sql &= "AND PO_NO_PO='" & txtNo_PO.Text & "' "
            sql &= "GROUP BY PO.PO_NO_PO, PO.PO_TGL_PO, PO.PO_SUPCO_MD "
            Scom.CommandText = sql

            sdar = Scom.ExecuteReader
            If sdar.Read = False Then
                Err_msg = "PO tidak ada. Atau Sudah BPB"
                GoTo Batal
            End If

            If sdar("SUPCO") <> lblSUPCO.Text And lblSUPCO.Text <> "" Then
                Err_msg = "PO Harus dari Supplier yang Sama."
                GoTo Batal
            End If



            ''Cek Status PO
            If CType(sdar("PO_TGL_PO"), Date).AddDays(IIf(sdar("PO_UMUR") <= 0, 7, sdar("PO_UMUR"))) < Now.Date Then
                Err_msg = "PO Sudah Kadaluarsa."
                GoTo Batal
            End If

            Dim rc As String = sdar("RECIDx") & ""
            Select Case rc
                Case "C"
                    Err_msg = "PO Di-Closing"
                Case "B"
                    Err_msg = "PO Sudah ada BPB-nya"
                Case "H"
                    Err_msg = "PO Hangus"
                Case "A"
                    Err_msg = "PO Sedang dibuat BPB-nya"
                Case "1"
                    Err_msg = "Item PO dihapus"
                Case "2"
                    Err_msg = "PO Revisi"
            End Select
            If Err_msg <> "" Then GoTo Batal

            If IFNULL(sdar("PO_QTY"), 0) + IFNULL(sdar("PO_GROSS"), 0) + IFNULL(sdar("PO_PPN"), 0) = 0 Then
                Err_msg = "Qty, Gross & PPN Kosong."
                GoTo Batal
            End If

            'Cek Supp. MrBread
            'CEK TBL ALOKASI DAN CEK SJ
            Dim IsMBread As Boolean = IsMrBread(sdar("SUPCO") & "", cDC_KODE)
            If IsMBread Then
                Dim Scon2 As New OleDbConnection(ConStrORA)
                Dim Scom2 As New OleDbCommand("", Scon2)

                Try
                    Scon2.Open()
                    Scom2.CommandType = CommandType.StoredProcedure
                    Scom2.CommandText = "IMPORT_MBREAD('" & cDC_KODE & "')"
                    Scom2.ExecuteNonQuery()

                    Scom2.CommandType = CommandType.Text
                    Scom2.CommandText = "select CEK_MRBREAD ( '" & txtNoFak.Text & _
                        "', TO_DATE('" & Format(txtTglFaktur.Value, "yyyyMMdd") & "','YYYYMMDD'), '" & txtNo_PO.Text & "') as x from dual"
                    Err_msg = Scom2.ExecuteScalar & " "
                    If Err_msg.Substring(0, 1) = "1" Or Err_msg.Substring(0, 1) = "3" Then
                        '1;No. Faktur atau Tanggal Faktur Salah.
                        '3;Jumlah Item Faktur > Jumlah Item PO.

                        Err_msg = Err_msg.Substring(2)
                        GoTo Batal
                    Else
                        '2;Total Faktur Dan PO Tidak Sama.
                        If Err_msg.Substring(0, 1) = "2" Then
                            Err_msg = Err_msg.Substring(2)
                            MessageBox.Show(Err_msg, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        End If
                    End If
                    Err_msg = ""
                Catch ex As Exception
                    Throw ex
                Finally
                    Scon2.Close()
                End Try

            End If

            'isi TextBOX
            txtTgl_PO.Text = sdar("PO_TGL_PO")
            txtSUPCO.Text = sdar("SUPCO")
            lblSUPID.Text = IFNULL(sdar("SUPID"), 0)
            If lblSUPCO.Text = "" Then
                lblSUPCO.Text = sdar("SUPCO")
            End If

            'Dim dr As Object
            'dr = Me.BindingContext(dsPo1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Current
            'dr.row("SUPID") = sdar("SUPID") & ""

            chkBUAT_PO.Checked = True ''''''''
            chkADA_HARGA.Checked = True ''''''

            txtTot_Item.Enabled = False
            txtPO_QTY.Enabled = False
            txtPO_GROSS.Enabled = False
            txtPO_PPN.Enabled = False

            If Not IsMBread Then
                txtPO_QTY.Text = Format(sdar("PO_QTY"), "#,##0")
                txtPO_GROSS.Text = Format(CDbl(sdar("PO_GROSS")), "#,##.##############")
                txtPO_PPN.Text = Format(CDbl(IFNULL(sdar("PO_PPN"), 0)), "#,##.##############")
                txtPO_Total.Text = Format(CDbl(sdar("PO_GROSS")) + CDbl(IFNULL(sdar("PO_PPN"), 0)) + CDbl(IFNULL(sdar("PPN_BOTOL"), 0)), "#,##.##############")
                txtTot_Item.Text = CDbl("0" & sdar("TOT_ITEM"))
            Else
                sdar.Close()

                sql = " SELECT "
                sql &= "MAX(PO_RECID) AS RECIDx,MIN(PO_GUDANG) AS PO_GUDANG,PO.PO_NO_PO, "
                sql &= "PO.PO_TGL_PO, PO.PO_SUPCO_MD AS SUPID, "
                sql &= "GET_SUPCO(PO.PO_SUPCO_MD)AS SUPCO, "
                sql &= "COUNT(*) AS TOT_ITEM "
                sql &= ",SUM(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*NVL(BREAD.JUM,0)*PODTL_ISI_SATB) AS PO_QTY "
                sql &= ",SUM( IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*(NVL(BREAD.JUM,0)*PODTL_ISI_SATB*PODTL_PRICE- "
                sql &= "   ((NVL(BREAD.JUM,0)*PODTL_ISI_SATB)/((NVL(BREAD.JUM,0)*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
                sql &= "   *NVL(TotDisc,0))) ) AS PO_GROSS "
                sql &= ",SUM(CASE WHEN PODTL_PPN > 0 THEN "
                sql &= "	(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*((NVL(BREAD.JUM,0)*PODTL_ISI_SATB*PODTL_PRICE- "
                sql &= "	((NVL(BREAD.JUM,0)*PODTL_ISI_SATB)/((NVL(BREAD.JUM,0)*PODTL_ISI_SATB)+PODTL_FRAC_QTYB) "
                sql &= "	*NVL(TotDisc,0)))*.1)) ELSE 0 END) AS PO_PPN "
                sql &= ",MIN(PO_UMUR) AS PO_UMUR "
                sql &= ",SUM(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*NVL(PODTL_PPN_BTL,0)) AS PPN_BOTOL "
                sql &= "FROM DC_PO_T PO "
                sql &= "LEFT JOIN DC_PODTL_T DT ON PO.PO_NO_PO = DT.PODTL_FK_NO_PO "
                sql &= "LEFT JOIN ("
                sql &= "	SELECT MBR_FK_PLUID,(MBR_TAG) AS MBR_TAG "
                sql &= "	FROM DC_BARANG_DC_V "
                sql &= "	WHERE TBL_DC_KODE='" & cDC_KODE & "') BRG ON DT.PODTL_PLUMD=BRG.MBR_FK_PLUID "
                sql &= "LEFT JOIN ( "
                sql &= "	SELECT podisc_fk_no_po,PODISC_FK_PLU, "
                sql &= "	SUM(NVL(podisc_nilai,0)) AS TotDisc "
                sql &= "	FROM DC_PODISC_T "
                sql &= "	GROUP BY podisc_fk_no_po,PODISC_FK_PLU) S ON PO.PO_NO_PO=S.podisc_fk_no_po "
                sql &= "	AND DT.PODTL_PLUMD=S.PODISC_FK_PLU "
                sql &= "LEFT JOIN ( "
                sql &= "	 SELECT   a.pluid AS plumd, SUM (a.qty) AS Jum "
                sql &= "     FROM alokasi_tampung a "
                sql &= "	 WHERE (a.no_sj = '" & txtNoFak.Text & "') "
                sql &= "   	 GROUP BY a.no_sj, a.tgl_sj, a.pluid "
                sql &= "	 order by plumd) BREAD ON  DT.podtl_plumd=BREAD.PLUMD "
                sql &= "WHERE (PODTL_RECID IS NULL OR PODTL_RECID='') "
                sql &= "AND PO_NO_PO='" & txtNo_PO.Text & "' "
                sql &= "GROUP BY PO.PO_NO_PO, PO.PO_TGL_PO, PO.PO_SUPCO_MD "
                Scom.CommandText = sql
                sdar = Scom.ExecuteReader
                If sdar.Read Then
                    txtPO_QTY.Text = Format(sdar("PO_QTY"), "#,##0")
                    txtPO_GROSS.Text = Format(CDbl(sdar("PO_GROSS")), "#,##.##############")
                    txtPO_PPN.Text = Format(CDbl(IFNULL(sdar("PO_PPN"), 0)), "#,##.##############")
                    txtPO_Total.Text = Format(CDbl(sdar("PO_GROSS")) + CDbl(IFNULL(sdar("PO_PPN"), 0)) + CDbl(IFNULL(sdar("PPN_BOTOL"), 0)), "#,##.##############")
                    txtTot_Item.Text = CDbl("0" & sdar("TOT_ITEM"))
                Else
                    Err_msg = "Data Alokasi MBREAD Tidak ada."
                    GoTo Batal
                End If
            End If

            sdar.Close()
            sdar = Nothing

            sql = "Select S.SUP_NAMA AS SNAMA from DC_SUPPLIER_DC_V H,DC_SUPPLIER_T S " & _
                "Where H.SUP_FK_SUPID=s.SUP_SUPID And " & _
                "TBL_DC_KODE='" & cDC_KODE & _
                "' AND H.SUP_SUPKODE='" & txtSUPCO.Text & "'"
            Scom.CommandText = sql

            txtNamaSupp.Text = "" & Scom.ExecuteScalar
            If lblSNAMA.Text = "" Then
                lblSNAMA.Text = txtNamaSupp.Text
            End If

            txtSUPCO.Enabled = False
            txtTgl_PO.Enabled = False
            chkADA_HARGA.Enabled = False

            btnSimpanPO.Focus()


            Exit Try
Batal:
            MessageBox.Show(Err_msg, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            If NoPO <> "" Then
                txtNo_PO.Text = NoPO
            Else
                txtNo_PO.Text = ""
                NoPO = ""
                txtNo_PO.Focus()
            End If

            e.Cancel = True
        Catch ex As Exception
            ShowError("Error Baca PO", ex)
        End Try
    End Sub
    '    Private Sub HandleColomPO(ByVal sender As Object, ByVal e As System.Data.DataColumnChangeEventArgs)
    '        If e.Column.ColumnName = "NOPO" Then
    '            'TODO: CEK TBL ALOKASI DAN CEK SJ
    '            'TODO: Cek Item2 yang tidak maen di DC aktif (Jika ada Tolak PO)

    '            Dim Err_msg As String

    '            'Tanpa PO
    '            If txtNo_PO.Text = "" Then
    '                lWithPO = False

    '                txtTgl_PO.Enabled = True
    '                txtSUPCO.Enabled = True
    '                chkADA_HARGA.Enabled = True

    '                txtTgl_PO.Text = Now.Date

    '                'chkADA_HARGA.Value = 1
    '                'chkBUAT_PO.Value = 0
    '                chkADA_HARGA.Checked = True
    '                chkBUAT_PO.Checked = False

    '                txtPO_QTY.Text = Format(0, "#,##0")
    '                txtPO_GROSS.Text = Format(0, "#,##.##############")
    '                txtPO_PPN.Text = Format(0, "#,##.##############")
    '                txtPO_Total.Text = Format(0, "#,##.##############")
    '                txtTot_Item.Text = CInt("0")

    '                'DoEvents
    '                'txtTGL_PO.SetFocus
    '                'txtTGL_PO.SetFocus
    '                'SendKeys("{TAB}")

    '                Exit Sub
    '            End If
    '            lWithPO = True

    '            txtNo_PO.Text = txtNo_PO.Text.ToUpper
    '            If txtNo_PO.Text = NoPO Then
    '                Exit Sub
    '            End If

    '            If Len(txtNo_PO.Text) < 9 Then
    '                MsgBox("PO Tidak ada.", vbCritical)
    '                'txtNO_PO.Text = ""
    '                'e.Cancel = True
    '                e.ProposedValue = e.Row(e.Column)
    '                Exit Sub
    '            End If

    '            Dim sql As String
    '            Dim Scon As New OleDb.OleDbConnection(ConStrORA)
    '            Dim Scom As New OleDb.OleDbCommand("", Scon)
    '            Try
    '                Scon.Open()
    '                sql = "Select COUNT(*) From DC_JLR_DaftarPO_T Where NoPO='" & _
    '                    txtNo_PO.Text & "' AND NO_FAK='" & txtNoFak.Text & "' To_Char(Tanggal)=To_Char(sysdate)"
    '                Scom.CommandText = sql
    '                If Scom.ExecuteScalar > 0 Then
    '                    Err_msg = "PO sudah pernah didaftar."
    '                    GoTo Batal
    '                End If

    '                sql = "SELECT MAX(PO_RECID) AS RECIDx,PO.PO_NO_PO, PO.PO_TGL_PO, PO.PO_SUPCO_MD as SUPID, GET_SUPCO(PO.PO_SUPCO_MD)AS SUPCO,"
    '                sql &= "COUNT(*) AS TOT_ITEM, SUM(DT.PODTL_QTYB) AS PO_QTY, "
    '                sql &= "SUM(((FLOOR(((PODTL_QTYB*PODTL_ISI_SATB)+ PODTL_FRAC_QTYB)/PODTL_ISI_SATB))*PODTL_ISI_SATB*PODTL_PRICE)-PODTL_DISC) AS PO_GROSS, "
    '                sql &= "SUM(CASE WHEN PODTL_PPN > 0 THEN (((FLOOR(((PODTL_QTYB*PODTL_ISI_SATB)+ PODTL_FRAC_QTYB)/PODTL_ISI_SATB))*PODTL_ISI_SATB*PODTL_PRICE)-PODTL_DISC)*.1 ELSE 0 END) AS PO_PPN, "
    '                sql &= "MAX(PO_UMUR) as PO_UMUR "
    '                sql &= "FROM DC_PO_T PO, DC_PODTL_T DT "
    '                sql &= "Where PO.PO_NO_PO = DT.PODTL_FK_NO_PO AND PO_NO_PO='" & txtNo_PO.Text & "' AND PO_GUDANG='" & cDC_KODE & "' "
    '                sql &= "GROUP BY PO.PO_NO_PO, PO.PO_TGL_PO, PO.PO_SUPCO_MD "
    '                Scom.CommandText = sql

    '                Dim sdar As OleDb.OleDbDataReader
    '                sdar = Scom.ExecuteReader
    '                If sdar.Read = False Then
    '                    Err_msg = "PO tidak ada."
    '                    GoTo Batal
    '                End If

    '                Dim sSupco As String
    '                Try
    '                    If sSupco = "" And dsPo1.DC_JLR_DAFTARJALUR_T.Rows(Me.BindingContext("DC_JLR_DAFTARJALUR_T").Position - 1)("SUPCO") <> "" Then
    '                        sSupco = dsPo1.DC_JLR_DAFTARJALUR_T.Rows(Me.BindingContext("DC_JLR_DAFTARJALUR_T").Position - 1)("SUPCO")
    '                    End If
    '                Catch

    '                End Try


    '                If sdar("SUPCO") <> sSupco And sSupco <> "" Then
    '                    Err_msg = "PO Harus dari Supplier yang Sama."
    '                    GoTo Batal
    '                End If
    '                Try
    '                    If sSupco = "" Then
    '                        dsPo1.DC_JLR_DAFTARJALUR_T.Rows(Me.BindingContext("DC_JLR_DAFTARJALUR_T").Position - 1)("SUPCO") = sdar("SUPCO")
    '                        sSupco = sdar("SUPCO")
    '                    End If
    '                Catch

    '                End Try

    '                ''Cek Status PO
    '                If CType(sdar("PO_TGL_PO"), Date).AddDays(IIf(sdar("PO_UMUR") <= 0, 7, sdar("PO_UMUR"))) < Now.Date Then
    '                    Err_msg = "PO Sudah Kadaluarsa."
    '                    GoTo Batal
    '                End If

    '                Select Case sdar("RECIDx") & ""
    '                    Case "C"
    '                        Err_msg = "PO Di-Closing"
    '                    Case "R"
    '                        Err_msg = "PO Sudah ada BPB-nya"
    '                    Case "H"
    '                        Err_msg = "PO Hangus"
    '                    Case "A"
    '                        Err_msg = "PO Sedang dibuat BPB-nya"
    '                    Case "1"
    '                        Err_msg = "Item PO dihapus"
    '                    Case "2"
    '                        Err_msg = "PO Revisi"
    '                End Select
    '                If Err_msg <> "" Then GoTo Batal

    '                If IFNULL(sdar("PO_QTY"), 0) + IFNULL(sdar("PO_GROSS"), 0) + IFNULL(sdar("PO_PPN"), 0) = 0 Then
    '                    Err_msg = "Qty, Gross & PPN Kosong."
    '                    GoTo Batal
    '                End If

    '                'isi TextBOX
    '                txtTgl_PO.Text = sdar("PO_TGL_PO")
    '                txtSUPCO.Text = sdar("SUPCO")
    '                lblSUPID.Text = IFNULL(sdar("SUPID"), 0)
    '                If lblSUPCO.Text = "" Then
    '                    lblSUPCO.Text = sdar("SUPCO")
    '                End If
    '                chkBUAT_PO.Checked = True ''''''''
    '                chkADA_HARGA.Checked = True ''''''
    '                txtPO_QTY.Text = Format(sdar("PO_QTY"), "#,##0")
    '                txtPO_GROSS.Text = Format(CDbl(sdar("PO_GROSS")), "#,##.##############")
    '                txtPO_PPN.Text = Format(CDbl(sdar("PO_PPN")), "#,##.##############")
    '                txtPO_Total.Text = Format(CDbl(sdar("PO_GROSS")) + CDbl(sdar("PO_PPN")), "#,##.##############")
    '                txtTot_Item.Text = CDbl("0" & sdar("TOT_ITEM"))


    '                sdar.Close()
    '                sdar = Nothing

    '                sql = "Select S.SUP_NAMA AS SNAMA from DC_SUPPLIER_DC_V H,DC_SUPPLIER_T S " & _
    '                    "Where H.SUP_FK_SUPID=s.SUP_SUPID And " & _
    '                    "TBL_DC_KODE='" & cDC_KODE & _
    '                    "' AND H.SUP_SUPKODE='" & txtSUPCO.Text & "'"
    '                Scom.CommandText = sql

    '                txtNamaSupp.Text = "" & Scom.ExecuteScalar
    '                If lblSNAMA.Text = "" Then
    '                    lblSNAMA.Text = txtNamaSupp.Text
    '                End If

    '                txtSUPCO.Enabled = False
    '                txtTgl_PO.Enabled = False
    '                chkADA_HARGA.Enabled = False

    '                Exit Try
    'Batal:
    '                MessageBox.Show(Err_msg, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
    '                txtNo_PO.Text = ""
    '                NoPO = ""
    '                txtNo_PO.Focus()
    '                e.ProposedValue = e.Row(e.Column)
    '            Catch ex As Exception
    '                ShowError("Error Baca PO", ex)
    '            End Try

    '            'If MessageBox.Show("Haloo", "aaa", MessageBoxButtons.YesNo) <> DialogResult.Yes Then
    '            '    e.ProposedValue = e.Row(e.Column)
    '            'End If
    '        End If
    '    End Sub
    '    Private Sub HandleRowPo(ByVal sender As Object, ByVal e As System.Data.DataRowChangeEventArgs)
    '        If e.Action = DataRowAction.Add Then
    '            If e.Row("SUPCO") = "" Then
    '                'MessageBox.Show("AAAAAAAAAAAAAAAAAAAAA")
    '                Debug.WriteLine("SUPCO Blank")
    '            End If
    '        End If
    '    End Sub
#End Region

    Private Sub txtSUPCO_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtSUPCO.Validating
        If txtSUPCO.Text = "" And Not lWithPO Then
            MessageBox.Show("KODE SUPPLIER HARUS DIISI", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            e.Cancel = True
            Exit Sub
        End If

        If txtSUPCO.Text <> lblSUPCO.Text And lblSUPCO.Text <> "" Then
            MessageBox.Show("Pedaftaran Harus Dari Supplier yang Sama.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            e.Cancel = True
            Exit Sub
        End If

        If Len(txtSUPCO.Text) < 4 Then
            MessageBox.Show("Supplier " & txtSUPCO.Text & " tidak ada !!!", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            e.Cancel = True
            Exit Sub
        End If

        Dim sql As String
        Dim Scon As New OleDbConnection(ConStrORA)
        Dim Scom As New OleDbCommand("", Scon)
        Dim Sdar As OleDbDataReader
        Try
            Scon.Open()
            'Todo: Buat PO tidak ada Kolom
            sql = "Select S.SUP_NAMA AS SNAMA,H.SUP_SUPKODE AS SUPCO,H.SUP_FLAG_BUATPO AS BUAT_PO,s.SUP_SUPID AS SUPID from DC_SUPPLIER_DC_V H,DC_SUPPLIER_T S "
            sql &= "Where H.SUP_FK_SUPID=s.SUP_SUPID And "
            sql &= "TBL_DC_KODE='" & cDC_KODE
            sql &= "' AND H.SUP_SUPKODE='" & txtSUPCO.Text & "'"
            Scom.CommandText = sql
            Sdar = Scom.ExecuteReader
            If Sdar.Read Then
                'Cek With PO
                If Not lWithPO Then
                    If "" & Sdar("BUAT_PO") = "Y" Then
                        MsgBox("Supplier " & txtSUPCO.Text & " Harus Pakai PO !!!", vbCritical)
                        txtSUPCO.Text = ""
                        txtNamaSupp.Text = ""
                        e.Cancel = True
                        GoTo ex
                    Else
                        txtPO_QTY.Focus()
                    End If
                End If
                txtNamaSupp.Text = Sdar("SNAMA") & ""

                lblSUPID.Text = IFNULL(Sdar("SUPID"), 0)

                If lblSUPCO.Text = "" Then
                    lblSUPCO.Text = Sdar("SUPCO")
                End If
                If lblSNAMA.Text = "" Then
                    lblSNAMA.Text = txtNamaSupp.Text
                End If
            Else
                MsgBox("Supplier " & txtSUPCO.Text & " tidak ada !!!", vbCritical)
                e.Cancel = True
            End If
ex:         Sdar.Close()
        Catch ex As Exception
            ShowError("Error Baca Supplier", ex)
        Finally
            Scon.Close()
            Scon = Nothing
        End Try
    End Sub
    Private Sub txtNoMobil_Validate(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtNoMobil.Validating

        Dim Scon As New OleDbConnection(ConStrORA)
        Dim Scom As New OleDbCommand("", Scon)

        Scon.Open()
        Scom.CommandText = "Select COUNT(*) From DC_JLR_DaftarJalur_T Where NoMobil='" & _
            txtNoMobil.Text & "' AND TO_CHAR(Tanggal,'dd/mon/yyyy')=TO_CHAR(sysdate,'dd/mon/yyyy') AND DC_ID=" & cDC_ID
        If Scom.ExecuteScalar > 0 Then
            e.Cancel = True
            MsgBox("No Mobil sudah didaftarkan.", vbCritical)
        End If
        Scon.Close()
    End Sub

    Private Sub btnPrev2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrev2.Click
        Try
            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Position -= 1
        Catch 'ex As Exception
            'Throw ex
        End Try
    End Sub
    Private Sub btnNext2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext2.Click
        Try
            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Position += 1
        Catch 'ex As Exception
            'Throw ex
        End Try
    End Sub

    Private Function GetIdDaftarJalur() As Integer
        Dim Scon As New OleDbConnection(ConStrORA)
        Dim Scom As New OleDbCommand("", Scon)
        Dim n As Integer


        Scon.Open()
        Scom.CommandText = "select DC_JLR_DaftarJalur_T_SEQ.nextval from dual"
        n = Scom.ExecuteScalar()
        Scon.Close()

        Return n
    End Function
    Private Function GetIdDaftarPO() As Integer
        Dim Scon As New OleDbConnection(ConStrORA)
        Dim Scom As New OleDbCommand("", Scon)
        Dim n As Integer

        Scon.Open()
        Scom.CommandText = "select DC_JLR_DaftarPO_T_SEQ.nextval from dual"
        n = Scom.ExecuteScalar()
        Scon.Close()

        Return n
    End Function
    Private Function KasihNoAntrian() As Boolean

        Dim drMobil As Object
        drMobil = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Current


        Dim nNoUrut As Integer = NextAntrian()

        '        'ISI Booking Jalur
        '        Dim Scon As New OleDbConnection(ConStrORA)
        '        Dim Scom As New OleDbCommand("Select A.Jalur,S.Jam1,S.Jam2,S.ID_Antrian From DC_JLR_SUPP1ST_V S Left Join DC_JLR_Antrian_T A ON S.ID_Antrian=A.ID_Antrian " & _
        '            "Where S.SUPCO='" & txtSUPCO.Text & "' AND A.DC_ID=" & cDC_ID & _
        '            "", Scon)
        '        Dim Sdar As OleDbDataReader
        '        Dim Sdar2 As OleDbDataReader

        '        If Sdar.Read Then
        '            'Cek Supp BESAR langsung masuk (Jam Supp)
        '            If Not IsNothing(Sdar("jam1")) Then
        '                dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("Jalur") = Sdar("Jalur")

        '                'cek Boking Kosong
        '                Scom.CommandText = "Select Count(*) as Jum From DC_JLR_Antrian_T " & _
        '                    "Where Jalur='" & dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("Jalur") & _
        '                    "' AND  (Supplier ='' Or Supplier IS NULL) AND DC_ID=" & cDC_ID
        '                If Scom.ExecuteScalar > 0 Then
        '                    'cek Jam Booking
        '                    If Now.ToShortTimeString >= Sdar("jam1") And Now.ToShortTimeString <= Sdar("JAM2") Then
        'MasukinSupp:            'Masukkan Supplier
        '                        dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("Recid") = 2
        '                        dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("TglStart") = Now()
        '                        Scom.CommandText = _
        '                            "UPDATE DC_JLR_Antrian_T SET Supplier='" & txtSUPCO.Text & _
        '                            "', NoAntrian=" & nNoUrut & " Where Jalur='" & dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("Jalur") & "' AND DC_ID=" & cDC_ID
        '                        Scom.ExecuteNonQuery()

        '                        Scom.CommandText = "INSERT INTO DC_JLR_TempAntrian_T ( Jalur, SUPCO, SNAMA, NoMobil, NoAntrian,DC_ID) " & _
        '                                                    "VALUES('" & dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("Jalur") & "','" & txtSUPCO.Text & "','" & _
        '                                                    txtNamaSupp.Text & "','" & txtNoMobil.Text & "'," & nNoUrut & "," & cDC_ID & ")"
        '                        Scom.ExecuteNonQuery()
        '                    Else
        '                        'Todo:Cek Jam Bebas
        '                        Scom.CommandText = "Select Count(*) as Jum from DC_JLR_Supp1st_V where ID_ANTRIAN=" & Sdar("ID_Antrian") & _
        '                            " AND TO_CHAR(SYSDATE,'hh24:mi:ss') between TO_CHAR(jam1,'hh24:mi:ss') and " & _
        '                            "TO_CHAR(jam1+0.5/24,'hh:mi:ss')"
        '                        If Scom.ExecuteScalar = 0 Then
        '                            GoTo MasukinSupp
        '                        End If
        '                    End If
        '                End If
        '            Else
        '                'Supplier Kecil langsung Masuk Pada Jam Jalur -nya

        '                'Cek Jalurnya Masih Aktif
        '                Scom.CommandText = "Select Supplier,NoAntrian From DC_JLR_Antrian_T " & _
        '                    "Where Jalur='" & Sdar("Jalur") & _
        '                    "' AND TO_CHAR(SYSDATE,'hh24:mi:ss') BETWEEN TO_CHAR(jam1,'hh24:mi:ss') and TO_CHAR(jam2,'hh24:mi:ss') AND DC_ID=" & cDC_ID
        '                Sdar = Scom.ExecuteReader

        '                If Sdar.Read Then
        '                    dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("Jalur") = Sdar("Jalur")
        '                    If "" & Sdar("Supplier") = "" Then
        '                        GoTo MasukinSupp
        '                    End If
        '                End If
        '            End If
        '        End If
        '        Sdar.Close()


        drMobil.ROW("NOURUT") = nNoUrut
        drMobil.ROW("SUPCO") = txtSUPCO.Text
        Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").EndCurrentEdit()
    End Function
    Private Function NextAntrian() As Integer
        Dim Scon As New OleDbConnection(ConStrORA)
        Dim Scom As New OleDbCommand("", Scon)
        Dim n As Integer

        Scon.Open()
        Scom.CommandText = "Select COUNT(*) From DC_JLR_Setting_T WHERE DC_ID=" & cDC_ID
        If Scom.ExecuteScalar = 0 Then
            Scom.CommandText = "INSERT INTO VALUES(" & cDC_ID & ",2,TRUNC(SYSDATE())"
            Scom.ExecuteNonQuery()
            Return 1
        End If

        Scom.CommandText = "Select NextNoUrut From DC_JLR_Setting_T WHERE DC_ID=" & cDC_ID
        n = "0" & Scom.ExecuteScalar()
        If n = 0 Then
            n = 1
        End If

        Scom.CommandText = "UPDATE DC_JLR_Setting_T  SET NextNoUrut=" & n & "+1 WHERE DC_ID=" & cDC_ID
        Scom.ExecuteNonQuery()

        Scon.Close()

        Return n

    End Function

    Private Sub btnHapusPO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHapusPO.Click
        Dim X As Integer
        X = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Position


        If X < 0 Then
            MsgBox("Tidak Ada Data yang dihapus !", vbCritical)
            Exit Sub
        End If
        Dim dr As Object
        dr = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Current


        If "" & dr.row("Recid") = "B" Then
            MsgBox("Tidak Bisa Hapus, Faktur sudah ada BPB-nya !", vbCritical)
            Exit Sub
        End If

        If MsgBox("Menghapus Faktur akan menghapus BPB bila BPB sudah diinput." & vbCrLf & _
            "Hapus Faktur No." & txtNoFak.Text & " ?", vbExclamation Or vbYesNo Or vbDefaultButton2) = vbNo Then
            Exit Sub
        End If

        Dim lHapusMobil As Boolean
        lHapusMobil = False
        If Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Count = 1 Then
            If MsgBox("PO HANYA 1. Hapus PO Akan Menghapus Mobil ini. LANJUTKAN?", vbExclamation Or vbYesNo Or vbDefaultButton2) = vbNo Then
                Exit Sub
            End If
            lHapusMobil = True
        End If
        Debug.WriteLine("Hapus PO " & X)
        Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").RemoveAt(X)

        If lHapusMobil Then
            Debug.WriteLine("Hapus Mobil " & X)
            X = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position
            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").RemoveAt(X)
        End If

        Try
            Dim ch As dsPO
            ch = DsPO1.GetChanges
            If (Not (ch) Is Nothing) Then
                Me.olcon.Open()
                Debug.WriteLine("Delete Daftar Langsung: " & oldapPO.Update(ch))
                Debug.WriteLine("Delete Mobil Langsung: " & oldapMobil.Update(ch))
                'Dim Olcom As New OleDbCommand("", olcon)
                'Olcom.CommandText = "Delete From DC_JLR_DaftarPO_T where "
                'Olcom.ExecuteNonQuery()
            End If


            DsPO1.DC_JLR_DAFTARJALUR_T.AcceptChanges()
            DsPO1.DC_JLR_DAFTARPO_T.AcceptChanges()
        Catch updateException As System.Exception
            'Add your error handling code here.
            Throw updateException
        Finally
            'Close the connection whether or not the exception was thrown.
            Me.olcon.Close()
        End Try
    End Sub

    Private Sub btnEditPO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEditPO.Click
        'If txtNo_PO.Text = "" Then
        '    MsgBox("Tidak Bisa Edit Pendaftaran Tanpa PO.", vbCritical)
        '    Exit Sub
        'End If

        ''EnableInput
        'txtNoFak.Enabled = True
        'txtTglFaktur.Enabled = True


        'txtNo_PO.Enabled = True
        'txtPO_QTY.Enabled = True
        'txtPO_GROSS.Enabled = True
        'txtPO_PPN.Enabled = True

        'txtNoFak.Focus()

        ''UnBindData
        'btnSimpanPO.Enabled = True
        'btnBatalPO.Enabled = True

        If lblStatus.Text <> "" Then
            MessageBox.Show("Tidak Bisa Edit PO. " & lblStatusKeterangan.Text & "", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        If txtNo_PO.Text = "" Then
            MessageBox.Show("Tidak Bisa Edit Pendaftaran Tanpa PO.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If


        Dim LastQTY As Double
        Dim LastGross As Double
        LastQTY = IFNULL(txtPO_QTY.Text, 0)
        LastGross = IFNULL(txtPO_GROSS.Text, 0)

        NoPO = txtNo_PO.Text

        Dim fe As New frmEditPO

        fe.sNoPo = txtNo_PO.Text
        fe.nIdDaftarPO = lblIdDaftarPO.Text
        If IsMrBread(txtSUPCO.Text, cDC_KODE) Then
            fe.FakturMBread = txtNoFak.Text
            fe.IsMrBread = True

            MessageBox.Show("Tidak Bisa Edit Pendaftaran Mr.Bread.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub

        Else
            fe.IsMrBread = False
        End If

        'If fe.CekItemPO = True Then

        'fe.Top += Me.Height - fe.Height

        If fe.ShowDialog = Windows.Forms.DialogResult.OK Then
            txtPO_QTY.Text = Format(fe.nQTY, "#,##0")
            txtTot_Item.Text = Format(fe.nItem, "#,##0")
            txtPO_GROSS.Text = Format(fe.nGROSS, "#,##.##############")

            txtPO_PPN.Text = Format(fe.nPPN, "#,##.##############")
            txtPO_Total.Text = Format(fe.nGROSS + fe.nPPN, "#,##.##############")

            'txtPO_PPN.Text = Format(fe.nGROSS * 0.1, "#,##.##############")
            'txtPO_Total.Text = Format(fe.nGROSS + (fe.nGROSS * 0.1), "#,##.##############")
            lblTglRevisi.Text = GetOracleDate()


            'Simpan Langsung
            Try
                Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").EndCurrentEdit()
                Dim ch As dsPO.DC_JLR_DAFTARPO_TDataTable
                ch = DsPO1.DC_JLR_DAFTARPO_T.GetChanges
                If (Not (ch) Is Nothing) Then
                    Me.olcon.Open()
                    Debug.WriteLine("PO Langsung PERUBAHAN: " & oldapPO.Update(ch))
                    'Debug.WriteLine("PO Langsung: " & oldapPO.Update(Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").Current))
                    'Debug.WriteLine("PO Langsung: " & OleDbDataAdapter1.Update(ch))
                End If
                DsPO1.DC_JLR_DAFTARPO_T.AcceptChanges()
            Catch updateException As System.Exception
                'Add your error handling code here.
                Throw updateException
            Finally
                'Close the connection whether or not the exception was thrown.
                Me.olcon.Close()
            End Try
        End If
        fe.Dispose()

    End Sub

    Private Sub btnKeluar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKeluar.Click
        Me.Close()
    End Sub

    Private Sub txtPO_GROSS_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtPO_GROSS.Validating
        If Not IsNumeric(txtPO_GROSS.Text) Then
            MessageBox.Show("Masukkan Nulai Rupiah", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            e.Cancel = True
        End If
        If Not lWithPO Then
            Dim x As Double
            x = CType(txtPO_GROSS.Text, Double) * 0.1
            txtPO_PPN.Text = x
            txtPO_Total.Text = CType(txtPO_GROSS.Text, Double) + x
        End If
    End Sub

    Private Sub TXTPO_PPN_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtPO_PPN.Validating
        If Not IsNumeric(txtPO_PPN.Text) Then
            MessageBox.Show("Masukkan Nulai Rupiah", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            e.Cancel = True
        End If
        If Not lWithPO Then
            Dim x As Double
            x = CType(txtPO_PPN.Text, Double)
            txtPO_Total.Text = CType(txtPO_GROSS.Text, Double) + x
        End If
    End Sub

    Private Sub btnCari_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCari.Click

        Dim f As New frmCariPO
        f.DataGrid1.DataSource = DsPO1.DC_JLR_DAFTARPO_T
        If f.ShowDialog <> Windows.Forms.DialogResult.OK Then
            Exit Sub
        End If

        Dim IdDaftarJalur As Integer
        Dim IdDaftar As Integer

        IdDaftar = f.idDaftar
        Dim rw As DataRow = DsPO1.DC_JLR_DAFTARPO_T.FindByID_DAFTARPO(IdDaftar)
        If IsNothing(rw) Then
            Exit Sub
        End If

        IdDaftarJalur = "0" & rw("ID_DAFTARJALUR")
        Dim rwMobil As DataRow = DsPO1.DC_JLR_DAFTARJALUR_T.FindByID_DAFTARJALUR(IdDaftarJalur)

        For j As Integer = 0 To DsPO1.DC_JLR_DAFTARJALUR_T.Rows.Count - 1
            If rwMobil.Equals(DsPO1.DC_JLR_DAFTARJALUR_T.Rows(j)) Then
                Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position = j
                Exit For
            End If
        Next


        For i As Integer = 0 To Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").Count - 1
            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").Position = i
            If CType(Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").Current, DataRowView).Row.Equals(rw) Then
                Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").Position = i
                Exit For
            End If
        Next

    End Sub


    Private Function GetOracleDate() As Date
        Dim Scon As New OleDbConnection(ConStrORA)
        Dim Scom As New OleDbCommand("", Scon)
        Try
            Scon.Open()
            Scom.CommandText = "Select sysdate from dual"
            Return Scom.ExecuteScalar

        Catch ex As Exception
            ShowError("error Baca Jam", ex)
        Finally
            Scon.Close()
        End Try

    End Function

    Private Sub btnDaftar_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDaftar.EnabledChanged
        btnDraftRetur.Enabled = CType(sender, Button).Enabled
    End Sub

    Private Sub btnDraftRetur_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDraftRetur.Click
        If lblSUPCO.Text = "" Then
            MessageBox.Show("Tidak Ada Data Supplier.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        Dim f As New frmDraftRetur
        Dim nBulan As Integer = 0
        If f.ShowDialog = Windows.Forms.DialogResult.OK Then
            nBulan = f.nBulan
        Else
            Exit Sub
        End If


        Dim Scon As New OleDbConnection(ConStrORA)
        Dim Scom As New OleDbCommand("", Scon)
        Dim Sdap As New OleDbDataAdapter("", Scon)
        Dim dt As New DataTable
        Try
            Scon.Open()
            Scom.CommandText = "JLR_Create_Draft_Retur('" & lblSUPCO.Text & "','" & cDC_KODE & "'," & nBulan & ")"
            Scom.CommandType = CommandType.StoredProcedure
            Scom.ExecuteNonQuery()
            Scom.CommandType = CommandType.Text

            Scom.CommandText = "Select D.*,PRDCD,NAMA,SINGKAT from dc_jlr_draft_retur_t d, "
            Scom.CommandText &= "(SELECT MBR_FK_PLUID,mbr_plukode PRDCD,MBR_FULL_NAMA NAMA,MBR_SINGKATAN SINGKAT FROM DC_BARANG_DC_V WHERE MBR_FK_DCID=" & cDC_ID & ") brg "
            Scom.CommandText &= "WHERE(SUPCO = '" & lblSUPCO.Text & "') "
            Scom.CommandText &= "AND Tanggal=TRUNC(SYSDATE) "
            Scom.CommandText &= "AND D.PLUID=BRG.MBR_FK_PLUID "
            Scom.CommandText &= "ORDER BY  PRDCD "
            Sdap.SelectCommand = Scom
            Sdap.Fill(dt)

            If dt.Rows.Count > 0 Then
                Cetak_DrafRetur(dt)
                MessageBox.Show("Draft Retur Selesai.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("Tidak Ada Data Untuk Draft Retur.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        Catch ex As Exception
            ShowError("error Create Draft Retur", ex)
        Finally
            Scon.Close()
        End Try
    End Sub

    Private Sub Cetak_DrafRetur(ByVal dt As DataTable)
        'Cetak PB BKL
        Dim nProw As Integer = 0
        Dim nHal As Integer = 0
        Dim NoUrut As Integer = 0
        Dim mDIV As String = ""
        Dim sw As New IO.StreamWriter(Application.StartupPath & "\TempCetakDraftRetur.TXT", False)

        sw.WriteLine(Chr(27) & "x" & "0" & Chr(27) & "M" + Chr(15))

        'SETENGAH PLY
        sw.Write(Chr(27) & "C" & Chr(33))
        For i As Short = 0 To dt.Rows.Count - 1
            If nProw = 0 Then
                nHal += 1
                If nHal < 2 Then
                    sw.WriteLine(Chr(27) & "W" & "0")
                    sw.WriteLine((cDC_KODE & "-" & cDC_NAMA).PadRight(104) & Format(Now, "dd/MM/yyyy"))
                    'sw.WriteLine(Chr(14) & Chr(27) & "W" & "1")
                    sw.Write(Chr(14) + (Chr(27) + "W" + "1"))
                    sw.WriteLine(strCenter("DRAFT RETUR SUPPLIER", 65))
                    'sw.WriteLine(Chr(20) & Chr(27) & "W" & "0")
                    sw.WriteLine(Chr(20) + (Chr(27) + "W" + "0"))
                    sw.WriteLine(strCenter("Supplier : " & lblSUPCO.Text & "-" & lblSNAMA.Text, 120))
                    'sw.WriteLine(strCenter("Nomor PB BKL : " & nDocno & "/Tgl. : " & Format(Now, "dd/MM/yyyy"), 120))
                    sw.WriteLine(("Halaman: " & CType(nHal, String).PadLeft(2)).PadLeft(108))
                    nProw += 7
                Else
                    'sw.WriteLine(("PB Kirim Langsung No. : " & nDocno).PadRight(108) & "Halaman: " & CType(nHal, String).PadLeft(2))
                    sw.WriteLine((" ").PadRight(108) & "Halaman: " & CType(nHal, String).PadLeft(2))
                    nProw += 1
                End If

                sw.WriteLine("-".PadRight(120, "-"))
                sw.WriteLine("|  No. |  PLU |  Nama Barang dan Spesifikasi                                  | Kuantitas |  Aktual  |    Keterangan    |")
                sw.WriteLine("|-----------------------------------------------------------------------------|-----------|----------|------------------|")
                nProw += 3
            End If
            NoUrut += 1
            sw.Write("| " & CType(NoUrut, String).PadLeft(3) & ". | ")
            sw.Write(dt.Rows(i)("PRDCD") & " |  ")
            sw.Write(CType("" & dt.Rows(i)("NAMA"), String).PadRight(50).Substring(0, 50) & "   ")
            sw.Write(CType(" ", String).PadRight(6).Substring(0, 6) & "  | ")
            sw.WriteLine(CType(Format(dt.Rows(i)("QTY"), "#,##0"), String).PadLeft(9) & " | " & "".PadRight(8) & " | " & "".PadRight(17) & "|")
            nProw += 1
            If nProw >= 28 Then
                sw.WriteLine("|" & "-".PadRight(119, "-") & "|")
                nProw = 0
                'EJECT
                sw.Write(Chr(12) + Chr(13))
            End If
        Next
        'sw.WriteLine("|" & "-".PadRight(119, "-") & "|")
        'sw.WriteLine(("|".PadRight(16) & ("Disetujui :").PadRight(93 - 16) & "Dicetak :").PadRight(120) & "|")
        'sw.WriteLine("|" & " ".PadRight(119) & "|")
        'sw.WriteLine("|" & " ".PadRight(119) & "|")
        'sw.WriteLine("|" & " ".PadRight(119) & "|")
        'sw.WriteLine(("|".PadRight(16) & ("___________").PadRight(93 - 16) & "_________").PadRight(120) & "|")
        'sw.WriteLine(("|".PadRight(12) & ("Chief of Store/Asst").PadRight(93 - 12) & "         ").PadRight(120) & "|")
        sw.WriteLine("-" & "-".PadRight(119, "-") & "-")
        sw.Write(Chr(12) + Chr(13))
        sw.Write(Chr(18))
        sw.Flush()
        sw.Close()

        ''''''''''''
        Dim sr As New IO.StreamReader(Application.StartupPath & "\TempCetakDraftRetur.TXT")
        DoCetak(sr.ReadToEnd)
        sr.Close()
    End Sub
End Class
