﻿Option Explicit On
Imports Microsoft.Win32

Module Crypt
    Private Seri As String = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890_!@#$%^&*()-=~:'<>?+ ,/[]{}\|."""
    Function Tulis_Setting(ByVal SubKey As String, ByVal Key As String, ByVal Nilai As String) As String
        Dim Rk As RegistryKey
        Rk = Registry.CurrentUser.OpenSubKey(SubKey, True)
        If Rk Is Nothing Then
            Rk = Registry.CurrentUser
            Rk.CreateSubKey(SubKey)
            Rk = Registry.CurrentUser.OpenSubKey(SubKey, True)
        End If
        Rk.SetValue(Key, Nilai)
        Return ""
    End Function
    Sub TulisRegistry(ByVal SubKey As String, ByVal Key As String, ByVal Nilai As String)
        Dim Rk As RegistryKey
        Rk = Registry.CurrentUser.OpenSubKey(SubKey, True)
        If Rk Is Nothing Then
            Rk = Registry.CurrentUser
            Rk.CreateSubKey(SubKey)
            Rk = Registry.CurrentUser.OpenSubKey(SubKey, True)
        End If
        If Nilai Is Nothing Or Nilai = "" Then
            Rk.SetValue(Key, Nilai)
        Else
            Rk.SetValue(Key, Encrypt(Nilai))
        End If
    End Sub
    Function BacaRegistry(ByVal SubKey As String, ByVal Key As String) As String
        Dim Rkey As RegistryKey
        Dim a As String = ""
        Try
            Rkey = Registry.CurrentUser.OpenSubKey(SubKey)
            Try
                If Not Rkey Is Nothing Then
                    a = Rkey.GetValue(Key)
                Else
                    a = "" ' nulis_null(a)
                End If
            Catch ex As Exception
            End Try
        Catch ex As Exception

        End Try
        a = Decrypt(a)
        Return a
    End Function
    Private Function GetNumber(ByVal strGet As String) As Integer
        GetNumber = InStrRev(Seri, strGet, , CompareMethod.Binary)
    End Function

    Private Function GetString(ByVal WhereNum As Integer) As String
        GetString = Mid(Seri, WhereNum, 1)
    End Function

    Public Function Encrypt(ByVal EncrypText As String, Optional ByVal KeyText As String = "") As String
        Dim I As Integer
        Dim X As Integer
        Dim CurI As Integer
        Dim CurX As Integer
        Dim Encrypted As String
        Dim EncStr As String
        Dim Hari = Now.Day + (Now.Millisecond), Bulan = Now.Month + (Now.Millisecond), _
             Tahun = Now.Year + (Now.Millisecond), Jam = Now.Hour + (Now.Millisecond), _
             Menit = Now.Minute + (Now.Millisecond), Detik = Now.Second + (Now.Millisecond)

        If KeyText = "" Then
            KeyText = Hari.ToString.Trim & Bulan.ToString.Trim & Tahun.ToString.Trim & _
                    Jam.ToString.Trim & Menit.ToString.Trim & Detik.ToString.Trim
            '            KeyText = Format(Now, "ddMMyyyyhhmmssfff")
        End If

        Encrypted = "IDM" & Chr(Str(Len(KeyText)))

        For I = 1 To Len(KeyText)
            Encrypted = Encrypted & Chr(Str(GetNumber(Mid(KeyText, I, 1))))
        Next I

        CurI = 1
        CurX = 1

        For X = 1 To Len(KeyText)

            For I = CurI To Len(EncrypText)
                EncStr = Str(GetNumber(Mid(KeyText, X, 1)) + GetNumber(Mid(EncrypText, CurI, 1)))
                Encrypted = Encrypted & Chr(EncStr)
                CurI = I + 1
                If CurI > Len(EncrypText) Then GoTo Keluar
                GoTo NextX
            Next I

NextX:
            CurX = X + 1
            If CurX > Len(KeyText) Then X = 0
        Next X

Keluar:

        Encrypt = Encrypted

    End Function

    Public Function Decrypt(ByVal CryptText As String) As String

        Dim I As Integer
        Dim X As Integer
        Dim PanjangKey As Integer
        Dim KeyText As String = ""
        Dim EncText As String
        Dim CurI As Integer
        Dim CurX As Integer
        Dim Num1 As Integer
        Dim Num2 As Integer
        Dim DecStr As String = ""


        If Mid(CryptText, 1, 3) <> "IDM" Then
            Decrypt = ""
            Exit Function
        End If

        CryptText = Mid(CryptText, 4, Len(CryptText) - 3)

        PanjangKey = Val(Asc(Mid(CryptText, 1, 1)))

        For I = 2 To PanjangKey + 1
            KeyText = KeyText & Mid(CryptText, I, 1)
        Next I

        EncText = Mid(CryptText, PanjangKey + 2, Len(CryptText) - PanjangKey + 2)

        CurX = 1
        CurI = 1


        For X = 1 To Len(KeyText)
            Num1 = Val(Asc(Mid(KeyText, X, 1)))

            For I = CurI To Len(EncText)
                Num2 = Val(Asc(Mid(EncText, I, 1)))

                DecStr = DecStr & GetString(Str(Num2 - Num1))
                CurI = I + 1
                If CurI > Len(EncText) Then GoTo Keluar
                GoTo NextX
            Next I
NextX:
            CurX = X + 1
            If CurX > Len(KeyText) Then X = 0
        Next X
Keluar:

        Decrypt = DecStr

    End Function

End Module
