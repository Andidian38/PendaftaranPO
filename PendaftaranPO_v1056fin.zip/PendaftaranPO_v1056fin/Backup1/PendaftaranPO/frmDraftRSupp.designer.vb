<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDraftRSupp
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDraftRSupp))
        Me.CmbSupco = New System.Windows.Forms.ComboBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.btnBatal = New System.Windows.Forms.Button
        Me.CmbNama = New System.Windows.Forms.ComboBox
        Me.grpHidden = New System.Windows.Forms.GroupBox
        Me.lblTglRevisi = New System.Windows.Forms.Label
        Me.lblSUPID = New System.Windows.Forms.Label
        Me.lblLokasiKode = New System.Windows.Forms.Label
        Me.lblGudangKode = New System.Windows.Forms.Label
        Me.btnDraftRetur = New System.Windows.Forms.Button
        Me.Label7 = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label30 = New System.Windows.Forms.Label
        Me.grpHidden.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'CmbSupco
        '
        Me.CmbSupco.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.CmbSupco.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.CmbSupco.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.CmbSupco.FormattingEnabled = True
        Me.CmbSupco.Location = New System.Drawing.Point(65, 14)
        Me.CmbSupco.Name = "CmbSupco"
        Me.CmbSupco.Size = New System.Drawing.Size(75, 24)
        Me.CmbSupco.TabIndex = 76
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(11, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(60, 20)
        Me.Label1.TabIndex = 75
        Me.Label1.Text = "Kode  :"
        '
        'btnBatal
        '
        Me.btnBatal.BackColor = System.Drawing.Color.Transparent
        Me.btnBatal.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnBatal.Image = Global.PendaftaranPO.My.Resources.Resources.cross
        Me.btnBatal.Location = New System.Drawing.Point(447, 70)
        Me.btnBatal.Name = "btnBatal"
        Me.btnBatal.Size = New System.Drawing.Size(86, 37)
        Me.btnBatal.TabIndex = 74
        Me.btnBatal.Text = "&Keluar"
        Me.btnBatal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnBatal.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnBatal.UseVisualStyleBackColor = False
        '
        'CmbNama
        '
        Me.CmbNama.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.CmbNama.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.CmbNama.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.CmbNama.FormattingEnabled = True
        Me.CmbNama.Location = New System.Drawing.Point(65, 41)
        Me.CmbNama.Name = "CmbNama"
        Me.CmbNama.Size = New System.Drawing.Size(468, 24)
        Me.CmbNama.TabIndex = 73
        '
        'grpHidden
        '
        Me.grpHidden.Controls.Add(Me.lblTglRevisi)
        Me.grpHidden.Controls.Add(Me.lblSUPID)
        Me.grpHidden.Controls.Add(Me.lblLokasiKode)
        Me.grpHidden.Controls.Add(Me.lblGudangKode)
        Me.grpHidden.Location = New System.Drawing.Point(22, 117)
        Me.grpHidden.Name = "grpHidden"
        Me.grpHidden.Size = New System.Drawing.Size(200, 13)
        Me.grpHidden.TabIndex = 18
        Me.grpHidden.TabStop = False
        '
        'lblTglRevisi
        '
        Me.lblTglRevisi.Location = New System.Drawing.Point(22, 92)
        Me.lblTglRevisi.Name = "lblTglRevisi"
        Me.lblTglRevisi.Size = New System.Drawing.Size(100, 16)
        Me.lblTglRevisi.TabIndex = 23
        Me.lblTglRevisi.Text = "lblTglRevisi"
        '
        'lblSUPID
        '
        Me.lblSUPID.Location = New System.Drawing.Point(20, 63)
        Me.lblSUPID.Name = "lblSUPID"
        Me.lblSUPID.Size = New System.Drawing.Size(100, 16)
        Me.lblSUPID.TabIndex = 22
        Me.lblSUPID.Text = "lblSUPID"
        '
        'lblLokasiKode
        '
        Me.lblLokasiKode.Location = New System.Drawing.Point(20, 39)
        Me.lblLokasiKode.Name = "lblLokasiKode"
        Me.lblLokasiKode.Size = New System.Drawing.Size(100, 16)
        Me.lblLokasiKode.TabIndex = 17
        Me.lblLokasiKode.Text = "LokasiKode"
        '
        'lblGudangKode
        '
        Me.lblGudangKode.Location = New System.Drawing.Point(20, 15)
        Me.lblGudangKode.Name = "lblGudangKode"
        Me.lblGudangKode.Size = New System.Drawing.Size(100, 16)
        Me.lblGudangKode.TabIndex = 16
        Me.lblGudangKode.Text = "GudangKode"
        '
        'btnDraftRetur
        '
        Me.btnDraftRetur.BackColor = System.Drawing.Color.Transparent
        Me.btnDraftRetur.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnDraftRetur.Image = Global.PendaftaranPO.My.Resources.Resources.printer
        Me.btnDraftRetur.Location = New System.Drawing.Point(316, 71)
        Me.btnDraftRetur.Name = "btnDraftRetur"
        Me.btnDraftRetur.Size = New System.Drawing.Size(125, 37)
        Me.btnDraftRetur.TabIndex = 6
        Me.btnDraftRetur.Text = "&Cetak Draft Retur"
        Me.btnDraftRetur.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnDraftRetur.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnDraftRetur.UseVisualStyleBackColor = False
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label7.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.Location = New System.Drawing.Point(11, 43)
        Me.Label7.Name = "Label7"
        Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label7.Size = New System.Drawing.Size(60, 20)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Nama  :"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.CmbSupco)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.btnBatal)
        Me.Panel1.Controls.Add(Me.btnDraftRetur)
        Me.Panel1.Controls.Add(Me.CmbNama)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Location = New System.Drawing.Point(7, 11)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(544, 119)
        Me.Panel1.TabIndex = 7
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.BackColor = System.Drawing.Color.Tan
        Me.Label30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label30.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(14, 5)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(141, 15)
        Me.Label30.TabIndex = 78
        Me.Label30.Text = "CETAK DRAFT RETUR"
        '
        'frmDraftRSupp
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.ClientSize = New System.Drawing.Size(560, 146)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.grpHidden)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmDraftRSupp"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Cetak Draft Retur"
        Me.grpHidden.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents CmbNama As System.Windows.Forms.ComboBox
    Friend WithEvents grpHidden As System.Windows.Forms.GroupBox
    Friend WithEvents lblTglRevisi As System.Windows.Forms.Label
    Friend WithEvents lblSUPID As System.Windows.Forms.Label
    Friend WithEvents lblLokasiKode As System.Windows.Forms.Label
    Friend WithEvents lblGudangKode As System.Windows.Forms.Label
    Friend WithEvents btnDraftRetur As System.Windows.Forms.Button
    Public WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents btnBatal As System.Windows.Forms.Button
    Friend WithEvents CmbSupco As System.Windows.Forms.ComboBox
    Public WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label30 As System.Windows.Forms.Label
End Class
