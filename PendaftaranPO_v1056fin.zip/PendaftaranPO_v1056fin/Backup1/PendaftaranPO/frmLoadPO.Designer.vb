﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLoadPO
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmLoadPO))
        Me.dgvLoadPO = New System.Windows.Forms.DataGridView
        Me.PRDCD = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.FRAC = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.FRACASAL = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.PO_GROSS = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.PO_PPN = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.PO_DISC = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.UNIT = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.QTYBONUS = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DESKRIPSI = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.PO_NO_PO = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.SATUAN = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.PODTL_PRICE = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.PEMBAGIDISC = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.PO_PPNASAL = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.PO_DISCASAL = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.PPN_BOTOLASAL = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.PPN_BOTOL = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.QTYBONUSASAL = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.MBRTAG = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.EXTAG = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.btnBatal = New System.Windows.Forms.Button
        Me.btnSimpan = New System.Windows.Forms.Button
        Me.DsPO1 = New PendaftaranPO.DS_
        Me.olcon = New System.Data.OleDb.OleDbConnection
        Me.oldapPO = New System.Data.OleDb.OleDbDataAdapter
        Me.OleDbDeleteCommand2 = New System.Data.OleDb.OleDbCommand
        Me.OleDbInsertCommand2 = New System.Data.OleDb.OleDbCommand
        Me.OleDbSelectCommand2 = New System.Data.OleDb.OleDbCommand
        Me.OleDbUpdateCommand2 = New System.Data.OleDb.OleDbCommand
        Me.oldapMobil = New System.Data.OleDb.OleDbDataAdapter
        Me.OleDbDeleteCommand1 = New System.Data.OleDb.OleDbCommand
        Me.OleDbInsertCommand1 = New System.Data.OleDb.OleDbCommand
        Me.OleDbSelectCommand1 = New System.Data.OleDb.OleDbCommand
        Me.OleDbUpdateCommand1 = New System.Data.OleDb.OleDbCommand
        CType(Me.dgvLoadPO, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsPO1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvLoadPO
        '
        Me.dgvLoadPO.AllowUserToAddRows = False
        Me.dgvLoadPO.AllowUserToDeleteRows = False
        Me.dgvLoadPO.BackgroundColor = System.Drawing.Color.LightGoldenrodYellow
        Me.dgvLoadPO.CausesValidation = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvLoadPO.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvLoadPO.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvLoadPO.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.PRDCD, Me.FRAC, Me.FRACASAL, Me.PO_GROSS, Me.PO_PPN, Me.PO_DISC, Me.UNIT, Me.QTYBONUS, Me.DESKRIPSI, Me.PO_NO_PO, Me.SATUAN, Me.PODTL_PRICE, Me.PEMBAGIDISC, Me.PO_PPNASAL, Me.PO_DISCASAL, Me.PPN_BOTOLASAL, Me.PPN_BOTOL, Me.QTYBONUSASAL, Me.MBRTAG, Me.EXTAG})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvLoadPO.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgvLoadPO.GridColor = System.Drawing.Color.Olive
        Me.dgvLoadPO.Location = New System.Drawing.Point(2, 2)
        Me.dgvLoadPO.Name = "dgvLoadPO"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvLoadPO.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgvLoadPO.Size = New System.Drawing.Size(969, 430)
        Me.dgvLoadPO.TabIndex = 0
        '
        'PRDCD
        '
        Me.PRDCD.DataPropertyName = "PRDCD"
        Me.PRDCD.HeaderText = "PLU"
        Me.PRDCD.Name = "PRDCD"
        Me.PRDCD.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'FRAC
        '
        Me.FRAC.DataPropertyName = "FRAC"
        Me.FRAC.HeaderText = "Qty BPB"
        Me.FRAC.Name = "FRAC"
        Me.FRAC.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.FRAC.Width = 40
        '
        'FRACASAL
        '
        Me.FRACASAL.DataPropertyName = "FRACASAL"
        Me.FRACASAL.HeaderText = "Qty PO"
        Me.FRACASAL.Name = "FRACASAL"
        Me.FRACASAL.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.FRACASAL.Width = 40
        '
        'PO_GROSS
        '
        Me.PO_GROSS.DataPropertyName = "PO_GROSS"
        Me.PO_GROSS.HeaderText = "Nilai"
        Me.PO_GROSS.Name = "PO_GROSS"
        Me.PO_GROSS.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.PO_GROSS.Width = 80
        '
        'PO_PPN
        '
        Me.PO_PPN.DataPropertyName = "PO_PPN"
        Me.PO_PPN.HeaderText = "PPn"
        Me.PO_PPN.Name = "PO_PPN"
        Me.PO_PPN.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.PO_PPN.Width = 80
        '
        'PO_DISC
        '
        Me.PO_DISC.DataPropertyName = "PO_DISC"
        Me.PO_DISC.HeaderText = "Disc"
        Me.PO_DISC.Name = "PO_DISC"
        Me.PO_DISC.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.PO_DISC.Width = 80
        '
        'UNIT
        '
        Me.UNIT.HeaderText = "Unit"
        Me.UNIT.Name = "UNIT"
        Me.UNIT.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.UNIT.Width = 40
        '
        'QTYBONUS
        '
        Me.QTYBONUS.DataPropertyName = "QTYBONUS"
        Me.QTYBONUS.HeaderText = "Bonus"
        Me.QTYBONUS.Name = "QTYBONUS"
        Me.QTYBONUS.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.QTYBONUS.Width = 40
        '
        'DESKRIPSI
        '
        Me.DESKRIPSI.DataPropertyName = "DESKRIPSI"
        Me.DESKRIPSI.HeaderText = "Deskripsi"
        Me.DESKRIPSI.Name = "DESKRIPSI"
        Me.DESKRIPSI.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'PO_NO_PO
        '
        Me.PO_NO_PO.HeaderText = "NO PO"
        Me.PO_NO_PO.Name = "PO_NO_PO"
        Me.PO_NO_PO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.PO_NO_PO.Visible = False
        '
        'SATUAN
        '
        Me.SATUAN.HeaderText = "SATUAN"
        Me.SATUAN.Name = "SATUAN"
        Me.SATUAN.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.SATUAN.Visible = False
        '
        'PODTL_PRICE
        '
        Me.PODTL_PRICE.HeaderText = "PO DTL PRICE"
        Me.PODTL_PRICE.Name = "PODTL_PRICE"
        Me.PODTL_PRICE.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.PODTL_PRICE.Visible = False
        '
        'PEMBAGIDISC
        '
        Me.PEMBAGIDISC.HeaderText = "PEMBAGI DISC"
        Me.PEMBAGIDISC.Name = "PEMBAGIDISC"
        Me.PEMBAGIDISC.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.PEMBAGIDISC.Visible = False
        '
        'PO_PPNASAL
        '
        Me.PO_PPNASAL.HeaderText = "PO PPN ASAL"
        Me.PO_PPNASAL.Name = "PO_PPNASAL"
        Me.PO_PPNASAL.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.PO_PPNASAL.Visible = False
        '
        'PO_DISCASAL
        '
        Me.PO_DISCASAL.HeaderText = "PO DISCASAL"
        Me.PO_DISCASAL.Name = "PO_DISCASAL"
        Me.PO_DISCASAL.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.PO_DISCASAL.Visible = False
        '
        'PPN_BOTOLASAL
        '
        Me.PPN_BOTOLASAL.HeaderText = "PPN BOTOLASAL"
        Me.PPN_BOTOLASAL.Name = "PPN_BOTOLASAL"
        Me.PPN_BOTOLASAL.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.PPN_BOTOLASAL.Visible = False
        '
        'PPN_BOTOL
        '
        Me.PPN_BOTOL.HeaderText = "PPN BOTOL"
        Me.PPN_BOTOL.Name = "PPN_BOTOL"
        Me.PPN_BOTOL.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.PPN_BOTOL.Visible = False
        '
        'QTYBONUSASAL
        '
        Me.QTYBONUSASAL.HeaderText = "QTYBONUSASAL"
        Me.QTYBONUSASAL.Name = "QTYBONUSASAL"
        Me.QTYBONUSASAL.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.QTYBONUSASAL.Visible = False
        '
        'MBRTAG
        '
        Me.MBRTAG.HeaderText = "TAG"
        Me.MBRTAG.Name = "MBRTAG"
        Me.MBRTAG.ReadOnly = True
        '
        'EXTAG
        '
        Me.EXTAG.HeaderText = "F_EXCBPB"
        Me.EXTAG.Name = "EXTAG"
        Me.EXTAG.ReadOnly = True
        '
        'btnBatal
        '
        Me.btnBatal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnBatal.BackColor = System.Drawing.Color.Transparent
        Me.btnBatal.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnBatal.Image = Global.PendaftaranPO.My.Resources.Resources.arrow_undo
        Me.btnBatal.Location = New System.Drawing.Point(866, 434)
        Me.btnBatal.Name = "btnBatal"
        Me.btnBatal.Size = New System.Drawing.Size(105, 36)
        Me.btnBatal.TabIndex = 4
        Me.btnBatal.Text = "&Batal"
        Me.btnBatal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnBatal.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnBatal.UseVisualStyleBackColor = False
        '
        'btnSimpan
        '
        Me.btnSimpan.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSimpan.BackColor = System.Drawing.Color.Transparent
        Me.btnSimpan.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.btnSimpan.Image = Global.PendaftaranPO.My.Resources.Resources.disk
        Me.btnSimpan.Location = New System.Drawing.Point(755, 434)
        Me.btnSimpan.Name = "btnSimpan"
        Me.btnSimpan.Size = New System.Drawing.Size(105, 36)
        Me.btnSimpan.TabIndex = 3
        Me.btnSimpan.Text = "&Simpan"
        Me.btnSimpan.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSimpan.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnSimpan.UseVisualStyleBackColor = False
        '
        'DsPO1
        '
        Me.DsPO1.DataSetName = "dsPO"
        Me.DsPO1.Locale = New System.Globalization.CultureInfo("en-US")
        Me.DsPO1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'olcon
        '
        Me.olcon.ConnectionString = "Provider=""MSDAORA.1"";User ID=DCSIM;Data Source=SIMULASIA;Password=dcsim"
        '
        'oldapPO
        '
        Me.oldapPO.DeleteCommand = Me.OleDbDeleteCommand2
        Me.oldapPO.InsertCommand = Me.OleDbInsertCommand2
        Me.oldapPO.SelectCommand = Me.OleDbSelectCommand2
        Me.oldapPO.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "DC_JLR_DAFTARPO_T", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("ID_DAFTARPO", "ID_DAFTARPO"), New System.Data.Common.DataColumnMapping("TANGGAL", "TANGGAL"), New System.Data.Common.DataColumnMapping("RECID", "RECID"), New System.Data.Common.DataColumnMapping("ID_DAFTARJALUR", "ID_DAFTARJALUR"), New System.Data.Common.DataColumnMapping("NO_FAK", "NO_FAK"), New System.Data.Common.DataColumnMapping("TGL_FAK", "TGL_FAK"), New System.Data.Common.DataColumnMapping("NOPO", "NOPO"), New System.Data.Common.DataColumnMapping("SUPCO", "SUPCO"), New System.Data.Common.DataColumnMapping("SNAMA", "SNAMA"), New System.Data.Common.DataColumnMapping("BUAT_PO", "BUAT_PO"), New System.Data.Common.DataColumnMapping("ADA_HARGA", "ADA_HARGA"), New System.Data.Common.DataColumnMapping("QTY", "QTY"), New System.Data.Common.DataColumnMapping("ITEM", "ITEMnya"), New System.Data.Common.DataColumnMapping("RUPIAH", "RUPIAH"), New System.Data.Common.DataColumnMapping("PPN", "PPN"), New System.Data.Common.DataColumnMapping("BPB_NO", "BPB_NO"), New System.Data.Common.DataColumnMapping("TGL_MULAI", "TGL_MULAI"), New System.Data.Common.DataColumnMapping("JAM_MULAI", "JAM_MULAI"), New System.Data.Common.DataColumnMapping("TGL_AKHIR", "TGL_AKHIR"), New System.Data.Common.DataColumnMapping("JAM_AKHIR", "JAM_AKHIR"), New System.Data.Common.DataColumnMapping("JML_MOBIL", "JML_MOBIL"), New System.Data.Common.DataColumnMapping("TGL_REVISI", "TGL_REVISI"), New System.Data.Common.DataColumnMapping("JAM_REVISI", "JAM_REVISI"), New System.Data.Common.DataColumnMapping("USER_NAME", "USER_NAME"), New System.Data.Common.DataColumnMapping("MRBREAD", "MRBREAD"), New System.Data.Common.DataColumnMapping("UPDATE", "UPDATE"), New System.Data.Common.DataColumnMapping("SUPID", "SUPID"), New System.Data.Common.DataColumnMapping("GUDANG_KODE", "GUDANG_KODE"), New System.Data.Common.DataColumnMapping("LOKASI_KODE", "LOKASI_KODE"), New System.Data.Common.DataColumnMapping("TOTAL", "Total"), New System.Data.Common.DataColumnMapping("STATUS", "Status")})})
        Me.oldapPO.UpdateCommand = Me.OleDbUpdateCommand2
        '
        'OleDbDeleteCommand2
        '
        Me.OleDbDeleteCommand2.CommandText = "DELETE FROM DC_JLR_DAFTARPO_T WHERE (ID_DAFTARPO = ?)"
        Me.OleDbDeleteCommand2.Connection = Me.olcon
        Me.OleDbDeleteCommand2.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("ID_DAFTARPO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARPO", System.Data.DataRowVersion.Original, Nothing)})
        '
        'OleDbInsertCommand2
        '
        Me.OleDbInsertCommand2.CommandText = resources.GetString("OleDbInsertCommand2.CommandText")
        Me.OleDbInsertCommand2.Connection = Me.olcon
        Me.OleDbInsertCommand2.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("ID_DAFTARPO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARPO", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TANGGAL", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TANGGAL"), New System.Data.OleDb.OleDbParameter("RECID", System.Data.OleDb.OleDbType.VarChar, 1, "RECID"), New System.Data.OleDb.OleDbParameter("ID_DAFTARJALUR", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("NO_FAK", System.Data.OleDb.OleDbType.VarChar, 15, "NO_FAK"), New System.Data.OleDb.OleDbParameter("TGL_FAK", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_FAK"), New System.Data.OleDb.OleDbParameter("NOPO", System.Data.OleDb.OleDbType.VarChar, 9, "NOPO"), New System.Data.OleDb.OleDbParameter("SUPCO", System.Data.OleDb.OleDbType.VarChar, 4, "SUPCO"), New System.Data.OleDb.OleDbParameter("SNAMA", System.Data.OleDb.OleDbType.VarChar, 50, "SNAMA"), New System.Data.OleDb.OleDbParameter("BUAT_PO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BUAT_PO", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("ADA_HARGA", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ADA_HARGA", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("QTY", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "QTY", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("ITEM", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("RUPIAH", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("PPN", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "PPN", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("BPB_NO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BPB_NO", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TGL_MULAI", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_MULAI"), New System.Data.OleDb.OleDbParameter("JAM_MULAI", System.Data.OleDb.OleDbType.VarChar, 8, "JAM_MULAI"), New System.Data.OleDb.OleDbParameter("TGL_AKHIR", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_AKHIR"), New System.Data.OleDb.OleDbParameter("JAM_AKHIR", System.Data.OleDb.OleDbType.VarChar, 8, "JAM_AKHIR"), New System.Data.OleDb.OleDbParameter("JML_MOBIL", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "JML_MOBIL", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TGL_REVISI", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_REVISI"), New System.Data.OleDb.OleDbParameter("JAM_REVISI", System.Data.OleDb.OleDbType.VarChar, 8, "JAM_REVISI"), New System.Data.OleDb.OleDbParameter("USER_NAME", System.Data.OleDb.OleDbType.VarChar, 15, "USER_NAME"), New System.Data.OleDb.OleDbParameter("MRBREAD", System.Data.OleDb.OleDbType.VarChar, 1, "MRBREAD"), New System.Data.OleDb.OleDbParameter("UPDATE", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "UPDATE"), New System.Data.OleDb.OleDbParameter("SUPID", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "SUPID", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("GUDANG_KODE", System.Data.OleDb.OleDbType.VarChar, 8, "GUDANG_KODE"), New System.Data.OleDb.OleDbParameter("LOKASI_KODE", System.Data.OleDb.OleDbType.VarChar, 8, "LOKASI_KODE")})
        '
        'OleDbSelectCommand2
        '
        Me.OleDbSelectCommand2.CommandText = resources.GetString("OleDbSelectCommand2.CommandText")
        Me.OleDbSelectCommand2.Connection = Me.olcon
        '
        'OleDbUpdateCommand2
        '
        Me.OleDbUpdateCommand2.CommandText = resources.GetString("OleDbUpdateCommand2.CommandText")
        Me.OleDbUpdateCommand2.Connection = Me.olcon
        Me.OleDbUpdateCommand2.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("ID_DAFTARPO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARPO", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TANGGAL", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TANGGAL"), New System.Data.OleDb.OleDbParameter("RECID", System.Data.OleDb.OleDbType.VarChar, 1, "RECID"), New System.Data.OleDb.OleDbParameter("ID_DAFTARJALUR", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("NO_FAK", System.Data.OleDb.OleDbType.VarChar, 15, "NO_FAK"), New System.Data.OleDb.OleDbParameter("TGL_FAK", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_FAK"), New System.Data.OleDb.OleDbParameter("NOPO", System.Data.OleDb.OleDbType.VarChar, 9, "NOPO"), New System.Data.OleDb.OleDbParameter("SUPCO", System.Data.OleDb.OleDbType.VarChar, 4, "SUPCO"), New System.Data.OleDb.OleDbParameter("SNAMA", System.Data.OleDb.OleDbType.VarChar, 50, "SNAMA"), New System.Data.OleDb.OleDbParameter("BUAT_PO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BUAT_PO", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("ADA_HARGA", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ADA_HARGA", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("QTY", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "QTY", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("ITEM", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("RUPIAH", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("PPN", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "PPN", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("BPB_NO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BPB_NO", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TGL_MULAI", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_MULAI"), New System.Data.OleDb.OleDbParameter("JAM_MULAI", System.Data.OleDb.OleDbType.VarChar, 8, "JAM_MULAI"), New System.Data.OleDb.OleDbParameter("TGL_AKHIR", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_AKHIR"), New System.Data.OleDb.OleDbParameter("JAM_AKHIR", System.Data.OleDb.OleDbType.VarChar, 8, "JAM_AKHIR"), New System.Data.OleDb.OleDbParameter("JML_MOBIL", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "JML_MOBIL", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TGL_REVISI", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_REVISI"), New System.Data.OleDb.OleDbParameter("JAM_REVISI", System.Data.OleDb.OleDbType.VarChar, 8, "JAM_REVISI"), New System.Data.OleDb.OleDbParameter("USER_NAME", System.Data.OleDb.OleDbType.VarChar, 15, "USER_NAME"), New System.Data.OleDb.OleDbParameter("MRBREAD", System.Data.OleDb.OleDbType.VarChar, 1, "MRBREAD"), New System.Data.OleDb.OleDbParameter("UPDATE", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "UPDATE"), New System.Data.OleDb.OleDbParameter("SUPID", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "SUPID", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("GUDANG_KODE", System.Data.OleDb.OleDbType.VarChar, 8, "GUDANG_KODE"), New System.Data.OleDb.OleDbParameter("LOKASI_KODE", System.Data.OleDb.OleDbType.VarChar, 8, "LOKASI_KODE"), New System.Data.OleDb.OleDbParameter("Original_ID_DAFTARPO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARPO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ADA_HARGA", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ADA_HARGA", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ADA_HARGA1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ADA_HARGA", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_BPB_NO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BPB_NO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_BPB_NO1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BPB_NO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_BUAT_PO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BUAT_PO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_BUAT_PO1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BUAT_PO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_GUDANG_KODE", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "GUDANG_KODE", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_GUDANG_KODE1", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "GUDANG_KODE", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ID_DAFTARJALUR", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ID_DAFTARJALUR1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ITEM", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ITEM1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JAM_AKHIR", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JAM_AKHIR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JAM_AKHIR1", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JAM_AKHIR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JAM_MULAI", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JAM_MULAI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JAM_MULAI1", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JAM_MULAI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JAM_REVISI", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JAM_REVISI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JAM_REVISI1", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JAM_REVISI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JML_MOBIL", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "JML_MOBIL", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JML_MOBIL1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "JML_MOBIL", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_LOKASI_KODE", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LOKASI_KODE", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_LOKASI_KODE1", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LOKASI_KODE", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_MRBREAD", System.Data.OleDb.OleDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "MRBREAD", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_MRBREAD1", System.Data.OleDb.OleDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "MRBREAD", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_NOPO", System.Data.OleDb.OleDbType.VarChar, 9, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "NOPO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_NOPO1", System.Data.OleDb.OleDbType.VarChar, 9, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "NOPO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_NO_FAK", System.Data.OleDb.OleDbType.VarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "NO_FAK", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_NO_FAK1", System.Data.OleDb.OleDbType.VarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "NO_FAK", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_PPN", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "PPN", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_PPN1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "PPN", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_QTY", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "QTY", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_QTY1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "QTY", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RECID", System.Data.OleDb.OleDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "RECID", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RECID1", System.Data.OleDb.OleDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "RECID", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RUPIAH", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RUPIAH1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SNAMA", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SNAMA", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SNAMA1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SNAMA", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SUPCO", System.Data.OleDb.OleDbType.VarChar, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SUPCO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SUPID", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "SUPID", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SUPID1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "SUPID", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TANGGAL", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TANGGAL", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TANGGAL1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TANGGAL", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_AKHIR", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_AKHIR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_AKHIR1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_AKHIR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_FAK", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_FAK", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_FAK1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_FAK", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_MULAI", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_MULAI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_MULAI1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_MULAI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_REVISI", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_REVISI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_REVISI1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_REVISI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_UPDATE", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UPDATE", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_UPDATE1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UPDATE", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_USER_NAME", System.Data.OleDb.OleDbType.VarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "USER_NAME", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_USER_NAME1", System.Data.OleDb.OleDbType.VarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "USER_NAME", System.Data.DataRowVersion.Original, Nothing)})
        '
        'oldapMobil
        '
        Me.oldapMobil.DeleteCommand = Me.OleDbDeleteCommand1
        Me.oldapMobil.InsertCommand = Me.OleDbInsertCommand1
        Me.oldapMobil.SelectCommand = Me.OleDbSelectCommand1
        Me.oldapMobil.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "DC_JLR_DAFTARJALUR_T", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("ID_DAFTARJALUR", "ID_DAFTARJALUR"), New System.Data.Common.DataColumnMapping("DC_ID", "DC_ID"), New System.Data.Common.DataColumnMapping("TANGGAL", "TANGGAL"), New System.Data.Common.DataColumnMapping("RECID", "RECID"), New System.Data.Common.DataColumnMapping("NOMOBIL", "NOMOBIL"), New System.Data.Common.DataColumnMapping("NOURUT", "NOURUT"), New System.Data.Common.DataColumnMapping("SUPCO", "SUPCO"), New System.Data.Common.DataColumnMapping("SNAMA", "SNAMA"), New System.Data.Common.DataColumnMapping("ITEM", "ITEMnya"), New System.Data.Common.DataColumnMapping("RUPIAH", "RUPIAH"), New System.Data.Common.DataColumnMapping("TGLSTART", "TGLSTART"), New System.Data.Common.DataColumnMapping("TGLEND", "TGLEND"), New System.Data.Common.DataColumnMapping("JALUR", "JALUR")})})
        Me.oldapMobil.UpdateCommand = Me.OleDbUpdateCommand1
        '
        'OleDbDeleteCommand1
        '
        Me.OleDbDeleteCommand1.CommandText = "DELETE FROM DC_JLR_DAFTARJALUR_T WHERE (ID_DAFTARJALUR = ?)"
        Me.OleDbDeleteCommand1.Connection = Me.olcon
        Me.OleDbDeleteCommand1.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("ID_DAFTARJALUR", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Original, Nothing)})
        '
        'OleDbInsertCommand1
        '
        Me.OleDbInsertCommand1.CommandText = "INSERT INTO DC_JLR_DAFTARJALUR_T(ID_DAFTARJALUR, DC_ID, TANGGAL, RECID, NOMOBIL, " & _
            "NOURUT, SUPCO, SNAMA, ITEM, RUPIAH, TGLSTART, TGLEND, JALUR) VALUES (?, ?, ?, ?," & _
            " ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        Me.OleDbInsertCommand1.Connection = Me.olcon
        Me.OleDbInsertCommand1.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("ID_DAFTARJALUR", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("DC_ID", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "DC_ID", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TANGGAL", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TANGGAL"), New System.Data.OleDb.OleDbParameter("RECID", System.Data.OleDb.OleDbType.VarChar, 1, "RECID"), New System.Data.OleDb.OleDbParameter("NOMOBIL", System.Data.OleDb.OleDbType.VarChar, 11, "NOMOBIL"), New System.Data.OleDb.OleDbParameter("NOURUT", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "NOURUT", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("SUPCO", System.Data.OleDb.OleDbType.VarChar, 4, "SUPCO"), New System.Data.OleDb.OleDbParameter("SNAMA", System.Data.OleDb.OleDbType.VarChar, 50, "SNAMA"), New System.Data.OleDb.OleDbParameter("ITEM", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("RUPIAH", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TGLSTART", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGLSTART"), New System.Data.OleDb.OleDbParameter("TGLEND", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGLEND"), New System.Data.OleDb.OleDbParameter("JALUR", System.Data.OleDb.OleDbType.VarChar, 50, "JALUR")})
        '
        'OleDbSelectCommand1
        '
        Me.OleDbSelectCommand1.CommandText = "SELECT     ID_DAFTARJALUR, DC_ID, TANGGAL, RECID, NOMOBIL, NOURUT, SUPCO, SNAMA, " & _
            "ITEM, RUPIAH, TGLSTART, TGLEND, JALUR, PRINT_ID" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "FROM         DC_JLR_DAFTARJALUR" & _
            "_T"
        Me.OleDbSelectCommand1.Connection = Me.olcon
        '
        'OleDbUpdateCommand1
        '
        Me.OleDbUpdateCommand1.CommandText = resources.GetString("OleDbUpdateCommand1.CommandText")
        Me.OleDbUpdateCommand1.Connection = Me.olcon
        Me.OleDbUpdateCommand1.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("ID_DAFTARJALUR", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("DC_ID", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "DC_ID", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TANGGAL", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TANGGAL"), New System.Data.OleDb.OleDbParameter("RECID", System.Data.OleDb.OleDbType.VarChar, 1, "RECID"), New System.Data.OleDb.OleDbParameter("NOMOBIL", System.Data.OleDb.OleDbType.VarChar, 11, "NOMOBIL"), New System.Data.OleDb.OleDbParameter("NOURUT", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "NOURUT", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("SUPCO", System.Data.OleDb.OleDbType.VarChar, 4, "SUPCO"), New System.Data.OleDb.OleDbParameter("SNAMA", System.Data.OleDb.OleDbType.VarChar, 50, "SNAMA"), New System.Data.OleDb.OleDbParameter("ITEM", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("RUPIAH", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TGLSTART", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGLSTART"), New System.Data.OleDb.OleDbParameter("TGLEND", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGLEND"), New System.Data.OleDb.OleDbParameter("JALUR", System.Data.OleDb.OleDbType.VarChar, 50, "JALUR"), New System.Data.OleDb.OleDbParameter("Original_ID_DAFTARJALUR", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_DC_ID", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "DC_ID", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ITEM", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ITEM1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JALUR", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JALUR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JALUR1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JALUR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_NOMOBIL", System.Data.OleDb.OleDbType.VarChar, 11, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "NOMOBIL", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_NOURUT", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "NOURUT", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_NOURUT1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "NOURUT", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RECID", System.Data.OleDb.OleDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "RECID", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RECID1", System.Data.OleDb.OleDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "RECID", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RUPIAH", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RUPIAH1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SNAMA", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SNAMA", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SNAMA1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SNAMA", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SUPCO", System.Data.OleDb.OleDbType.VarChar, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SUPCO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SUPCO1", System.Data.OleDb.OleDbType.VarChar, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SUPCO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TANGGAL", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TANGGAL", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TANGGAL1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TANGGAL", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGLEND", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGLEND", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGLEND1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGLEND", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGLSTART", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGLSTART", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGLSTART1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGLSTART", System.Data.DataRowVersion.Original, Nothing)})
        '
        'frmLoadPO
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.ClientSize = New System.Drawing.Size(974, 491)
        Me.Controls.Add(Me.btnBatal)
        Me.Controls.Add(Me.btnSimpan)
        Me.Controls.Add(Me.dgvLoadPO)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "frmLoadPO"
        Me.Text = "frmLoadPO"
        CType(Me.dgvLoadPO, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsPO1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnBatal As System.Windows.Forms.Button
    Friend WithEvents btnSimpan As System.Windows.Forms.Button
    Friend WithEvents dgvLoadPO As System.Windows.Forms.DataGridView
    Friend WithEvents DsPO1 As PendaftaranPO.DS_
    Friend WithEvents olcon As System.Data.OleDb.OleDbConnection
    Friend WithEvents oldapPO As System.Data.OleDb.OleDbDataAdapter
    Friend WithEvents OleDbDeleteCommand2 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbInsertCommand2 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbSelectCommand2 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbUpdateCommand2 As System.Data.OleDb.OleDbCommand
    Friend WithEvents oldapMobil As System.Data.OleDb.OleDbDataAdapter
    Friend WithEvents OleDbDeleteCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbInsertCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbSelectCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbUpdateCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents PRDCD As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FRAC As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FRACASAL As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PO_GROSS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PO_PPN As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PO_DISC As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents UNIT As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents QTYBONUS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DESKRIPSI As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PO_NO_PO As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SATUAN As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PODTL_PRICE As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PEMBAGIDISC As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PO_PPNASAL As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PO_DISCASAL As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PPN_BOTOLASAL As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PPN_BOTOL As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents QTYBONUSASAL As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents MBRTAG As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EXTAG As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
