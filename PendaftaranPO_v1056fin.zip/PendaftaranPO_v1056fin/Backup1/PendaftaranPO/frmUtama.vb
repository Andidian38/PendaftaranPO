Imports IDM.Fungsi
Imports System.Data.OleDb

'Imports System.Data.OracleClient

Public Class frmUtama
    Inherits System.Windows.Forms.Form

    Private _NIK As String
    Dim Jam As String
    Friend WithEvents btnDraftRetur As System.Windows.Forms.Button
    Dim Tgl As String
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Dim vb As New vb
    Protected Overrides Sub OnHandleCreated(ByVal e As System.EventArgs)
        Dim CurrentProcesses() As Process
        CurrentProcesses = Process.GetProcessesByName _
                           (Process.GetCurrentProcess.ProcessName)
        If CurrentProcesses.GetUpperBound(0) <= 0 Then
            Exit Sub
        End If
        Dim i As Integer
        Dim ProcessHandle As Long
        For i = 0 To CurrentProcesses.GetUpperBound(0)
            ProcessHandle = CurrentProcesses(i).MainWindowHandle.ToInt32
        Next
        End

    End Sub

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnDaftar As System.Windows.Forms.Button
    Friend WithEvents picIDM As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents lblUser As System.Windows.Forms.Label
    Friend WithEvents lblDC As System.Windows.Forms.Label
    Friend WithEvents lblGudang As System.Windows.Forms.Label
    Friend WithEvents lblLok As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents btnKeluar As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmUtama))
        Me.btnDaftar = New System.Windows.Forms.Button
        Me.picIDM = New System.Windows.Forms.PictureBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.lblLok = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.lblGudang = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.lblDC = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.lblUser = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.btnKeluar = New System.Windows.Forms.Button
        Me.btnDraftRetur = New System.Windows.Forms.Button
        Me.Label29 = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        CType(Me.picIDM, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnDaftar
        '
        Me.btnDaftar.BackColor = System.Drawing.Color.Transparent
        Me.btnDaftar.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDaftar.Image = Global.PendaftaranPO.My.Resources.Resources.book_open
        Me.btnDaftar.Location = New System.Drawing.Point(14, 125)
        Me.btnDaftar.Name = "btnDaftar"
        Me.btnDaftar.Size = New System.Drawing.Size(91, 28)
        Me.btnDaftar.TabIndex = 5
        Me.btnDaftar.Text = "&Daftar"
        Me.btnDaftar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnDaftar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnDaftar.UseVisualStyleBackColor = False
        '
        'picIDM
        '
        Me.picIDM.Image = Global.PendaftaranPO.My.Resources.Resources.indomaret_transparant_small
        Me.picIDM.Location = New System.Drawing.Point(261, 6)
        Me.picIDM.Name = "picIDM"
        Me.picIDM.Size = New System.Drawing.Size(227, 76)
        Me.picIDM.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.picIDM.TabIndex = 26
        Me.picIDM.TabStop = False
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(77, 81)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(15, 14)
        Me.Label9.TabIndex = 11
        Me.Label9.Text = ":"
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(77, 58)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(15, 14)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = ":"
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(77, 35)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(15, 14)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = ":"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(77, 12)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(15, 14)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = ":"
        '
        'lblLok
        '
        Me.lblLok.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLok.Location = New System.Drawing.Point(92, 81)
        Me.lblLok.Name = "lblLok"
        Me.lblLok.Size = New System.Drawing.Size(150, 16)
        Me.lblLok.TabIndex = 7
        Me.lblLok.Text = "lblLokasi"
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(11, 81)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(63, 16)
        Me.Label8.TabIndex = 6
        Me.Label8.Text = "Lokasi"
        '
        'lblGudang
        '
        Me.lblGudang.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGudang.Location = New System.Drawing.Point(92, 58)
        Me.lblGudang.Name = "lblGudang"
        Me.lblGudang.Size = New System.Drawing.Size(150, 16)
        Me.lblGudang.TabIndex = 5
        Me.lblGudang.Text = "lblGudang"
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(11, 58)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(63, 16)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Gudang"
        '
        'lblDC
        '
        Me.lblDC.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDC.Location = New System.Drawing.Point(92, 35)
        Me.lblDC.Name = "lblDC"
        Me.lblDC.Size = New System.Drawing.Size(150, 16)
        Me.lblDC.TabIndex = 3
        Me.lblDC.Text = "lblDC"
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(11, 35)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(63, 16)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "DC"
        '
        'lblUser
        '
        Me.lblUser.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUser.Location = New System.Drawing.Point(92, 12)
        Me.lblUser.Name = "lblUser"
        Me.lblUser.Size = New System.Drawing.Size(150, 16)
        Me.lblUser.TabIndex = 1
        Me.lblUser.Text = "lblUser"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(11, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(83, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Nama User"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(263, 80)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(223, 23)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "PT. INDOMARCO PRISMATAMA"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnKeluar
        '
        Me.btnKeluar.BackColor = System.Drawing.Color.Transparent
        Me.btnKeluar.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnKeluar.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnKeluar.Image = Global.PendaftaranPO.My.Resources.Resources.cross
        Me.btnKeluar.Location = New System.Drawing.Point(410, 125)
        Me.btnKeluar.Name = "btnKeluar"
        Me.btnKeluar.Size = New System.Drawing.Size(93, 28)
        Me.btnKeluar.TabIndex = 33
        Me.btnKeluar.Text = "&Keluar"
        Me.btnKeluar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnKeluar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnKeluar.UseVisualStyleBackColor = False
        '
        'btnDraftRetur
        '
        Me.btnDraftRetur.BackColor = System.Drawing.Color.Transparent
        Me.btnDraftRetur.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDraftRetur.Image = Global.PendaftaranPO.My.Resources.Resources.printer
        Me.btnDraftRetur.Location = New System.Drawing.Point(111, 125)
        Me.btnDraftRetur.Name = "btnDraftRetur"
        Me.btnDraftRetur.Size = New System.Drawing.Size(156, 28)
        Me.btnDraftRetur.TabIndex = 34
        Me.btnDraftRetur.Text = "&Cetak Draft Retur"
        Me.btnDraftRetur.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnDraftRetur.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnDraftRetur.UseVisualStyleBackColor = False
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.BackColor = System.Drawing.Color.Tan
        Me.Label29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label29.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(25, 4)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(70, 15)
        Me.Label29.TabIndex = 77
        Me.Label29.Text = "Info User"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.picIDM)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.lblLok)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.lblUser)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.lblGudang)
        Me.Panel1.Controls.Add(Me.lblDC)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Location = New System.Drawing.Point(10, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(493, 107)
        Me.Panel1.TabIndex = 78
        '
        'frmUtama
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.CancelButton = Me.btnKeluar
        Me.ClientSize = New System.Drawing.Size(512, 164)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.btnDraftRetur)
        Me.Controls.Add(Me.btnKeluar)
        Me.Controls.Add(Me.btnDaftar)
        Me.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmUtama"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Antrian DC"
        CType(Me.picIDM, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    Private Sub frmUtama_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim arguments As String() = Environment.GetCommandLineArgs()
        Dim argument As String
        For Each argument In arguments
            If argument.Split("=")(0).ToLower = "/u" Then
                Dim guid As String = argument.Split("=")(1)
                Dim path As String = _
                   Environment.GetFolderPath(Environment.SpecialFolder.System)
                Dim si As New ProcessStartInfo(path & _
                          "\msiexec.exe", "/i " & guid)
                Process.Start(si)
                Close()
                Application.Exit()
                End
            End If
        Next
        Me.Text = Application.ProductName & " v" & Application.ProductVersion
        'Dim Scon As New OracleConnection(ConStrORA)
        'Dim Scom As New OracleCommand("", Scon)
        'Dim Sdap As New OracleDataAdapter("", Scon)

        'Dim Scon As New OleDb.OleDbConnection(ConStrORA)
        'Dim Scom As New OleDb.OleDbCommand("", Scon)
        'Dim Sdap As New OleDb.OleDbDataAdapter("", Scon)
        'Dim dt As New DataTable
        'Try
        '    Scon.Open()
        '    Sdap.SelectCommand.CommandText = "SELECT * FROM DC_JLR_ANTRIAN_T"
        '    Sdap.Fill(dt)
        '    DataGrid1.DataSource = dt

        'Catch ex As Exception
        '    ShowError("Error Load Form Utama", ex)
        'Finally
        '    Scon.Close()
        'End Try

        'MAIN
        'ConStrORA = "user id=DCSIM;data source=SIMULASIA;password=DCSIM"
        'Dim Scon As New OracleConnection(ConStrORA)
        'Dim Scom As New OracleCommand("", Scon)
        'Dim Sdar As OracleDataReader
        Readme_User()
        'MessageBox.Show(cUsrOra)
        If USER_DATA(3) = "" Then
            MessageBox.Show("Setting Server Oracle Kurang.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        'ConStrORA = "Provider=MSDAORA.1;User ID=" & cUsrOra & ";password=" & cPassOra & ";Data Source=" & cTnsOra & ""
        'MessageBox.Show(ConStrORA)
        Me.Text = Application.ProductName & " v" & Application.ProductVersion & " [" & USER_DATA(3) & "]"
        frmLoadPO.Text = " Load || " & Application.ProductName & " v" & Application.ProductVersion & " [" & USER_DATA(3) & "]"
        frmDaftarPO.Text = " Daftar PO || " & Application.ProductName & " v" & Application.ProductVersion & " [" & USER_DATA(3) & "]"
        frmEditPO.Text = " Edit PO || " & Application.ProductName & " v" & Application.ProductVersion & " [" & USER_DATA(3) & "]"
        Dim dc As String() = vb.ambilDataDC(ConStrORA)
        'vb.Cek_Program(dc(0), ConStrORA)

        'Dim Versi As String = vb.Cek_Update_Prog(ConStrORA, Application.ProductName)
        'MessageBox.Show(Application.ProductName)
        Dim Scon As New OleDb.OleDbConnection(ConStrORA)
        Dim Scom As New OleDb.OleDbCommand("", Scon)
        Dim Sdar As OleDb.OleDbDataReader

        Dim Sql As String

        'If GetSetting("Indomaret\JalurDC ORA", "Setup", "OraData") <> "1" Then
        '    Call SetUpDbOra()
        '    Call SaveSetting("Indomaret\JalurDC ORA", "Setup", "OraData", "1")
        'End If

        Dim f As New FormLogin
        f.Text = "Login - [" & Application.ProductName & " v" & Application.ProductVersion & "]"
        Dim lcount As Integer = 0
        Try
            Scon.Open()

Pass:
            If f.ShowDialog() <> Windows.Forms.DialogResult.OK Then
                Me.Close()
                Exit Sub
            End If

            Dim cUser As String, cPass As String
            cUser = f.txtUser.Text.Replace("'", "")
            cPass = f.txtPass.Text
            'Todo: Hilangkan Password
            'If cUser = "" Then
            '    cUser = "BPO1"
            '    cPass = "7670"
            'End If
            cUser = cUser.ToUpper
            cPass = cPass.ToUpper
            Scom.CommandText = "Select Count(*) as JUM from DC_USER_T " & _
                "Where UPPER(USER_NAME)='" & cUser & "' AND UPPER(USER_PASSWORD)='" & cPass & "'"
            If Scom.ExecuteScalar = 0 Then
                MsgBox("NAMA USER ATAU PASSWORD SALAH.", vbCritical)
                If lcount = 2 Then
                    Me.Close()
                    Exit Sub
                End If
                lcount += 1
                GoTo Pass
            End If
            f.Dispose()

            'Cek HAK
            Sql = " SELECT U.USER_NAME,DC.TBL_DCID,DC.TBL_DC_KODE,DC.TBL_DC_NAMA,"
            Sql &= "U.USER_FK_TBL_DEPOID,G.TBL_GUDANG_KODE,"
            Sql &= "G.TBL_GUDANG_NAMA,U.USER_FK_TBL_LOKASIID,L.TBL_LOKASI_KODE,"
            Sql &= "L.TBL_LOKASIID,L.TBL_LOKASI_NAMA,L.TBL_LOKASI_TYPE "
            Sql &= "from DC_USER_T U "
            Sql &= "LEFT JOIN DC_TABEL_DC_T DC ON U.USER_FK_TBL_DCID = DC.TBL_DCID "
            Sql &= "LEFT JOIN DC_TABEL_GUDANG_T G ON U.USER_FK_TBL_DEPOID=G.TBL_GUDANGID "
            Sql &= "LEFT JOIN DC_TABEL_LOKASI_T L ON U.USER_FK_TBL_LOKASIID=L.TBL_LOKASIID "
            Sql &= "WHERE 1=1 "
            Sql &= "AND USER_NAME='" & cUser & "' "
            'Sql &= "AND L.TBL_LOKASI_TYPE='BAIK' "
            Scom.CommandText = Sql
            Dim ds As New DataSet
            Dim da As New OleDb.OleDbDataAdapter
            da.SelectCommand = Scom
            da.Fill(ds)
            Sdar = Scom.ExecuteReader

            Sdar.Read()
            cDC_ID = "" & Sdar("TBL_DCID")
            cDC_KODE = "" & Sdar("TBL_DC_KODE")
            cDC_NAMA = "" & Sdar("TBL_DC_NAMA")

            cGUDANG_ID = "" & Sdar("USER_FK_TBL_DEPOID")
            cGUDANG_KODE = "" & Sdar("TBL_GUDANG_KODE")
            cGUDANG_NAMA = "" & Sdar("TBL_GUDANG_NAMA")

            cLOKASI_KODE = "" & Sdar("TBL_LOKASIID")
            cLOKASI_TYPE = "" & Sdar("TBL_LOKASI_TYPE")
            Sdar.Close()

            'Cek DC
            'Scom.CommandText = "SELECT USER_FK_TBL_DCID from DC_USER_T " & _
            '    "Where USER_NAME='" & cUser & "' AND USER_PASSWORD='" & cPass & "'"
            'cDC_ID = "" & Scom.ExecuteScalar
            If cDC_ID = "" Then
                'Pilih DC Sendiri
                Dim fp As New frmPilih
                fp.Text = "PILIH KODE DC - " & Application.ProductName

                Scom.CommandText = "Select TBL_DCID,TBL_DC_KODE,TBL_DC_NAMA FROM DC_TABEL_DC_T ORDER BY TBL_DC_KODE"
                Sdar = Scom.ExecuteReader
                Dim ls As New Collection

                fp.ListBox1.Items.Clear()
                Do While Sdar.Read
                    'ls.Add(Sdar("TBL_DC_KODE") & " - " & Sdar("TBL_DC_NAMA"), Sdar("TBL_DCID"))
                    ls.Add(Sdar("TBL_DCID"))

                    fp.ListBox1.Items.Add(Sdar("TBL_DC_KODE") & " - " & Sdar("TBL_DC_NAMA"))
                    'fp.ListBox1.Items.Add(ls)
                Loop
                Sdar.Close()
                fp.ListBox1.SelectedIndex = 0

                If fp.ShowDialog <> Windows.Forms.DialogResult.OK Then
                    Exit Sub
                End If
                cDC_ID = ls(fp.ListBox1.SelectedIndex + 1)
                cDC_KODE = fp.ListBox1.SelectedItem

                cDC_NAMA = cDC_KODE.Substring(cDC_KODE.IndexOf("-") + 2)
                cDC_KODE = cDC_KODE.Substring(0, cDC_KODE.IndexOf("-") - 1)

                fp.Dispose()
                ls = Nothing

            Else
                ''PUNYA DC
                'Scom.CommandText = "Select TBL_DCID,TBL_DC_KODE,TBL_DC_NAMA FROM DC_TABEL_DC_T " & _
                '    "WHERE TBL_DC_ID='" & cDC_ID & "'"
                'Sdar = Scom.ExecuteReader
                'Do While Sdar.Read
                '    cDC_KODE = Sdar("TBL_DC_KODE")
                '    cDC_NAMA = Sdar("TBL_DC_NAMA")
                'Loop
                'Sdar.Close()
            End If

            'Cek DEPO
            If cGUDANG_KODE = "" Then
                'Pilih DC Sendiri
                Dim fp As New frmPilih
                fp.Text = "PILIH DEPO - " & Application.ProductName

                Scom.CommandText = "Select TBL_GUDANGID,TBL_GUDANG_KODE,TBL_GUDANG_NAMA " & _
                    "FROM DC_TABEL_GUDANG_T " & _
                    "WHERE TBL_FK_DCID='" & cDC_ID & "' ORDER BY TBL_GUDANG_KODE"
                Sdar = Scom.ExecuteReader
                Dim ls As New Collection

                fp.ListBox1.Items.Clear()
                Do While Sdar.Read
                    'ls.Add(Sdar("TBL_DC_KODE") & " - " & Sdar("TBL_DC_NAMA"), Sdar("TBL_DCID"))
                    ls.Add(Sdar("TBL_GUDANGID"))

                    fp.ListBox1.Items.Add(Sdar("TBL_GUDANG_KODE") & " - " & Sdar("TBL_GUDANG_NAMA"))
                    'fp.ListBox1.Items.Add(ls)
                Loop
                Sdar.Close()
                Try
                    fp.ListBox1.SelectedIndex = 0
                Catch
                    MessageBox.Show("Tidak Ada Data Gudang.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End Try


                If fp.ShowDialog <> Windows.Forms.DialogResult.OK Then
                    Exit Sub
                End If
                cGUDANG_ID = ls(fp.ListBox1.SelectedIndex + 1)
                cGUDANG_KODE = fp.ListBox1.SelectedItem

                cGUDANG_NAMA = cGUDANG_KODE.Substring(cGUDANG_KODE.IndexOf("-") + 2)
                cGUDANG_KODE = cGUDANG_KODE.Substring(0, cGUDANG_KODE.IndexOf("-") - 1)

                fp.Dispose()
                ls = Nothing

                'Cek Lokasinya
                Scom.CommandText = "SELECT TBL_LOKASIID,TBL_LOKASI_TYPE FROM DC_TABEL_LOKASI_T " & _
                    "WHERE TBL_FK_GUDANGID='" & cGUDANG_ID & "' " & _
                    "AND TBL_LOKASI_TYPE='BAIK'"
                Sdar = Scom.ExecuteReader
                If Sdar.Read Then
                    cLOKASI_KODE = "" & Sdar("TBL_LOKASIID")
                    cLOKASI_TYPE = "" & Sdar("TBL_LOKASI_TYPE")
                End If
                Sdar.Close()
            End If


            'Cek Lokasi
            If cLOKASI_TYPE <> "BAIK" Then
                MsgBox("User Bukan Untuk Lokasi Barang Baik.", vbCritical)
                Me.Close()
                Exit Sub
            End If


            Scom.CommandText = "Select COUNT(*) From DC_JLR_Setting_T WHERE DC_ID=" & cDC_ID
            If Scom.ExecuteScalar = 0 Then
                Scom.CommandText = "INSERT INTO DC_JLR_SETTING_T(DC_ID,NEXTNOURUT,LASTDATE) VALUES(" & cDC_ID & ",1,TRUNC(SYSDATE))"
                Scom.ExecuteNonQuery()
                GoTo UPD
            End If

            Scom.CommandText = "Select Trunc(LastDate) as LastDate From DC_JLR_Setting_T WHERE DC_ID=" & cDC_ID
            If Scom.ExecuteScalar <> GetOracleDate() Then 'diganti sysdate oracle
UPD:            Sql = "UPDATE DC_JLR_Antrian_T Set Recid='O',Supplier=NULL,NoAntrian=Null Where DC_ID=" & cDC_ID & ""
                Scom.CommandText = Sql
                Scom.ExecuteNonQuery()

                Sql = "UPDATE DC_JLR_Setting_T Set NextNoUrut=1,LastDate=Trunc(sysdate) Where DC_ID=" & cDC_ID & ""
                Scom.CommandText = Sql
                Scom.ExecuteNonQuery()

                Sql = "Delete from DC_JLR_TempAntrian_T Where DC_ID=" & cDC_ID & ""
                Scom.CommandText = Sql
                Scom.ExecuteNonQuery()
            End If

            If Scom.ExecuteScalar > Now.Date Then
                MessageBox.Show("Program tidak bisa Mundur Tanggal", Application.ProductName, MessageBoxButtons.OK)
                Exit Try
            End If

            If ds.Tables(0).Rows.Count > 1 Then
                lblDC.Visible = False
                lblGudang.Visible = False
                lblLok.Visible = False
            End If
            'Dim fu As New frmUtama
            lblUser.Text = cUser
            lblDC.Text = cDC_KODE & " - " & cDC_NAMA
            lblGudang.Text = cGUDANG_NAMA
            lblLok.Text = cLOKASI_TYPE
            'Dim fu As New DataForm1
            SignIn(lblUser.Text, cDC_ID)
        Catch ex As Exception
            ShowError("Error Initial Data.", ex)
            Me.Close()
        Finally
            Scon.Close()
        End Try

    End Sub
    Private Function GetOracleDate() As Date
        Dim Scon As New OleDbConnection(ConStrORA)
        Dim Scom As New OleDbCommand("", Scon)
        Try
            Scon.Open()
            Scom.CommandText = "Select trunc(sysdate) from dual"
            Return Scom.ExecuteScalar

        Catch ex As Exception
            ShowError("error Baca Jam", ex)
        Finally
            Scon.Close()
        End Try

    End Function
    Private Sub btnDaftar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDaftar.Click
        Me.Visible = False
        Dim f As New frmDaftarPO
        f.ShowDialog()

        Me.Visible = True
    End Sub
    Private Sub btnKeluar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKeluar.Click
        Me.Close()
    End Sub
    Private Sub frmUtama_Leave(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles MyBase.FormClosed
        SignOut(cDC_ID)
    End Sub

    Private Function SignIn(ByVal _Usr As String, ByVal GD_ID As String) As String
        Dim _t As String = "-1"
        Dim Scon As New OleDb.OleDbConnection(ConStrORA)
        Dim Scom As New OleDb.OleDbCommand("", Scon)

        Try
            If Scon.State = ConnectionState.Open Then
                Scon.Close()
                Scon.Dispose()
            End If

            Scom.CommandText = "select USER_NIK from dc_user_t where user_name='" & _Usr & "'"
            Scon.Open()
            _NIK = Scom.ExecuteScalar.ToString
            Scon.Close()

            If _NIK = "" Then
                MsgBox("NIK User " & _Usr & " tidak ada, User tidak dapat melakukan presensi")
                _t = "-1"
                Return _t
                Exit Function
            End If

            Scon.Open()
            If Scon.State = ConnectionState.Open Then
                Jam = Now.Hour & ":" & Now.Minute & ":" & Now.Second
                Tgl = Now.Day & "/" & Now.Month & "/" & Now.Year
                Dim _t2 As String = "INSERT INTO DC_ADMIN_ABSEN_T (NIK,TGL_LOGIN,JAM_LOGIN,DCID) VALUES" & _
                                    "('" & _NIK & "',to_date('" & Tgl & "','dd/mm/yy'),'" & Jam & "'," & GD_ID & ")"
                Scom = New OleDb.OleDbCommand(_t2, Scon)
                Scom.ExecuteNonQuery()
                _t = "0"
                Scom.Dispose()
                Scom = Nothing
            End If
        Catch ex As Exception
            _t = ex.Message
        End Try

        Return _t
    End Function

    Private Function SignOut(ByVal GD_ID As String) As String
        Dim _t As String = "-1"
        Dim Scon As New OleDb.OleDbConnection(ConStrORA)
        Dim Scom As New OleDb.OleDbCommand("", Scon)
        Dim Jam_kluar As String
        Dim Tgl_kluar As String

        Try
            If Scon.State = ConnectionState.Open Then
                Scon.Close()
            End If

            If _NIK = "" Then
                _t = "-1"
                Return _t
                Exit Function
            End If

            Scon.Open()
            If Scon.State = ConnectionState.Open Then
                Jam_kluar = Now.Hour & ":" & Now.Minute & ":" & Now.Second
                Tgl_kluar = Now.Day & "/" & Now.Month & "/" & Now.Year
                Dim _t2 As String = "UPDATE DC_ADMIN_ABSEN_T SET TGL_LOGOUT=to_date('" & Tgl_kluar & "','dd/mm/yy'),JAM_LOGOUT='" & Jam_kluar & "' " & _
                                    "where NIK='" & _NIK & "' and TGL_LOGIN=to_date('" & Tgl & "','dd/mm/yy') and JAM_LOGIN='" & Jam & "' and DCID=" & GD_ID
                Scom = New OleDb.OleDbCommand(_t2, Scon)
                Scom.ExecuteNonQuery()
                _t = "0"
                Scom.Dispose()
                Scom = Nothing
            End If
        Catch ex As Exception
            _t = ex.Message
        End Try

        Return _t
    End Function

    Private Sub btnDraftRetur_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDraftRetur.Click
        Me.Visible = False
        Dim f As New frmDraftRSupp
        f.ShowDialog()

        Me.Visible = True
    End Sub
End Class
