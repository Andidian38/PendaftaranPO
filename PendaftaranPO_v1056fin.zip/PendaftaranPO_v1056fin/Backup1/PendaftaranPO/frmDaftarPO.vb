Imports IDM.Fungsi
Imports System.Data.OleDb
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.Drawing.Printing.PaperSize

Public Class frmDaftarPO
    Inherits System.Windows.Forms.Form
    Public saveLoadPO As String
    Public datasetload As DataTable
    Friend WithEvents txtNoAntrianPO As System.Windows.Forms.TextBox
    Public WithEvents Label25 As System.Windows.Forms.Label
    Public NoAntrian As String
    ' Private WithEvents frmLoadPO1 As New frmLoadPO

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        Me.txtTglFaktur.BackColor = System.Drawing.SystemColors.Window
        Me.txtTglFaktur.ForeColor = System.Drawing.SystemColors.WindowText

        'Format Textbox
        Dim bd As Binding
        bd = txtPO_GROSS.DataBindings("Text")
        AddHandler bd.Format, AddressOf formatTextBox
        AddHandler bd.Parse, AddressOf formatTextBox

        'bd = txtPO_QTY.DataBindings("Text")
        'AddHandler bd.Format, AddressOf formatTextBox
        'AddHandler bd.Parse, AddressOf formatTextBox

        bd = txtPO_PPN.DataBindings("Text")
        AddHandler bd.Format, AddressOf formatTextBox
        AddHandler bd.Parse, AddressOf formatTextBox

        bd = txtPO_Total.DataBindings("Text")
        AddHandler bd.Format, AddressOf formatTextBox
        AddHandler bd.Parse, AddressOf formatTextBox
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents btnCancelAll As System.Windows.Forms.Button
    Friend WithEvents oldapMobil As System.Data.OleDb.OleDbDataAdapter
    Friend WithEvents oldapPO As System.Data.OleDb.OleDbDataAdapter
    Friend WithEvents olcon As System.Data.OleDb.OleDbConnection
    Public WithEvents txtNoAntrian As System.Windows.Forms.TextBox
    Public WithEvents Label17 As System.Windows.Forms.Label
    Public WithEvents Label26 As System.Windows.Forms.Label
    Public WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents btnNext As System.Windows.Forms.Button
    Friend WithEvents btnPrev As System.Windows.Forms.Button
    Friend WithEvents btnDaftar As System.Windows.Forms.Button
    Friend WithEvents grpSup As System.Windows.Forms.GroupBox
    Friend WithEvents btnTambahPO As System.Windows.Forms.Button
    Public WithEvents Frame4 As System.Windows.Forms.GroupBox
    Public WithEvents lblBPB_NO As System.Windows.Forms.Label
    Public WithEvents Label16 As System.Windows.Forms.Label
    Public WithEvents Label15 As System.Windows.Forms.Label
    Public WithEvents Label14 As System.Windows.Forms.Label
    Public WithEvents lblStatus As System.Windows.Forms.Label
    Public WithEvents lblStatusKeterangan As System.Windows.Forms.Label
    Public WithEvents Frame1 As System.Windows.Forms.GroupBox
    Public WithEvents txtTgl_PO As FlexMaskEditBox
    Public WithEvents txtNo_PO As System.Windows.Forms.TextBox
    Public WithEvents txtPO_QTY As System.Windows.Forms.TextBox
    Public WithEvents txtPO_GROSS As System.Windows.Forms.TextBox
    Public WithEvents txtPO_PPN As System.Windows.Forms.TextBox
    Public WithEvents txtPO_Total As System.Windows.Forms.TextBox
    Public WithEvents chkBUAT_PO As System.Windows.Forms.CheckBox
    Public WithEvents chkADA_HARGA As System.Windows.Forms.CheckBox
    Public WithEvents txtTot_Item As System.Windows.Forms.TextBox
    Public WithEvents Label1 As System.Windows.Forms.Label
    Public WithEvents Label2 As System.Windows.Forms.Label
    Public WithEvents Label3 As System.Windows.Forms.Label
    Public WithEvents Label7 As System.Windows.Forms.Label
    Public WithEvents Label10 As System.Windows.Forms.Label
    Public WithEvents Label11 As System.Windows.Forms.Label
    Public WithEvents Label12 As System.Windows.Forms.Label
    Public WithEvents Label13 As System.Windows.Forms.Label
    Public WithEvents Label8 As System.Windows.Forms.Label
    Public WithEvents Label9 As System.Windows.Forms.Label
    Public WithEvents Label4 As System.Windows.Forms.Label
    Public WithEvents Frame2 As System.Windows.Forms.GroupBox
    Public WithEvents txtNoFak As System.Windows.Forms.TextBox
    Public WithEvents Label5 As System.Windows.Forms.Label
    Public WithEvents Label6 As System.Windows.Forms.Label
    Public WithEvents Frame3 As System.Windows.Forms.GroupBox
    Public WithEvents txtUPDATE As System.Windows.Forms.TextBox
    Public WithEvents txtTGL_AKHIR As FlexMaskEditBox
    Public WithEvents txtTGL_MULAI As FlexMaskEditBox
    Public WithEvents Label18 As System.Windows.Forms.Label
    Public WithEvents Label19 As System.Windows.Forms.Label
    Public WithEvents Label20 As System.Windows.Forms.Label
    Public WithEvents Label21 As System.Windows.Forms.Label
    Public WithEvents Label22 As System.Windows.Forms.Label
    Public WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents grpDaftar As System.Windows.Forms.GroupBox
    Friend WithEvents btnSimpanPO As System.Windows.Forms.Button
    Friend WithEvents btnBatalPO As System.Windows.Forms.Button
    Friend WithEvents btnNext2 As System.Windows.Forms.Button
    Friend WithEvents btnPrev2 As System.Windows.Forms.Button
    Friend WithEvents btnEditPO As System.Windows.Forms.Button
    Friend WithEvents btnHapusPO As System.Windows.Forms.Button
    Friend WithEvents cmbFilter As System.Windows.Forms.ComboBox
    Friend WithEvents txtTglFaktur As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtTglDaftar As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblSUPID As System.Windows.Forms.Label
    Friend WithEvents lblSUPCO As System.Windows.Forms.Label
    Friend WithEvents lblSNAMA As System.Windows.Forms.Label
    Friend WithEvents OleDbSelectCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbInsertCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbUpdateCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbDeleteCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents DsPO1 As PendaftaranPO.DS_
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents OleDbSelectCommand2 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbInsertCommand2 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbUpdateCommand2 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbDeleteCommand2 As System.Data.OleDb.OleDbCommand
    Friend WithEvents lblLokasiKode As System.Windows.Forms.Label
    Friend WithEvents lblGudangKode As System.Windows.Forms.Label
    Public WithEvents txtSupID As System.Windows.Forms.TextBox
    Public WithEvents txtLokasiKode As System.Windows.Forms.TextBox
    Public WithEvents txtGudangkode As System.Windows.Forms.TextBox
    Friend WithEvents grpHidden As System.Windows.Forms.GroupBox
    Friend WithEvents btnKeluar As System.Windows.Forms.Button
    Friend WithEvents lblTglRevisi As System.Windows.Forms.Label
    Friend WithEvents lblIdDaftarPO As System.Windows.Forms.Label
    Friend WithEvents btnDraftRetur As System.Windows.Forms.Button
    Friend WithEvents CmbSUPCO As System.Windows.Forms.ComboBox
    Friend WithEvents LBMobil As System.Windows.Forms.ListBox
    Friend WithEvents btnPrint As System.Windows.Forms.Button
    Friend WithEvents btnPrintUlang As System.Windows.Forms.Button
    Friend WithEvents CmbNama As System.Windows.Forms.ComboBox
    Friend WithEvents BtnPrintStck As System.Windows.Forms.Button
    Friend WithEvents btnCari As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDaftarPO))
        Me.olcon = New System.Data.OleDb.OleDbConnection
        Me.oldapMobil = New System.Data.OleDb.OleDbDataAdapter
        Me.OleDbDeleteCommand1 = New System.Data.OleDb.OleDbCommand
        Me.OleDbInsertCommand1 = New System.Data.OleDb.OleDbCommand
        Me.OleDbSelectCommand1 = New System.Data.OleDb.OleDbCommand
        Me.OleDbUpdateCommand1 = New System.Data.OleDb.OleDbCommand
        Me.oldapPO = New System.Data.OleDb.OleDbDataAdapter
        Me.OleDbDeleteCommand2 = New System.Data.OleDb.OleDbCommand
        Me.OleDbInsertCommand2 = New System.Data.OleDb.OleDbCommand
        Me.OleDbSelectCommand2 = New System.Data.OleDb.OleDbCommand
        Me.OleDbUpdateCommand2 = New System.Data.OleDb.OleDbCommand
        Me.btnUpdate = New System.Windows.Forms.Button
        Me.btnCancelAll = New System.Windows.Forms.Button
        Me.grpSup = New System.Windows.Forms.GroupBox
        Me.txtNoAntrianPO = New System.Windows.Forms.TextBox
        Me.Label25 = New System.Windows.Forms.Label
        Me.BtnPrintStck = New System.Windows.Forms.Button
        Me.CmbNama = New System.Windows.Forms.ComboBox
        Me.btnPrintUlang = New System.Windows.Forms.Button
        Me.btnPrint = New System.Windows.Forms.Button
        Me.LBMobil = New System.Windows.Forms.ListBox
        Me.CmbSUPCO = New System.Windows.Forms.ComboBox
        Me.btnDraftRetur = New System.Windows.Forms.Button
        Me.btnCari = New System.Windows.Forms.Button
        Me.lblSUPCO = New System.Windows.Forms.Label
        Me.DsPO1 = New PendaftaranPO.DS_
        Me.txtTglDaftar = New System.Windows.Forms.DateTimePicker
        Me.txtNoAntrian = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.btnNext = New System.Windows.Forms.Button
        Me.btnPrev = New System.Windows.Forms.Button
        Me.btnDaftar = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.lblSNAMA = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.grpHidden = New System.Windows.Forms.GroupBox
        Me.lblTglRevisi = New System.Windows.Forms.Label
        Me.lblSUPID = New System.Windows.Forms.Label
        Me.lblLokasiKode = New System.Windows.Forms.Label
        Me.lblGudangKode = New System.Windows.Forms.Label
        Me.btnTambahPO = New System.Windows.Forms.Button
        Me.grpDaftar = New System.Windows.Forms.GroupBox
        Me.Frame4 = New System.Windows.Forms.GroupBox
        Me.lblBPB_NO = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.lblStatus = New System.Windows.Forms.Label
        Me.lblStatusKeterangan = New System.Windows.Forms.Label
        Me.Frame1 = New System.Windows.Forms.GroupBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.txtTgl_PO = New PendaftaranPO.FlexMaskEditBox
        Me.txtNo_PO = New System.Windows.Forms.TextBox
        Me.txtPO_QTY = New System.Windows.Forms.TextBox
        Me.txtPO_GROSS = New System.Windows.Forms.TextBox
        Me.txtPO_PPN = New System.Windows.Forms.TextBox
        Me.txtPO_Total = New System.Windows.Forms.TextBox
        Me.chkBUAT_PO = New System.Windows.Forms.CheckBox
        Me.chkADA_HARGA = New System.Windows.Forms.CheckBox
        Me.txtTot_Item = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Frame2 = New System.Windows.Forms.GroupBox
        Me.txtTglFaktur = New System.Windows.Forms.DateTimePicker
        Me.txtNoFak = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Frame3 = New System.Windows.Forms.GroupBox
        Me.txtSupID = New System.Windows.Forms.TextBox
        Me.txtLokasiKode = New System.Windows.Forms.TextBox
        Me.txtGudangkode = New System.Windows.Forms.TextBox
        Me.txtUPDATE = New System.Windows.Forms.TextBox
        Me.txtTGL_AKHIR = New PendaftaranPO.FlexMaskEditBox
        Me.txtTGL_MULAI = New PendaftaranPO.FlexMaskEditBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.lblIdDaftarPO = New System.Windows.Forms.Label
        Me.cmbFilter = New System.Windows.Forms.ComboBox
        Me.btnHapusPO = New System.Windows.Forms.Button
        Me.btnEditPO = New System.Windows.Forms.Button
        Me.btnNext2 = New System.Windows.Forms.Button
        Me.btnPrev2 = New System.Windows.Forms.Button
        Me.btnBatalPO = New System.Windows.Forms.Button
        Me.btnSimpanPO = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.btnKeluar = New System.Windows.Forms.Button
        Me.grpSup.SuspendLayout()
        CType(Me.DsPO1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpHidden.SuspendLayout()
        Me.grpDaftar.SuspendLayout()
        Me.Frame4.SuspendLayout()
        Me.Frame1.SuspendLayout()
        Me.Frame2.SuspendLayout()
        Me.Frame3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'olcon
        '
        Me.olcon.ConnectionString = "Provider=""MSDAORA.1"";User ID=DCSIM;Data Source=SIMULASIA;Password=dcsim"
        '
        'oldapMobil
        '
        Me.oldapMobil.DeleteCommand = Me.OleDbDeleteCommand1
        Me.oldapMobil.InsertCommand = Me.OleDbInsertCommand1
        Me.oldapMobil.SelectCommand = Me.OleDbSelectCommand1
        Me.oldapMobil.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "DC_JLR_DAFTARJALUR_T", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("ID_DAFTARJALUR", "ID_DAFTARJALUR"), New System.Data.Common.DataColumnMapping("DC_ID", "DC_ID"), New System.Data.Common.DataColumnMapping("TANGGAL", "TANGGAL"), New System.Data.Common.DataColumnMapping("RECID", "RECID"), New System.Data.Common.DataColumnMapping("NOMOBIL", "NOMOBIL"), New System.Data.Common.DataColumnMapping("NOURUT", "NOURUT"), New System.Data.Common.DataColumnMapping("SUPCO", "SUPCO"), New System.Data.Common.DataColumnMapping("SNAMA", "SNAMA"), New System.Data.Common.DataColumnMapping("ITEM", "ITEMnya"), New System.Data.Common.DataColumnMapping("RUPIAH", "RUPIAH"), New System.Data.Common.DataColumnMapping("TGLSTART", "TGLSTART"), New System.Data.Common.DataColumnMapping("TGLEND", "TGLEND"), New System.Data.Common.DataColumnMapping("JALUR", "JALUR")})})
        Me.oldapMobil.UpdateCommand = Me.OleDbUpdateCommand1
        '
        'OleDbDeleteCommand1
        '
        Me.OleDbDeleteCommand1.CommandText = "DELETE FROM DC_JLR_DAFTARJALUR_T WHERE (ID_DAFTARJALUR = ?)"
        Me.OleDbDeleteCommand1.Connection = Me.olcon
        Me.OleDbDeleteCommand1.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("ID_DAFTARJALUR", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Original, Nothing)})
        '
        'OleDbInsertCommand1
        '
        Me.OleDbInsertCommand1.CommandText = "INSERT INTO DC_JLR_DAFTARJALUR_T(ID_DAFTARJALUR, DC_ID, TANGGAL, RECID, NOMOBIL, " & _
            "NOURUT, SUPCO, SNAMA, ITEM, RUPIAH, TGLSTART, TGLEND, JALUR) VALUES (?, ?, ?, ?," & _
            " ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        Me.OleDbInsertCommand1.Connection = Me.olcon
        Me.OleDbInsertCommand1.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("ID_DAFTARJALUR", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("DC_ID", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "DC_ID", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TANGGAL", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TANGGAL"), New System.Data.OleDb.OleDbParameter("RECID", System.Data.OleDb.OleDbType.VarChar, 1, "RECID"), New System.Data.OleDb.OleDbParameter("NOMOBIL", System.Data.OleDb.OleDbType.VarChar, 11, "NOMOBIL"), New System.Data.OleDb.OleDbParameter("NOURUT", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "NOURUT", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("SUPCO", System.Data.OleDb.OleDbType.VarChar, 4, "SUPCO"), New System.Data.OleDb.OleDbParameter("SNAMA", System.Data.OleDb.OleDbType.VarChar, 50, "SNAMA"), New System.Data.OleDb.OleDbParameter("ITEM", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("RUPIAH", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TGLSTART", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGLSTART"), New System.Data.OleDb.OleDbParameter("TGLEND", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGLEND"), New System.Data.OleDb.OleDbParameter("JALUR", System.Data.OleDb.OleDbType.VarChar, 50, "JALUR")})
        '
        'OleDbSelectCommand1
        '
        Me.OleDbSelectCommand1.CommandText = "SELECT     ID_DAFTARJALUR, DC_ID, TANGGAL, RECID, NOMOBIL, NOURUT, SUPCO, SNAMA, " & _
            "ITEM, RUPIAH, TGLSTART, TGLEND, JALUR, PRINT_ID" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "FROM         DC_JLR_DAFTARJALUR" & _
            "_T"
        Me.OleDbSelectCommand1.Connection = Me.olcon
        '
        'OleDbUpdateCommand1
        '
        Me.OleDbUpdateCommand1.CommandText = resources.GetString("OleDbUpdateCommand1.CommandText")
        Me.OleDbUpdateCommand1.Connection = Me.olcon
        Me.OleDbUpdateCommand1.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("ID_DAFTARJALUR", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("DC_ID", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "DC_ID", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TANGGAL", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TANGGAL"), New System.Data.OleDb.OleDbParameter("RECID", System.Data.OleDb.OleDbType.VarChar, 1, "RECID"), New System.Data.OleDb.OleDbParameter("NOMOBIL", System.Data.OleDb.OleDbType.VarChar, 11, "NOMOBIL"), New System.Data.OleDb.OleDbParameter("NOURUT", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "NOURUT", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("SUPCO", System.Data.OleDb.OleDbType.VarChar, 4, "SUPCO"), New System.Data.OleDb.OleDbParameter("SNAMA", System.Data.OleDb.OleDbType.VarChar, 50, "SNAMA"), New System.Data.OleDb.OleDbParameter("ITEM", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("RUPIAH", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TGLSTART", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGLSTART"), New System.Data.OleDb.OleDbParameter("TGLEND", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGLEND"), New System.Data.OleDb.OleDbParameter("JALUR", System.Data.OleDb.OleDbType.VarChar, 50, "JALUR"), New System.Data.OleDb.OleDbParameter("Original_ID_DAFTARJALUR", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_DC_ID", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "DC_ID", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ITEM", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ITEM1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JALUR", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JALUR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JALUR1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JALUR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_NOMOBIL", System.Data.OleDb.OleDbType.VarChar, 11, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "NOMOBIL", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_NOURUT", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "NOURUT", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_NOURUT1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "NOURUT", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RECID", System.Data.OleDb.OleDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "RECID", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RECID1", System.Data.OleDb.OleDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "RECID", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RUPIAH", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RUPIAH1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SNAMA", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SNAMA", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SNAMA1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SNAMA", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SUPCO", System.Data.OleDb.OleDbType.VarChar, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SUPCO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SUPCO1", System.Data.OleDb.OleDbType.VarChar, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SUPCO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TANGGAL", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TANGGAL", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TANGGAL1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TANGGAL", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGLEND", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGLEND", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGLEND1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGLEND", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGLSTART", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGLSTART", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGLSTART1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGLSTART", System.Data.DataRowVersion.Original, Nothing)})
        '
        'oldapPO
        '
        Me.oldapPO.DeleteCommand = Me.OleDbDeleteCommand2
        Me.oldapPO.InsertCommand = Me.OleDbInsertCommand2
        Me.oldapPO.SelectCommand = Me.OleDbSelectCommand2
        Me.oldapPO.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "DC_JLR_DAFTARPO_T", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("ID_DAFTARPO", "ID_DAFTARPO"), New System.Data.Common.DataColumnMapping("TANGGAL", "TANGGAL"), New System.Data.Common.DataColumnMapping("RECID", "RECID"), New System.Data.Common.DataColumnMapping("ID_DAFTARJALUR", "ID_DAFTARJALUR"), New System.Data.Common.DataColumnMapping("NO_FAK", "NO_FAK"), New System.Data.Common.DataColumnMapping("TGL_FAK", "TGL_FAK"), New System.Data.Common.DataColumnMapping("NOPO", "NOPO"), New System.Data.Common.DataColumnMapping("SUPCO", "SUPCO"), New System.Data.Common.DataColumnMapping("SNAMA", "SNAMA"), New System.Data.Common.DataColumnMapping("BUAT_PO", "BUAT_PO"), New System.Data.Common.DataColumnMapping("ADA_HARGA", "ADA_HARGA"), New System.Data.Common.DataColumnMapping("QTY", "QTY"), New System.Data.Common.DataColumnMapping("ITEM", "ITEMnya"), New System.Data.Common.DataColumnMapping("RUPIAH", "RUPIAH"), New System.Data.Common.DataColumnMapping("PPN", "PPN"), New System.Data.Common.DataColumnMapping("BPB_NO", "BPB_NO"), New System.Data.Common.DataColumnMapping("TGL_MULAI", "TGL_MULAI"), New System.Data.Common.DataColumnMapping("JAM_MULAI", "JAM_MULAI"), New System.Data.Common.DataColumnMapping("TGL_AKHIR", "TGL_AKHIR"), New System.Data.Common.DataColumnMapping("JAM_AKHIR", "JAM_AKHIR"), New System.Data.Common.DataColumnMapping("JML_MOBIL", "JML_MOBIL"), New System.Data.Common.DataColumnMapping("TGL_REVISI", "TGL_REVISI"), New System.Data.Common.DataColumnMapping("JAM_REVISI", "JAM_REVISI"), New System.Data.Common.DataColumnMapping("USER_NAME", "USER_NAME"), New System.Data.Common.DataColumnMapping("MRBREAD", "MRBREAD"), New System.Data.Common.DataColumnMapping("UPDATE", "UPDATE"), New System.Data.Common.DataColumnMapping("SUPID", "SUPID"), New System.Data.Common.DataColumnMapping("GUDANG_KODE", "GUDANG_KODE"), New System.Data.Common.DataColumnMapping("LOKASI_KODE", "LOKASI_KODE"), New System.Data.Common.DataColumnMapping("TOTAL", "Total"), New System.Data.Common.DataColumnMapping("STATUS", "Status")})})
        Me.oldapPO.UpdateCommand = Me.OleDbUpdateCommand2
        '
        'OleDbDeleteCommand2
        '
        Me.OleDbDeleteCommand2.CommandText = "DELETE FROM DC_JLR_DAFTARPO_T WHERE (ID_DAFTARPO = ?)"
        Me.OleDbDeleteCommand2.Connection = Me.olcon
        Me.OleDbDeleteCommand2.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("ID_DAFTARPO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARPO", System.Data.DataRowVersion.Original, Nothing)})
        '
        'OleDbInsertCommand2
        '
        Me.OleDbInsertCommand2.CommandText = resources.GetString("OleDbInsertCommand2.CommandText")
        Me.OleDbInsertCommand2.Connection = Me.olcon
        Me.OleDbInsertCommand2.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("ID_DAFTARPO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARPO", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TANGGAL", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TANGGAL"), New System.Data.OleDb.OleDbParameter("RECID", System.Data.OleDb.OleDbType.VarChar, 1, "RECID"), New System.Data.OleDb.OleDbParameter("ID_DAFTARJALUR", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("NO_FAK", System.Data.OleDb.OleDbType.VarChar, 15, "NO_FAK"), New System.Data.OleDb.OleDbParameter("TGL_FAK", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_FAK"), New System.Data.OleDb.OleDbParameter("NOPO", System.Data.OleDb.OleDbType.VarChar, 9, "NOPO"), New System.Data.OleDb.OleDbParameter("SUPCO", System.Data.OleDb.OleDbType.VarChar, 4, "SUPCO"), New System.Data.OleDb.OleDbParameter("SNAMA", System.Data.OleDb.OleDbType.VarChar, 50, "SNAMA"), New System.Data.OleDb.OleDbParameter("BUAT_PO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BUAT_PO", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("ADA_HARGA", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ADA_HARGA", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("QTY", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "QTY", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("ITEM", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("RUPIAH", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("PPN", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "PPN", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("BPB_NO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BPB_NO", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TGL_MULAI", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_MULAI"), New System.Data.OleDb.OleDbParameter("JAM_MULAI", System.Data.OleDb.OleDbType.VarChar, 8, "JAM_MULAI"), New System.Data.OleDb.OleDbParameter("TGL_AKHIR", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_AKHIR"), New System.Data.OleDb.OleDbParameter("JAM_AKHIR", System.Data.OleDb.OleDbType.VarChar, 8, "JAM_AKHIR"), New System.Data.OleDb.OleDbParameter("JML_MOBIL", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "JML_MOBIL", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TGL_REVISI", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_REVISI"), New System.Data.OleDb.OleDbParameter("JAM_REVISI", System.Data.OleDb.OleDbType.VarChar, 8, "JAM_REVISI"), New System.Data.OleDb.OleDbParameter("USER_NAME", System.Data.OleDb.OleDbType.VarChar, 15, "USER_NAME"), New System.Data.OleDb.OleDbParameter("MRBREAD", System.Data.OleDb.OleDbType.VarChar, 1, "MRBREAD"), New System.Data.OleDb.OleDbParameter("UPDATE", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "UPDATE"), New System.Data.OleDb.OleDbParameter("SUPID", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "SUPID", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("GUDANG_KODE", System.Data.OleDb.OleDbType.VarChar, 8, "GUDANG_KODE"), New System.Data.OleDb.OleDbParameter("LOKASI_KODE", System.Data.OleDb.OleDbType.VarChar, 8, "LOKASI_KODE")})
        '
        'OleDbSelectCommand2
        '
        Me.OleDbSelectCommand2.CommandText = resources.GetString("OleDbSelectCommand2.CommandText")
        Me.OleDbSelectCommand2.Connection = Me.olcon
        '
        'OleDbUpdateCommand2
        '
        Me.OleDbUpdateCommand2.CommandText = resources.GetString("OleDbUpdateCommand2.CommandText")
        Me.OleDbUpdateCommand2.Connection = Me.olcon
        Me.OleDbUpdateCommand2.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("ID_DAFTARPO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARPO", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TANGGAL", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TANGGAL"), New System.Data.OleDb.OleDbParameter("RECID", System.Data.OleDb.OleDbType.VarChar, 1, "RECID"), New System.Data.OleDb.OleDbParameter("ID_DAFTARJALUR", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("NO_FAK", System.Data.OleDb.OleDbType.VarChar, 15, "NO_FAK"), New System.Data.OleDb.OleDbParameter("TGL_FAK", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_FAK"), New System.Data.OleDb.OleDbParameter("NOPO", System.Data.OleDb.OleDbType.VarChar, 9, "NOPO"), New System.Data.OleDb.OleDbParameter("SUPCO", System.Data.OleDb.OleDbType.VarChar, 4, "SUPCO"), New System.Data.OleDb.OleDbParameter("SNAMA", System.Data.OleDb.OleDbType.VarChar, 50, "SNAMA"), New System.Data.OleDb.OleDbParameter("BUAT_PO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BUAT_PO", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("ADA_HARGA", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ADA_HARGA", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("QTY", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "QTY", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("ITEM", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("RUPIAH", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("PPN", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "PPN", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("BPB_NO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BPB_NO", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TGL_MULAI", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_MULAI"), New System.Data.OleDb.OleDbParameter("JAM_MULAI", System.Data.OleDb.OleDbType.VarChar, 8, "JAM_MULAI"), New System.Data.OleDb.OleDbParameter("TGL_AKHIR", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_AKHIR"), New System.Data.OleDb.OleDbParameter("JAM_AKHIR", System.Data.OleDb.OleDbType.VarChar, 8, "JAM_AKHIR"), New System.Data.OleDb.OleDbParameter("JML_MOBIL", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "JML_MOBIL", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("TGL_REVISI", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "TGL_REVISI"), New System.Data.OleDb.OleDbParameter("JAM_REVISI", System.Data.OleDb.OleDbType.VarChar, 8, "JAM_REVISI"), New System.Data.OleDb.OleDbParameter("USER_NAME", System.Data.OleDb.OleDbType.VarChar, 15, "USER_NAME"), New System.Data.OleDb.OleDbParameter("MRBREAD", System.Data.OleDb.OleDbType.VarChar, 1, "MRBREAD"), New System.Data.OleDb.OleDbParameter("UPDATE", System.Data.OleDb.OleDbType.DBTimeStamp, 0, "UPDATE"), New System.Data.OleDb.OleDbParameter("SUPID", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "SUPID", System.Data.DataRowVersion.Current, Nothing), New System.Data.OleDb.OleDbParameter("GUDANG_KODE", System.Data.OleDb.OleDbType.VarChar, 8, "GUDANG_KODE"), New System.Data.OleDb.OleDbParameter("LOKASI_KODE", System.Data.OleDb.OleDbType.VarChar, 8, "LOKASI_KODE"), New System.Data.OleDb.OleDbParameter("Original_ID_DAFTARPO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARPO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ADA_HARGA", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ADA_HARGA", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ADA_HARGA1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ADA_HARGA", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_BPB_NO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BPB_NO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_BPB_NO1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BPB_NO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_BUAT_PO", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BUAT_PO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_BUAT_PO1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "BUAT_PO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_GUDANG_KODE", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "GUDANG_KODE", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_GUDANG_KODE1", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "GUDANG_KODE", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ID_DAFTARJALUR", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ID_DAFTARJALUR1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ID_DAFTARJALUR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ITEM", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_ITEM1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "ITEM", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JAM_AKHIR", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JAM_AKHIR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JAM_AKHIR1", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JAM_AKHIR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JAM_MULAI", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JAM_MULAI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JAM_MULAI1", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JAM_MULAI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JAM_REVISI", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JAM_REVISI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JAM_REVISI1", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "JAM_REVISI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JML_MOBIL", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "JML_MOBIL", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_JML_MOBIL1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "JML_MOBIL", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_LOKASI_KODE", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LOKASI_KODE", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_LOKASI_KODE1", System.Data.OleDb.OleDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LOKASI_KODE", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_MRBREAD", System.Data.OleDb.OleDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "MRBREAD", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_MRBREAD1", System.Data.OleDb.OleDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "MRBREAD", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_NOPO", System.Data.OleDb.OleDbType.VarChar, 9, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "NOPO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_NOPO1", System.Data.OleDb.OleDbType.VarChar, 9, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "NOPO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_NO_FAK", System.Data.OleDb.OleDbType.VarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "NO_FAK", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_NO_FAK1", System.Data.OleDb.OleDbType.VarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "NO_FAK", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_PPN", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "PPN", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_PPN1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "PPN", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_QTY", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "QTY", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_QTY1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "QTY", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RECID", System.Data.OleDb.OleDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "RECID", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RECID1", System.Data.OleDb.OleDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "RECID", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RUPIAH", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_RUPIAH1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "RUPIAH", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SNAMA", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SNAMA", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SNAMA1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SNAMA", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SUPCO", System.Data.OleDb.OleDbType.VarChar, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SUPCO", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SUPID", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "SUPID", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_SUPID1", System.Data.OleDb.OleDbType.[Decimal], 0, System.Data.ParameterDirection.Input, False, CType(38, Byte), CType(0, Byte), "SUPID", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TANGGAL", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TANGGAL", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TANGGAL1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TANGGAL", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_AKHIR", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_AKHIR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_AKHIR1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_AKHIR", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_FAK", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_FAK", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_FAK1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_FAK", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_MULAI", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_MULAI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_MULAI1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_MULAI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_REVISI", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_REVISI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_TGL_REVISI1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TGL_REVISI", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_UPDATE", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UPDATE", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_UPDATE1", System.Data.OleDb.OleDbType.DBTimeStamp, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UPDATE", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_USER_NAME", System.Data.OleDb.OleDbType.VarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "USER_NAME", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_USER_NAME1", System.Data.OleDb.OleDbType.VarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "USER_NAME", System.Data.DataRowVersion.Original, Nothing)})
        '
        'btnUpdate
        '
        Me.btnUpdate.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnUpdate.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnUpdate.Location = New System.Drawing.Point(576, 16)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(75, 23)
        Me.btnUpdate.TabIndex = 1
        Me.btnUpdate.Text = "&Update"
        Me.btnUpdate.Visible = False
        '
        'btnCancelAll
        '
        Me.btnCancelAll.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCancelAll.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnCancelAll.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnCancelAll.Location = New System.Drawing.Point(576, 48)
        Me.btnCancelAll.Name = "btnCancelAll"
        Me.btnCancelAll.Size = New System.Drawing.Size(75, 23)
        Me.btnCancelAll.TabIndex = 2
        Me.btnCancelAll.Text = "Ca&ncel All"
        Me.btnCancelAll.Visible = False
        '
        'grpSup
        '
        Me.grpSup.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpSup.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.grpSup.Controls.Add(Me.txtNoAntrianPO)
        Me.grpSup.Controls.Add(Me.Label25)
        Me.grpSup.Controls.Add(Me.BtnPrintStck)
        Me.grpSup.Controls.Add(Me.CmbNama)
        Me.grpSup.Controls.Add(Me.btnPrintUlang)
        Me.grpSup.Controls.Add(Me.btnPrint)
        Me.grpSup.Controls.Add(Me.LBMobil)
        Me.grpSup.Controls.Add(Me.CmbSUPCO)
        Me.grpSup.Controls.Add(Me.btnDraftRetur)
        Me.grpSup.Controls.Add(Me.btnCari)
        Me.grpSup.Controls.Add(Me.lblSUPCO)
        Me.grpSup.Controls.Add(Me.txtTglDaftar)
        Me.grpSup.Controls.Add(Me.txtNoAntrian)
        Me.grpSup.Controls.Add(Me.Label17)
        Me.grpSup.Controls.Add(Me.Label26)
        Me.grpSup.Controls.Add(Me.Label24)
        Me.grpSup.Controls.Add(Me.btnNext)
        Me.grpSup.Controls.Add(Me.btnPrev)
        Me.grpSup.Controls.Add(Me.btnDaftar)
        Me.grpSup.Controls.Add(Me.Label3)
        Me.grpSup.Controls.Add(Me.lblSNAMA)
        Me.grpSup.Controls.Add(Me.Label7)
        Me.grpSup.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpSup.Location = New System.Drawing.Point(7, 6)
        Me.grpSup.Name = "grpSup"
        Me.grpSup.Size = New System.Drawing.Size(678, 110)
        Me.grpSup.TabIndex = 5
        Me.grpSup.TabStop = False
        Me.grpSup.Text = " &Supplier"
        '
        'txtNoAntrianPO
        '
        Me.txtNoAntrianPO.Enabled = False
        Me.txtNoAntrianPO.Location = New System.Drawing.Point(415, 18)
        Me.txtNoAntrianPO.Name = "txtNoAntrianPO"
        Me.txtNoAntrianPO.Size = New System.Drawing.Size(68, 23)
        Me.txtNoAntrianPO.TabIndex = 75
        '
        'Label25
        '
        Me.Label25.BackColor = System.Drawing.Color.Transparent
        Me.Label25.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label25.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label25.Location = New System.Drawing.Point(351, 23)
        Me.Label25.Name = "Label25"
        Me.Label25.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label25.Size = New System.Drawing.Size(95, 19)
        Me.Label25.TabIndex = 76
        Me.Label25.Text = "No. Jalur:"
        '
        'BtnPrintStck
        '
        Me.BtnPrintStck.BackColor = System.Drawing.Color.Transparent
        Me.BtnPrintStck.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnPrintStck.Image = Global.PendaftaranPO.My.Resources.Resources.printer
        Me.BtnPrintStck.Location = New System.Drawing.Point(358, 77)
        Me.BtnPrintStck.Name = "BtnPrintStck"
        Me.BtnPrintStck.Size = New System.Drawing.Size(94, 28)
        Me.BtnPrintStck.TabIndex = 74
        Me.BtnPrintStck.Text = "Print Sticker"
        Me.BtnPrintStck.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnPrintStck.UseVisualStyleBackColor = False
        Me.BtnPrintStck.Visible = False
        '
        'CmbNama
        '
        Me.CmbNama.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbNama.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.CmbNama.FormattingEnabled = True
        Me.CmbNama.Location = New System.Drawing.Point(59, 46)
        Me.CmbNama.Name = "CmbNama"
        Me.CmbNama.Size = New System.Drawing.Size(506, 24)
        Me.CmbNama.TabIndex = 73
        Me.CmbNama.Visible = False
        '
        'btnPrintUlang
        '
        Me.btnPrintUlang.BackColor = System.Drawing.Color.Transparent
        Me.btnPrintUlang.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPrintUlang.Image = Global.PendaftaranPO.My.Resources.Resources.printer
        Me.btnPrintUlang.Location = New System.Drawing.Point(255, 77)
        Me.btnPrintUlang.Name = "btnPrintUlang"
        Me.btnPrintUlang.Size = New System.Drawing.Size(97, 28)
        Me.btnPrintUlang.TabIndex = 72
        Me.btnPrintUlang.Text = "Print No. Urut"
        Me.btnPrintUlang.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnPrintUlang.UseVisualStyleBackColor = False
        Me.btnPrintUlang.Visible = False
        '
        'btnPrint
        '
        Me.btnPrint.BackColor = System.Drawing.Color.Transparent
        Me.btnPrint.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPrint.Image = Global.PendaftaranPO.My.Resources.Resources.printer
        Me.btnPrint.Location = New System.Drawing.Point(166, 77)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.Size = New System.Drawing.Size(77, 28)
        Me.btnPrint.TabIndex = 9
        Me.btnPrint.Text = "Print"
        Me.btnPrint.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnPrint.UseVisualStyleBackColor = False
        '
        'LBMobil
        '
        Me.LBMobil.Enabled = False
        Me.LBMobil.Font = New System.Drawing.Font("Times New Roman", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBMobil.FormattingEnabled = True
        Me.LBMobil.ItemHeight = 17
        Me.LBMobil.Location = New System.Drawing.Point(571, 29)
        Me.LBMobil.Name = "LBMobil"
        Me.LBMobil.Size = New System.Drawing.Size(102, 38)
        Me.LBMobil.TabIndex = 71
        '
        'CmbSUPCO
        '
        Me.CmbSUPCO.Enabled = False
        Me.CmbSUPCO.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.CmbSUPCO.FormattingEnabled = True
        Me.CmbSUPCO.Location = New System.Drawing.Point(59, 21)
        Me.CmbSUPCO.MaxLength = 4
        Me.CmbSUPCO.Name = "CmbSUPCO"
        Me.CmbSUPCO.Size = New System.Drawing.Size(64, 24)
        Me.CmbSUPCO.TabIndex = 69
        Me.CmbSUPCO.Visible = False
        '
        'btnDraftRetur
        '
        Me.btnDraftRetur.BackColor = System.Drawing.Color.Transparent
        Me.btnDraftRetur.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnDraftRetur.Image = Global.PendaftaranPO.My.Resources.Resources.printer
        Me.btnDraftRetur.Location = New System.Drawing.Point(461, 77)
        Me.btnDraftRetur.Name = "btnDraftRetur"
        Me.btnDraftRetur.Size = New System.Drawing.Size(93, 28)
        Me.btnDraftRetur.TabIndex = 6
        Me.btnDraftRetur.Text = "&Draft Retur"
        Me.btnDraftRetur.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnDraftRetur.UseVisualStyleBackColor = False
        Me.btnDraftRetur.Visible = False
        '
        'btnCari
        '
        Me.btnCari.BackColor = System.Drawing.Color.Transparent
        Me.btnCari.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnCari.Image = Global.PendaftaranPO.My.Resources.Resources.zoom
        Me.btnCari.Location = New System.Drawing.Point(84, 76)
        Me.btnCari.Name = "btnCari"
        Me.btnCari.Size = New System.Drawing.Size(78, 28)
        Me.btnCari.TabIndex = 5
        Me.btnCari.Text = "&Cari"
        Me.btnCari.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnCari.UseVisualStyleBackColor = False
        '
        'lblSUPCO
        '
        Me.lblSUPCO.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.SUPCO", True))
        Me.lblSUPCO.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSUPCO.Location = New System.Drawing.Point(56, 26)
        Me.lblSUPCO.Name = "lblSUPCO"
        Me.lblSUPCO.Size = New System.Drawing.Size(58, 15)
        Me.lblSUPCO.TabIndex = 64
        Me.lblSUPCO.Text = "lblSUPCO"
        '
        'DsPO1
        '
        Me.DsPO1.DataSetName = "dsPO"
        Me.DsPO1.Locale = New System.Globalization.CultureInfo("en-US")
        Me.DsPO1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'txtTglDaftar
        '
        Me.txtTglDaftar.CustomFormat = "dd-MM-yyyy"
        Me.txtTglDaftar.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.TANGGAL", True))
        Me.txtTglDaftar.Enabled = False
        Me.txtTglDaftar.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.txtTglDaftar.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.txtTglDaftar.Location = New System.Drawing.Point(153, 21)
        Me.txtTglDaftar.Name = "txtTglDaftar"
        Me.txtTglDaftar.Size = New System.Drawing.Size(95, 23)
        Me.txtTglDaftar.TabIndex = 3
        '
        'txtNoAntrian
        '
        Me.txtNoAntrian.AcceptsReturn = True
        Me.txtNoAntrian.BackColor = System.Drawing.SystemColors.Window
        Me.txtNoAntrian.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtNoAntrian.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.NOURUT", True))
        Me.txtNoAntrian.Enabled = False
        Me.txtNoAntrian.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNoAntrian.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtNoAntrian.Location = New System.Drawing.Point(309, 20)
        Me.txtNoAntrian.Name = "txtNoAntrian"
        Me.txtNoAntrian.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtNoAntrian.Size = New System.Drawing.Size(42, 23)
        Me.txtNoAntrian.TabIndex = 5
        Me.txtNoAntrian.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label17.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label17.Location = New System.Drawing.Point(568, 7)
        Me.Label17.Name = "Label17"
        Me.Label17.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label17.Size = New System.Drawing.Size(78, 19)
        Me.Label17.TabIndex = 0
        Me.Label17.Text = "No. Mobil :"
        '
        'Label26
        '
        Me.Label26.BackColor = System.Drawing.Color.Transparent
        Me.Label26.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label26.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label26.Location = New System.Drawing.Point(122, 24)
        Me.Label26.Name = "Label26"
        Me.Label26.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label26.Size = New System.Drawing.Size(80, 19)
        Me.Label26.TabIndex = 2
        Me.Label26.Text = "Tgl:"
        '
        'Label24
        '
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label24.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label24.Location = New System.Drawing.Point(249, 23)
        Me.Label24.Name = "Label24"
        Me.Label24.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label24.Size = New System.Drawing.Size(95, 19)
        Me.Label24.TabIndex = 4
        Me.Label24.Text = "No. Urut:"
        '
        'btnNext
        '
        Me.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnNext.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnNext.Location = New System.Drawing.Point(528, 17)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(38, 23)
        Me.btnNext.TabIndex = 8
        Me.btnNext.Text = ">>"
        '
        'btnPrev
        '
        Me.btnPrev.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnPrev.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnPrev.Location = New System.Drawing.Point(489, 17)
        Me.btnPrev.Name = "btnPrev"
        Me.btnPrev.Size = New System.Drawing.Size(38, 23)
        Me.btnPrev.TabIndex = 7
        Me.btnPrev.Text = "<<"
        '
        'btnDaftar
        '
        Me.btnDaftar.BackColor = System.Drawing.Color.Transparent
        Me.btnDaftar.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnDaftar.Image = Global.PendaftaranPO.My.Resources.Resources.book_open
        Me.btnDaftar.Location = New System.Drawing.Point(10, 77)
        Me.btnDaftar.Name = "btnDaftar"
        Me.btnDaftar.Size = New System.Drawing.Size(72, 28)
        Me.btnDaftar.TabIndex = 0
        Me.btnDaftar.Text = "&Daftar"
        Me.btnDaftar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnDaftar.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(7, 26)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(60, 18)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Kode  :"
        '
        'lblSNAMA
        '
        Me.lblSNAMA.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.SNAMA", True))
        Me.lblSNAMA.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSNAMA.Location = New System.Drawing.Point(56, 50)
        Me.lblSNAMA.Name = "lblSNAMA"
        Me.lblSNAMA.Size = New System.Drawing.Size(327, 15)
        Me.lblSNAMA.TabIndex = 65
        Me.lblSNAMA.Text = "lblSNAMA"
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label7.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.Location = New System.Drawing.Point(5, 50)
        Me.Label7.Name = "Label7"
        Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label7.Size = New System.Drawing.Size(60, 20)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Nama  :"
        '
        'grpHidden
        '
        Me.grpHidden.Controls.Add(Me.lblTglRevisi)
        Me.grpHidden.Controls.Add(Me.lblSUPID)
        Me.grpHidden.Controls.Add(Me.lblLokasiKode)
        Me.grpHidden.Controls.Add(Me.lblGudangKode)
        Me.grpHidden.Location = New System.Drawing.Point(466, 535)
        Me.grpHidden.Name = "grpHidden"
        Me.grpHidden.Size = New System.Drawing.Size(200, 14)
        Me.grpHidden.TabIndex = 18
        Me.grpHidden.TabStop = False
        '
        'lblTglRevisi
        '
        Me.lblTglRevisi.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.TGL_REVISI", True))
        Me.lblTglRevisi.Location = New System.Drawing.Point(22, 92)
        Me.lblTglRevisi.Name = "lblTglRevisi"
        Me.lblTglRevisi.Size = New System.Drawing.Size(100, 16)
        Me.lblTglRevisi.TabIndex = 23
        Me.lblTglRevisi.Text = "lblTglRevisi"
        '
        'lblSUPID
        '
        Me.lblSUPID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.SUPID", True))
        Me.lblSUPID.Location = New System.Drawing.Point(20, 63)
        Me.lblSUPID.Name = "lblSUPID"
        Me.lblSUPID.Size = New System.Drawing.Size(100, 16)
        Me.lblSUPID.TabIndex = 22
        Me.lblSUPID.Text = "lblSUPID"
        '
        'lblLokasiKode
        '
        Me.lblLokasiKode.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.LOKASI_KODE", True))
        Me.lblLokasiKode.Location = New System.Drawing.Point(20, 39)
        Me.lblLokasiKode.Name = "lblLokasiKode"
        Me.lblLokasiKode.Size = New System.Drawing.Size(100, 16)
        Me.lblLokasiKode.TabIndex = 17
        Me.lblLokasiKode.Text = "LokasiKode"
        '
        'lblGudangKode
        '
        Me.lblGudangKode.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.GUDANG_KODE", True))
        Me.lblGudangKode.Location = New System.Drawing.Point(20, 15)
        Me.lblGudangKode.Name = "lblGudangKode"
        Me.lblGudangKode.Size = New System.Drawing.Size(100, 16)
        Me.lblGudangKode.TabIndex = 16
        Me.lblGudangKode.Text = "GudangKode"
        '
        'btnTambahPO
        '
        Me.btnTambahPO.BackColor = System.Drawing.Color.Transparent
        Me.btnTambahPO.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnTambahPO.Image = Global.PendaftaranPO.My.Resources.Resources.add
        Me.btnTambahPO.Location = New System.Drawing.Point(13, 12)
        Me.btnTambahPO.Name = "btnTambahPO"
        Me.btnTambahPO.Size = New System.Drawing.Size(87, 56)
        Me.btnTambahPO.TabIndex = 0
        Me.btnTambahPO.Text = "&Tambah PO"
        Me.btnTambahPO.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnTambahPO.UseVisualStyleBackColor = False
        '
        'grpDaftar
        '
        Me.grpDaftar.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpDaftar.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.grpDaftar.Controls.Add(Me.Frame4)
        Me.grpDaftar.Controls.Add(Me.Frame1)
        Me.grpDaftar.Controls.Add(Me.Frame2)
        Me.grpDaftar.Controls.Add(Me.Frame3)
        Me.grpDaftar.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpDaftar.Location = New System.Drawing.Point(7, 122)
        Me.grpDaftar.Name = "grpDaftar"
        Me.grpDaftar.Size = New System.Drawing.Size(678, 359)
        Me.grpDaftar.TabIndex = 5
        Me.grpDaftar.TabStop = False
        Me.grpDaftar.Text = " &Daftar PO"
        '
        'Frame4
        '
        Me.Frame4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Frame4.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.Frame4.Controls.Add(Me.lblBPB_NO)
        Me.Frame4.Controls.Add(Me.Label16)
        Me.Frame4.Controls.Add(Me.Label15)
        Me.Frame4.Controls.Add(Me.Label14)
        Me.Frame4.Controls.Add(Me.lblStatus)
        Me.Frame4.Controls.Add(Me.lblStatusKeterangan)
        Me.Frame4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame4.Location = New System.Drawing.Point(8, 16)
        Me.Frame4.Name = "Frame4"
        Me.Frame4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame4.Size = New System.Drawing.Size(660, 33)
        Me.Frame4.TabIndex = 0
        Me.Frame4.TabStop = False
        '
        'lblBPB_NO
        '
        Me.lblBPB_NO.BackColor = System.Drawing.Color.Transparent
        Me.lblBPB_NO.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblBPB_NO.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.BPB_NO", True))
        Me.lblBPB_NO.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBPB_NO.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblBPB_NO.Location = New System.Drawing.Point(366, 14)
        Me.lblBPB_NO.Name = "lblBPB_NO"
        Me.lblBPB_NO.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblBPB_NO.Size = New System.Drawing.Size(167, 15)
        Me.lblBPB_NO.TabIndex = 47
        Me.lblBPB_NO.Text = "lblBPB_NO"
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label16.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label16.Location = New System.Drawing.Point(290, 14)
        Me.Label16.Name = "Label16"
        Me.Label16.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label16.Size = New System.Drawing.Size(70, 15)
        Me.Label16.TabIndex = 46
        Me.Label16.Text = "No. BPB :"
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label15.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label15.Location = New System.Drawing.Point(86, 13)
        Me.Label15.Name = "Label15"
        Me.Label15.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label15.Size = New System.Drawing.Size(3, 15)
        Me.Label15.TabIndex = 45
        Me.Label15.Text = "-"
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label14.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label14.Location = New System.Drawing.Point(10, 13)
        Me.Label14.Name = "Label14"
        Me.Label14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label14.Size = New System.Drawing.Size(78, 15)
        Me.Label14.TabIndex = 44
        Me.Label14.Text = "STATUS :"
        '
        'lblStatus
        '
        Me.lblStatus.BackColor = System.Drawing.Color.Transparent
        Me.lblStatus.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblStatus.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.RECID", True))
        Me.lblStatus.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblStatus.Location = New System.Drawing.Point(89, 13)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblStatus.Size = New System.Drawing.Size(15, 15)
        Me.lblStatus.TabIndex = 43
        Me.lblStatus.Text = "lblStatus"
        '
        'lblStatusKeterangan
        '
        Me.lblStatusKeterangan.BackColor = System.Drawing.Color.Transparent
        Me.lblStatusKeterangan.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblStatusKeterangan.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.Status", True))
        Me.lblStatusKeterangan.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatusKeterangan.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblStatusKeterangan.Location = New System.Drawing.Point(110, 13)
        Me.lblStatusKeterangan.Name = "lblStatusKeterangan"
        Me.lblStatusKeterangan.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblStatusKeterangan.Size = New System.Drawing.Size(167, 15)
        Me.lblStatusKeterangan.TabIndex = 42
        Me.lblStatusKeterangan.Text = "lblStatus"
        '
        'Frame1
        '
        Me.Frame1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Frame1.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.Frame1.Controls.Add(Me.Label9)
        Me.Frame1.Controls.Add(Me.txtTgl_PO)
        Me.Frame1.Controls.Add(Me.txtNo_PO)
        Me.Frame1.Controls.Add(Me.txtPO_QTY)
        Me.Frame1.Controls.Add(Me.txtPO_GROSS)
        Me.Frame1.Controls.Add(Me.txtPO_PPN)
        Me.Frame1.Controls.Add(Me.txtPO_Total)
        Me.Frame1.Controls.Add(Me.chkBUAT_PO)
        Me.Frame1.Controls.Add(Me.chkADA_HARGA)
        Me.Frame1.Controls.Add(Me.txtTot_Item)
        Me.Frame1.Controls.Add(Me.Label1)
        Me.Frame1.Controls.Add(Me.Label2)
        Me.Frame1.Controls.Add(Me.Label10)
        Me.Frame1.Controls.Add(Me.Label11)
        Me.Frame1.Controls.Add(Me.Label12)
        Me.Frame1.Controls.Add(Me.Label13)
        Me.Frame1.Controls.Add(Me.Label8)
        Me.Frame1.Controls.Add(Me.Label4)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(8, 112)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(660, 136)
        Me.Frame1.TabIndex = 2
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "Dengan PO."
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label9.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.Location = New System.Drawing.Point(153, 99)
        Me.Label9.Name = "Label9"
        Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label9.Size = New System.Drawing.Size(47, 18)
        Me.Label9.TabIndex = 10
        Me.Label9.Text = "Harga"
        '
        'txtTgl_PO
        '
        Me.txtTgl_PO.AcceptsReturn = True
        Me.txtTgl_PO.BackColor = System.Drawing.SystemColors.Window
        Me.txtTgl_PO.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTgl_PO.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.TANGGAL", True))
        Me.txtTgl_PO.Enabled = False
        Me.txtTgl_PO.FieldType = PendaftaranPO.FlexMaskEditBox._FieldType.DATE_
        Me.txtTgl_PO.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.txtTgl_PO.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTgl_PO.Location = New System.Drawing.Point(98, 41)
        Me.txtTgl_PO.Name = "txtTgl_PO"
        Me.txtTgl_PO.SetFormatString = "dd-MM-yyyy"
        Me.txtTgl_PO.Size = New System.Drawing.Size(72, 23)
        Me.txtTgl_PO.TabIndex = 3
        '
        'txtNo_PO
        '
        Me.txtNo_PO.AcceptsReturn = True
        Me.txtNo_PO.BackColor = System.Drawing.SystemColors.Window
        Me.txtNo_PO.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtNo_PO.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtNo_PO.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.NOPO", True))
        Me.txtNo_PO.Enabled = False
        Me.txtNo_PO.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.txtNo_PO.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtNo_PO.Location = New System.Drawing.Point(98, 15)
        Me.txtNo_PO.MaxLength = 9
        Me.txtNo_PO.Name = "txtNo_PO"
        Me.txtNo_PO.Size = New System.Drawing.Size(84, 23)
        Me.txtNo_PO.TabIndex = 1
        Me.txtNo_PO.Tag = "1"
        '
        'txtPO_QTY
        '
        Me.txtPO_QTY.AcceptsReturn = True
        Me.txtPO_QTY.BackColor = System.Drawing.SystemColors.Window
        Me.txtPO_QTY.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPO_QTY.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.QTY", True))
        Me.txtPO_QTY.Enabled = False
        Me.txtPO_QTY.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.txtPO_QTY.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPO_QTY.Location = New System.Drawing.Point(467, 17)
        Me.txtPO_QTY.Name = "txtPO_QTY"
        Me.txtPO_QTY.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtPO_QTY.Size = New System.Drawing.Size(119, 23)
        Me.txtPO_QTY.TabIndex = 15
        Me.txtPO_QTY.Tag = "1"
        Me.txtPO_QTY.Text = "123"
        Me.txtPO_QTY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtPO_GROSS
        '
        Me.txtPO_GROSS.AcceptsReturn = True
        Me.txtPO_GROSS.BackColor = System.Drawing.SystemColors.Window
        Me.txtPO_GROSS.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPO_GROSS.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.RUPIAH", True))
        Me.txtPO_GROSS.Enabled = False
        Me.txtPO_GROSS.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.txtPO_GROSS.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPO_GROSS.Location = New System.Drawing.Point(467, 45)
        Me.txtPO_GROSS.Name = "txtPO_GROSS"
        Me.txtPO_GROSS.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtPO_GROSS.Size = New System.Drawing.Size(148, 23)
        Me.txtPO_GROSS.TabIndex = 17
        Me.txtPO_GROSS.Tag = "1"
        Me.txtPO_GROSS.Text = "123"
        Me.txtPO_GROSS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtPO_PPN
        '
        Me.txtPO_PPN.AcceptsReturn = True
        Me.txtPO_PPN.BackColor = System.Drawing.SystemColors.Window
        Me.txtPO_PPN.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPO_PPN.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.PPN", True))
        Me.txtPO_PPN.Enabled = False
        Me.txtPO_PPN.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.txtPO_PPN.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPO_PPN.Location = New System.Drawing.Point(467, 73)
        Me.txtPO_PPN.Name = "txtPO_PPN"
        Me.txtPO_PPN.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtPO_PPN.Size = New System.Drawing.Size(148, 23)
        Me.txtPO_PPN.TabIndex = 19
        Me.txtPO_PPN.Tag = "1"
        Me.txtPO_PPN.Text = "123"
        Me.txtPO_PPN.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtPO_Total
        '
        Me.txtPO_Total.AcceptsReturn = True
        Me.txtPO_Total.BackColor = System.Drawing.SystemColors.Window
        Me.txtPO_Total.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPO_Total.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.Total", True))
        Me.txtPO_Total.Enabled = False
        Me.txtPO_Total.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.txtPO_Total.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPO_Total.Location = New System.Drawing.Point(467, 101)
        Me.txtPO_Total.Name = "txtPO_Total"
        Me.txtPO_Total.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtPO_Total.Size = New System.Drawing.Size(150, 23)
        Me.txtPO_Total.TabIndex = 21
        Me.txtPO_Total.Text = "123"
        Me.txtPO_Total.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'chkBUAT_PO
        '
        Me.chkBUAT_PO.BackColor = System.Drawing.Color.Transparent
        Me.chkBUAT_PO.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkBUAT_PO.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.BUAT_PO", True))
        Me.chkBUAT_PO.Enabled = False
        Me.chkBUAT_PO.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkBUAT_PO.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkBUAT_PO.Location = New System.Drawing.Point(98, 100)
        Me.chkBUAT_PO.Name = "chkBUAT_PO"
        Me.chkBUAT_PO.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkBUAT_PO.Size = New System.Drawing.Size(48, 17)
        Me.chkBUAT_PO.TabIndex = 9
        Me.chkBUAT_PO.UseVisualStyleBackColor = False
        '
        'chkADA_HARGA
        '
        Me.chkADA_HARGA.BackColor = System.Drawing.Color.Transparent
        Me.chkADA_HARGA.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkADA_HARGA.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.ADA_HARGA", True))
        Me.chkADA_HARGA.Enabled = False
        Me.chkADA_HARGA.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkADA_HARGA.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkADA_HARGA.Location = New System.Drawing.Point(202, 99)
        Me.chkADA_HARGA.Name = "chkADA_HARGA"
        Me.chkADA_HARGA.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkADA_HARGA.Size = New System.Drawing.Size(58, 18)
        Me.chkADA_HARGA.TabIndex = 11
        Me.chkADA_HARGA.UseVisualStyleBackColor = False
        '
        'txtTot_Item
        '
        Me.txtTot_Item.AcceptsReturn = True
        Me.txtTot_Item.BackColor = System.Drawing.SystemColors.Window
        Me.txtTot_Item.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTot_Item.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.ITEMnya", True))
        Me.txtTot_Item.Enabled = False
        Me.txtTot_Item.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.txtTot_Item.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTot_Item.Location = New System.Drawing.Point(97, 68)
        Me.txtTot_Item.Name = "txtTot_Item"
        Me.txtTot_Item.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTot_Item.Size = New System.Drawing.Size(45, 23)
        Me.txtTot_Item.TabIndex = 13
        Me.txtTot_Item.Tag = "1"
        Me.txtTot_Item.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(7, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(81, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Nomor "
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(6, 44)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(81, 20)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Tanggal"
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label10.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label10.Location = New System.Drawing.Point(394, 23)
        Me.Label10.Name = "Label10"
        Me.Label10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label10.Size = New System.Drawing.Size(81, 15)
        Me.Label10.TabIndex = 14
        Me.Label10.Text = "Qty."
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label11.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label11.Location = New System.Drawing.Point(394, 48)
        Me.Label11.Name = "Label11"
        Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label11.Size = New System.Drawing.Size(81, 15)
        Me.Label11.TabIndex = 16
        Me.Label11.Text = "Gross."
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label12.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label12.Location = New System.Drawing.Point(394, 76)
        Me.Label12.Name = "Label12"
        Me.Label12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label12.Size = New System.Drawing.Size(81, 15)
        Me.Label12.TabIndex = 18
        Me.Label12.Text = "Ppn."
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label13.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label13.Location = New System.Drawing.Point(394, 104)
        Me.Label13.Name = "Label13"
        Me.Label13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label13.Size = New System.Drawing.Size(81, 15)
        Me.Label13.TabIndex = 20
        Me.Label13.Text = "Total"
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label8.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(6, 99)
        Me.Label8.Name = "Label8"
        Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label8.Size = New System.Drawing.Size(86, 17)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "Dengan PO."
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(7, 73)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(43, 15)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Item "
        '
        'Frame2
        '
        Me.Frame2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Frame2.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.Frame2.Controls.Add(Me.txtTglFaktur)
        Me.Frame2.Controls.Add(Me.txtNoFak)
        Me.Frame2.Controls.Add(Me.Label5)
        Me.Frame2.Controls.Add(Me.Label6)
        Me.Frame2.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame2.Location = New System.Drawing.Point(8, 55)
        Me.Frame2.Name = "Frame2"
        Me.Frame2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame2.Size = New System.Drawing.Size(660, 46)
        Me.Frame2.TabIndex = 1
        Me.Frame2.TabStop = False
        Me.Frame2.Text = " &FAKTUR "
        '
        'txtTglFaktur
        '
        Me.txtTglFaktur.BackColor = System.Drawing.SystemColors.Window
        Me.txtTglFaktur.CustomFormat = "dd-MM-yyyy"
        Me.txtTglFaktur.Enabled = False
        Me.txtTglFaktur.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTglFaktur.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTglFaktur.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.txtTglFaktur.Location = New System.Drawing.Point(279, 15)
        Me.txtTglFaktur.Name = "txtTglFaktur"
        Me.txtTglFaktur.Size = New System.Drawing.Size(95, 23)
        Me.txtTglFaktur.TabIndex = 62
        '
        'txtNoFak
        '
        Me.txtNoFak.AcceptsReturn = True
        Me.txtNoFak.BackColor = System.Drawing.SystemColors.Window
        Me.txtNoFak.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtNoFak.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtNoFak.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.NO_FAK", True))
        Me.txtNoFak.Enabled = False
        Me.txtNoFak.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNoFak.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtNoFak.Location = New System.Drawing.Point(69, 16)
        Me.txtNoFak.MaxLength = 7
        Me.txtNoFak.Name = "txtNoFak"
        Me.txtNoFak.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtNoFak.Size = New System.Drawing.Size(81, 23)
        Me.txtNoFak.TabIndex = 1
        Me.txtNoFak.Tag = "1"
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label5.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(192, 20)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(81, 19)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Tanggal"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label6.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(11, 20)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(81, 15)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Nomor "
        '
        'Frame3
        '
        Me.Frame3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Frame3.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.Frame3.Controls.Add(Me.btnUpdate)
        Me.Frame3.Controls.Add(Me.btnCancelAll)
        Me.Frame3.Controls.Add(Me.txtSupID)
        Me.Frame3.Controls.Add(Me.txtLokasiKode)
        Me.Frame3.Controls.Add(Me.txtGudangkode)
        Me.Frame3.Controls.Add(Me.txtUPDATE)
        Me.Frame3.Controls.Add(Me.txtTGL_AKHIR)
        Me.Frame3.Controls.Add(Me.txtTGL_MULAI)
        Me.Frame3.Controls.Add(Me.Label18)
        Me.Frame3.Controls.Add(Me.Label19)
        Me.Frame3.Controls.Add(Me.Label20)
        Me.Frame3.Controls.Add(Me.Label21)
        Me.Frame3.Controls.Add(Me.Label22)
        Me.Frame3.Controls.Add(Me.Label23)
        Me.Frame3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame3.Location = New System.Drawing.Point(8, 254)
        Me.Frame3.Name = "Frame3"
        Me.Frame3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame3.Size = New System.Drawing.Size(660, 96)
        Me.Frame3.TabIndex = 3
        Me.Frame3.TabStop = False
        Me.Frame3.Text = " &DAFTAR "
        '
        'txtSupID
        '
        Me.txtSupID.AcceptsReturn = True
        Me.txtSupID.BackColor = System.Drawing.SystemColors.Window
        Me.txtSupID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSupID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.SUPID", True))
        Me.txtSupID.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSupID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSupID.Location = New System.Drawing.Point(328, 63)
        Me.txtSupID.Name = "txtSupID"
        Me.txtSupID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSupID.Size = New System.Drawing.Size(100, 23)
        Me.txtSupID.TabIndex = 15
        Me.txtSupID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtSupID.Visible = False
        '
        'txtLokasiKode
        '
        Me.txtLokasiKode.AcceptsReturn = True
        Me.txtLokasiKode.BackColor = System.Drawing.SystemColors.Window
        Me.txtLokasiKode.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtLokasiKode.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.LOKASI_KODE", True))
        Me.txtLokasiKode.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLokasiKode.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtLokasiKode.Location = New System.Drawing.Point(328, 38)
        Me.txtLokasiKode.Name = "txtLokasiKode"
        Me.txtLokasiKode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtLokasiKode.Size = New System.Drawing.Size(100, 23)
        Me.txtLokasiKode.TabIndex = 11
        Me.txtLokasiKode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtLokasiKode.Visible = False
        '
        'txtGudangkode
        '
        Me.txtGudangkode.AcceptsReturn = True
        Me.txtGudangkode.BackColor = System.Drawing.SystemColors.Window
        Me.txtGudangkode.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtGudangkode.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.GUDANG_KODE", True))
        Me.txtGudangkode.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGudangkode.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtGudangkode.Location = New System.Drawing.Point(328, 13)
        Me.txtGudangkode.Name = "txtGudangkode"
        Me.txtGudangkode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtGudangkode.Size = New System.Drawing.Size(100, 23)
        Me.txtGudangkode.TabIndex = 7
        Me.txtGudangkode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtGudangkode.Visible = False
        '
        'txtUPDATE
        '
        Me.txtUPDATE.AcceptsReturn = True
        Me.txtUPDATE.BackColor = System.Drawing.SystemColors.Window
        Me.txtUPDATE.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtUPDATE.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.UPDATE", True))
        Me.txtUPDATE.Enabled = False
        Me.txtUPDATE.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUPDATE.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtUPDATE.Location = New System.Drawing.Point(96, 65)
        Me.txtUPDATE.Name = "txtUPDATE"
        Me.txtUPDATE.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtUPDATE.Size = New System.Drawing.Size(100, 23)
        Me.txtUPDATE.TabIndex = 13
        Me.txtUPDATE.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtTGL_AKHIR
        '
        Me.txtTGL_AKHIR.AcceptsReturn = True
        Me.txtTGL_AKHIR.BackColor = System.Drawing.SystemColors.Window
        Me.txtTGL_AKHIR.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTGL_AKHIR.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.TGL_AKHIR", True))
        Me.txtTGL_AKHIR.Enabled = False
        Me.txtTGL_AKHIR.FieldType = PendaftaranPO.FlexMaskEditBox._FieldType.DATE_
        Me.txtTGL_AKHIR.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTGL_AKHIR.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTGL_AKHIR.Location = New System.Drawing.Point(96, 41)
        Me.txtTGL_AKHIR.Name = "txtTGL_AKHIR"
        Me.txtTGL_AKHIR.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTGL_AKHIR.SetFormatString = "dd-MM-yyyy HH:mm"
        Me.txtTGL_AKHIR.Size = New System.Drawing.Size(112, 23)
        Me.txtTGL_AKHIR.TabIndex = 9
        Me.txtTGL_AKHIR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtTGL_MULAI
        '
        Me.txtTGL_MULAI.BackColor = System.Drawing.SystemColors.Window
        Me.txtTGL_MULAI.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTGL_MULAI.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.TGL_MULAI", True))
        Me.txtTGL_MULAI.Enabled = False
        Me.txtTGL_MULAI.FieldType = PendaftaranPO.FlexMaskEditBox._FieldType.DATE_
        Me.txtTGL_MULAI.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTGL_MULAI.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTGL_MULAI.Location = New System.Drawing.Point(96, 16)
        Me.txtTGL_MULAI.Name = "txtTGL_MULAI"
        Me.txtTGL_MULAI.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTGL_MULAI.SetFormatString = "dd-MM-yyyy HH:mm"
        Me.txtTGL_MULAI.Size = New System.Drawing.Size(112, 23)
        Me.txtTGL_MULAI.TabIndex = 1
        Me.txtTGL_MULAI.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label18.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label18.Location = New System.Drawing.Point(248, 66)
        Me.Label18.Name = "Label18"
        Me.Label18.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label18.Size = New System.Drawing.Size(81, 15)
        Me.Label18.TabIndex = 14
        Me.Label18.Text = "Lamanya"
        Me.Label18.Visible = False
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label19.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label19.Location = New System.Drawing.Point(248, 42)
        Me.Label19.Name = "Label19"
        Me.Label19.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label19.Size = New System.Drawing.Size(81, 15)
        Me.Label19.TabIndex = 10
        Me.Label19.Text = "Jam BPB"
        Me.Label19.Visible = False
        '
        'Label20
        '
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label20.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label20.Location = New System.Drawing.Point(248, 16)
        Me.Label20.Name = "Label20"
        Me.Label20.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label20.Size = New System.Drawing.Size(81, 15)
        Me.Label20.TabIndex = 6
        Me.Label20.Text = "Jam Daftar"
        Me.Label20.Visible = False
        '
        'Label21
        '
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label21.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label21.Location = New System.Drawing.Point(7, 68)
        Me.Label21.Name = "Label21"
        Me.Label21.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label21.Size = New System.Drawing.Size(81, 15)
        Me.Label21.TabIndex = 12
        Me.Label21.Text = "Update."
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label22.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label22.Location = New System.Drawing.Point(6, 44)
        Me.Label22.Name = "Label22"
        Me.Label22.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label22.Size = New System.Drawing.Size(81, 21)
        Me.Label22.TabIndex = 8
        Me.Label22.Text = "Tgl. BPB"
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.Color.Transparent
        Me.Label23.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label23.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label23.Location = New System.Drawing.Point(6, 19)
        Me.Label23.Name = "Label23"
        Me.Label23.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label23.Size = New System.Drawing.Size(81, 19)
        Me.Label23.TabIndex = 0
        Me.Label23.Text = "Tgl. Daftar"
        '
        'lblIdDaftarPO
        '
        Me.lblIdDaftarPO.AutoSize = True
        Me.lblIdDaftarPO.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO.ID_DAFTARPO", True))
        Me.lblIdDaftarPO.Location = New System.Drawing.Point(20, 176)
        Me.lblIdDaftarPO.Name = "lblIdDaftarPO"
        Me.lblIdDaftarPO.Size = New System.Drawing.Size(45, 13)
        Me.lblIdDaftarPO.TabIndex = 63
        Me.lblIdDaftarPO.Text = "Label25"
        '
        'cmbFilter
        '
        Me.cmbFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbFilter.Items.AddRange(New Object() {"Hari ini", "Tahun ini"})
        Me.cmbFilter.Location = New System.Drawing.Point(445, 30)
        Me.cmbFilter.Name = "cmbFilter"
        Me.cmbFilter.Size = New System.Drawing.Size(121, 21)
        Me.cmbFilter.TabIndex = 8
        '
        'btnHapusPO
        '
        Me.btnHapusPO.BackColor = System.Drawing.Color.Transparent
        Me.btnHapusPO.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnHapusPO.Image = Global.PendaftaranPO.My.Resources.Resources.delete
        Me.btnHapusPO.Location = New System.Drawing.Point(101, 12)
        Me.btnHapusPO.Name = "btnHapusPO"
        Me.btnHapusPO.Size = New System.Drawing.Size(88, 28)
        Me.btnHapusPO.TabIndex = 1
        Me.btnHapusPO.Text = "&Hapus PO"
        Me.btnHapusPO.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnHapusPO.UseVisualStyleBackColor = False
        '
        'btnEditPO
        '
        Me.btnEditPO.BackColor = System.Drawing.Color.Transparent
        Me.btnEditPO.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnEditPO.Image = Global.PendaftaranPO.My.Resources.Resources.pencil
        Me.btnEditPO.Location = New System.Drawing.Point(101, 40)
        Me.btnEditPO.Name = "btnEditPO"
        Me.btnEditPO.Size = New System.Drawing.Size(88, 28)
        Me.btnEditPO.TabIndex = 2
        Me.btnEditPO.Text = "&Edit PO"
        Me.btnEditPO.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnEditPO.UseVisualStyleBackColor = False
        '
        'btnNext2
        '
        Me.btnNext2.BackColor = System.Drawing.Color.Transparent
        Me.btnNext2.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnNext2.Image = Global.PendaftaranPO.My.Resources.Resources.go
        Me.btnNext2.Location = New System.Drawing.Point(357, 12)
        Me.btnNext2.Name = "btnNext2"
        Me.btnNext2.Size = New System.Drawing.Size(75, 56)
        Me.btnNext2.TabIndex = 6
        Me.btnNext2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnNext2.UseVisualStyleBackColor = False
        '
        'btnPrev2
        '
        Me.btnPrev2.BackColor = System.Drawing.Color.Transparent
        Me.btnPrev2.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnPrev2.Image = Global.PendaftaranPO.My.Resources.Resources.back
        Me.btnPrev2.Location = New System.Drawing.Point(276, 12)
        Me.btnPrev2.Name = "btnPrev2"
        Me.btnPrev2.Size = New System.Drawing.Size(75, 56)
        Me.btnPrev2.TabIndex = 5
        Me.btnPrev2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnPrev2.UseVisualStyleBackColor = False
        '
        'btnBatalPO
        '
        Me.btnBatalPO.BackColor = System.Drawing.Color.Transparent
        Me.btnBatalPO.Enabled = False
        Me.btnBatalPO.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnBatalPO.Image = Global.PendaftaranPO.My.Resources.Resources.arrow_undo
        Me.btnBatalPO.Location = New System.Drawing.Point(195, 40)
        Me.btnBatalPO.Name = "btnBatalPO"
        Me.btnBatalPO.Size = New System.Drawing.Size(75, 28)
        Me.btnBatalPO.TabIndex = 4
        Me.btnBatalPO.Text = "&Batal"
        Me.btnBatalPO.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnBatalPO.UseVisualStyleBackColor = False
        '
        'btnSimpanPO
        '
        Me.btnSimpanPO.BackColor = System.Drawing.Color.Transparent
        Me.btnSimpanPO.Enabled = False
        Me.btnSimpanPO.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnSimpanPO.Image = Global.PendaftaranPO.My.Resources.Resources.disk
        Me.btnSimpanPO.Location = New System.Drawing.Point(195, 12)
        Me.btnSimpanPO.Name = "btnSimpanPO"
        Me.btnSimpanPO.Size = New System.Drawing.Size(75, 28)
        Me.btnSimpanPO.TabIndex = 3
        Me.btnSimpanPO.Text = "&Load"
        Me.btnSimpanPO.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnSimpanPO.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.GroupBox1.Controls.Add(Me.btnKeluar)
        Me.GroupBox1.Controls.Add(Me.cmbFilter)
        Me.GroupBox1.Controls.Add(Me.btnSimpanPO)
        Me.GroupBox1.Controls.Add(Me.btnHapusPO)
        Me.GroupBox1.Controls.Add(Me.btnEditPO)
        Me.GroupBox1.Controls.Add(Me.btnNext2)
        Me.GroupBox1.Controls.Add(Me.btnPrev2)
        Me.GroupBox1.Controls.Add(Me.btnTambahPO)
        Me.GroupBox1.Controls.Add(Me.btnBatalPO)
        Me.GroupBox1.Location = New System.Drawing.Point(7, 487)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(678, 76)
        Me.GroupBox1.TabIndex = 15
        Me.GroupBox1.TabStop = False
        '
        'btnKeluar
        '
        Me.btnKeluar.BackColor = System.Drawing.Color.Transparent
        Me.btnKeluar.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btnKeluar.Image = Global.PendaftaranPO.My.Resources.Resources.cross
        Me.btnKeluar.Location = New System.Drawing.Point(593, 12)
        Me.btnKeluar.Name = "btnKeluar"
        Me.btnKeluar.Size = New System.Drawing.Size(75, 56)
        Me.btnKeluar.TabIndex = 7
        Me.btnKeluar.Text = "&Keluar"
        Me.btnKeluar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnKeluar.UseVisualStyleBackColor = False
        '
        'frmDaftarPO
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.ClientSize = New System.Drawing.Size(690, 575)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.grpSup)
        Me.Controls.Add(Me.grpDaftar)
        Me.Controls.Add(Me.lblIdDaftarPO)
        Me.Controls.Add(Me.grpHidden)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(698, 590)
        Me.Name = "frmDaftarPO"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.grpSup.ResumeLayout(False)
        Me.grpSup.PerformLayout()
        CType(Me.DsPO1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpHidden.ResumeLayout(False)
        Me.grpDaftar.ResumeLayout(False)
        Me.Frame4.ResumeLayout(False)
        Me.Frame1.ResumeLayout(False)
        Me.Frame1.PerformLayout()
        Me.Frame2.ResumeLayout(False)
        Me.Frame2.PerformLayout()
        Me.Frame3.ResumeLayout(False)
        Me.Frame3.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    Private SqlMobil As String, WhrMobil As String
    Private SqlDaftar As String, WhrDaftar As String
    Private ds As New DataSet
    Private dsSupp As New DataSet
    Private PO As Boolean
    Private vb As New vb
    Public Pointer As Integer
    Public sNoPo, CancelLoad As String

    Private Sub frmDaftarPO_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        olcon.ConnectionString = ConStrORA
        Me.Text = "Form Pendaftaran - [" & Application.ProductName & " v" & Application.ProductVersion & " - " & USER_DATA(3) & "]"
        'AddHandler dsPo1.DC_JLR_DAFTARPO_T.ColumnChanging, AddressOf HandleColomPO
        'AddHandler dsPo1.DC_JLR_DAFTARPO_T.RowChanging, AddressOf HandleRowPo

        'SetTombol(True)
        For Each Tx As Control In Me.Controls
            If Tx.GetType Is GetType(GroupBox) Then

                For Each Tx2 As Control In Tx.Controls
                    If Tx2.GetType Is GetType(GroupBox) Then
                        For Each Tx3 As Control In Tx2.Controls
                            If Tx3.Tag = "1" Then
                                AddHandler Tx3.KeyDown, AddressOf txt_Keydown
                                AddHandler Tx3.Enter, AddressOf BlockAll
                            End If
                        Next
                    Else
                        If Tx2.Tag = "1" Then
                            AddHandler Tx2.KeyDown, AddressOf txt_Keydown
                            AddHandler Tx2.Enter, AddressOf BlockAll
                        End If
                    End If
                Next

            End If
        Next
        ''load
        'Dim Scon As New OleDb.OleDbConnection(ConStrORA)
        'Dim sdap As New OleDb.OleDbDataAdapter("Select * from dc_jlr_daftarjalur_t", Scon)
        'Scon.Open()
        'DsPO1.DC_JLR_DAFTARJALUR_T.Clear()
        'sdap.Fill(DsPO1.DC_JLR_DAFTARJALUR_T)
        'Scon.Close()
        ''coba
        SqlMobil = oldapMobil.SelectCommand.CommandText
        SqlDaftar = oldapPO.SelectCommand.CommandText
        cmbFilter.SelectedIndex = 0
        EnTambahPO()
        RECID()
        ''If CmbNama.Visible = False Then
        ''    grpSup.Enabled = False
        ''Else
        ''    grpSup.Enabled = True
        ''End If
        If txtNo_PO.Text <> "" Then
            btnTambahPO.Enabled = True
            btnEditPO.Enabled = True
            btnHapusPO.Enabled = True
        Else
            btnBatalPO.Enabled = False
            btnEditPO.Enabled = False
            btnHapusPO.Enabled = False
            btnTambahPO.Enabled = False
            btnSimpanPO.Enabled = False
            btnHapusPO.Enabled = False
        End If
        btnNext_Click(Nothing, Nothing)
        btnPrev_Click(Nothing, Nothing)
    End Sub
    Private Sub formatTextBox(ByVal sender As Object, ByVal e As System.Windows.Forms.ConvertEventArgs)
        Try
            'CType(sender, TextBox).Tag = ""
            e.Value = FormatNumber(e.Value, 2)
            'e.Value = FormatNumber(e.Value, 2).Replace(".", "A").Replace(",", ".").Replace("A", ",")
        Catch

        End Try
    End Sub

    Private Sub cmbFilter_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbFilter.SelectedIndexChanged
        Try
            'Attempt to load the dataset.
            Me.LoadDataSet()
            RECID()
            mobil()
        Catch eLoad As System.Exception
            'Add your error handling code here.
            'Display error message, if any.
            MsgBox(eLoad.ToString)
            'System.Windows.Forms.MessageBox.Show(eLoad.Message)
        End Try
    End Sub
#Region "Handle Textbox"
    Private Sub txt_Keydown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
        If e.Control Then
            Exit Sub
        End If
        Select Case e.KeyCode
            Case Keys.Enter, Keys.Down
                SendKeys.Flush()
                SendKeys.SendWait("{TAB}")
            Case Keys.Up
                SendKeys.Send("+{TAB}")
        End Select
    End Sub
    Private Sub BlockAll(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            CType(sender, TextBox).SelectAll()
        Catch ex As Exception
            ex = Nothing
        End Try

    End Sub
#End Region
    Public Sub LoadDataSet()
        'Create a new dataset to hold the records returned from the call to FillDataSet.
        'A temporary dataset is used because filling the existing dataset would
        'require the databindings to be rebound.
        Dim objDataSetTemp As PendaftaranPO.DS_
        objDataSetTemp = New PendaftaranPO.DS_
        Try
            'Attempt to fill the temporary dataset.
            Me.FillDataSet(objDataSetTemp)
        Catch eFillDataSet As System.Exception
            'Add your error handling code here.
            Throw eFillDataSet
        End Try
        Try
            'grdDC_JLR_DAFTARPO_T.DataSource = Nothing
            'grdDC_JLR_DAFTARJALUR_T.DataSource = Nothing

            'Empty the old records from the dataset.
            DsPO1.Clear()
            'Merge the records into the main dataset.
            DsPO1.Merge(objDataSetTemp)

            'grdDC_JLR_DAFTARJALUR_T.SetDataBinding(dsPo1, "DC_JLR_DAFTARJALUR_T")
            'grdDC_JLR_DAFTARPO_T.SetDataBinding(dsPo1, "DC_JLR_DAFTARJALUR_T.Daf_PO")

            'Atur Default
            DsPO1.DC_JLR_DAFTARJALUR_T.TANGGALColumn.DefaultValue = GetOracleDate()
            DsPO1.DC_JLR_DAFTARJALUR_T.DC_IDColumn.DefaultValue = cDC_ID
            'dsPo1.DC_JLR_DAFTARJALUR_T.NOMOBILColumn.DefaultValue = ""
            'DsPO1.DC_JLR_DAFTARJALUR_T.ID_DAFTARJALURColumn.AutoIncrementSeed = GetIdDaftarJalur()

            'dsPo1.DC_JLR_DAFTARPO_T.TANGGALColumn.DefaultValue = Now.Date
            DsPO1.DC_JLR_DAFTARPO_T.TGL_FAKColumn.DefaultValue = GetOracleDate.Date
            'DsPO1.DC_JLR_DAFTARPO_T.ID_DAFTARPOColumn.AutoIncrementSeed = GetIdDaftarPO()

            DsPO1.DC_JLR_DAFTARPO_T.SUPCOColumn.DefaultValue = ""
        Catch eLoadMerge As System.Exception
            'Add your error handling code here.
            Throw eLoadMerge
        End Try

    End Sub
    Public Sub FillDataSet(ByVal dataSet As PendaftaranPO.DS_)
        'Turn off constraint checking before the dataset is filled.
        'This allows the adapters to fill the dataset without concern
        'for dependencies between the tables.
        dataSet.EnforceConstraints = False
        Try
            'Open the connection.

            Me.olcon.Open()
            'Attempt to fill the dataset through the oldapMobil.

            If cmbFilter.SelectedIndex = 0 Then
                'txtTglDaftar.Enabled = False
                WhrMobil = " WHERE TRUNC(TANGGAL)=TRUNC(SYSDATE)"
                WhrDaftar = " WHERE ID_DAFTARJALUR IN (SELECT ID_DAFTARJALUR FROM DC_JLR_DAFTARJALUR_T " & WhrMobil & ")"
            Else
                'txtTglDaftar.Enabled = False
                WhrMobil = " WHERE TO_CHAR(TANGGAL, 'yyyy')=TO_CHAR(SYSDATE, 'yyyy')"
                WhrDaftar = " WHERE ID_DAFTARJALUR IN (SELECT ID_DAFTARJALUR FROM DC_JLR_DAFTARJALUR_T " & WhrMobil & ")"
                'ElseIf cmbFilter.SelectedIndex = 2 Then
                '    txtTglDaftar.Enabled = True
                '    WhrMobil = " WHERE TO_DATE(TRUNC(TANGGAL),'dd-mm-yy')=TO_DATE('" & txtTglDaftar.Text & "','dd-mm-yy')"
                '    WhrDaftar = " WHERE ID_DAFTARJALUR IN (SELECT ID_DAFTARJALUR FROM DC_JLR_DAFTARJALUR_T " & WhrMobil & ")"
            End If

            oldapMobil.SelectCommand.CommandText = SqlMobil & WhrMobil & "  ORDER BY ID_DAFTARJALUR"
            oldapPO.SelectCommand.CommandText = SqlDaftar & WhrDaftar & " ORDER BY ID_DAFTARPO"

            Try
                Me.oldapMobil.Fill(dataSet)
                Me.oldapPO.Fill(dataSet)
            Catch
            End Try

        Catch fillException As System.Exception
            'Add your error handling code here.
            Throw fillException
        Finally
            'Turn constraint checking back on.
            dataSet.EnforceConstraints = True
            'Close the connection whether or not the exception was thrown.
            Me.olcon.Close()
        End Try

    End Sub
    Private Sub btnCancelAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelAll.Click
        Me.DsPO1.RejectChanges()
    End Sub
    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        Try
            'Attempt to update the datasource.
            Me.UpdateDataSet()
        Catch eUpdate As System.Exception
            'Add your error handling code here.
            'Display error message, if any.
            ShowError("Error Update", eUpdate)
        End Try

    End Sub

    Public Sub UpdateDataSet()
        'Create a new dataset to hold the changes that have been made to the main dataset.
        Dim objDataSetChanges As PendaftaranPO.DS_ = New PendaftaranPO.DS_
        'Stop any current edits.
        Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").EndCurrentEdit()
        Try
            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").EndCurrentEdit()
        Catch

        End Try

        'Get the changes that have been made to the main dataset.
        objDataSetChanges = CType(DsPO1.GetChanges, PendaftaranPO.DS_)
        'Check to see if any changes have been made.
        If (Not (objDataSetChanges) Is Nothing) Then
            Try
                'There are changes that need to be made, so attempt to update the datasource by
                'calling the update method and passing the dataset and any parameters.
                Me.UpdateDataSource(objDataSetChanges)
                DsPO1.Merge(objDataSetChanges)
                DsPO1.AcceptChanges()
            Catch eUpdate As System.Exception
                'Add your error handling code here.
                Throw eUpdate
            End Try
            'Add your code to check the returned dataset for any errors that may have been
            'pushed into the row object's error.
        End If

    End Sub
    Public Sub UpdateDataSource(ByVal ChangedRows As PendaftaranPO.DS_)
        Try
            'The data source only needs to be updated if there are changes pending.
            If (Not (ChangedRows) Is Nothing) Then
                'Open the connection.
                Me.olcon.Open()
                'Attempt to update the data source.
                Debug.WriteLine("Mobil: " & oldapMobil.Update(ChangedRows))
                Application.DoEvents()
                Debug.WriteLine("PO: " & oldapPO.Update(ChangedRows))

            End If
        Catch updateException As System.Exception
            'Add your error handling code here.
            Throw updateException
        Finally
            'Close the connection whether or not the exception was thrown.
            Me.olcon.Close()
        End Try

    End Sub

    Public Sub btnPrev_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrev.Click
        Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position -= 1
        'lblSUPCO.Text = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.SUPCO").Current
        RECID()
        mobil()
        If txtNo_PO.Text <> "" And txtNo_PO.Text <> "" Then
            btnTambahPO.Enabled = True
        End If
        LoadNoAntrian()
    End Sub
    Public Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click
        Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position += 1
        RECID()
        mobil()
        If txtNo_PO.Text <> "" And txtNo_PO.Text <> "" Then
            btnTambahPO.Enabled = True
        End If
        LoadNoAntrian()
    End Sub

    Public Sub JagaanLoad()

        txtNoAntrian.Text = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T,NOURUT").Current
        lblSUPCO.Text = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T,SUPCO").Current
        lblSNAMA.Text = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T,SNAMA").Current
        If lblSUPCO.Text = "" Or lblSNAMA.Text = "" Then
            If btnPrintUlang.Visible = True Or txtNoAntrian.Text = "" Then
                btnTambahPO.Enabled = False
            Else
                btnTambahPO.Enabled = True
            End If
        Else
            btnTambahPO.Enabled = True
        End If
        LoadNoAntrian()
        'grpSup.Enabled = False

        'btnTambahPO.Enabled = True
        'btnHapusPO.Enabled = True
        'btnEditPO.Enabled = True

        'If txtNoAntrian.Text = "" Then
        '    btnPrint.Enabled = False
        '    btnPrintUlang.Visible = False
        '    'BtnPrintStck.Visible = False
        '    btnTambahPO.Enabled = False
        '    Exit Sub
        'End If
        ''Dim a As String = Format(txtTglDaftar.Value, "MM/dd/yyyy 00:00:00")
        ''Dim b As Date = Format(txtTglDaftar.Value, "MM/dd/yyyy 00:00:00")
        ''MessageBox.Show(Format(txtTglDaftar.Value, "MM/dd/yyyy 00:00:00"))
        'DsPO1.Tables("DC_JLR_DAFTARJALUR_T").DefaultView.RowFilter = _
        '"NOURUT= " & txtNoAntrian.Text & " and TANGGAL >= '" & Format(txtTglDaftar.Value, "MM/dd/yyyy 00:00:00") & _
        '                                "' and TANGGAL <= '" & Format(txtTglDaftar.Value, "MM/dd/yyyy 23:59:59") & "'"
        'If DsPO1.Tables("DC_JLR_DAFTARJALUR_T").DefaultView.Item(0).Item("PRINT_ID").ToString = "" Then
        '    btnPrint.Enabled = True
        '    btnPrintUlang.Visible = False
        '    'BtnPrintStck.Visible = False
        '    btnTambahPO.Enabled = True
        'Else
        '    btnPrint.Enabled = False
        '    btnPrintUlang.Visible = True
        '    'BtnPrintStck.Visible = True
        '    btnTambahPO.Enabled = False
        'End If
        'If lblBPB_NO.Text <> "" Then
        '    btnPrint.Enabled = False
        '    btnPrintUlang.Enabled = False
        '    btnHapusPO.Enabled = False
        '    btnEditPO.Enabled = False
        'Else
        '    btnHapusPO.Enabled = True
        '    btnEditPO.Enabled = True
        'End If
        'If txtTglDaftar.Value <> Now.Date And lblBPB_NO.Text <> "" Then
        '    btnTambahPO.Enabled = False
        'Else
        '    btnPrintUlang.Enabled = True
        'End If

        ''If txtPO_Total.Text = "" Then
        ''    btnPrint.Enabled = False
        ''Else
        ''    btnPrint.Enabled = True
        ''End If
    End Sub
    Private Sub RECID()
        If txtNoAntrian.Text = "" Then
            btnPrint.Enabled = False
            btnPrintUlang.Visible = False
            'BtnPrintStck.Visible = False
            btnTambahPO.Enabled = False
            Exit Sub
        End If
        'Dim a As String = Format(txtTglDaftar.Value, "MM/dd/yyyy 00:00:00")
        'Dim b As Date = Format(txtTglDaftar.Value, "MM/dd/yyyy 00:00:00")
        'MessageBox.Show(Format(txtTglDaftar.Value, "MM/dd/yyyy 00:00:00"))


        'DsPO1.Tables("DC_JLR_DAFTARJALUR_T").DefaultView.RowFilter = _
        '"NOURUT= " & txtNoAntrian.Text & " and TANGGAL >= '" & Format(txtTglDaftar.Value, "MM/dd/yyyy 00:00:00") & _
        '                                "' and TANGGAL <= '" & Format(txtTglDaftar.Value, "MM/dd/yyyy 23:59:59") & "'"
        'If DsPO1.Tables("DC_JLR_DAFTARJALUR_T").DefaultView.Item(0).Item("PRINT_ID").ToString = "" Then


        Dim dt_getPRINTID As DataTable = getDS(" SELECT *" & _
"   FROM dc_jlr_daftarjalur_t" & _
"  WHERE NOURUT= " & txtNoAntrian.Text & " and TANGGAL >= to_date('" & Format(txtTglDaftar.Value, "MM/dd/yyyy 00:00:00") & "', 'MM/dd/yyyy HH24:mi:ss') " & _
                                        " and TANGGAL <= to_date('" & Format(txtTglDaftar.Value, "MM/dd/yyyy 23:59:59") & "', 'MM/dd/yyyy HH24:mi:ss')", ConStrORA).Tables(0)
        If dt_getPRINTID.Rows.Count > 0 Then
            If dt_getPRINTID.Rows(0)("PRINT_ID").ToString = "" Then
                btnPrint.Enabled = True
                btnPrintUlang.Visible = False
                'BtnPrintStck.Visible = False
                btnTambahPO.Enabled = True
            Else
                btnPrint.Enabled = False
                btnPrintUlang.Visible = True
                'BtnPrintStck.Visible = True
                btnTambahPO.Enabled = False
            End If
        End If
        If lblBPB_NO.Text <> "" Then
            btnPrint.Enabled = False
            btnPrintUlang.Enabled = False
            btnHapusPO.Enabled = False
            btnEditPO.Enabled = False
        Else
            btnHapusPO.Enabled = True
            btnEditPO.Enabled = True
        End If
        If txtTglDaftar.Value <> Now.Date And lblBPB_NO.Text <> "" Then
            btnTambahPO.Enabled = False
        Else
            btnPrintUlang.Enabled = True
        End If

        'If txtPO_Total.Text = "" Then
        '    btnPrint.Enabled = False
        'Else
        '    btnPrint.Enabled = True
        'End If
    End Sub

    Private Sub btnDaftar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDaftar.Click
        ' isiData()

        'Dim abc As String
        'abc = LBMobil.SelectedItem
        'abc = LBMobil.SelectedItems.ToString
        'abc = LBMobil.SelectedValue
        'abc = LBMobil.Items.ToString

        '        Dim dt_cekDAFTAR As DataTable = getDS("SELECT COUNT(*) FROM dc_jlr_daftarmobil_hdr_t WHERE nomobil = '" & LBMobil.Items.ToString & "' and supco = '" & lblSUPCO.Text & "'", ConStrORA).Tables(0)

        Dim m As String
        Dim d As String
        Dim tgl As String
        m = Date.Now.Month
        d = Date.Now.Day
        If m.Length < 2 And d.Length < 2 Then
            m = "0" & Date.Now.Month
            d = "0" & Date.Now.Day
        ElseIf m.Length < 2 Then
            m = "0" & Date.Now.Month
        ElseIf d.Length < 2 Then
            d = "0" & Date.Now.Day
        End If
        tgl = d & "/" & m & "/" & Date.Now.Year

        Dim Qcon As New OleDb.OleDbConnection(ConStrORA)
        Dim Qcom As New OleDb.OleDbCommand("", Qcon)
        Dim Qdap As New OleDb.OleDbDataAdapter
        'MsgBox(cDC_KODE)
        Qcom.CommandText = "select distinct SUPCO,H.SUP_NAMA AS SNAMA,S.TGLMASUK " & _
                            "from DC_JLR_DAFTARMOBIL_HDR_T S, DC_SUPPLIER_DC_V H " & _
                            "where to_char(TRUNC(TGLMASUK),'dd/mm/yyyy')='" & tgl & "' and TGLKELUAR is null " & _
                            "and S.supco=H.sup_supkode and H.TBL_DC_KODE='" & cDC_KODE & "' " & _
                            "order by s.tglmasuk"
        '"and nomobil not in(Select distinct nomobil from dc_jlr_daftarjalur_t D where to_char(TRUNC(tanggal),'dd/mm/yyyy')='" & tgl & "') " & _

        '"select distinct SUPCO,H.SUP_NAMA AS SNAMA " & _
        '"from DC_JLR_DAFTARMOBIL_HDR_T S, DC_SUPPLIER_DC_V H " & _
        '"where to_char(TRUNC(TGLMASUK),'dd/mm/yyyy')='" & tgl & "' and TGLKELUAR is null " & _
        '"and supco not in(Select distinct supco from dc_jlr_daftarjalur_t D " & _
        '"where to_char(TRUNC(tanggal),'dd/mm/yyyy')='" & tgl & "' " & _
        '"and id_daftarjalur in (select distinct id_daftarjalur from dc_jlr_daftarpo_t " & _
        '"where to_char(TRUNC(tgl_fak),'dd/mm/yyyy')='" & tgl & "' " & _
        '"and bpb_no is null)) " & _
        '"and S.supco=H.sup_supkode and H.TBL_DC_KODE='" & cDC_KODE & "' " & _
        '"order by snama"
        Qdap.SelectCommand = Qcom
        dsSupp.Clear()
        Qcon.Open()

        'LBMobil.DataSource = ds.Tables(0)
        'LBMobil.DisplayMember = "NOMOBIL"
        'If btnDaftar.Enabled = True And btnTambahPO.Enabled = True Then
        '    LBMobil.ClearSelected()
        'End If

        Qdap.Fill(dsSupp)
        If dsSupp.Tables(0).Rows.Count <> 0 Then
            CmbSUPCO.DisplayMember = "SUPCO"
            CmbSUPCO.DataSource = dsSupp.Tables(0)
            CmbNama.DisplayMember = "SNAMA"
            CmbNama.DataSource = dsSupp.Tables(0)
            CmbNama.ValueMember = "TGLMASUK"
            'LBMobil.DataSource = dsSupp.Tables(0)
            'LBMobil.DisplayMember = "NOMOBIL"
        Else
            MsgBox("Tidak Bisa Daftar, Supplier Belum Ada Yang Datang", MsgBoxStyle.Information)
            RECID()
            GoTo out
        End If
        Qcon.Close()

        CmbSUPCO.Visible = True
        CmbNama.Visible = True

        If CmbSUPCO.Text <> "" Then
            Dim sql As String
            Dim Qdar As OleDb.OleDbDataReader
            Qcon.Open()
            'Todo: Buat PO tidak ada Kolom
            sql = "Select S.SUP_NAMA AS SNAMA,H.SUP_FLAG_BUATPO AS BUAT_PO,s.SUP_SUPID AS SUPID from DC_SUPPLIER_DC_V H,DC_SUPPLIER_T S "
            sql &= "Where H.SUP_FK_SUPID=s.SUP_SUPID And "
            sql &= "TBL_DC_KODE='" & cDC_KODE
            sql &= "' AND H.SUP_SUPKODE='" & CmbSUPCO.Text & "'"
            Qcom.CommandText = sql
            Qdar = Qcom.ExecuteReader
            Qdar.Read()
            lblSUPCO.Text = CmbSUPCO.Text
            lblSNAMA.Text = IIf(IsDBNull(Qdar("SNAMA").ToString), "", Qdar("SNAMA"))
            Qdar.Close()
            Qcon.Close()
        Else
            lblSNAMA.Text = ""
        End If

        'txtSUPCO.Visible = True
        'txtNamaSupp.Visible = True
        'txtSUPCO.Enabled = True

        Dim NamaS As String
        NamaS = lblSNAMA.Text
        Try
            'DsPO1.DC_JLR_DAFTARJALUR_T.ID_DAFTARJALURColumn.AutoIncrementSeed = GetIdDaftarJalur()

            DsPO1.DC_JLR_DAFTARJALUR_T.ID_DAFTARJALURColumn.DefaultValue = GetIdDaftarJalur()

            DsPO1.DC_JLR_DAFTARJALUR_T.NOMOBILColumn.DefaultValue = " "
            'Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").EndCurrentEdit()
            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").AddNew()

            'txtNoMobil.Enabled = True
            'txtSUPCO.Enabled = True
            'txtTglDaftar.Enabled = True

            btnHapusPO.Enabled = False
            btnEditPO.Enabled = False

            btnNext.Enabled = False
            btnPrev.Enabled = False
            btnDaftar.Enabled = False
            btnCari.Enabled = False

            'btnSimpan.Enabled = True
            'btnBatal.Enabled = True

            'Dim X As Integer
            'X = Me.BindingContext(dsPo1, "DC_JLR_DAFTARJALUR_T").Position

            'dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("ID_DAFTARJALUR") = GetIdDaftarJalur()

            Debug.WriteLine("Jumlah Record : " & DsPO1.DC_JLR_DAFTARJALUR_T.Rows.Count)

            ''txtNoMobil.Focus()
            'txtSUPCO.Focus()
            btnTambahPO.Enabled = True
        Catch eEndEdit As System.Exception
            System.Windows.Forms.MessageBox.Show(eEndEdit.Message)
        End Try
        CmbSUPCO.Focus()
        lblSNAMA.Text = NamaS
        LBMobil.Enabled = True
        'If LBMobil.SelectedIndex = -1 And LBMobil.Items.Count <> 0 Then
        '    LBMobil.SelectedIndex = 0
        'End If
        btnPrint.Enabled = False
        btnPrev2.Enabled = True
        btnNext2.Enabled = True

        'If LBMobil.SelectedIndex = -1 And LBMobil.Items.Count <> 0 Then
        '    LBMobil.SelectedIndex = 0
        'End If
out:    EnTambahPO()
    End Sub

    Public Sub EnTambahPO()
        If lblSUPCO.Text = "" Or lblSNAMA.Text = "" Then
            If btnPrintUlang.Visible = True Or txtNoAntrian.Text = "" Then
                btnTambahPO.Enabled = False
            Else
                btnTambahPO.Enabled = True
            End If
        Else
            btnTambahPO.Enabled = True
        End If
    End Sub

    Private Sub grpSupplier_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles grpSup.Leave
        Try
            If CmbSUPCO.Text = "" And btnDaftar.Enabled = False Then
                Err.Raise(99)
            End If
            'Dim sup As String
            'Dim supnama As String
            'sup = txtSUPCO.Text
            'supnama = txtNamaSupp.Text
            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").EndCurrentEdit()
            'txtSUPCO.Text = sup
            'txtNamaSupp.Text = supnama


            'If Not btnDaftar.Enabled And btnTambahPO.Enabled Then
            '    btnTambahPO.PerformClick()
            'End If

        Catch ex As Exception
            'ShowError("Error Simpan Daftar Mobil", ex)
            ' ''Debug.WriteLine("Error Simpan Daftar SupCo" & ex.Message)
            ' ''ex = Nothing

            ' ''If MessageBox.Show("Kode Supplier Tidak Boleh Kosong." & vbCrLf & _
            ' ''    "     Edit Kode Supplier ?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Error) = Windows.Forms.DialogResult.Yes Then
            ' ''    txtNoMobil.Focus()
            ' ''Else
            ' ''    Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").CancelCurrentEdit()
            ' ''    btnNext.Focus()
            ' ''    SetTombol(False)
            ' ''End If

            'ShowError("Error Simpan Daftar Mobil", ex)
            ''Debug.WriteLine("Error Simpan Daftar Mobil" & ex.Message)
            ''ex = Nothing

            ''If MessageBox.Show("No Mobil Tidak Boleh Kosong." & vbCrLf & _
            ''    "     Edit No Mobil ?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Error) = Windows.Forms.DialogResult.Yes Then
            ''    txtNoMobil.Focus()
            ''Else
            ''    Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").CancelCurrentEdit()
            ''    btnNext.Focus()
            ''    SetTombol(False)
            ''End If
        End Try
    End Sub

    Private Sub btnTambahPO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTambahPO.Click
        'DsPO1.DC_JLR_DAFTARPO_T.ID_DAFTARPOColumn.AutoIncrementSeed = GetIdDaftarPO()

        'Dim sup As String
        'sup = txtSUPCO.Text
        'Dim supnama As String
        'supnama = txtNamaSupp.Text

        ''If txtNoMobil.Text = "" Then
        ''    MessageBox.Show("Daftarkan Mobil Terlebih Dahulu", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
        ''    Exit Sub
        ''End If
        If LBMobil.SelectedIndex = -1 And LBMobil.Items.Count <> 0 Then
            LBMobil.SelectedIndex = 0
        End If
        Dim dt_cekNOURUT As DataTable = getDS(" SELECT nourut" & _
"   FROM dc_jlr_daftarjalur_t" & _
"  WHERE  supco = '" & lblSUPCO.Text & "' AND nomobil = '" & LBMobil.Text & "' and tanggal = trunc(sysdate)", ConStrORA).Tables(0)
        If dt_cekNOURUT.Rows.Count > 0 And txtNoAntrian.Text = "" Then
            txtNoAntrian.Text = dt_cekNOURUT.Rows(0)(0).ToString
        ElseIf txtNoAntrian.Text = "" Then
            txtNoAntrian.Text = frmLoadPO.NextAntrian()
        End If

        If btnDaftar.Enabled = False Then
            If CmbSUPCO.Text = "" And lblSNAMA.Text = "" Then
                MessageBox.Show("Daftarkan Supplier Terlebih Dahulu", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
                'Else
                'txtSUPCO.Enabled = False
                'txtNamaSupp.Enabled = False
            End If

            'CmbSUPCO.Enabled = False
            'CmbNama.Enabled = False

            CmbSUPCO.Visible = False
            CmbNama.Visible = False
            lblSUPCO.Text = CmbSUPCO.Text
            lblSNAMA.Text = CmbNama.Text
            'If LBMobil.Text = "" Then
            '    MsgBox("No. Mobil belum dipilih", vbCritical)
            '    Exit Sub
            'End If

            'Else
            '    If lblSUPCO.Text = "" And lblSNAMA.Text = "" Then
            '        MessageBox.Show("Nama Atau Code Supplier Tidak Lengkap", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            '        Exit Sub
            '    End If
        End If

        Dim sql As String
        Dim Scon As New OleDbConnection(ConStrORA)
        Dim Scom As New OleDbCommand("", Scon)
        Dim Sdar As OleDbDataReader
        Try
            Scon.Open()
            'Todo: Buat PO tidak ada Kolom
            sql = "Select S.SUP_NAMA AS SNAMA,H.SUP_SUPKODE AS SUPCO,H.SUP_FLAG_BUATPO AS BUAT_PO,s.SUP_SUPID AS SUPID from DC_SUPPLIER_DC_V H,DC_SUPPLIER_T S "
            sql &= "Where H.SUP_FK_SUPID=s.SUP_SUPID And "
            sql &= "TBL_DC_KODE='" & cDC_KODE
            sql &= "' AND H.SUP_SUPKODE='" & CmbSUPCO.Text & "'"
            Scom.CommandText = sql
            Sdar = Scom.ExecuteReader
            If Sdar.Read Then
                'Cek With PO
                If Not lWithPO Then
                    If "" & Sdar("BUAT_PO") = "Y" Then
                        'MsgBox("Supplier " & CmbSUPCO.Text & " Harus Pakai PO !!!", vbCritical)
                        'Sdar.Close()
                        'Scon.Close()
                        'Scon = Nothing
                        'Exit Sub
                        PO = True
                    Else
                        txtPO_QTY.Focus()
                    End If
                End If
            End If
            Sdar.Close()
        Catch ex As Exception
            ShowError("Error Baca Supplier", ex)
        Finally
            Scon.Close()
            Scon = Nothing
        End Try

        DsPO1.DC_JLR_DAFTARPO_T.ID_DAFTARPOColumn.DefaultValue = GetIdDaftarPO()

        Try
            Try
                Dim rw As Object
                rw = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DaF_PO").Current
                If CType(rw, DS_.DC_JLR_DAFTARPO_TRow).RowState <> DataRowState.Unchanged Then
                    Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DaF_PO").EndCurrentEdit()
                End If
            Catch
            End Try

            Try

                Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DaF_PO").AddNew()

            Catch ' ex As Exception

            End Try

            'txtSUPCO.Text = sup
            'txtNamaSupp.Text = supnama

            'Dim X As Integer
            'X = Me.BindingContext(dsPo1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Position
            'dsPo1.DC_JLR_DAFTARPO_T.Rows(X)("DC_JLR_DAFTARJALUR_T.DAF_PO") = GetIdDaftarJalur()

        Catch eEndEdit As System.Exception
            ShowError("Error Tambah PO", eEndEdit)
        End Try
        'Tombol
        SetTombol(True)
 
        txtNoFak.Focus()

    End Sub

    Private Sub grpDaftar_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles grpDaftar.Leave
        Try

            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").EndCurrentEdit()
        Catch ex As Exception
            'ShowError("Error Simpan Daftar PO", ex)

            'If MessageBox.Show("Kode Supplier Tidak Boleh Kosong." & vbCrLf & " Edit Kode Supplier ?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Error) = DialogResult.Yes Then
            '    txtSUPCO.Focus()
            'Else
            '    Me.BindingContext(dsPo1, "DC_JLR_DAFTARJALUR_T.DAF_PO").CancelCurrentEdit()
            '    SetTombol(False)
            'End If
            Debug.WriteLine("Error Simpan Daftar PO" & vbCrLf & ex.Message)
            ex = Nothing
        End Try

    End Sub



    Private Sub btnSimpanPO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimpanPO.Click
        'If txtNo_PO.Text = "" Then
        '    MessageBox.Show("Harap isi No PO", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
        '    Exit Sub
        'End If
        If txtNoFak.Text = "" Then
            MessageBox.Show("Harap isi No Faktur", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub

        End If
        If txtNo_PO.Text = "" Then
            MsgBox("Tidak Bisa Edit Pendaftaran Tanpa PO.", vbCritical)
            Exit Sub
        End If
        'If Not lWithPO And PO = True And txtNo_PO.Text = "" Then
        '    MsgBox("Supplier " & CmbSUPCO.Text & " Harus Pakai PO !!!", vbCritical)
        '    Exit Sub
        'End If

        frmLoadPO.NOURUT = txtNoAntrian.Text
        'If Not lWithPO Then
        '    'Cek Faktur
        '    Try
        '        Dim olcom As New OleDbCommand("", olcon)
        '        olcom.CommandText = "Select count(*) From DC_DAFTARJALUR"
        '        If olcom.ExecuteScalar > 0 Then
        '            MsgBox("No. Mobil tidak boleh kosong", vbCritical)
        '            txtNoFak.Focus()
        '            Exit Sub
        '        End If
        '    Catch ex As Exception
        '        Throw ex
        '    End Try
        'End If


        If Not lWithPO Then
            If txtPO_GROSS.Text = "0" Or txtPO_QTY.Text = "0" Then
                MessageBox.Show("Isi QTY dan Gross Pendaftaran.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
                txtPO_QTY.Focus()
                Exit Sub
            End If
        End If

        'If txtNoMobil.Text = "" Then
        '    MsgBox("No. Mobil tidak boleh kosong", vbCritical)
        '    txtNoMobil.Focus()
        '    Exit Sub
        'End If

        If lblSNAMA.Text = "" Then
            MsgBox("Nama Supplier tidak boleh kosong", vbCritical)
            CmbSUPCO.Focus()
            Exit Sub
        End If

        'txtSUPCO.Text = CmbSUPCO.Text
        'txtSUPCO.Visible = True
        'txtNoMobil.Text = DGV.Item(0, 0).Value
        'txtNoMobil.Visible = True

        Dim Scon As New OleDbConnection(ConStrORA)
        Dim Scom As New OleDbCommand("", Scon)
        Scon.Open()
        Scom.CommandText = "Select sysdate from dual"
        txtTGL_MULAI.Text = Scom.ExecuteScalar
        Scom.CommandText = ""
        Scon.Close()
        'Dim dr As Object
        'dr = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Current
        'dr.row("SUPCO") = CmbSUPCO.Text
        'dr.row("SNAMA") = txtNamaSupp.Text
        'dr.row("NOMOBIL") = DGV.Item(0, 0).Value
        'dr.row("GUDANG_KODE") = cGUDANG_KODE
        'dr.row("LOKASI_KODE") = cLOKASI_KODE
        'dr.row("SUPID") = lblSUPID.Text
        'Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").EndCurrentEdit()

        lblGudangKode.Text = cGUDANG_KODE
        lblLokasiKode.Text = cLOKASI_KODE
        txtSupID.Text = lblSUPID.Text


        'load datanya dulu baru save
        frmLoadPO.sNoPo = txtNo_PO.Text

        If LBMobil.SelectedIndex = -1 And LBMobil.Items.Count <> 0 Then
            LBMobil.SelectedIndex = 0
        End If
        frmLoadPO.NOMOBIL = LBMobil.Text
        frmLoadPO.SUPCO = lblSUPCO.Text
        frmLoadPO.SNAMA = lblSNAMA.Text
        frmLoadPO.ITEMnya = IIf(txtTot_Item.Text = "", 0, txtTot_Item.Text)
        frmLoadPO.RUPIAH = txtPO_GROSS.Text
        frmLoadPO.FAKTUR = txtNoFak.Text
        frmLoadPO.NoAntrian = txtNoAntrian.Text
        frmLoadPO.tglDaftar = txtTglDaftar.Value
        frmLoadPO.tglFaktur = txtTglFaktur.Value

        
        If chkBUAT_PO.Checked = True Then
            frmLoadPO.adaPO = "1"
        Else
            frmLoadPO.adaPO = "0"
        End If

        If chkADA_HARGA.Checked = True Then
            frmLoadPO.adaHarga = "1"
        Else
            frmLoadPO.adaHarga = "0"
        End If
        If frmLoadPO.ShowDialog = Windows.Forms.DialogResult.OK Then

            CmbSUPCO.Visible = False
            CmbNama.Visible = False
            LBMobil.ClearSelected()
            LBMobil.Enabled = False
            SetTombol(False)
            'lblSNAMA.Text = ""
            'lblSUPCO.Text = ""
            'Me.BindingContext(dsPo1, "DC_JLR_DAFTARJALUR_T.DAF_PO").CancelCurrentEdit()
            ' btnCancelAll_Click(sender, e)
            RECID()
            '  frmDaftarPO_Load(sender, e)
            ''load
            'Dim Scon1 As New OleDb.OleDbConnection(ConStrORA)
            'Dim sdap As New OleDb.OleDbDataAdapter("Select * from dc_jlr_daftarjalur_t", Scon1)
            'Dim sdap2 As New OleDb.OleDbDataAdapter("Select * from dc_jlr_daftarpo_t", Scon1)
            'Scon1.Open()
            'DsPO1.DC_JLR_DAFTARPO_T.Clear()
            'DsPO1.DC_JLR_DAFTARJALUR_T.Clear()
            'DsPO1.DC_JLR_DAFTARPO_T.AcceptChanges()
            'DsPO1.DC_JLR_DAFTARJALUR_T.AcceptChanges()
            'sdap.Fill(DsPO1.DC_JLR_DAFTARJALUR_T)
            'sdap2.Fill(DsPO1.DC_JLR_DAFTARPO_T)
            'Scon1.Close()
            'DsPO1.DC_JLR_DAFTARPO_T.AcceptChanges()
            'DsPO1.DC_JLR_DAFTARJALUR_T.AcceptChanges()
            'DsPO1.GetChanges()
            'cmbFilter_SelectedIndexChanged(sender, e)
            LoadDataSet()
            Dim loadnourut As String = frmLoadPO.NOURUT
            For i As Integer = 0 To DsPO1.DC_JLR_DAFTARJALUR_T.Rows.Count - 1
                If DsPO1.DC_JLR_DAFTARJALUR_T.Rows(i)("NOURUT").ToString = loadnourut Then
                    Exit For
                Else
                    Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position += 1
                End If
            Next

            'Dim loadnodaf As String = frmLoadPO.FAKTUR
            For i As Integer = 0 To DsPO1.DC_JLR_DAFTARPO_T.Rows.Count - 1

                Dim NOFAK1 As String = DsPO1.DC_JLR_DAFTARPO_T.Rows(i)("NO_FAK").ToString
                Dim NOFAK2 As String = frmLoadPO.FAKTUR
                Dim NoPO1 As String = DsPO1.DC_JLR_DAFTARPO_T.Rows(i)("NOPO").ToString
                Dim NOPO2 As String = frmLoadPO.sNoPo.ToString

                If DsPO1.DC_JLR_DAFTARPO_T.Rows(i)("NO_FAK").ToString = frmLoadPO.FAKTUR And DsPO1.DC_JLR_DAFTARPO_T.Rows(i)("NOPO").ToString = frmLoadPO.sNoPo Then
                    Exit For
                Else
                    Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Position += 1
                End If
            Next
            mobil()
        End If
        'frmLoadPO.Show()
        'frmLoadPO.Visible = True


batalLoad:
    End Sub
    'Public Sub showdialogLoadPO(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles frmLoadPO1.FormClosing
    '    btnBatalPO_Click(sender, e)
    '    'test dgvload bisa di access ga dari sini

    '    'datasetload = frmLoadPO.dgvLoadPO.DataSource TryCast(dgvMyMembers.DataSource, DataTable)
    '    'If frmLoadPO.Visible = False Then
    '    '    If CancelLoad = "" Then
    '    '        SetTombol(False)
    '    '    Else
    '    '        SetTombol(True)
    '    '    End If
    '    'End If

    'End Sub
    Public Sub btnBatalPO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBatalPO.Click ', frmLoadPO1.FormClosing
        CmbSUPCO.Visible = False
        CmbNama.Visible = False
        LBMobil.ClearSelected()
        LBMobil.Enabled = False
        SetTombol(False)
        'lblSNAMA.Text = ""
        'lblSUPCO.Text = ""
        'Me.BindingContext(dsPo1, "DC_JLR_DAFTARJALUR_T.DAF_PO").CancelCurrentEdit()
        btnCancelAll_Click(sender, e)
        RECID()
        btn_Next(lblSUPCO.Text)
        'txtSUPCO.Visible = False
        'txtNamaSupp.Visible = False
    End Sub


    Private Sub grdDC_JLR_DAFTARPO_T_LostFocus(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'Me.BindingContext(dsPo1, "DC_JLR_DAFTARJALUR_T.Daf_PO").EndCurrentEdit()
        Debug.WriteLine("Grid PO Lost")
    End Sub

    Public Sub SetTombol(ByVal i As Boolean)
        'txtNoMobil.Enabled = i
        txtTglDaftar.Enabled = i

        txtNoFak.Enabled = i
        txtTglFaktur.Enabled = i
        txtNo_PO.Enabled = i
        txtPO_QTY.Enabled = i
        txtPO_GROSS.Enabled = i
        txtPO_PPN.Enabled = i
        'txtTgl_PO.Enabled = i
        'txtSUPCO.Enabled = i

        btnSimpanPO.Enabled = i
        btnBatalPO.Enabled = i

        btnNext.Enabled = Not i
        btnPrev.Enabled = Not i
        btnNext2.Enabled = Not i
        btnPrev2.Enabled = Not i
        btnEditPO.Enabled = Not i
        btnTambahPO.Enabled = Not i
        btnHapusPO.Enabled = Not i

        btnDaftar.Enabled = Not i
        btnCari.Enabled = Not i
        btnPrev.Enabled = Not i
        btnNext.Enabled = Not i
        btnPrev2.Enabled = Not i
        btnNext2.Enabled = Not i
        txtTglDaftar.Enabled = Not i



    End Sub

#Region "Validasi PO"
    Private NoPO As String

    Private lWithPO As Boolean
    Private Sub txtNo_PO_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNo_PO.Enter
        NoPO = txtNo_PO.Text.ToUpper
    End Sub

    Private Sub txtNo_PO_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtNo_PO.TextChanged

        If txtNo_PO.Enabled = False Then
            Exit Sub
        End If
        If txtNo_PO.Text.Length = 9 Then
            Dim Err_msg As String = ""

            'Tanpa PO
            If txtNo_PO.Text = "" Then
                lWithPO = False

                txtTgl_PO.Enabled = True
                'txtSUPCO.Enabled = True
                chkADA_HARGA.Enabled = True

                'txtTgl_PO.Text = Now.Date

                'chkADA_HARGA.Value = 1
                'chkBUAT_PO.Value = 0
                chkADA_HARGA.Checked = True
                chkBUAT_PO.Checked = False

                'txtPO_QTY.Text = Format(0, "#,##0")
                'txtPO_GROSS.Text = Format(0, "#,##.##############")
                'txtPO_PPN.Text = Format(0, "#,##.##############")
                'txtPO_Total.Text = Format(0, "#,##.##############")
                'txtTot_Item.Text = CInt("0")

                txtPO_QTY.Text = "0"
                txtPO_GROSS.Text = "0"
                txtPO_PPN.Text = "0"
                txtPO_Total.Text = "0"
                txtTot_Item.Text = "0"

                'DoEvents
                'txtTGL_PO.SetFocus
                'txtTGL_PO.SetFocus
                'SendKeys("{TAB}")

                Exit Sub
            End If
            lWithPO = True

            txtNo_PO.Text = txtNo_PO.Text.ToUpper
            If txtNo_PO.Text = NoPO Then
                Exit Sub
            End If

            If Len(txtNo_PO.Text) < 9 Then
                MsgBox("PO Tidak ada.", vbCritical)
                'txtNO_PO.Text = ""
                If NoPO <> "" Then
                    txtNo_PO.Text = NoPO
                End If
                'e.Cancel = True
                Exit Sub
            End If

            Dim sql As String
            Dim Scon As New OleDb.OleDbConnection(ConStrORA)
            Dim Scom As New OleDb.OleDbCommand("", Scon)
            Dim sdar As OleDb.OleDbDataReader
            Dim dt As New DataTable
            Dim da As New OleDb.OleDbDataAdapter("", Scon)
            Dim tampilTagN As String = "Di PO ini ada PLU yang tidak boleh diBPB :" & vbCrLf
            Try
                Scon.Open()

                sql = "Select COUNT(*) From DC_JLR_DaftarPO_T Where NoPO='" & _
                    txtNo_PO.Text & "' "
                'sql &= "AND TRUNC(Tanggal)=TRUNC(sysdate) "
                sql &= "AND NO_FAK='" & txtNoFak.Text & "' "

                Scom.CommandText = sql
                If Scom.ExecuteScalar > 0 Then
                    Err_msg = "PO sudah pernah didaftar dengan faktur sama."
                    GoTo Batal
                End If

                sql = "Select COUNT(*) From DC_JLR_DaftarPO_T Where NoPO='" & _
                    txtNo_PO.Text & "' and BPB_NO is null"
                Scom.CommandText = sql
                If Scom.ExecuteScalar > 0 Then
                    If MsgBox("PO sudah pernah didaftar. Daftarkan lagi ?", MsgBoxStyle.YesNo) = MsgBoxResult.No Then
                        GoTo Selesai
                    End If
                End If

                'MessageBox.Show(txtNo_PO.Text & vbCrLf & cDC_KODE)

                'cek PLU yg Tag N

                'sql = "SELECT PLU FROM (" & _
                '"SELECT b.mbr_plukode AS PLU, b.mbr_full_nama AS nama_sup, IsTag_BolehBPB(194,b.MBR_TAG) AS cek " & _
                '"FROM dc_barang_dc_v b, DC_PODTL_T a " & _
                '"WHERE(a.PODTL_PLUMD = b.MBR_FK_PLUID) " & _
                '"AND a.podtl_fk_no_po ='LH6B32194' " & _
                '"AND b.TBL_DC_KODE='G020' " & _
                '")WHERE cek=0 "

                sql = " SELECT PLU FROM ( " & _
                "SELECT b.mbr_plukode AS PLU, b.mbr_full_nama AS nama, IsTag_BolehBPB(" & cDC_ID & ",b.MBR_TAG) AS cek " & _
                "FROM dc_barang_dc_v b, DC_PODTL_T a  " & _
                "WHERE(a.PODTL_PLUMD = b.MBR_FK_PLUID) " & _
                "AND a.podtl_fk_no_po ='" & txtNo_PO.Text & "'  " & _
                "AND b.TBL_DC_KODE = '" & cDC_KODE & "' " & _
                ")WHERE cek=0"
                dt.Clear()
                da.SelectCommand.CommandText = sql
                da.Fill(dt)
                If dt.Rows.Count > 0 Then
                    For x As Integer = 0 To dt.Rows.Count - 1
                        If x = dt.Rows.Count - 1 Then
                            tampilTagN &= (dt.Rows(x)("PLU")) & "."
                        Else
                            tampilTagN &= (dt.Rows(x)("PLU")) & ", " '& " - " & (dt.Rows(x)("nama"))
                        End If

                    Next
                    MessageBox.Show(tampilTagN, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information)

                    ' Err_msg = tampilTagN
                    ' GoTo Batal
                End If
                'end Cek PLU
                'MessageBox.Show(dt.Rows.Count)

                ' kasus lombok jd harus matiin optimizer use feedback 14/3/2017 /*+OPT_PARAM(_'OPTIMIZER_USE_FEEDBACK' 'FALSE)*/
                sql = " SELECT    "
                sql &= "MAX(PO_RECID) AS RECIDx,MIN(PO_GUDANG) AS PO_GUDANG,PO.PO_NO_PO,PO.PO_EXPIRED, "
                sql &= "PO.PO_TGL_PO, PO.PO_SUPCO_MD AS SUPID, "
                sql &= "GET_SUPCO(PO.PO_SUPCO_MD)AS SUPCO, "
                sql &= "COUNT(*) AS TOT_ITEM "
                sql &= ",SUM(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*PODTL_QTYB*PODTL_ISI_SATB) AS PO_QTY "
                sql &= ",SUM( IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*(PODTL_QTYB*PODTL_ISI_SATB*PODTL_PRICE- "
                sql &= "   ((PODTL_QTYB*PODTL_ISI_SATB)/((PODTL_QTYB*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
                sql &= "   *NVL(TotDisc,0))) ) AS PO_GROSS "
                sql &= ",SUM(CASE WHEN PODTL_PPN > 0 THEN (IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)"
                sql &= "	*((PODTL_QTYB*PODTL_ISI_SATB*PODTL_PRICE-((PODTL_QTYB*PODTL_ISI_SATB)"
                sql &= "	/((PODTL_QTYB*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
                sql &= "	*NVL(TotDisc,0)))*.1)) ELSE 0 END) AS PO_PPN "
                sql &= ",MIN(PO_UMUR) AS PO_UMUR,PO_TGL_KIRIM "
                sql &= ",SUM(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*NVL(PODTL_PPN_BTL,0)) AS PPN_BOTOL "
                sql &= "FROM DC_PO_T PO "
                sql &= "LEFT JOIN DC_PODTL_T DT ON PO.PO_NO_PO = DT.PODTL_FK_NO_PO "
                sql &= "LEFT JOIN ("
                sql &= "	SELECT MBR_FK_PLUID,(MBR_TAG) AS MBR_TAG "
                sql &= "	FROM DC_BARANG_DC_V WHERE TBL_DC_KODE='" & cDC_KODE & "') BRG ON DT.PODTL_PLUMD=BRG.MBR_FK_PLUID "
                sql &= "LEFT JOIN ( "
                sql &= "	SELECT podisc_fk_no_po,PODISC_FK_PLU, "
                sql &= "	SUM(NVL(podisc_nilai,0)) AS TotDisc "
                sql &= "	FROM DC_PODISC_T "
                sql &= "	GROUP BY podisc_fk_no_po,PODISC_FK_PLU) S ON PO.PO_NO_PO=S.podisc_fk_no_po "
                sql &= "	AND DT.PODTL_PLUMD=S.PODISC_FK_PLU "
                sql &= "WHERE ((PODTL_RECID IS NULL OR PODTL_RECID='') AND PODTL_NO_BPB IS NULL) "
                sql &= "AND PO_NO_PO='" & txtNo_PO.Text & "' "
                sql &= "GROUP BY PO.PO_NO_PO, PO.PO_TGL_PO, PO.PO_SUPCO_MD, PO.PO_EXPIRED,PO.PO_TGL_KIRIM "
                Scom.CommandText = sql

                sdar = Scom.ExecuteReader
                If sdar.Read = False Then
                    Err_msg = "PO tidak ada. Atau Sudah BPB"
                    GoTo Batal
                End If

                'If sdar("SUPCO") <> lblSUPCO.Text And lblSUPCO.Text <> "" Then
                If sdar("SUPCO") <> lblSUPCO.Text Then
                    Err_msg = "Supplier tidak punya PO " & txtNo_PO.Text & "."
                    GoTo Batal
                End If

                ''Cek Status PO
                'Dim abc As Date = CType(sdar("PO_TGL_KIRIM"), Date)

                If Not IsDBNull(sdar("PO_TGL_KIRIM")) Then
                    If CType(sdar("PO_TGL_KIRIM"), Date) <> Now.Date Then
                        Err_msg = "PO Tidak Sesuai Tanggal Kirim."
                        GoTo Batal
                    End If
                Else
                    If CType(sdar("PO_TGL_PO"), Date).AddDays(sdar("PO_UMUR")) < Now.Date Then
                        Err_msg = "PO Sudah Kadaluarsa."
                        If IsDBNull(sdar("PO_EXPIRED")) Then
                            Dim SconE As New OleDbConnection(ConStrORA)
                            Dim ScomE As New OleDbCommand("", SconE)
                            SconE.Open()
                            ScomE.CommandText = "update DC_PO_T set PO_EXPIRED='Y' where PO_NO_PO='" & txtNo_PO.Text & "' "
                            ScomE.ExecuteNonQuery()
                            SconE.Close()
                            ScomE = Nothing
                            SconE = Nothing
                        End If
                        GoTo Batal
                    End If
                End If

                Dim rc As String = sdar("RECIDx") & ""
                Select Case rc
                    Case "C"
                        Err_msg = "PO Di-Closing"
                    Case "B"
                        Err_msg = "PO Sudah ada BPB-nya"
                    Case "H"
                        Err_msg = "PO Hangus"
                    Case "A"
                        Err_msg = "PO Sedang dibuat BPB-nya"
                    Case "1"
                        Err_msg = "Item PO dihapus"
                    Case "2"
                        Err_msg = "PO Revisi"
                End Select
                If Err_msg <> "" Then GoTo Batal

                If IFNULL(sdar("PO_QTY"), 0) + IFNULL(sdar("PO_GROSS"), 0) + IFNULL(sdar("PO_PPN"), 0) = 0 Then
                    Err_msg = "Qty, Gross & PPN Kosong."
                    GoTo Batal
                End If

                'Cek Supp. MrBread
                'CEK TBL ALOKASI DAN CEK SJ
                Dim IsMBread As Boolean = IsMrBread(sdar("SUPCO") & "", cDC_KODE)
                If IsMBread Then
                    Dim Scon2 As New OleDbConnection(ConStrORA)
                    Dim Scom2 As New OleDbCommand("", Scon2)

                    Try
                        Scon2.Open()
                        Scom2.CommandType = CommandType.StoredProcedure
                        Scom2.CommandText = "IMPORT_MBREAD('" & cDC_KODE & "')"
                        Scom2.ExecuteNonQuery()

                        Scom2.CommandType = CommandType.Text
                        Scom2.CommandText = "select CEK_MRBREAD ( '" & txtNoFak.Text & _
                            "', TO_DATE('" & Format(txtTglFaktur.Value, "yyyyMMdd") & "','YYYYMMDD'), '" & txtNo_PO.Text & "') as x from dual"
                        Err_msg = Scom2.ExecuteScalar & " "
                        If Err_msg.Substring(0, 1) = "1" Or Err_msg.Substring(0, 1) = "3" Then
                            '1;No. Faktur atau Tanggal Faktur Salah.
                            '3;Jumlah Item Faktur > Jumlah Item PO.

                            Err_msg = Err_msg.Substring(2)
                            GoTo Batal
                        Else
                            '2;Total Faktur Dan PO Tidak Sama.
                            If Err_msg.Substring(0, 1) = "2" Then
                                Err_msg = Err_msg.Substring(2)
                                MessageBox.Show(Err_msg, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
                            End If
                        End If
                        Err_msg = ""
                    Catch ex As Exception
                        Throw ex
                    Finally
                        Scon2.Close()
                    End Try

                End If

                'isi TextBOX
                txtTgl_PO.Text = sdar("PO_TGL_PO")
                'txtSUPCO.Text = sdar("SUPCO")
                lblSUPID.Text = IFNULL(sdar("SUPID"), 0)
                'If lblSUPCO.Text = "" Then
                '    lblSUPCO.Text = sdar("SUPCO")
                'End If

                'Dim dr As Object
                'dr = Me.BindingContext(dsPo1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Current
                'dr.row("SUPID") = sdar("SUPID") & ""

                chkBUAT_PO.Checked = True ''''''''
                chkADA_HARGA.Checked = True ''''''

                txtTot_Item.Enabled = False
                txtPO_QTY.Enabled = False
                txtPO_GROSS.Enabled = False
                txtPO_PPN.Enabled = False

                If Not IsMBread Then
                    txtPO_QTY.Text = Format(sdar("PO_QTY"), "#,##0")
                    txtPO_GROSS.Text = Format(CDbl(sdar("PO_GROSS")), "#,##.##############")
                    txtPO_PPN.Text = Format(CDbl(IFNULL(sdar("PO_PPN"), 0)), "#,##.##############")
                    txtPO_Total.Text = Format(CDbl(sdar("PO_GROSS")) + CDbl(IFNULL(sdar("PO_PPN"), 0)) + CDbl(IFNULL(sdar("PPN_BOTOL"), 0)), "#,##.##############")
                    txtTot_Item.Text = CDbl("0" & sdar("TOT_ITEM"))
                Else
                    sdar.Close()

                    ' kasus lombok jd harus matiin optimizer use feedback 14/3/2017
                    sql = " SELECT    "
                    sql &= "MAX(PO_RECID) AS RECIDx,MIN(PO_GUDANG) AS PO_GUDANG,PO.PO_NO_PO, "
                    sql &= "PO.PO_TGL_PO, PO.PO_SUPCO_MD AS SUPID, "
                    'sql &= "GET_SUPCO(PO.PO_SUPCO_MD)AS SUPCO, "
                    sql &= "COUNT(*) AS TOT_ITEM "
                    sql &= ",SUM(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*NVL(BREAD.JUM,0)*PODTL_ISI_SATB) AS PO_QTY "
                    sql &= ",SUM( IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*(NVL(BREAD.JUM,0)*PODTL_ISI_SATB*PODTL_PRICE- "
                    sql &= "   ((NVL(BREAD.JUM,0)*PODTL_ISI_SATB)/((NVL(BREAD.JUM,0)*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
                    sql &= "   *NVL(TotDisc,0))) ) AS PO_GROSS "
                    sql &= ",SUM(CASE WHEN PODTL_PPN > 0 THEN "
                    sql &= "	(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*((NVL(BREAD.JUM,0)*PODTL_ISI_SATB*PODTL_PRICE- "
                    sql &= "	((NVL(BREAD.JUM,0)*PODTL_ISI_SATB)/((NVL(BREAD.JUM,0)*PODTL_ISI_SATB)+PODTL_FRAC_QTYB) "
                    sql &= "	*NVL(TotDisc,0)))*.1)) ELSE 0 END) AS PO_PPN "
                    sql &= ",MIN(PO_UMUR) AS PO_UMUR "
                    sql &= ",SUM(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*NVL(PODTL_PPN_BTL,0)) AS PPN_BOTOL "
                    sql &= "FROM DC_PO_T PO "
                    sql &= "LEFT JOIN DC_PODTL_T DT ON PO.PO_NO_PO = DT.PODTL_FK_NO_PO "
                    sql &= "LEFT JOIN ("
                    sql &= "	SELECT MBR_FK_PLUID,(MBR_TAG) AS MBR_TAG "
                    sql &= "	FROM DC_BARANG_DC_V "
                    sql &= "	WHERE TBL_DC_KODE='" & cDC_KODE & "') BRG ON DT.PODTL_PLUMD=BRG.MBR_FK_PLUID "
                    sql &= "LEFT JOIN ( "
                    sql &= "	SELECT podisc_fk_no_po,PODISC_FK_PLU, "
                    sql &= "	SUM(NVL(podisc_nilai,0)) AS TotDisc "
                    sql &= "	FROM DC_PODISC_T "
                    sql &= "	GROUP BY podisc_fk_no_po,PODISC_FK_PLU) S ON PO.PO_NO_PO=S.podisc_fk_no_po "
                    sql &= "	AND DT.PODTL_PLUMD=S.PODISC_FK_PLU "
                    sql &= "LEFT JOIN ( "
                    sql &= "	 SELECT   a.pluid AS plumd, SUM (a.qty) AS Jum "
                    sql &= "     FROM alokasi_tampung a "
                    sql &= "	 WHERE (a.no_sj = '" & txtNoFak.Text & "') "
                    sql &= "   	 GROUP BY a.no_sj, a.tgl_sj, a.pluid "
                    sql &= "	 order by plumd) BREAD ON  DT.podtl_plumd=BREAD.PLUMD "
                    sql &= "WHERE (PODTL_RECID IS NULL OR PODTL_RECID='') "
                    sql &= "AND PO_NO_PO='" & txtNo_PO.Text & "' "
                    sql &= "GROUP BY PO.PO_NO_PO, PO.PO_TGL_PO, PO.PO_SUPCO_MD "
                    Scom.CommandText = sql
                    sdar = Scom.ExecuteReader
                    If sdar.Read Then
                        txtNoFak.Enabled = False
                        txtPO_QTY.Text = Format(sdar("PO_QTY"), "#,##0")
                        txtPO_GROSS.Text = Format(CDbl(sdar("PO_GROSS")), "#,##.##############")
                        txtPO_PPN.Text = Format(CDbl(IFNULL(sdar("PO_PPN"), 0)), "#,##.##############")
                        txtPO_Total.Text = Format(CDbl(sdar("PO_GROSS")) + CDbl(IFNULL(sdar("PO_PPN"), 0)) + CDbl(IFNULL(sdar("PPN_BOTOL"), 0)), "#,##.##############")
                        txtTot_Item.Text = CDbl("0" & sdar("TOT_ITEM"))
                    Else
                        Err_msg = "Data Alokasi MBREAD Tidak ada."
                        GoTo Batal
                    End If
                End If

                sdar.Close()

                sdar = Nothing

                'sql = "Select S.SUP_NAMA AS SNAMA from DC_SUPPLIER_DC_V H,DC_SUPPLIER_T S " & _
                '    "Where H.SUP_FK_SUPID=s.SUP_SUPID And " & _
                '    "TBL_DC_KODE='" & cDC_KODE & _
                '    "' AND H.SUP_SUPKODE='" & cmbSUPCO.Text & "'"
                'Scom.CommandText = sql

                'txtNamaSupp.Text = "" & Scom.ExecuteScalar
                'If lblSNAMA.Text = "" Then
                '    lblSNAMA.Text = txtNamaSupp.Text
                'End If

                'txtSUPCO.Enabled = False
                txtTgl_PO.Enabled = False
                chkADA_HARGA.Enabled = False


                'double msg
                'Dim a As String = txtNo_PO.Text
                'btnSimpanPO.Focus()
                'txtNo_PO.Text = a

                Exit Try

Selesai:
                txtNo_PO.Text = ""
                txtTgl_PO.Text = ""
                txtTot_Item.Text = ""
                chkBUAT_PO.Checked = False
                chkADA_HARGA.Checked = False
                txtPO_QTY.Text = ""
                txtPO_GROSS.Text = ""
                txtPO_PPN.Text = ""
                txtPO_Total.Text = ""
                NoPO = ""
                txtNo_PO.Focus()
                Exit Try

Batal:
                MessageBox.Show(Err_msg, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                If NoPO <> "" Then
                    txtNo_PO.Text = NoPO
                Else
                    txtNo_PO.Text = ""
                    NoPO = ""
                    txtNo_PO.Focus()
                End If

                'e.Cancel = True

            Catch ex As Exception
                ShowError("Error Baca PO", ex)
                'MsgBox("Error Baca PO : Data PO Salah", MsgBoxStyle.Critical)
                'txtNo_PO.Text = ""
            End Try
        End If
    End Sub

    '    Private Sub txtNo_PO_Validating(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtNo_PO.Validating
    '        'TODO: Cek Item2 yang tidak maen di DC aktif (Jika ada Tolak PO)

    '        Dim Err_msg As String = ""

    '        'Tanpa PO
    '        If txtNo_PO.Text = "" Then
    '            lWithPO = False

    '            txtTgl_PO.Enabled = True
    '            'txtSUPCO.Enabled = True
    '            chkADA_HARGA.Enabled = True

    '            'txtTgl_PO.Text = Now.Date

    '            'chkADA_HARGA.Value = 1
    '            'chkBUAT_PO.Value = 0
    '            chkADA_HARGA.Checked = True
    '            chkBUAT_PO.Checked = False

    '            'txtPO_QTY.Text = Format(0, "#,##0")
    '            'txtPO_GROSS.Text = Format(0, "#,##.##############")
    '            'txtPO_PPN.Text = Format(0, "#,##.##############")
    '            'txtPO_Total.Text = Format(0, "#,##.##############")
    '            'txtTot_Item.Text = CInt("0")

    '            txtPO_QTY.Text = "0"
    '            txtPO_GROSS.Text = "0"
    '            txtPO_PPN.Text = "0"
    '            txtPO_Total.Text = "0"
    '            txtTot_Item.Text = "0"

    '            'DoEvents
    '            'txtTGL_PO.SetFocus
    '            'txtTGL_PO.SetFocus
    '            'SendKeys("{TAB}")

    '            Exit Sub
    '        End If
    '        lWithPO = True

    '        txtNo_PO.Text = txtNo_PO.Text.ToUpper
    '        If txtNo_PO.Text = NoPO Then
    '            Exit Sub
    '        End If

    '        If Len(txtNo_PO.Text) < 9 Then
    '            MsgBox("PO Tidak ada.", vbCritical)
    '            'txtNO_PO.Text = ""
    '            If NoPO <> "" Then
    '                txtNo_PO.Text = NoPO
    '            End If
    '            e.Cancel = True
    '            Exit Sub
    '        End If

    '        Dim sql As String
    '        Dim Scon As New OleDb.OleDbConnection(ConStrORA)
    '        Dim Scom As New OleDb.OleDbCommand("", Scon)
    '        Dim sdar As OleDb.OleDbDataReader

    '        'hack: Test
    '        'Dim Scon As New OracleClient.OracleConnection("user id=DCSIM;data source=SIMULASIA;password=DCSIM")
    '        'Dim Scom As New OracleClient.OracleCommand("", Scon)
    '        'Dim sdar As OracleClient.OracleDataReader
    '        Try
    '            Scon.Open()

    '            sql = "Select COUNT(*) From DC_JLR_DaftarPO_T Where NoPO='" & _
    '                txtNo_PO.Text & "' "
    '            'sql &= "AND TRUNC(Tanggal)=TRUNC(sysdate) "
    '            sql &= "AND NO_FAK='" & txtNoFak.Text & "' "

    '            Scom.CommandText = sql
    '            If Scom.ExecuteScalar > 0 Then
    '                Err_msg = "PO sudah pernah didaftar dengan faktur sama."
    '                GoTo Batal
    '            End If

    '            'sql = "SELECT * "
    '            'sql &= "FROM JLR_GET_SUM_DAFTARPO_V "
    '            'sql &= "Where PO_NO_PO='" & txtNo_PO.Text & "' "
    '            'sql &= "AND PO_GUDANG='" & cDC_KODE & "' "

    '            sql = " SELECT "
    '            sql &= "MAX(PO_RECID) AS RECIDx,MIN(PO_GUDANG) AS PO_GUDANG,PO.PO_NO_PO, "
    '            sql &= "PO.PO_TGL_PO, PO.PO_SUPCO_MD AS SUPID, "
    '            sql &= "GET_SUPCO(PO.PO_SUPCO_MD)AS SUPCO, "
    '            sql &= "COUNT(*) AS TOT_ITEM "
    '            sql &= ",SUM(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*PODTL_QTYB*PODTL_ISI_SATB) AS PO_QTY "
    '            sql &= ",SUM( IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*(PODTL_QTYB*PODTL_ISI_SATB*PODTL_PRICE- "
    '            sql &= "   ((PODTL_QTYB*PODTL_ISI_SATB)/((PODTL_QTYB*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
    '            sql &= "   *NVL(TotDisc,0))) ) AS PO_GROSS "
    '            sql &= ",SUM(CASE WHEN PODTL_PPN > 0 THEN (IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)"
    '            sql &= "	*((PODTL_QTYB*PODTL_ISI_SATB*PODTL_PRICE-((PODTL_QTYB*PODTL_ISI_SATB)"
    '            sql &= "	/((PODTL_QTYB*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
    '            sql &= "	*NVL(TotDisc,0)))*.1)) ELSE 0 END) AS PO_PPN "
    '            sql &= ",MIN(PO_UMUR) AS PO_UMUR "
    '            sql &= ",SUM(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*NVL(PODTL_PPN_BTL,0)) AS PPN_BOTOL "
    '            sql &= "FROM DC_PO_T PO "
    '            sql &= "LEFT JOIN DC_PODTL_T DT ON PO.PO_NO_PO = DT.PODTL_FK_NO_PO "
    '            sql &= "LEFT JOIN ("
    '            sql &= "	SELECT MBR_FK_PLUID,(MBR_TAG) AS MBR_TAG "
    '            sql &= "	FROM DC_BARANG_DC_V WHERE TBL_DC_KODE='" & cDC_KODE & "') BRG ON DT.PODTL_PLUMD=BRG.MBR_FK_PLUID "
    '            sql &= "LEFT JOIN ( "
    '            sql &= "	SELECT podisc_fk_no_po,PODISC_FK_PLU, "
    '            sql &= "	SUM(NVL(podisc_nilai,0)) AS TotDisc "
    '            sql &= "	FROM DC_PODISC_T "
    '            sql &= "	GROUP BY podisc_fk_no_po,PODISC_FK_PLU) S ON PO.PO_NO_PO=S.podisc_fk_no_po "
    '            sql &= "	AND DT.PODTL_PLUMD=S.PODISC_FK_PLU "
    '            sql &= "WHERE (PODTL_RECID IS NULL OR PODTL_RECID='') "
    '            sql &= "AND PO_NO_PO='" & txtNo_PO.Text & "' "
    '            sql &= "GROUP BY PO.PO_NO_PO, PO.PO_TGL_PO, PO.PO_SUPCO_MD "
    '            Scom.CommandText = sql

    '            sdar = Scom.ExecuteReader
    '            If sdar.Read = False Then
    '                Err_msg = "PO tidak ada. Atau Sudah BPB"
    '                GoTo Batal
    '            End If

    '            If sdar("SUPCO") <> lblSUPCO.Text And lblSUPCO.Text <> "" Then
    '                Err_msg = "Supplier tidak punya PO " & txtNo_PO.Text & "."
    '                GoTo Batal
    '            End If



    '            ''Cek Status PO
    '            If CType(sdar("PO_TGL_PO"), Date).AddDays(IIf(sdar("PO_UMUR") <= 0, 7, sdar("PO_UMUR"))) < Now.Date Then
    '                Err_msg = "PO Sudah Kadaluarsa."
    '                GoTo Batal
    '            End If

    '            Dim rc As String = sdar("RECIDx") & ""
    '            Select Case rc
    '                Case "C"
    '                    Err_msg = "PO Di-Closing"
    '                Case "B"
    '                    Err_msg = "PO Sudah ada BPB-nya"
    '                Case "H"
    '                    Err_msg = "PO Hangus"
    '                Case "A"
    '                    Err_msg = "PO Sedang dibuat BPB-nya"
    '                Case "1"
    '                    Err_msg = "Item PO dihapus"
    '                Case "2"
    '                    Err_msg = "PO Revisi"
    '            End Select
    '            If Err_msg <> "" Then GoTo Batal

    '            If IFNULL(sdar("PO_QTY"), 0) + IFNULL(sdar("PO_GROSS"), 0) + IFNULL(sdar("PO_PPN"), 0) = 0 Then
    '                Err_msg = "Qty, Gross & PPN Kosong."
    '                GoTo Batal
    '            End If

    '            'Cek Supp. MrBread
    '            'CEK TBL ALOKASI DAN CEK SJ
    '            Dim IsMBread As Boolean = IsMrBread(sdar("SUPCO") & "", cDC_KODE)
    '            If IsMBread Then
    '                Dim Scon2 As New OleDbConnection(ConStrORA)
    '                Dim Scom2 As New OleDbCommand("", Scon2)

    '                Try
    '                    Scon2.Open()
    '                    Scom2.CommandType = CommandType.StoredProcedure
    '                    Scom2.CommandText = "IMPORT_MBREAD('" & cDC_KODE & "')"
    '                    Scom2.ExecuteNonQuery()

    '                    Scom2.CommandType = CommandType.Text
    '                    Scom2.CommandText = "select CEK_MRBREAD ( '" & txtNoFak.Text & _
    '                        "', TO_DATE('" & Format(txtTglFaktur.Value, "yyyyMMdd") & "','YYYYMMDD'), '" & txtNo_PO.Text & "') as x from dual"
    '                    Err_msg = Scom2.ExecuteScalar & " "
    '                    If Err_msg.Substring(0, 1) = "1" Or Err_msg.Substring(0, 1) = "3" Then
    '                        '1;No. Faktur atau Tanggal Faktur Salah.
    '                        '3;Jumlah Item Faktur > Jumlah Item PO.

    '                        Err_msg = Err_msg.Substring(2)
    '                        GoTo Batal
    '                    Else
    '                        '2;Total Faktur Dan PO Tidak Sama.
    '                        If Err_msg.Substring(0, 1) = "2" Then
    '                            Err_msg = Err_msg.Substring(2)
    '                            MessageBox.Show(Err_msg, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
    '                        End If
    '                    End If
    '                    Err_msg = ""
    '                Catch ex As Exception
    '                    Throw ex
    '                Finally
    '                    Scon2.Close()
    '                End Try

    '            End If

    '            'isi TextBOX
    '            txtTgl_PO.Text = sdar("PO_TGL_PO")
    '            'txtSUPCO.Text = sdar("SUPCO")
    '            lblSUPID.Text = IFNULL(sdar("SUPID"), 0)
    '            'If lblSUPCO.Text = "" Then
    '            '    lblSUPCO.Text = sdar("SUPCO")
    '            'End If

    '            'Dim dr As Object
    '            'dr = Me.BindingContext(dsPo1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Current
    '            'dr.row("SUPID") = sdar("SUPID") & ""

    '            chkBUAT_PO.Checked = True ''''''''
    '            chkADA_HARGA.Checked = True ''''''

    '            txtTot_Item.Enabled = False
    '            txtPO_QTY.Enabled = False
    '            txtPO_GROSS.Enabled = False
    '            txtPO_PPN.Enabled = False

    '            If Not IsMBread Then
    '                txtPO_QTY.Text = Format(sdar("PO_QTY"), "#,##0")
    '                txtPO_GROSS.Text = Format(CDbl(sdar("PO_GROSS")), "#,##.##############")
    '                txtPO_PPN.Text = Format(CDbl(IFNULL(sdar("PO_PPN"), 0)), "#,##.##############")
    '                txtPO_Total.Text = Format(CDbl(sdar("PO_GROSS")) + CDbl(IFNULL(sdar("PO_PPN"), 0)) + CDbl(IFNULL(sdar("PPN_BOTOL"), 0)), "#,##.##############")
    '                txtTot_Item.Text = CDbl("0" & sdar("TOT_ITEM"))
    '            Else
    '                sdar.Close()

    '                sql = " SELECT "
    '                sql &= "MAX(PO_RECID) AS RECIDx,MIN(PO_GUDANG) AS PO_GUDANG,PO.PO_NO_PO, "
    '                sql &= "PO.PO_TGL_PO, PO.PO_SUPCO_MD AS SUPID, "
    '                'sql &= "GET_SUPCO(PO.PO_SUPCO_MD)AS SUPCO, "
    '                sql &= "COUNT(*) AS TOT_ITEM "
    '                sql &= ",SUM(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*NVL(BREAD.JUM,0)*PODTL_ISI_SATB) AS PO_QTY "
    '                sql &= ",SUM( IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*(NVL(BREAD.JUM,0)*PODTL_ISI_SATB*PODTL_PRICE- "
    '                sql &= "   ((NVL(BREAD.JUM,0)*PODTL_ISI_SATB)/((NVL(BREAD.JUM,0)*PODTL_ISI_SATB)+PODTL_FRAC_QTYB)"
    '                sql &= "   *NVL(TotDisc,0))) ) AS PO_GROSS "
    '                sql &= ",SUM(CASE WHEN PODTL_PPN > 0 THEN "
    '                sql &= "	(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*((NVL(BREAD.JUM,0)*PODTL_ISI_SATB*PODTL_PRICE- "
    '                sql &= "	((NVL(BREAD.JUM,0)*PODTL_ISI_SATB)/((NVL(BREAD.JUM,0)*PODTL_ISI_SATB)+PODTL_FRAC_QTYB) "
    '                sql &= "	*NVL(TotDisc,0)))*.1)) ELSE 0 END) AS PO_PPN "
    '                sql &= ",MIN(PO_UMUR) AS PO_UMUR "
    '                sql &= ",SUM(IsTag_BolehBPB(" & cDC_ID & ",MBR_TAG)*NVL(PODTL_PPN_BTL,0)) AS PPN_BOTOL "
    '                sql &= "FROM DC_PO_T PO "
    '                sql &= "LEFT JOIN DC_PODTL_T DT ON PO.PO_NO_PO = DT.PODTL_FK_NO_PO "
    '                sql &= "LEFT JOIN ("
    '                sql &= "	SELECT MBR_FK_PLUID,(MBR_TAG) AS MBR_TAG "
    '                sql &= "	FROM DC_BARANG_DC_V "
    '                sql &= "	WHERE TBL_DC_KODE='" & cDC_KODE & "') BRG ON DT.PODTL_PLUMD=BRG.MBR_FK_PLUID "
    '                sql &= "LEFT JOIN ( "
    '                sql &= "	SELECT podisc_fk_no_po,PODISC_FK_PLU, "
    '                sql &= "	SUM(NVL(podisc_nilai,0)) AS TotDisc "
    '                sql &= "	FROM DC_PODISC_T "
    '                sql &= "	GROUP BY podisc_fk_no_po,PODISC_FK_PLU) S ON PO.PO_NO_PO=S.podisc_fk_no_po "
    '                sql &= "	AND DT.PODTL_PLUMD=S.PODISC_FK_PLU "
    '                sql &= "LEFT JOIN ( "
    '                sql &= "	 SELECT   a.pluid AS plumd, SUM (a.qty) AS Jum "
    '                sql &= "     FROM alokasi_tampung a "
    '                sql &= "	 WHERE (a.no_sj = '" & txtNoFak.Text & "') "
    '                sql &= "   	 GROUP BY a.no_sj, a.tgl_sj, a.pluid "
    '                sql &= "	 order by plumd) BREAD ON  DT.podtl_plumd=BREAD.PLUMD "
    '                sql &= "WHERE (PODTL_RECID IS NULL OR PODTL_RECID='') "
    '                sql &= "AND PO_NO_PO='" & txtNo_PO.Text & "' "
    '                sql &= "GROUP BY PO.PO_NO_PO, PO.PO_TGL_PO, PO.PO_SUPCO_MD "
    '                Scom.CommandText = sql
    '                sdar = Scom.ExecuteReader
    '                If sdar.Read Then
    '                    txtPO_QTY.Text = Format(sdar("PO_QTY"), "#,##0")
    '                    txtPO_GROSS.Text = Format(CDbl(sdar("PO_GROSS")), "#,##.##############")
    '                    txtPO_PPN.Text = Format(CDbl(IFNULL(sdar("PO_PPN"), 0)), "#,##.##############")
    '                    txtPO_Total.Text = Format(CDbl(sdar("PO_GROSS")) + CDbl(IFNULL(sdar("PO_PPN"), 0)) + CDbl(IFNULL(sdar("PPN_BOTOL"), 0)), "#,##.##############")
    '                    txtTot_Item.Text = CDbl("0" & sdar("TOT_ITEM"))
    '                Else
    '                    Err_msg = "Data Alokasi MBREAD Tidak ada."
    '                    GoTo Batal
    '                End If
    '            End If

    '            sdar.Close()
    '            sdar = Nothing

    '            'sql = "Select S.SUP_NAMA AS SNAMA from DC_SUPPLIER_DC_V H,DC_SUPPLIER_T S " & _
    '            '    "Where H.SUP_FK_SUPID=s.SUP_SUPID And " & _
    '            '    "TBL_DC_KODE='" & cDC_KODE & _
    '            '    "' AND H.SUP_SUPKODE='" & cmbSUPCO.Text & "'"
    '            'Scom.CommandText = sql

    '            'txtNamaSupp.Text = "" & Scom.ExecuteScalar
    '            'If lblSNAMA.Text = "" Then
    '            '    lblSNAMA.Text = txtNamaSupp.Text
    '            'End If

    '            'txtSUPCO.Enabled = False
    '            txtTgl_PO.Enabled = False
    '            chkADA_HARGA.Enabled = False

    '            btnSimpanPO.Focus()

    '            Exit Try
    'Batal:
    '            MessageBox.Show(Err_msg, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
    '            If NoPO <> "" Then
    '                txtNo_PO.Text = NoPO
    '            Else
    '                txtNo_PO.Text = ""
    '                NoPO = ""
    '                txtNo_PO.Focus()
    '            End If

    '            e.Cancel = True
    '        Catch ex As Exception
    '            ShowError("Error Baca PO", ex)
    '        End Try
    '    End Sub

    '    Private Sub HandleColomPO(ByVal sender As Object, ByVal e As System.Data.DataColumnChangeEventArgs)
    '        If e.Column.ColumnName = "NOPO" Then
    '            'TODO: CEK TBL ALOKASI DAN CEK SJ
    '            'TODO: Cek Item2 yang tidak maen di DC aktif (Jika ada Tolak PO)

    '            Dim Err_msg As String

    '            'Tanpa PO
    '            If txtNo_PO.Text = "" Then
    '                lWithPO = False

    '                txtTgl_PO.Enabled = True
    '                txtSUPCO.Enabled = True
    '                chkADA_HARGA.Enabled = True

    '                txtTgl_PO.Text = Now.Date

    '                'chkADA_HARGA.Value = 1
    '                'chkBUAT_PO.Value = 0
    '                chkADA_HARGA.Checked = True
    '                chkBUAT_PO.Checked = False

    '                txtPO_QTY.Text = Format(0, "#,##0")
    '                txtPO_GROSS.Text = Format(0, "#,##.##############")
    '                txtPO_PPN.Text = Format(0, "#,##.##############")
    '                txtPO_Total.Text = Format(0, "#,##.##############")
    '                txtTot_Item.Text = CInt("0")

    '                'DoEvents
    '                'txtTGL_PO.SetFocus
    '                'txtTGL_PO.SetFocus
    '                'SendKeys("{TAB}")

    '                Exit Sub
    '            End If
    '            lWithPO = True

    '            txtNo_PO.Text = txtNo_PO.Text.ToUpper
    '            If txtNo_PO.Text = NoPO Then
    '                Exit Sub
    '            End If

    '            If Len(txtNo_PO.Text) < 9 Then
    '                MsgBox("PO Tidak ada.", vbCritical)
    '                'txtNO_PO.Text = ""
    '                'e.Cancel = True
    '                e.ProposedValue = e.Row(e.Column)
    '                Exit Sub
    '            End If

    '            Dim sql As String
    '            Dim Scon As New OleDb.OleDbConnection(ConStrORA)
    '            Dim Scom As New OleDb.OleDbCommand("", Scon)
    '            Try
    '                Scon.Open()
    '                sql = "Select COUNT(*) From DC_JLR_DaftarPO_T Where NoPO='" & _
    '                    txtNo_PO.Text & "' AND NO_FAK='" & txtNoFak.Text & "' To_Char(Tanggal)=To_Char(sysdate)"
    '                Scom.CommandText = sql
    '                If Scom.ExecuteScalar > 0 Then
    '                    Err_msg = "PO sudah pernah didaftar."
    '                    GoTo Batal
    '                End If

    '                sql = "SELECT MAX(PO_RECID) AS RECIDx,PO.PO_NO_PO, PO.PO_TGL_PO, PO.PO_SUPCO_MD as SUPID, GET_SUPCO(PO.PO_SUPCO_MD)AS SUPCO,"
    '                sql &= "COUNT(*) AS TOT_ITEM, SUM(DT.PODTL_QTYB) AS PO_QTY, "
    '                sql &= "SUM(((FLOOR(((PODTL_QTYB*PODTL_ISI_SATB)+ PODTL_FRAC_QTYB)/PODTL_ISI_SATB))*PODTL_ISI_SATB*PODTL_PRICE)-PODTL_DISC) AS PO_GROSS, "
    '                sql &= "SUM(CASE WHEN PODTL_PPN > 0 THEN (((FLOOR(((PODTL_QTYB*PODTL_ISI_SATB)+ PODTL_FRAC_QTYB)/PODTL_ISI_SATB))*PODTL_ISI_SATB*PODTL_PRICE)-PODTL_DISC)*.1 ELSE 0 END) AS PO_PPN, "
    '                sql &= "MAX(PO_UMUR) as PO_UMUR "
    '                sql &= "FROM DC_PO_T PO, DC_PODTL_T DT "
    '                sql &= "Where PO.PO_NO_PO = DT.PODTL_FK_NO_PO AND PO_NO_PO='" & txtNo_PO.Text & "' AND PO_GUDANG='" & cDC_KODE & "' "
    '                sql &= "GROUP BY PO.PO_NO_PO, PO.PO_TGL_PO, PO.PO_SUPCO_MD "
    '                Scom.CommandText = sql

    '                Dim sdar As OleDb.OleDbDataReader
    '                sdar = Scom.ExecuteReader
    '                If sdar.Read = False Then
    '                    Err_msg = "PO tidak ada."
    '                    GoTo Batal
    '                End If

    '                Dim sSupco As String
    '                Try
    '                    If sSupco = "" And dsPo1.DC_JLR_DAFTARJALUR_T.Rows(Me.BindingContext("DC_JLR_DAFTARJALUR_T").Position - 1)("SUPCO") <> "" Then
    '                        sSupco = dsPo1.DC_JLR_DAFTARJALUR_T.Rows(Me.BindingContext("DC_JLR_DAFTARJALUR_T").Position - 1)("SUPCO")
    '                    End If
    '                Catch

    '                End Try


    '                If sdar("SUPCO") <> sSupco And sSupco <> "" Then
    '                    Err_msg = "PO Harus dari Supplier yang Sama."
    '                    GoTo Batal
    '                End If
    '                Try
    '                    If sSupco = "" Then
    '                        dsPo1.DC_JLR_DAFTARJALUR_T.Rows(Me.BindingContext("DC_JLR_DAFTARJALUR_T").Position - 1)("SUPCO") = sdar("SUPCO")
    '                        sSupco = sdar("SUPCO")
    '                    End If
    '                Catch

    '                End Try

    '                ''Cek Status PO
    '                If CType(sdar("PO_TGL_PO"), Date).AddDays(IIf(sdar("PO_UMUR") <= 0, 7, sdar("PO_UMUR"))) < Now.Date Then
    '                    Err_msg = "PO Sudah Kadaluarsa."
    '                    GoTo Batal
    '                End If

    '                Select Case sdar("RECIDx") & ""
    '                    Case "C"
    '                        Err_msg = "PO Di-Closing"
    '                    Case "R"
    '                        Err_msg = "PO Sudah ada BPB-nya"
    '                    Case "H"
    '                        Err_msg = "PO Hangus"
    '                    Case "A"
    '                        Err_msg = "PO Sedang dibuat BPB-nya"
    '                    Case "1"
    '                        Err_msg = "Item PO dihapus"
    '                    Case "2"
    '                        Err_msg = "PO Revisi"
    '                End Select
    '                If Err_msg <> "" Then GoTo Batal

    '                If IFNULL(sdar("PO_QTY"), 0) + IFNULL(sdar("PO_GROSS"), 0) + IFNULL(sdar("PO_PPN"), 0) = 0 Then
    '                    Err_msg = "Qty, Gross & PPN Kosong."
    '                    GoTo Batal
    '                End If

    '                'isi TextBOX
    '                txtTgl_PO.Text = sdar("PO_TGL_PO")
    '                txtSUPCO.Text = sdar("SUPCO")
    '                lblSUPID.Text = IFNULL(sdar("SUPID"), 0)
    '                If lblSUPCO.Text = "" Then
    '                    lblSUPCO.Text = sdar("SUPCO")
    '                End If
    '                chkBUAT_PO.Checked = True ''''''''
    '                chkADA_HARGA.Checked = True ''''''
    '                txtPO_QTY.Text = Format(sdar("PO_QTY"), "#,##0")
    '                txtPO_GROSS.Text = Format(CDbl(sdar("PO_GROSS")), "#,##.##############")
    '                txtPO_PPN.Text = Format(CDbl(sdar("PO_PPN")), "#,##.##############")
    '                txtPO_Total.Text = Format(CDbl(sdar("PO_GROSS")) + CDbl(sdar("PO_PPN")), "#,##.##############")
    '                txtTot_Item.Text = CDbl("0" & sdar("TOT_ITEM"))


    '                sdar.Close()
    '                sdar = Nothing

    '                sql = "Select S.SUP_NAMA AS SNAMA from DC_SUPPLIER_DC_V H,DC_SUPPLIER_T S " & _
    '                    "Where H.SUP_FK_SUPID=s.SUP_SUPID And " & _
    '                    "TBL_DC_KODE='" & cDC_KODE & _
    '                    "' AND H.SUP_SUPKODE='" & txtSUPCO.Text & "'"
    '                Scom.CommandText = sql

    '                txtNamaSupp.Text = "" & Scom.ExecuteScalar
    '                If lblSNAMA.Text = "" Then
    '                    lblSNAMA.Text = txtNamaSupp.Text
    '                End If

    '                txtSUPCO.Enabled = False
    '                txtTgl_PO.Enabled = False
    '                chkADA_HARGA.Enabled = False

    '                Exit Try
    'Batal:
    '                MessageBox.Show(Err_msg, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
    '                txtNo_PO.Text = ""
    '                NoPO = ""
    '                txtNo_PO.Focus()
    '                e.ProposedValue = e.Row(e.Column)
    '            Catch ex As Exception
    '                ShowError("Error Baca PO", ex)
    '            End Try

    '            'If MessageBox.Show("Haloo", "aaa", MessageBoxButtons.YesNo) <> DialogResult.Yes Then
    '            '    e.ProposedValue = e.Row(e.Column)
    '            'End If
    '        End If
    '    End Sub
    '    Private Sub HandleRowPo(ByVal sender As Object, ByVal e As System.Data.DataRowChangeEventArgs)
    '        If e.Action = DataRowAction.Add Then
    '            If e.Row("SUPCO") = "" Then
    '                'MessageBox.Show("AAAAAAAAAAAAAAAAAAAAA")
    '                Debug.WriteLine("SUPCO Blank")
    '            End If
    '        End If
    '    End Sub
#End Region

    'Private Sub txtSUPCO_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs)
    '    'If txtSUPCO.Text = "" Then 'And Not lWithPO
    '    '    MessageBox.Show("KODE SUPPLIER HARUS DIISI", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
    '    '    e.Cancel = True
    '    '    Exit Sub
    '    'End If

    '    'If txtSUPCO.Text <> lblSUPCO.Text And lblSUPCO.Text <> "" Then
    '    '    MessageBox.Show("Pedaftaran Harus Dari Supplier yang Sama.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
    '    '    e.Cancel = True
    '    '    Exit Sub
    '    'End If

    '    If Len(txtSUPCO.Text) < 4 Then
    '        MessageBox.Show("Supplier " & txtSUPCO.Text & " tidak ada !!!", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
    '        e.Cancel = True
    '        Exit Sub
    '    End If

    '    ' '' ''        Dim sql As String
    '    ' '' ''        Dim Scon As New OleDbConnection(ConStrORA)
    '    ' '' ''        Dim Scom As New OleDbCommand("", Scon)
    '    ' '' ''        Dim Sdar As OleDbDataReader
    '    ' '' ''        Try
    '    ' '' ''            Scon.Open()
    '    ' '' ''            'Todo: Buat PO tidak ada Kolom
    '    ' '' ''            sql = "Select S.SUP_NAMA AS SNAMA,H.SUP_SUPKODE AS SUPCO,H.SUP_FLAG_BUATPO AS BUAT_PO,s.SUP_SUPID AS SUPID from DC_SUPPLIER_DC_V H,DC_SUPPLIER_T S "
    '    ' '' ''            sql &= "Where H.SUP_FK_SUPID=s.SUP_SUPID And "
    '    ' '' ''            sql &= "TBL_DC_KODE='" & cDC_KODE
    '    ' '' ''            sql &= "' AND H.SUP_SUPKODE='" & txtSUPCO.Text & "'"
    '    ' '' ''            Scom.CommandText = sql
    '    ' '' ''            Sdar = Scom.ExecuteReader
    '    ' '' ''            If Sdar.Read Then
    '    ' '' ''                'Cek With PO
    '    ' '' ''                If Not lWithPO Then
    '    ' '' ''                    If "" & Sdar("BUAT_PO") = "Y" Then
    '    ' '' ''                        MsgBox("Supplier " & txtSUPCO.Text & " Harus Pakai PO !!!", vbCritical)
    '    ' '' ''                        txtSUPCO.Text = ""
    '    ' '' ''                        txtNamaSupp.Text = ""
    '    ' '' ''                        e.Cancel = True
    '    ' '' ''                        GoTo ex
    '    ' '' ''                    Else
    '    ' '' ''                        txtPO_QTY.Focus()
    '    ' '' ''                    End If
    '    ' '' ''                End If
    '    ' '' ''                txtNamaSupp.Text = Sdar("SNAMA") & ""

    '    ' '' ''                lblSUPID.Text = IFNULL(Sdar("SUPID"), 0)

    '    ' '' ''                If lblSUPCO.Text = "" Then
    '    ' '' ''                    lblSUPCO.Text = Sdar("SUPCO")
    '    ' '' ''                End If
    '    ' '' ''                If lblSNAMA.Text = "" Then
    '    ' '' ''                    lblSNAMA.Text = txtNamaSupp.Text
    '    ' '' ''                End If
    '    ' '' ''            Else
    '    ' '' ''                MsgBox("Supplier " & txtSUPCO.Text & " tidak ada !!!", vbCritical)
    '    ' '' ''                e.Cancel = True
    '    ' '' ''            End If
    '    ' '' ''ex:         Sdar.Close()
    '    ' '' ''        Catch ex As Exception
    '    ' '' ''            ShowError("Error Baca Supplier", ex)
    '    ' '' ''        Finally
    '    ' '' ''            Scon.Close()
    '    ' '' ''            Scon = Nothing
    '    ' '' ''        End Try
    'End Sub
    'Private Sub txtNoMobil_Validate(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs)

    '    Dim Scon As New OleDbConnection(ConStrORA)
    '    Dim Scom As New OleDbCommand("", Scon)

    '    Scon.Open()
    '    Scom.CommandText = "Select COUNT(*) From DC_JLR_DaftarJalur_T Where NoMobil='" & _
    '        txtNoMobil.Text & "' AND TO_CHAR(Tanggal,'dd/mon/yyyy')=TO_CHAR(sysdate,'dd/mon/yyyy') AND DC_ID=" & cDC_ID
    '    If Scom.ExecuteScalar > 0 Then
    '        e.Cancel = True
    '        MsgBox("No Mobil sudah didaftarkan.", vbCritical)
    '    End If
    '    Scon.Close()
    'End Sub

    Private Sub btnPrev2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrev2.Click
        Try
            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Position -= 1
            'btn_Prev(lblSUPCO.Text)
            If lblBPB_NO.Text <> "" Then
                btnPrint.Enabled = False
                btnPrintUlang.Enabled = False
                btnHapusPO.Enabled = False
                btnEditPO.Enabled = False
            Else
                btnHapusPO.Enabled = True
                btnEditPO.Enabled = True
            End If
            LoadNoAntrian()
        Catch 'ex As Exception
            'Throw ex
        End Try
    End Sub
    Private Sub btnNext2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext2.Click

        Try
            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Position += 1
            'btn_Next(lblSUPCO.Text)
            If lblBPB_NO.Text <> "" Then
                btnPrint.Enabled = False
                btnPrintUlang.Enabled = False
                btnHapusPO.Enabled = False
                btnEditPO.Enabled = False
            Else
                btnHapusPO.Enabled = True
                btnEditPO.Enabled = True
                txtNoAntrian.Text = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T,NOURUT").Current
            End If
            LoadNoAntrian()
        Catch 'ex As Exception
            'Throw ex
        End Try
    End Sub

    Private Function GetIdDaftarJalur() As Integer
        Dim Scon As New OleDbConnection(ConStrORA)
        Dim Scom As New OleDbCommand("", Scon)
        Dim n As Integer


        Scon.Open()
        Scom.CommandText = "select DC_JLR_DaftarJalur_T_SEQ.nextval from dual"
        n = Scom.ExecuteScalar()
        Scon.Close()

        Return n
    End Function
    Private Function GetIdDaftarPO() As Integer
        Dim Scon As New OleDbConnection(ConStrORA)
        Dim Scom As New OleDbCommand("", Scon)
        Dim n As Integer

        Scon.Open()
        Scom.CommandText = "select DC_JLR_DaftarPO_T_SEQ.nextval from dual"
        n = Scom.ExecuteScalar()
        Scon.Close()

        Return n
    End Function
    Private Function KasihNoAntrian() As Boolean

        Dim drMobil As Object
        drMobil = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Current


        Dim nNoUrut As Integer = NextAntrian()

        '        'ISI Booking Jalur
        '        Dim Scon As New OleDbConnection(ConStrORA)
        '        Dim Scom As New OleDbCommand("Select A.Jalur,S.Jam1,S.Jam2,S.ID_Antrian From DC_JLR_SUPP1ST_V S Left Join DC_JLR_Antrian_T A ON S.ID_Antrian=A.ID_Antrian " & _
        '            "Where S.SUPCO='" & txtSUPCO.Text & "' AND A.DC_ID=" & cDC_ID & _
        '            "", Scon)
        '        Dim Sdar As OleDbDataReader
        '        Dim Sdar2 As OleDbDataReader

        '        If Sdar.Read Then
        '            'Cek Supp BESAR langsung masuk (Jam Supp)
        '            If Not IsNothing(Sdar("jam1")) Then
        '                dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("Jalur") = Sdar("Jalur")

        '                'cek Boking Kosong
        '                Scom.CommandText = "Select Count(*) as Jum From DC_JLR_Antrian_T " & _
        '                    "Where Jalur='" & dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("Jalur") & _
        '                    "' AND  (Supplier ='' Or Supplier IS NULL) AND DC_ID=" & cDC_ID
        '                If Scom.ExecuteScalar > 0 Then
        '                    'cek Jam Booking
        '                    If Now.ToShortTimeString >= Sdar("jam1") And Now.ToShortTimeString <= Sdar("JAM2") Then
        'MasukinSupp:            'Masukkan Supplier
        '                        dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("Recid") = 2
        '                        dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("TglStart") = Now()
        '                        Scom.CommandText = _
        '                            "UPDATE DC_JLR_Antrian_T SET Supplier='" & txtSUPCO.Text & _
        '                            "', NoAntrian=" & nNoUrut & " Where Jalur='" & dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("Jalur") & "' AND DC_ID=" & cDC_ID
        '                        Scom.ExecuteNonQuery()

        '                        Scom.CommandText = "INSERT INTO DC_JLR_TempAntrian_T ( Jalur, SUPCO, SNAMA, NoMobil, NoAntrian,DC_ID) " & _
        '                                                    "VALUES('" & dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("Jalur") & "','" & txtSUPCO.Text & "','" & _
        '                                                    txtNamaSupp.Text & "','" & txtNoMobil.Text & "'," & nNoUrut & "," & cDC_ID & ")"
        '                        Scom.ExecuteNonQuery()
        '                    Else
        '                        'Todo:Cek Jam Bebas
        '                        Scom.CommandText = "Select Count(*) as Jum from DC_JLR_Supp1st_V where ID_ANTRIAN=" & Sdar("ID_Antrian") & _
        '                            " AND TO_CHAR(SYSDATE,'hh24:mi:ss') between TO_CHAR(jam1,'hh24:mi:ss') and " & _
        '                            "TO_CHAR(jam1+0.5/24,'hh:mi:ss')"
        '                        If Scom.ExecuteScalar = 0 Then
        '                            GoTo MasukinSupp
        '                        End If
        '                    End If
        '                End If
        '            Else
        '                'Supplier Kecil langsung Masuk Pada Jam Jalur -nya

        '                'Cek Jalurnya Masih Aktif
        '                Scom.CommandText = "Select Supplier,NoAntrian From DC_JLR_Antrian_T " & _
        '                    "Where Jalur='" & Sdar("Jalur") & _
        '                    "' AND TO_CHAR(SYSDATE,'hh24:mi:ss') BETWEEN TO_CHAR(jam1,'hh24:mi:ss') and TO_CHAR(jam2,'hh24:mi:ss') AND DC_ID=" & cDC_ID
        '                Sdar = Scom.ExecuteReader

        '                If Sdar.Read Then
        '                    dsPo1.DC_JLR_DAFTARJALUR_T.Rows(X)("Jalur") = Sdar("Jalur")
        '                    If "" & Sdar("Supplier") = "" Then
        '                        GoTo MasukinSupp
        '                    End If
        '                End If
        '            End If
        '        End If
        '        Sdar.Close()

        drMobil.ROW("NOURUT") = nNoUrut
        'drMobil.ROW("SUPCO") = txtSUPCO.Text
        drMobil.ROW("SUPCO") = CmbSUPCO.Text
        Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").EndCurrentEdit()
    End Function
    Private Function NextAntrian() As Integer
        Dim Scon As New OleDbConnection(ConStrORA)
        Dim Scom As New OleDbCommand("", Scon)
        Dim n As Integer

        Scon.Open()
        Scom.CommandText = "Select COUNT(*) From DC_JLR_Setting_T WHERE DC_ID=" & cDC_ID
        If Scom.ExecuteScalar = 0 Then
            Scom.CommandText = "INSERT INTO VALUES(" & cDC_ID & ",2,TRUNC(SYSDATE())"
            Scom.ExecuteNonQuery()
            Return 1
        End If

        Scom.CommandText = "Select NextNoUrut From DC_JLR_Setting_T WHERE DC_ID=" & cDC_ID
        n = "0" & Scom.ExecuteScalar()
        If n = 0 Then
            n = 1
        End If

        Scom.CommandText = "UPDATE DC_JLR_Setting_T  SET NextNoUrut=" & n & "+1 WHERE DC_ID=" & cDC_ID
        Scom.ExecuteNonQuery()

        Scon.Close()

        Return n

    End Function

    Private Sub btnHapusPO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHapusPO.Click
        If txtNo_PO.Text = "" Or txtNoFak.Text = "" Then
            MessageBox.Show("Tidak Bisa Hapus Pendaftaran Tanpa PO.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        Dim X As Integer
        Dim dr As Object
        Dim sisasatu As String
        If txtNoAntrian.Text = "" Then
            txtNoAntrian.Text = NoAntrian
        End If
        X = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Position
        dr = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Current
        If LBMobil.SelectedIndex = -1 And LBMobil.Items.Count <> 0 Then
            LBMobil.SelectedIndex = 0
        End If
        '        Dim dt_DAFTARJALUR As DataTable = getDS("    SELECT id_daftarjalur" & _
        '"   FROM dc_jlr_daftarjalur_t" & _
        '"  WHERE nomobil = '" & LBMobil.Text & "' AND nourut = '" & txtNoAntrian.Text & "' AND supco = '" & lblSUPCO.Text & "'", ConStrORA).Tables(0)

        Dim dt_DAFTARPO As DataTable = getDS(" SELECT id_daftarjalur, id_daftarpo, nopo, recid" & _
"   FROM dc_jlr_daftarpo_t" & _
"  WHERE supco = '" & lblSUPCO.Text & "'" & _
"    AND no_fak ='" & txtNoFak.Text & "'" & _
"    AND nopo = '" & txtNo_PO.Text & "'", ConStrORA).Tables(0)

        If dt_DAFTARPO.Rows.Count <= 0 Then
            MsgBox("Tidak Ada Data yang dihapus !", vbCritical)
            Exit Sub
        End If
        Dim id_po As String = dt_DAFTARPO.Rows(0)("ID_DAFTARPO").ToString
        Dim id_jlr As String = dt_DAFTARPO.Rows(0)("id_daftarjalur").ToString
        Dim nopo As String = IIf(IsDBNull(dt_DAFTARPO.Rows(0)("NOPO").ToString), "", dt_DAFTARPO.Rows(0)("nopo").ToString)


        Dim dt_Pointer As DataTable = getDS(" SELECT *" & _
                                            "   FROM dc_jlr_daftarpo_t" & _
                                            "  WHERE supco = '" & lblSUPCO.Text & "'" & _
                                            "    AND id_daftarjalur = '" & id_jlr & "'", ConStrORA).Tables(0)
        If dt_Pointer.Rows.Count <= 0 Then
            MsgBox("Tidak Ada Data yang dihapus !", vbCritical)
            Exit Sub
        End If

        If "" & dt_DAFTARPO.Rows(0)("RECID").ToString = "B" Then
            MsgBox("Tidak Bisa Hapus, Faktur sudah ada BPB-nya !", vbCritical)
            Exit Sub
        End If

        Dim Scon As New OleDbConnection(ConStrORA)
        Dim Scom As New OleDbCommand("", Scon)
        Dim n As String = ""
        'Dim id_jlr As String = dr.row("ID_DAFTARJALUR")
        'Dim id_po As String = dr.row("ID_DAFTARPO")
        'Dim nopo As String = IIf(IsDBNull(dr.row("NOPO")), "", dr.row("NOPO"))

        If id_po <> "" And txtNoFak.Text <> "" Then
            Scon.Open()
            Scom.CommandText = "Select distinct ID_FK,NOPO From DC_HH_SCAN_T WHERE nopo ='" & nopo & "' and id_fk='" & id_jlr & "' and DC_ID=" & cDC_ID
            n = IIf(IsDBNull(Scom.ExecuteScalar), "", Scom.ExecuteScalar)
            Dim PO As String = ""
            If n <> "" Then
                Dim dread As OleDbDataReader
                dread = Scom.ExecuteReader
                dread.Read()
                PO = "" + dread.Item("NOPO").ToString
                dread.Close()
            End If
            'If nopo = PO Then
            '    MsgBox("Tidak Bisa Hapus Pendaftaran, PO Sudah Di Periksa !", vbCritical)

            'End If
            'cek sudah ada yang di SLP blom?
            Dim query As String = "SELECT COUNT(*) FROM dc_trnbpb_dtl_t a, dc_trnbpb_hdr_t b " & _
            "WHERE(a.NO_PO = b.NO_PO And a.hdr_fk_id = b.HDR_ID) " & _
            "AND a.frac_slp IS NOT NULL AND b.no_po='" & nopo & "' AND b.NO_FAKTUR='" & txtNoFak.Text & "' " & _
            "GROUP BY b.no_po, b.no_faktur"
            If vb.execScalar(ConStrORA, query) > 0 And nopo = PO Then
                MsgBox("di faktur dan PO ini sudah ada PLU yang diSLP.. Data tidak dapat dihapus!!!")
            Else
                Dim msg As String = ""
                If nopo = PO Then
                    msg = "PO sedang dipegang Handheld.. Yakin hapus faktur :" & txtNoFak.Text & _
                                   " dengan No. PO : " & nopo & " dari pendaftaran?"
                Else
                    msg = "Yakin hapus faktur :" & txtNoFak.Text & _
                                   " dengan No. PO : " & nopo & " dari pendaftaran?"
                End If
                If MessageBox.Show(msg, "Konfirmasi", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                    Dim lHapusMobil As Boolean
                    lHapusMobil = False
                    If dt_Pointer.Rows.Count = 1 Then
                        If MsgBox("PO HANYA 1. Hapus PO Akan Menghapus Pendaftaran ini. LANJUTKAN?", vbExclamation Or vbYesNo Or vbDefaultButton2) = vbNo Then
                            ' btnDaftar_Click(sender, e)
                            Exit Sub
                        End If
                        lHapusMobil = True
                        'btnDaftar_Click(sender, e)

                    End If
                    Debug.WriteLine("Hapus PO ")
                    'Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").RemoveAt(X)


                    Scom.CommandText = "delete from dc_jlr_daftarpo_t where " & _
                                       "id_daftarpo=" & id_po
                    Scom.ExecuteNonQuery()
                    Scon.Close()

                    If lHapusMobil Then
                        Debug.WriteLine("Hapus Mobil ")
                        'X = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position
                        'Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").RemoveAt(X)
                        'If Scon.State = ConnectionState.Open Then
                        '    Scon.Close()
                        'End If
                        Scon.Open()
                        Scom.CommandText = "delete from dc_jlr_daftarjalur_t where " & _
                                           "id_daftarjalur=" & id_jlr
                        Scom.ExecuteNonQuery()
                        Scon.Close()
                    End If

                    Try
                        Dim ch As dsPO
                        ch = DsPO1.GetChanges
                        If (Not (ch) Is Nothing) Then
                            Me.olcon.Open()
                            Debug.WriteLine("Delete Daftar Langsung: " & oldapPO.Update(ch))
                            Debug.WriteLine("Delete Mobil Langsung: " & oldapMobil.Update(ch))
                            'Dim Olcom As New OleDbCommand("", olcon)
                            'Olcom.CommandText = "Delete From DC_JLR_DaftarPO_T where "
                            'Olcom.ExecuteNonQuery()
                        End If
                        DsPO1.DC_JLR_DAFTARJALUR_T.AcceptChanges()
                        DsPO1.DC_JLR_DAFTARPO_T.AcceptChanges()
                        Dim dt_getHDRID As DataTable = getDS("select hdr_id  from dc_trnbpb_hdr_t where id_daftarpo = '" & id_po & "'", ConStrORA).Tables(0)
                        Dim HDRIDHAPUS As String = ""
                        If dt_getHDRID.Rows.Count > 0 Then
                            HDRIDHAPUS = dt_getHDRID.Rows(0)(0).ToString

                            Scon.Open()
                            Scom.CommandText = "DELETE FROM dc_trnbpb_dtl_t WHERE hdr_fk_id = '" & HDRIDHAPUS & "'"
                            Scom.ExecuteNonQuery()

                            Scom.CommandText = "DELETE FROM dc_trnbpb_hdr_t WHERE id_daftarpo = '" & id_po & "'"
                            Scom.ExecuteNonQuery()

                            Scom.CommandText = "DELETE FROM dc_trnbpb_dtl_h WHERE hdr_fk_id = '" & HDRIDHAPUS & "'"
                            Scom.ExecuteNonQuery()

                            Scom.CommandText = "DELETE FROM dc_trnbpb_hdr_h WHERE id_daftarpo = '" & id_po & "'"
                            Scom.ExecuteNonQuery()
                            Scon.Close()
                            'SELECT hdr_id  FROM dc_trnbpb_hdr_t WHERE id_daftarpo = 1297809

                            'SELECT * FROM dc_trnbpb_dtl_t WHERE hdr_fk_id = 85
                        End If


                    Catch updateException As System.Exception
                        'Add your error handling code here.
                        Throw updateException
                    Finally
                        'Close the connection whether or not the exception was thrown.
                        btn_Next(lblSUPCO.Text)
                        Me.olcon.Close()
                    End Try
                    If lHapusMobil Then
                        Me.Close()
                    End If
                End If
            End If
            Scon.Close()
            LoadDataSet()
            Dim loadnourut As String = frmLoadPO.NOURUT
            For i As Integer = 0 To DsPO1.DC_JLR_DAFTARJALUR_T.Rows.Count - 1
                If DsPO1.DC_JLR_DAFTARJALUR_T.Rows(i)("NOURUT").ToString = loadnourut Then
                    Exit For
                Else
                    Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position += 1
                End If
            Next
            mobil()
        End If
    End Sub
    'Private Sub btnHapusPO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHapusPO.Click
    '    Dim X As Integer
    '    Dim dr As Object
    '    X = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Position
    '    dr = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Current


    '    Dim dt_Pointer As DataTable = getDS("select no_faktur, hdr_id from dc_trnbpb_hdr_t where supco = '" & lblSUPCO.Text & "' ", ConStrORA).Tables(0)
    '    If dt_Pointer.Rows.Count <= 0 Then
    '        MsgBox("Tidak Ada Data yang dihapus !", vbCritical)
    '        Exit Sub
    '    End If

    '    If "" & dr.row("Recid") = "B" Then
    '        MsgBox("Tidak Bisa Hapus, Faktur sudah ada BPB-nya !", vbCritical)
    '        Exit Sub
    '    End If

    '    Dim Scon As New OleDbConnection(ConStrORA)
    '    Dim Scom As New OleDbCommand("", Scon)
    '    Dim n As String = ""
    '    Dim id_jlr As String = dr.row("ID_DAFTARJALUR")
    '    Dim id_po As String = dr.row("ID_DAFTARPO")
    '    Dim nopo As String = IIf(IsDBNull(dr.row("NOPO")), "", dr.row("NOPO"))

    '    If id_po <> "" And txtNoFak.Text <> "" Then
    '        Scon.Open()
    '        Scom.CommandText = "Select distinct ID_FK,NOPO From DC_HH_SCAN_T WHERE nopo ='" & nopo & "' and id_fk='" & dr.row("ID_DAFTARJALUR") & "' and DC_ID=" & cDC_ID
    '        n = IIf(IsDBNull(Scom.ExecuteScalar), "", Scom.ExecuteScalar)
    '        Dim PO As String = ""
    '        If n <> "" Then
    '            Dim dread As OleDbDataReader
    '            dread = Scom.ExecuteReader
    '            dread.Read()
    '            PO = "" + dread.Item("NOPO").ToString
    '            dread.Close()
    '        End If
    '        'If nopo = PO Then
    '        '    MsgBox("Tidak Bisa Hapus Pendaftaran, PO Sudah Di Periksa !", vbCritical)

    '        'End If
    '        'cek sudah ada yang di SLP blom?
    '        Dim query As String = "SELECT COUNT(*) FROM dc_trnbpb_dtl_t a, dc_trnbpb_hdr_t b " & _
    '        "WHERE(a.NO_PO = b.NO_PO And a.hdr_fk_id = b.HDR_ID) " & _
    '        "AND a.frac_slp IS NOT NULL AND b.no_po='" & nopo & "' AND b.NO_FAKTUR='" & txtNoFak.Text & "' " & _
    '        "GROUP BY b.no_po, b.no_faktur"
    '        If vb.execScalar(ConStrORA, query) > 0 And nopo = PO Then
    '            MsgBox("di faktur dan PO ini sudah ada PLU yang diSLP.. Data tidak dapat dihapus!!!")
    '        Else
    '            Dim msg As String = ""
    '            If nopo = PO Then
    '                msg = "PO sedang dipegang Handheld.. Yakin hapus faktur :" & txtNoFak.Text & _
    '                               " dengan No. PO : " & nopo & " dari pendaftaran?"
    '            Else
    '                msg = "Yakin hapus faktur :" & txtNoFak.Text & _
    '                               " dengan No. PO : " & nopo & " dari pendaftaran?"
    '            End If
    '            If MessageBox.Show(msg, "Konfirmasi", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
    '                Dim lHapusMobil As Boolean
    '                lHapusMobil = False
    '                If Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Count = 1 Then
    '                    If MsgBox("PO HANYA 1. Hapus PO Akan Menghapus Pendaftaran ini. LANJUTKAN?", vbExclamation Or vbYesNo Or vbDefaultButton2) = vbNo Then
    '                        Exit Sub
    '                    End If
    '                    lHapusMobil = True
    '                End If
    '                Debug.WriteLine("Hapus PO " & X)
    '                Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").RemoveAt(X)


    '                Scom.CommandText = "delete from dc_jlr_daftarpo_t where " & _
    '                                   "id_daftarpo=" & id_po
    '                Scom.ExecuteNonQuery()
    '                Scon.Close()

    '                If lHapusMobil Then
    '                    Debug.WriteLine("Hapus Mobil " & X)
    '                    X = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position
    '                    Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").RemoveAt(X)
    '                    If Scon.State = ConnectionState.Open Then
    '                        Scon.Close()
    '                    End If
    '                    Scon.Open()
    '                    Scom.CommandText = "delete from dc_jlr_daftarjalur_t where " & _
    '                                       "id_daftarjalur=" & id_jlr
    '                    Scom.ExecuteNonQuery()
    '                    Scon.Close()
    '                End If

    '                Try
    '                    Dim ch As dsPO
    '                    ch = DsPO1.GetChanges
    '                    If (Not (ch) Is Nothing) Then
    '                        Me.olcon.Open()
    '                        Debug.WriteLine("Delete Daftar Langsung: " & oldapPO.Update(ch))
    '                        Debug.WriteLine("Delete Mobil Langsung: " & oldapMobil.Update(ch))
    '                        'Dim Olcom As New OleDbCommand("", olcon)
    '                        'Olcom.CommandText = "Delete From DC_JLR_DaftarPO_T where "
    '                        'Olcom.ExecuteNonQuery()
    '                    End If
    '                    DsPO1.DC_JLR_DAFTARJALUR_T.AcceptChanges()
    '                    DsPO1.DC_JLR_DAFTARPO_T.AcceptChanges()
    '                Catch updateException As System.Exception
    '                    'Add your error handling code here.
    '                    Throw updateException
    '                Finally
    '                    'Close the connection whether or not the exception was thrown.
    '                    Me.olcon.Close()
    '                End Try
    '            End If
    '        End If
    '        'End If
    '        Scon.Close()
    '    End If
    '    'If nopo <> "" Then
    '    '    Scon.Open()
    '    '    Scom.CommandText = "Select distinct ID_FK,NOPO From DC_HH_SCAN_T WHERE nopo ='" & nopo & "' and id_fk='" & dr.row("ID_DAFTARJALUR") & "' and DC_ID=" & cDC_ID
    '    '    n = IIf(IsDBNull(Scom.ExecuteScalar), "", Scom.ExecuteScalar)

    '    '    If n <> "" Then
    '    '        Dim dread As OleDbDataReader
    '    '        dread = Scom.ExecuteReader
    '    '        dread.Read()
    '    '        Dim PO As String = "" + dread.Item("NOPO").ToString
    '    '        If nopo = PO Then
    '    '            MsgBox("Tidak Bisa Hapus Pendaftaran, PO Sudah Di Periksa !", vbCritical)
    '    '            dread.Close()
    '    '            Scon.Close()
    '    '            Exit Sub
    '    '        End If
    '    '        dread.Close()
    '    '    End If
    '    '    Scon.Close()
    '    'End If

    '    'If MsgBox("Menghapus Faktur akan menghapus BPB bila BPB sudah diinput." & vbCrLf & _
    '    '    "Hapus Faktur No." & txtNoFak.Text & " ?", vbExclamation Or vbYesNo Or vbDefaultButton2) = vbNo Then
    '    '    Exit Sub
    '    'End If

    '    'Dim X As Integer
    '    'X = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Position


    '    'If X < 0 Then
    '    '    MsgBox("Tidak Ada Data yang dihapus !", vbCritical)
    '    '    Exit Sub
    '    'End If
    '    'Dim dr As Object
    '    'dr = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Current


    '    'If "" & dr.row("Recid") = "B" Then
    '    '    MsgBox("Tidak Bisa Hapus, Faktur sudah ada BPB-nya !", vbCritical)
    '    '    Exit Sub
    '    'End If

    '    'Dim Scon As New OleDbConnection(ConStrORA)
    '    'Dim Scom As New OleDbCommand("", Scon)
    '    'Dim n As String = ""
    '    'Dim id_jlr As String = dr.row("ID_DAFTARJALUR")
    '    'Dim id_po As String = dr.row("ID_DAFTARPO")
    '    'Dim nopo As String = IIf(IsDBNull(dr.row("NOPO")), "", dr.row("NOPO"))

    '    'If nopo <> "" Then
    '    '    Scon.Open()
    '    '    Scom.CommandText = "Select distinct ID_FK,NOPO From DC_HH_SCAN_T WHERE nopo ='" & nopo & "' and id_fk='" & dr.row("ID_DAFTARJALUR") & "' and DC_ID=" & cDC_ID
    '    '    n = IIf(IsDBNull(Scom.ExecuteScalar), "", Scom.ExecuteScalar)

    '    '    If n <> "" Then
    '    '        Dim dread As OleDbDataReader
    '    '        dread = Scom.ExecuteReader
    '    '        dread.Read()
    '    '        Dim PO As String = "" + dread.Item("NOPO").ToString
    '    '        If nopo = PO Then
    '    '            MsgBox("Tidak Bisa Hapus Pendaftaran, PO Sudah Di Periksa !", vbCritical)
    '    '            dread.Close()
    '    '            Scon.Close()
    '    '            Exit Sub
    '    '        End If
    '    '        dread.Close()
    '    '    End If
    '    '    Scon.Close()
    '    'End If

    '    ''If MsgBox("Menghapus Faktur akan menghapus BPB bila BPB sudah diinput." & vbCrLf & _
    '    ''    "Hapus Faktur No." & txtNoFak.Text & " ?", vbExclamation Or vbYesNo Or vbDefaultButton2) = vbNo Then
    '    ''    Exit Sub
    '    ''End If

    '    'Dim lHapusMobil As Boolean
    '    'lHapusMobil = False
    '    'If Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Count = 1 Then
    '    '    If MsgBox("PO HANYA 1. Hapus PO Akan Menghapus Pendaftaran ini. LANJUTKAN?", vbExclamation Or vbYesNo Or vbDefaultButton2) = vbNo Then
    '    '        Exit Sub
    '    '    End If
    '    '    lHapusMobil = True
    '    'End If
    '    'Debug.WriteLine("Hapus PO " & X)
    '    'Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").RemoveAt(X)

    '    'Scon.Open()
    '    'Scom.CommandText = "delete from dc_jlr_daftarpo_t where " & _
    '    '                   "id_daftarpo=" & id_po
    '    'Scom.ExecuteNonQuery()
    '    'Scon.Close()

    '    'If lHapusMobil Then
    '    '    Debug.WriteLine("Hapus Mobil " & X)
    '    '    X = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position
    '    '    Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").RemoveAt(X)
    '    '    If Scon.State = ConnectionState.Open Then
    '    '        Scon.Close()
    '    '    End If
    '    '    Scon.Open()
    '    '    Scom.CommandText = "delete from dc_jlr_daftarjalur_t where " & _
    '    '                       "id_daftarjalur=" & id_jlr
    '    '    Scom.ExecuteNonQuery()
    '    '    Scon.Close()
    '    'End If

    '    'Try
    '    '    Dim ch As dsPO
    '    '    ch = DsPO1.GetChanges
    '    '    If (Not (ch) Is Nothing) Then
    '    '        Me.olcon.Open()
    '    '        Debug.WriteLine("Delete Daftar Langsung: " & oldapPO.Update(ch))
    '    '        Debug.WriteLine("Delete Mobil Langsung: " & oldapMobil.Update(ch))
    '    '        'Dim Olcom As New OleDbCommand("", olcon)
    '    '        'Olcom.CommandText = "Delete From DC_JLR_DaftarPO_T where "
    '    '        'Olcom.ExecuteNonQuery()
    '    '    End If


    '    '    DsPO1.DC_JLR_DAFTARJALUR_T.AcceptChanges()
    '    '    DsPO1.DC_JLR_DAFTARPO_T.AcceptChanges()
    '    'Catch updateException As System.Exception
    '    '    'Add your error handling code here.
    '    '    Throw updateException
    '    'Finally
    '    '    'Close the connection whether or not the exception was thrown.
    '    '    Me.olcon.Close()
    '    'End Try
    'End Sub

    Private Sub btnEditPO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEditPO.Click
        'If txtNo_PO.Text = "" Then
        '    MsgBox("Tidak Bisa Edit Pendaftaran Tanpa PO.", vbCritical)
        '    Exit Sub
        'End If
        'load datanya dulu baru save

        If LBMobil.SelectedIndex = -1 And LBMobil.Items.Count <> 0 Then
            LBMobil.SelectedIndex = 0
        End If
        frmLoadPO.sNoPo = txtNo_PO.Text
        frmLoadPO.NOMOBIL = LBMobil.Text
        frmLoadPO.SUPCO = lblSUPCO.Text
        frmLoadPO.SNAMA = lblSNAMA.Text
        frmLoadPO.ITEMnya = IIf(txtTot_Item.Text = "", 0, txtTot_Item.Text)
        frmLoadPO.RUPIAH = txtPO_GROSS.Text
        frmLoadPO.FAKTUR = txtNoFak.Text
        frmLoadPO.NoAntrian = txtNoAntrian.Text
        frmLoadPO.tglDaftar = txtTglDaftar.Value
        frmLoadPO.tglFaktur = txtTglFaktur.Value


        ''EnableInput
        'txtNoFak.Enabled = True
        'txtTglFaktur.Enabled = True


        'txtNo_PO.Enabled = True
        'txtPO_QTY.Enabled = True
        'txtPO_GROSS.Enabled = True
        'txtPO_PPN.Enabled = True

        'txtNoFak.Focus()

        ''UnBindData
        'btnSimpanPO.Enabled = True
        'btnBatalPO.Enabled = True


        Dim sqlpo As String
        Dim skon As New OleDb.OleDbConnection(ConStrORA)
        Dim skom As New OleDb.OleDbCommand("", skon)
        skon.Open()
        sqlpo = "Select COUNT(*) From DC_TRN_PREBPB_T Where NoPO='" & txtNo_PO.Text & "' " & _
        " AND NO_FAKTUR='" & txtNoFak.Text & "' AND SUP_KODE = '" & lblSUPCO.Text & "' " & _
        " AND TBL_DC_KODE = '" & cDC_KODE & "' "
        skom.CommandText = sqlpo
        If skom.ExecuteScalar > 0 Then
            MessageBox.Show("BPB sudah diposting, Tidak Bisa Edit PO.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            skon.Close()
            skom = Nothing
            skon = Nothing
            Exit Sub
        End If

        If lblStatus.Text <> "" Then
            MessageBox.Show("Tidak Bisa Edit PO. " & lblStatusKeterangan.Text & "", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        If lblBPB_NO.Text <> "" Then

        End If

        If txtNo_PO.Text = "" Then
            MessageBox.Show("Tidak Bisa Edit Pendaftaran Tanpa PO.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If



        Dim LastQTY As Double
        Dim LastGross As Double
        LastQTY = IFNULL(txtPO_QTY.Text, 0)
        LastGross = IFNULL(txtPO_GROSS.Text, 0)

        NoPO = txtNo_PO.Text

        Dim fe As New frmEditPO

        fe.sNoPo = txtNo_PO.Text
        fe.nIdDaftarPO = lblIdDaftarPO.Text
        fe.sNoPo = txtNo_PO.Text
        fe.eNOMOBIL = LBMobil.Text
        fe.eSUPCO = lblSUPCO.Text
        fe.eSNAMA = lblSNAMA.Text
        fe.eITEMnya = IIf(txtTot_Item.Text = "", 0, txtTot_Item.Text)
        fe.eRUPIAH = txtPO_GROSS.Text
        fe.eFAKTUR = txtNoFak.Text
        fe.eNoAntrian = txtNoAntrian.Text
        fe.etglDaftar = txtTglDaftar.Value
        fe.etglFaktur = txtTglFaktur.Value
        'If IsMrBread(txtSUPCO.Text, cDC_KODE) Then
        If IsMrBread(CmbSUPCO.Text, cDC_KODE) Then
            fe.FakturMBread = txtNoFak.Text
            fe.IsMrBread = True

            MessageBox.Show("Tidak Bisa Edit Pendaftaran Mr.Bread.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub

        Else
            fe.IsMrBread = False
        End If

        'If fe.CekItemPO = True Then

        'fe.Top += Me.Height - fe.Height

        If fe.ShowDialog = Windows.Forms.DialogResult.OK Then
            'MsgBox("1")
            txtPO_QTY.Text = Format(fe.nQTY, "#,##0")
            txtTot_Item.Text = Format(fe.nItem, "#,##0")
            txtPO_GROSS.Text = Format(fe.nGROSS, "#,##.##############")

            txtPO_PPN.Text = Format(fe.nPPN, "#,##.##############")
            txtPO_Total.Text = Format(fe.nGROSS + fe.nPPN, "#,##.##############")
            'MsgBox("2")
            'txtPO_PPN.Text = Format(fe.nGROSS * 0.1, "#,##.##############")
            'txtPO_Total.Text = Format(fe.nGROSS + (fe.nGROSS * 0.1), "#,##.##############")
            lblTglRevisi.Text = GetOracleDate()
            'MsgBox("3")
            Dim getPO_ As String = "select qty, item, rupiah, ppn from dc_jlr_daftarpo_t where nopo= '" & txtNo_PO.Text & "'"
            Dim dt_getPO As DataTable = getDS(getPO_, ConStrORA).Tables(0)
            Dim drEDIT As Object
            drEDIT = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Current
            drEDIT.row("QTY") = dt_getPO.Rows(0)("QTY").ToString 'Format(fe.nQTY, "#,##0")
            drEDIT.row("ITEMNYA") = dt_getPO.Rows(0)("ITEM").ToString 'Format(fe.nItem, "#,##0")
            drEDIT.row("RUPIAH") = dt_getPO.Rows(0)("RUPIAH").ToString 'CType(IIf(Format(fe.nGROSS, "#,##.##############") = "", 0, Format(fe.nGROSS, "#,##.##############")), Double)
            drEDIT.row("PPN") = dt_getPO.Rows(0)("PPN").ToString 'CType(IIf(Format(fe.nPPN, "#,##.##############") = "", 0, Format(fe.nPPN, "#,##.##############")), Double)
            drEDIT.row("TOTAL") = CType(IIf(Format(dt_getPO.Rows(0)("RUPIAH") + dt_getPO.Rows(0)("PPN"), "#,##.##############") = "", 0, Format(dt_getPO.Rows(0)("RUPIAH") + dt_getPO.Rows(0)("PPN"), "#,##.##############")), Double)
            'CType(IIf(Format(fe.nGROSS + fe.nPPN, "#,##.##############") = "", 0, Format(fe.nGROSS + fe.nPPN, "#,##.##############")), Double)
            'drEDIT.row("TGL_REVISI") = IIf(lblTglRevisi.Text = "", 0, Now.Date)
            'MsgBox("4")
            'Simpan Langsung
            Try
                'Dim ch1 As dsPO.DC_JLR_DAFTARPO_TDataTable
                'ch1 = dsPO.DC_JLR_DAFTARPO_TRow

                Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").EndCurrentEdit()
                Dim ch As DS_.DC_JLR_DAFTARPO_TDataTable
                ch = DsPO1.DC_JLR_DAFTARPO_T.GetChanges
                If (Not (ch) Is Nothing) Then ' Or tgl_rev <> lblTglRevisi.Text
                    Dim Scon As New OleDbConnection(ConStrORA)
                    Dim Scom As New OleDbCommand("", Scon)

                    For i As Integer = 0 To ch.Rows.Count - 1
                        'update tgl_revisi ada jam. sebelumnya error karena tidak ada jamnya!
                        Dim waktu As DateTime
                        Dim tgl_revisi As String = ""
                        Try
                            waktu = Format(CType(ch.Rows(i)("tgl_revisi"), DateTime), "G")
                        Catch ex As Exception
                            tgl_revisi = "sysdate"
                            waktu = Date.Now
                        End Try
                        'Dim sql As String = "update dc_jlr_daftarpo_t set tgl_revisi=" & IIf(tgl_revisi = "sysdate", "sysdate", "to_date('" & Format(CType(dt.Rows(0)("tgl_revisi"), DateTime), "G") & "','MM/dd/yyyy hh:mi:ss AM')") & " where nopo='TH1828173'"
                        Scon.Open()
                        Scom.CommandText = "Update dc_jlr_daftarpo_t " & _
                                           "set qty=qty" & _
                                               " where " & _
                                               " id_daftarjalur=" & ch.Rows(i)("id_daftarjalur") & _
                                               " and id_daftarpo=" & ch.Rows(i)("id_daftarpo") & _
                                               " and no_fak='" & ch.Rows(i)("no_fak") & "'" & _
                                               " and nopo" & IIf(IsDBNull(ch.Rows(i)("nopo")), " is null ", "='" & ch.Rows(i)("nopo") & "' ") & _
                                               " and supco='" & ch.Rows(i)("supco") & "'"
                        Scom.ExecuteNonQuery()
                        Scon.Close()
                    Next
                    Me.olcon.Open()
                    Debug.WriteLine("PO Langsung PERUBAHAN: " & oldapPO.Update(ch))
                    'Debug.WriteLine("PO Langsung: " & oldapPO.Update(Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").Current))
                    'Debug.WriteLine("PO Langsung: " & OleDbDataAdapter1.Update(ch))
                Else
                    Dim dr As Object
                    dr = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Current
                    Dim id_jlr As String = dr.row("ID_DAFTARJALUR")
                    Dim id_po As String = dr.row("ID_DAFTARPO")
                    Dim no_fak As String = dr.row("NO_FAK")
                    Dim nopo As String = dr.row("NOPO")
                    MsgBox("Tidak Update ke Tabel Daftar PO !! ID Daftar PO = " & id_po & "," & id_jlr & "," & no_fak & "," & nopo, MsgBoxStyle.Information)
                End If
                DsPO1.DC_JLR_DAFTARPO_T.AcceptChanges()

            Catch updateException As System.Exception
                'Add your error handling code here.
                Throw updateException
            Finally
                'Close the connection whether or not the exception was thrown.
                Me.olcon.Close()
            End Try
            'LoadDataSet()
            'Dim loadnourut As String = txtNoAntrian.Text
            'For i As Integer = 0 To DsPO1.DC_JLR_DAFTARJALUR_T.Rows.Count - 1
            '    If DsPO1.DC_JLR_DAFTARJALUR_T.Rows(i)("NOURUT").ToString = loadnourut Then
            '        Exit For
            '    Else
            '        Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position += 1
            '    End If
            'Next

            'Dim NOFAKTUR_ = txtNoFak.Text
            'Dim NOPO_ = txtNo_PO.Text
            ''Dim loadnodaf As String = frmLoadPO.FAKTUR
            'For i As Integer = 0 To DsPO1.DC_JLR_DAFTARPO_T.Rows.Count - 1

            '    Dim NOFAK1 As String = DsPO1.DC_JLR_DAFTARPO_T.Rows(i)("NO_FAK").ToString
            '    Dim NOFAK2 As String = frmLoadPO.FAKTUR
            '    Dim NoPO1 As String = DsPO1.DC_JLR_DAFTARPO_T.Rows(i)("NOPO").ToString
            '    Dim NOPO2 As String = frmLoadPO.sNoPo.ToString
            '    If DsPO1.DC_JLR_DAFTARPO_T.Rows(i)("NO_FAK").ToString = NOFAKTUR_ And DsPO1.DC_JLR_DAFTARPO_T.Rows(i)("NOPO").ToString = NOPO_ Then
            '        Exit For
            '    Else
            '        Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.DAF_PO").Position += 1
            '    End If
            'Next
            'mobil()
        End If
        fe.Dispose()

    End Sub

    Private Sub btnKeluar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKeluar.Click
        Me.Close()
    End Sub

    Private Sub txtPO_GROSS_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtPO_GROSS.Validating
        If Not IsNumeric(txtPO_GROSS.Text) Then
            MessageBox.Show("Masukkan Nilai Rupiah", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            e.Cancel = True
        End If
        If Not lWithPO Then
            Dim x As Double
            x = CType(txtPO_GROSS.Text, Double) * 0.1
            txtPO_PPN.Text = x
            txtPO_Total.Text = CType(txtPO_GROSS.Text, Double) + x
        End If
    End Sub

    Private Sub TXTPO_PPN_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtPO_PPN.Validating
        If Not IsNumeric(txtPO_PPN.Text) Then
            MessageBox.Show("Masukkan Nilai Rupiah", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            e.Cancel = True
        End If
        If Not lWithPO Then
            Dim x As Double
            x = CType(IIf(txtPO_PPN.Text = "", 0, txtPO_PPN.Text), Double)
            txtPO_Total.Text = CType(IIf(txtPO_GROSS.Text = "", 0, txtPO_GROSS.Text), Double) + x
        End If
    End Sub

    Private Sub btnCari_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCari.Click

        Dim f As New frmCariPO
        f.DataGrid1.DataSource = DsPO1.DC_JLR_DAFTARPO_T
        If f.ShowDialog <> Windows.Forms.DialogResult.OK Then
            Exit Sub
        End If

        Dim IdDaftarJalur As Integer
        Dim IdDaftar As Integer

        IdDaftar = f.idDaftar
        Dim rw As DataRow = DsPO1.DC_JLR_DAFTARPO_T.FindByID_DAFTARPO(IdDaftar)
        If IsNothing(rw) Then
            Exit Sub
        End If

        IdDaftarJalur = "0" & rw("ID_DAFTARJALUR")
        Dim rwMobil As DataRow = DsPO1.DC_JLR_DAFTARJALUR_T.FindByID_DAFTARJALUR(IdDaftarJalur)

        For j As Integer = 0 To DsPO1.DC_JLR_DAFTARJALUR_T.Rows.Count - 1
            If rwMobil.Equals(DsPO1.DC_JLR_DAFTARJALUR_T.Rows(j)) Then
                Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position = j
                Exit For
            End If
        Next


        For i As Integer = 0 To Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").Count - 1
            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").Position = i
            If CType(Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").Current, DataRowView).Row.Equals(rw) Then
                Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").Position = i
                Exit For
            End If
        Next
        RECID()
        mobil()
    End Sub


    Private Function GetOracleDate() As Date
        Dim Scon As New OleDbConnection(ConStrORA)
        Dim Scom As New OleDbCommand("", Scon)
        Try
            Scon.Open()
            Scom.CommandText = "Select sysdate from dual"
            Return Scom.ExecuteScalar

        Catch ex As Exception
            ShowError("error Baca Jam", ex)
        Finally
            Scon.Close()
        End Try

    End Function

    Private Sub btnDaftar_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDaftar.EnabledChanged
        btnDraftRetur.Enabled = CType(sender, Button).Enabled
    End Sub

    Private Sub btnDraftRetur_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDraftRetur.Click
        subDraft(lblSUPCO.Text, cDC_KODE, cDC_ID)
    End Sub

    Public Sub subDraft(ByVal sd_supco As String, ByVal sd_dckode As String, ByVal sd_dcid As String)
        If lblSUPCO.Text = "" Then
            MessageBox.Show("Tidak Ada Data Supplier.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        Dim sd_supnama As String = ""
        Dim dt_getSUPNAMA As DataTable = getDS("SELECT sup_nama FROM dc_supplier_dc_v WHERE sup_supkode = '" & sd_supco & "'", ConStrORA).Tables(0)
        If dt_getSUPNAMA.Rows.Count > 0 Then
            sd_supnama = dt_getSUPNAMA.Rows(0)(0).ToString
        End If

        'Dim f As New frmDraftRetur
        Dim nBulan As Integer = 12
        'If f.ShowDialog = Windows.Forms.DialogResult.OK Then
        '    nBulan = f.nBulan
        'Else
        '    Exit Sub
        'End If


        Dim Scon As New OleDbConnection(ConStrORA)
        Dim Scom As New OleDbCommand("", Scon)
        Dim Sdap As New OleDbDataAdapter("", Scon)
        Dim dt As New DataTable
        Try
            Scon.Open()
            Scom.CommandText = "JLR_Create_Draft_Retur('" & sd_supco & "','" & sd_dckode & "'," & nBulan & ")"
            Scom.CommandType = CommandType.StoredProcedure
            Scom.ExecuteNonQuery()
            Scom.CommandType = CommandType.Text

            dt.Clear()

            Scom.CommandText = "Select D.*,PRDCD,NAMA,SINGKAT from dc_jlr_draft_retur_t d, "
            Scom.CommandText &= "(SELECT MBR_FK_PLUID,mbr_plukode PRDCD,MBR_FULL_NAMA NAMA,MBR_SINGKATAN SINGKAT FROM DC_BARANG_DC_V WHERE MBR_FK_DCID=" & sd_dcid & ") brg "
            Scom.CommandText &= "WHERE(SUPCO = '" & sd_supco & "') "
            Scom.CommandText &= "AND Tanggal=TRUNC(SYSDATE) "
            Scom.CommandText &= "AND D.PLUID=BRG.MBR_FK_PLUID "
            Scom.CommandText &= "ORDER BY  PRDCD "
            Sdap.SelectCommand = Scom
            Sdap.Fill(dt)

            Scom.CommandText = "select alamat from dc_printer_t where printer='RETUR' and DC_ID='" & sd_dcid & "'"
            Dim almt As String = IIf(IsNothing(Scom.ExecuteScalar) Or IsDBNull(Scom.ExecuteScalar), "", Scom.ExecuteScalar)
            If almt = "" Then
                MsgBox("Tidak Ada Alamat Printer Draft Retur")
            End If
            If dt.Rows.Count > 0 Then
                Cetak_DrafRetur(dt, almt, sd_supco, sd_supnama)
                MessageBox.Show("Draft Retur Selesai.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("Tidak Ada Data Untuk Draft Retur.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        Catch ex As Exception
            ShowError("error Create Draft Retur", ex)
        Finally
            Scon.Close()
        End Try
    End Sub

    'Private Sub Cetak_DrafRetur(ByVal dt As DataTable, ByVal nmPrinter As String)
    '    'Cetak PB BKL
    '    Dim nProw As Integer = 0
    '    Dim nHal As Integer = 0
    '    Dim NoUrut As Integer = 0
    '    Dim mDIV As String = ""
    '    Dim sw As New IO.StreamWriter(Application.StartupPath & "\TempCetakDraftRetur.TXT", False)

    '    sw.WriteLine(Chr(27) & "x" & "0" & Chr(27) & "M" + Chr(15))

    '    'SETENGAH PLY
    '    sw.Write(Chr(27) & "C" & Chr(33))
    '    For i As Short = 0 To dt.Rows.Count - 1
    '        If nProw = 0 Then
    '            nHal += 1
    '            If nHal < 2 Then
    '                sw.WriteLine(Chr(27) & "W" & "0")
    '                sw.WriteLine((cDC_KODE & "-" & cDC_NAMA).PadRight(104) & Format(Now, "dd/MM/yyyy"))
    '                'sw.WriteLine(Chr(14) & Chr(27) & "W" & "1")
    '                sw.Write(Chr(14) + (Chr(27) + "W" + "1"))
    '                sw.WriteLine(strCenter("DRAFT RETUR SUPPLIER", 65))
    '                'sw.WriteLine(Chr(20) & Chr(27) & "W" & "0")
    '                sw.WriteLine(Chr(20) + (Chr(27) + "W" + "0"))
    '                sw.WriteLine(strCenter("Supplier : " & lblSUPCO.Text & "-" & lblSNAMA.Text, 120))
    '                'sw.WriteLine(strCenter("Nomor PB BKL : " & nDocno & "/Tgl. : " & Format(Now, "dd/MM/yyyy"), 120))
    '                sw.WriteLine(("Halaman: " & CType(nHal, String).PadLeft(2)).PadLeft(108))
    '                nProw += 7
    '            Else
    '                'sw.WriteLine(("PB Kirim Langsung No. : " & nDocno).PadRight(108) & "Halaman: " & CType(nHal, String).PadLeft(2))
    '                sw.WriteLine((" ").PadRight(108) & "Halaman: " & CType(nHal, String).PadLeft(2))
    '                nProw += 1
    '            End If

    '            sw.WriteLine("-".PadRight(120, "-"))
    '            sw.WriteLine("|  No. |  PLU |  Nama Barang dan Spesifikasi                                  | Kuantitas |  Aktual  |    Keterangan    |")
    '            sw.WriteLine("|-----------------------------------------------------------------------------|-----------|----------|------------------|")
    '            nProw += 3
    '        End If
    '        NoUrut += 1
    '        sw.Write("| " & CType(NoUrut, String).PadLeft(3) & ". | ")
    '        sw.Write(dt.Rows(i)("PRDCD") & " |  ")
    '        sw.Write(CType("" & dt.Rows(i)("NAMA"), String).PadRight(50).Substring(0, 50) & "   ")
    '        sw.Write(CType(" ", String).PadRight(6).Substring(0, 6) & "  | ")
    '        sw.WriteLine(CType(Format(dt.Rows(i)("QTY"), "#,##0"), String).PadLeft(9) & " | " & "".PadRight(8) & " | " & "".PadRight(17) & "|")
    '        nProw += 1
    '        If nProw >= 28 Then
    '            sw.WriteLine("|" & "-".PadRight(119, "-") & "|")
    '            nProw = 0
    '            'EJECT
    '            sw.Write(Chr(12) + Chr(13))
    '        End If
    '    Next
    '    'sw.WriteLine("|" & "-".PadRight(119, "-") & "|")
    '    'sw.WriteLine(("|".PadRight(16) & ("Disetujui :").PadRight(93 - 16) & "Dicetak :").PadRight(120) & "|")
    '    'sw.WriteLine("|" & " ".PadRight(119) & "|")
    '    'sw.WriteLine("|" & " ".PadRight(119) & "|")
    '    'sw.WriteLine("|" & " ".PadRight(119) & "|")
    '    'sw.WriteLine(("|".PadRight(16) & ("___________").PadRight(93 - 16) & "_________").PadRight(120) & "|")
    '    'sw.WriteLine(("|".PadRight(12) & ("Chief of Store/Asst").PadRight(93 - 12) & "         ").PadRight(120) & "|")
    '    sw.WriteLine("-" & "-".PadRight(119, "-") & "-")
    '    sw.Write(Chr(12) + Chr(13))
    '    sw.Write(Chr(18))
    '    sw.Flush()
    '    sw.Close()

    '    ''''''''''''
    '    Dim sr As New IO.StreamReader(Application.StartupPath & "\TempCetakDraftRetur.TXT")
    '    DoPr(sr.ReadToEnd, nmPrinter)
    '    sr.Close()
    'End Sub
    Private Sub Cetak_DrafRetur(ByVal dt As DataTable, ByVal nmPrinter As String, ByVal supkode As String, ByVal supnama As String)
        'Cetak PB BKL
        Dim nProw As Integer = 0
        Dim nHal As Integer = 0
        Dim NoUrut As Integer = 0
        Dim mDIV As String = ""
        Dim sw As New IO.StreamWriter(Application.StartupPath & "\TempCetakDraftRetur.TXT", False)

        sw.WriteLine(Chr(27) & "x" & "0" & Chr(27) & "M" + Chr(15))

        'SETENGAH PLY
        sw.Write(Chr(27) & "C" & Chr(33))
        For i As Short = 0 To dt.Rows.Count - 1
            If nProw = 0 Then
                nHal += 1
                If nHal < 2 Then
                    sw.WriteLine(Chr(27) & "W" & "0")
                    sw.WriteLine((cDC_KODE & "-" & cDC_NAMA).PadRight(104) & Format(Now, "dd/MM/yyyy"))
                    'sw.WriteLine(Chr(14) & Chr(27) & "W" & "1")
                    sw.Write(Chr(14) + (Chr(27) + "W" + "1"))
                    sw.WriteLine(strCenter("DRAFT RETUR SUPPLIER", 65))
                    'sw.WriteLine(Chr(20) & Chr(27) & "W" & "0")
                    sw.WriteLine(Chr(20) + (Chr(27) + "W" + "0"))
                    sw.WriteLine(strCenter("Supplier : " & supkode & "-" & supnama, 120))
                    'sw.WriteLine(strCenter("Supplier : " & lblSUPCO.Text & "-" & lblSNAMA.Text, 120))
                    'sw.WriteLine(strCenter("Nomor PB BKL : " & nDocno & "/Tgl. : " & Format(Now, "dd/MM/yyyy"), 120))
                    sw.WriteLine(("Halaman: " & CType(nHal, String).PadLeft(2)).PadLeft(108))
                    nProw += 7
                Else
                    'sw.WriteLine(("PB Kirim Langsung No. : " & nDocno).PadRight(108) & "Halaman: " & CType(nHal, String).PadLeft(2))
                    sw.WriteLine((" ").PadRight(108) & "Halaman: " & CType(nHal, String).PadLeft(2))
                    nProw += 1
                End If

                sw.WriteLine("-".PadRight(120, "-"))
                sw.WriteLine("|  No. |   PLU    | Nama Barang dan Spesifikasi                               | Kuantitas |  Aktual  |    Keterangan    |")
                sw.WriteLine("|-----------------------------------------------------------------------------|-----------|----------|------------------|")
                nProw += 3
            End If
            NoUrut += 1
            sw.Write("| " & CType(NoUrut, String).PadLeft(3) & ". | ")
            sw.Write(IIf(dt.Rows(i)("PRDCD").Length = 4, "  " & dt.Rows(i)("PRDCD") & "   | ", dt.Rows(i)("PRDCD") & " | "))
            'sw.Write(dt.Rows(i)("PRDCD") & " |  ")
            sw.Write(CType("" & dt.Rows(i)("NAMA"), String).PadRight(55).Substring(0, 50) & "")
            sw.Write(CType(" ", String).PadRight(6).Substring(0, 6) & "  | ")
            sw.WriteLine(CType(Format(dt.Rows(i)("QTY"), "#,##0"), String).PadLeft(9) & " | " & "".PadRight(8) & " | " & "".PadRight(17) & "|")
            nProw += 1
            If nProw >= 28 Then
                sw.WriteLine("|" & "-".PadRight(119, "-") & "|")
                nProw = 0
                'EJECT
                sw.Write(Chr(12) + Chr(13))
            End If
        Next
        'sw.WriteLine("|" & "-".PadRight(119, "-") & "|")
        'sw.WriteLine(("|".PadRight(16) & ("Disetujui :").PadRight(93 - 16) & "Dicetak :").PadRight(120) & "|")
        'sw.WriteLine("|" & " ".PadRight(119) & "|")
        'sw.WriteLine("|" & " ".PadRight(119) & "|")
        'sw.WriteLine("|" & " ".PadRight(119) & "|")
        'sw.WriteLine(("|".PadRight(16) & ("___________").PadRight(93 - 16) & "_________").PadRight(120) & "|")
        'sw.WriteLine(("|".PadRight(12) & ("Chief of Store/Asst").PadRight(93 - 12) & "         ").PadRight(120) & "|")
        sw.WriteLine("-" & "-".PadRight(119, "-") & "-")
        sw.Write(Chr(12) + Chr(13))
        sw.Write(Chr(18))
        sw.Flush()
        sw.Close()

        ''''''''''''
        Dim sr As New IO.StreamReader(Application.StartupPath & "\TempCetakDraftRetur.TXT")
        DoPr(sr.ReadToEnd, nmPrinter)
        sr.Close()
    End Sub
    Private Sub CmbSUPCO_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CmbSUPCO.TextChanged
        If Len(CmbSUPCO.Text) = 4 Then
            CmbSUPCO.Text = CmbSUPCO.Text.ToUpper
            'If CmbSUPCO.Text = lblSUPCO.Text Then
            '    Exit Sub
            'End If
            Dim i As Integer
            For i = 0 To CmbSUPCO.Items.Count - 1
                If CmbSUPCO.Text = dsSupp.Tables(0).Rows(i).Item(0) Then
                    GoTo lanjut
                End If
            Next
            MsgBox("Supplier tidak terdaftar")
            CmbSUPCO.Text = dsSupp.Tables(0).Rows(0).Item(0)
            Exit Sub

lanjut:     Dim sql As String
            Dim Scon As New OleDbConnection(ConStrORA)
            Dim Scom As New OleDbCommand("", Scon)
            Dim Sdar As OleDbDataReader
            Dim Sdap As New OleDbDataAdapter
            Try
                Scon.Open()
                'Todo: Buat PO tidak ada Kolom
                sql = "Select S.SUP_NAMA AS SNAMA,s.SUP_SUPID AS SUPID from DC_SUPPLIER_DC_V H,DC_SUPPLIER_T S "
                sql &= "Where H.SUP_FK_SUPID=s.SUP_SUPID And "
                sql &= "TBL_DC_KODE='" & cDC_KODE
                sql &= "' AND H.SUP_SUPKODE='" & CmbSUPCO.Text.ToUpper & "'"
                Scom.CommandText = sql
                Sdar = Scom.ExecuteReader


                If Sdar.Read Then
                    'Cek With PO
                    If Not lWithPO Then
                        txtPO_QTY.Focus()
                    End If

                    lblSNAMA.Text = IIf(IsDBNull(Sdar("SNAMA")), "", Sdar("SNAMA"))
                    lblSUPID.Text = IFNULL(Sdar("SUPID"), 0)

                    If lblSNAMA.Text = "" Then
                        GoTo ex
                    End If

                Else
                    MsgBox("Supplier " & CmbSUPCO.Text & " tidak ada !!!", vbCritical)
                    lblSNAMA.Text = ""
                    Sdar.Close()
                    CmbSUPCO.Focus()
                    GoTo ex
                End If
                Sdar.Close()

                Dim m As String
                Dim d As String
                Dim tgl As String
                m = Date.Now.Month
                d = Date.Now.Day
                If m.Length < 2 And d.Length < 2 Then
                    m = "0" & Date.Now.Month
                    d = "0" & Date.Now.Day
                ElseIf m.Length < 2 Then
                    m = "0" & Date.Now.Month
                ElseIf d.Length < 2 Then
                    d = "0" & Date.Now.Day
                End If
                tgl = d & "/" & m & "/" & Date.Now.Year
                'Scom.CommandText = "select NOMOBIL from DC_JLR_DAFTARMOBIL_HDR_T where to_char(TRUNC(TGLMASUK),'dd/mm/yyyy')='" & tgl & "' and supco='" & CmbSUPCO.Text & "'"

                Scom.CommandText = "select NOMOBIL from DC_JLR_DAFTARMOBIL_HDR_T where TGLMASUK=to_date('" & Convert.ToDateTime(CmbNama.SelectedValue).ToString("MM/dd/yyyy hh:mm:ss tt") & "', 'MM/dd/yyyy hh:mi:ss am') and supco='" & CmbSUPCO.Text & "'"
                Sdap.SelectCommand = Scom
                ds.Clear()
                Sdap.Fill(ds)
                If ds.Tables(0).Rows.Count <= 0 Then
                    Scom.CommandText = " SELECT NOMOBIL FROM dc_jlr_daftarjalur_t" & _
                        "  WHERE supco = '" & lblSUPCO.Text & "'" & _
                        "    AND nourut = '" & txtNoAntrian.Text & "'" & _
                        "    AND TO_CHAR (TRUNC (tanggal), 'dd/MM/yyyy') = '" & Format(txtTglDaftar.Value, "dd/MM/yyyy") & "'"
                    Sdap.SelectCommand = Scom
                    ds.Clear()
                    Sdap.Fill(ds)
                End If
                LBMobil.DataSource = ds.Tables(0)
                LBMobil.DisplayMember = "NOMOBIL"
ex:             If lblSNAMA.Text = "" Then
                    ds.Clear()
                    CmbSUPCO.Focus()
                End If
            Catch ex As Exception
                ShowError("Error Baca Supplier", ex)
            Finally
                Scon.Close()
                Scon = Nothing
            End Try
            lblSUPCO.Text = CmbSUPCO.Text
        End If
    End Sub

    'Private Sub CmbSUPCO_TextUpdate(ByVal sender As Object, ByVal e As System.EventArgs) Handles CmbSUPCO.TextUpdate

    'End Sub

    ' ''    Private Sub txtSUPCO_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    ' ''        If Len(txtSUPCO.Text) = 4 Then
    ' ''            If txtSUPCO.Text = lblSUPCO.Text Then
    ' ''                Exit Sub
    ' ''            End If

    ' ''            Dim sql As String
    ' ''            Dim Scon As New OleDbConnection(ConStrORA)
    ' ''            Dim Scom As New OleDbCommand("", Scon)
    ' ''            Dim Sdar As OleDbDataReader
    ' ''            Try
    ' ''                Scon.Open()
    ' ''                'Todo: Buat PO tidak ada Kolom
    ' ''                sql = "Select S.SUP_NAMA AS SNAMA,H.SUP_SUPKODE AS SUPCO,H.SUP_FLAG_BUATPO AS BUAT_PO,s.SUP_SUPID AS SUPID from DC_SUPPLIER_DC_V H,DC_SUPPLIER_T S "
    ' ''                sql &= "Where H.SUP_FK_SUPID=s.SUP_SUPID And "
    ' ''                sql &= "TBL_DC_KODE='" & cDC_KODE
    ' ''                sql &= "' AND H.SUP_SUPKODE='" & txtSUPCO.Text & "'"
    ' ''                Scom.CommandText = sql
    ' ''                Sdar = Scom.ExecuteReader


    ' ''                If Sdar.Read Then
    ' ''                    'Cek With PO
    ' ''                    If Not lWithPO Then
    ' ''                        If "" & Sdar("BUAT_PO") = "Y" Then
    ' ''                            'MsgBox("Supplier " & txtSUPCO.Text & " Harus Pakai PO !!!", vbCritical)
    ' ''                            'txtSUPCO.Text = ""
    ' ''                            'txtNamaSupp.Text = ""
    ' ''                            'GoTo ex
    ' ''                        Else
    ' ''                            txtPO_QTY.Focus()
    ' ''                        End If
    ' ''                    End If
    ' ''                    txtNamaSupp.Text = Sdar("SNAMA") & ""

    ' ''                    lblSUPID.Text = IFNULL(Sdar("SUPID"), 0)

    ' ''                    If lblSUPCO.Text = "" Then
    ' ''                        lblSUPCO.Text = Sdar("SUPCO")
    ' ''                    End If
    ' ''                    If lblSNAMA.Text = "" Then
    ' ''                        lblSNAMA.Text = txtNamaSupp.Text
    ' ''                    End If
    ' ''                Else
    ' ''                    MsgBox("Supplier " & txtSUPCO.Text & " tidak ada !!!", vbCritical)
    ' ''                End If
    ' ''ex:             Sdar.Close()
    ' ''            Catch ex As Exception
    ' ''                ShowError("Error Baca Supplier", ex)
    ' ''            Finally
    ' ''                Scon.Close()
    ' ''                Scon = Nothing
    ' ''            End Try
    ' ''        End If
    ' ''    End Sub

    Private Sub lblSUPCO_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lblSUPCO.TextChanged
        isiData()
    End Sub

    Private Sub isiData()
        If CmbSUPCO.Visible = True Then
            lblSUPCO.Text = CmbSUPCO.Text
        End If
        Dim m As String
        Dim d As String
        Dim tgl As String
        m = Date.Now.Month
        d = Date.Now.Day
        If m.Length < 2 And d.Length < 2 Then
            m = "0" & Date.Now.Month
            d = "0" & Date.Now.Day
        ElseIf m.Length < 2 Then
            m = "0" & Date.Now.Month
        ElseIf d.Length < 2 Then
            d = "0" & Date.Now.Day
        End If
        tgl = d & "/" & m & "/" & Date.Now.Year

        If tgl <> Format(txtTglDaftar.Value, "dd/MM/yyyy") Then
            mobil()
            Exit Sub
        End If

        Dim Scon As New OleDbConnection(ConStrORA)
        Dim Scom As New OleDbCommand("", Scon)
        Dim Sdap As New OleDbDataAdapter
        Try
            Scon.Open()
            Scom.CommandText = "select NOMOBIL from DC_JLR_DAFTARMOBIL_HDR_T where TGLMASUK =to_date('" & CmbNama.SelectedValue & "', 'MM/dd/yyyy hh:mi:ss am') and supco='" & lblSUPCO.Text & "' and TGLKELUAR is null"
            Sdap.SelectCommand = Scom
            ds.Clear()
            Sdap.Fill(ds)

            If ds.Tables(0).Rows.Count <= 0 Then
                Scom.CommandText = " SELECT NOMOBIL FROM dc_jlr_daftarjalur_t" & _
                    "  WHERE supco = '" & lblSUPCO.Text & "'" & _
                    "    AND nourut = '" & txtNoAntrian.Text & "'" & _
                    "    AND TO_CHAR (TRUNC (tanggal), 'dd/MM/yyyy') = '" & Format(txtTglDaftar.Value, "dd/MM/yyyy") & "'"
                Sdap.SelectCommand = Scom
                ds.Clear()
                Sdap.Fill(ds)
            End If
            LBMobil.DataSource = ds.Tables(0)
            LBMobil.DisplayMember = "NOMOBIL"
            If btnDaftar.Enabled = True And btnTambahPO.Enabled = True Then
                LBMobil.ClearSelected()
            End If
        Catch ex As Exception

        Finally
            Scon.Close()
            Scon = Nothing
        End Try
    End Sub

#Region " com calls "
    ''' <summary> 
    ''' 
    ''' </summary> 
    ''' <param name="lpFileName"></param> 
    ''' <param name="dwDesiredAccess"></param> 
    ''' <param name="dwShareMode"></param> 
    ''' <param name="lpSecurityAttributes"></param> 
    ''' <param name="dwCreationDisposition"></param> 
    ''' <param name="dwFlagsAndAttributes"></param> 
    ''' <param name="hTemplateFile"></param> 
    ''' <returns></returns> 
    ''' <remarks></remarks> 
    Private Declare Function CreateFile Lib "kernel32" Alias "CreateFileA" (ByVal lpFileName As String, ByVal dwDesiredAccess As Integer, ByVal dwShareMode As Integer, <MarshalAs(UnmanagedType.Struct)> ByRef lpSecurityAttributes As SECURITY_ATTRIBUTES, ByVal dwCreationDisposition As Integer, ByVal dwFlagsAndAttributes As Integer, ByVal hTemplateFile As Integer) As Microsoft.Win32.SafeHandles.SafeFileHandle
#End Region
#Region " Private constants "
    Private Const GENERIC_WRITE As Integer = &H40000000
    Private Const OPEN_EXISTING As Integer = 3
#End Region
#Region " private structures "
    ''' <summary> 
    ''' Structure for CreateFile.  Used only to fill requirement 
    ''' </summary> 
    <StructLayout(LayoutKind.Sequential)> _
    Public Structure SECURITY_ATTRIBUTES
        Private nLength As Integer
        Private lpSecurityDescriptor As Integer
        Private bInheritHandle As Integer
    End Structure
#End Region

    Private Sub btnPrint_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        Dim NoUrut As String
        Dim Ps As New Printing.PrinterSettings
        Dim drSup As Object
        drSup = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Current
        drSup.row("PRINT_ID") = "1"
        Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").EndCurrentEdit()
        NoUrut = drSup.row("NOURUT")

        Dim ID_JLR As String = drSup.row("ID_DAFTARJALUR")
        Dim DC_ID As String = drSup.row("DC_ID")
        'Dim ID_PO As String = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").Current.row("ID_DAFTARPO")

        If NoUrut.Length = 2 Then
            NoUrut = "0" & NoUrut
        ElseIf NoUrut.Length = 1 Then
            NoUrut = "00" & NoUrut
        ElseIf NoUrut.Length = 0 Or NoUrut.Length > 3 Then
            MsgBox("No Urut Error, Tidak Bisa Print")
            Exit Sub
        End If
        Dim Tgl As String
        Dim m As String
        Dim d As String
        Dim day As String
        Tgl = Format(drSup.row("TANGGAL"), "MM/dd/yyyy")

        m = Tgl.Substring(0, 2)
        d = Tgl.Substring(3, 2)
        Tgl = Tgl.Substring(8, 2)
        If m.Length < 2 And d.Length < 2 Then
            m = "0" & m
            d = "0" & d
        ElseIf m.Length < 2 Then
            m = "0" & m
        ElseIf d.Length < 2 Then
            d = "0" & d
        End If
        day = d & m & Tgl
        NoUrut = "*" & NoUrut & day & "*"
        Try
            Dim ch As DS_.DC_JLR_DAFTARJALUR_TDataTable
            ch = DsPO1.DC_JLR_DAFTARJALUR_T.GetChanges
            If (Not (ch) Is Nothing) Then
                If Me.olcon.State = ConnectionState.Open Then
                    Me.olcon.Close()
                End If
                Me.olcon.Open()
                Debug.WriteLine("Mobil Langsung: " & oldapMobil.Update(ch))
            End If
            Print(drSup.row("PRINT_ID"), drSup.row("ID_DAFTARJALUR"))
        Catch updateException As System.Exception
            'Add your error handling code here.
            Throw updateException
            MsgBox("Update Error")
        Finally
            'Close the connection whether or not the exception was thrown.
            Me.olcon.Close()
        End Try

        Dim Scon As New OleDbConnection(ConStrORA)
        Dim Scom As New OleDbCommand("", Scon)
        Dim Sdap As New OleDbDataAdapter
        Dim drpt As New DataSet

        Dim dsPlt As New DataSet
        Dim namaPrt As String = ""

        Try
            Scon.Open()
            Scom.CommandText = "select a.nourut,trunc(a.tanggal) as tgl,a.SUPCO,a.SNAMA,b.TBL_DC_KODE,b.TBL_DC_NAMA " & _
                               "from dc_jlr_daftarjalur_t a," & _
                                    "dc_tabel_dc_t b " & _
                               "where id_daftarjalur='" & ID_JLR & "' " & _
                                     "and a.dc_id=b.TBL_DCID"
            Sdap.SelectCommand = Scom
            drpt.Clear()
            Sdap.Fill(drpt)
            drpt.Tables(0).Columns.Add("barcode")
            drpt.Tables(0).Rows(0).Item("barcode") = NoUrut
            drpt.WriteXml(Application.StartupPath & "PrintD.xml", XmlWriteMode.WriteSchema)

            Scom.CommandText = "select alamat from dc_printer_t where Printer='DAFTAR'"
            namaPrt = Scom.ExecuteScalar()


        Catch ex As Exception

        Finally
            Scon.Close()
            Scon = Nothing
        End Try

        If namaPrt = "" Then
            MsgBox("Alamat Printer Tidak Diketahui")
            Exit Sub
        End If

        'prSticker(DC_ID, ID_JLR)

        Dim Rpt As New CrystalDecisions.CrystalReports.Engine.ReportDocument
        Try
            Rpt = New CRpt

            'Rpt.PrintOptions.PrinterName = namaPrt
            'Rpt.PrintOptions.PaperSize = CrystalDecisions.Shared.PaperSize.PaperEnvelopePersonal
            Rpt.SetDataSource(drpt)
            'Rpt.PrintOptions.
            Rpt.PrintOptions.PrinterName = namaPrt

            'Dim doctoprint As New System.Drawing.Printing.PrintDocument
            'doctoprint.PrinterSettings.PrinterName = namaPrt '"192.168.5.41\EpsonLQ"
            'Dim rawKind As Integer = 0
            'For i As Integer = 0 To doctoprint.PrinterSettings.PaperSizes.Count - 1
            '    If doctoprint.PrinterSettings.PaperSizes(i).PaperName = "DAFTAR" Then
            '        rawKind = CInt(doctoprint.PrinterSettings.PaperSizes(i).GetType().GetField("kind", System.Reflection.BindingFlags.Instance Or System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes(i)))
            '        Exit For
            '    End If
            'Next

            'Rpt.PrintOptions.PaperSize = CrystalDecisions.Shared.PaperSize.PaperEnvelope10

            'Dim pixelX As Integer = cm / 2.54 * dpi
            'Dim pixelY = scaleY(35, vbcentimeters, vbpixels)
            'Dim pkPaperSize As New Printing.PaperSize("sdfgsfdg", 850, 1100)
            'Rpt.PrintOptions.PaperSize = CrystalDecisions.Shared.PaperSize.PaperEnvelopePersonal
            'Rpt.PrintOptions.PaperOrientation = CrystalDecisions.Shared.PaperOrientation.Portrait

            ''Rpt.PrintOptions.PaperSize = paper_size()
            ''CrystalDecisions.Shared.PaperSize.DefaultPaperSize()
            'MsgBox(Rpt.PrintOptions.PageContentWidth & "," & Rpt.PrintOptions.PageContentHeight)
            'Exit Try


            ' ''Dim _outFile As FileStream
            ' ''Dim _fileWriter As StreamWriter
            ' ''Dim SA As SECURITY_ATTRIBUTES
            ' '' ''Try
            ' '' ''    _outFile = New FileStream(CreateFile(namaPrt, GENERIC_WRITE, 0, SA, OPEN_EXISTING, 0, 0), FileAccess.Write)
            ' '' ''    _fileWriter = New StreamWriter(_outFile)
            ' '' ''Catch ex As Exception
            ' '' ''    MsgBox("Printer Tidak Dapat Ditemukan", MsgBoxStyle.Critical)
            ' '' ''    Exit Sub
            ' '' ''End Try

            Rpt.PrintToPrinter(1, True, 1, 1)
        Catch ex As Exception
            MsgBox("Tidak Bisa Print No. Urut - " & ex.ToString)
        Finally
            Rpt.Dispose()
        End Try

        'RawPrinterHelper.SendStringToPrinter(Ps.PrinterName, Chr(27) & "M" & Chr(15))
        'RawPrinterHelper.SendStringToPrinter(Ps.PrinterName, (Chr(27) + Chr(40) + Chr(66) + Chr(15) + Chr(0) + Chr(5) + Chr(2) + Chr(0) + Chr(80) + Chr(0) + Chr(2)) & NoUrut & vbCrLf)
        'RawPrinterHelper.SendStringToPrinter(Ps.PrinterName, "" & vbCrLf)
        'RawPrinterHelper.SendStringToPrinter(Ps.PrinterName, "" & vbCrLf)

selesai: RECID()
    End Sub

    Private Sub prSticker(ByVal DC_ID As String, ByVal ID_JLR As String)
        Dim Scon As New OleDbConnection(ConStrORA)
        Dim Scom As New OleDbCommand("", Scon)
        Dim Sdap As New OleDbDataAdapter
        Dim dsSt As New DataSet
        Dim dsPal As New DataSet
        Dim StkP As String = ""
        Dim bar As String = ""
        If lblBPB_NO.Text <> "" Then
            MsgBox("Sudah Selesai BPB,Tidak Bisa cetak")
            Exit Sub
        End If

        Try
            Scon.Open()
            Scom.CommandText = "select id_daftarpo " & _
                               "from dc_jlr_daftarjalur_t a," & _
                                    "dc_jlr_daftarpo_t b " & _
                               "where a.id_daftarjalur = " & ID_JLR & " " & _
                                     "and a.id_daftarjalur=b.id_daftarjalur " & _
                                     "and dc_id=" & DC_ID
            Sdap.SelectCommand = Scom
            dsSt.Clear()
            Sdap.Fill(dsSt)

            Scom.CommandText = "select alamat from dc_printer_t where Printer='STICKER' and dc_id='" & DC_ID & "' and no_hh=0"
            StkP = IIf(IsNothing(Scom.ExecuteScalar) Or IsDBNull(Scom.ExecuteScalar), "", Scom.ExecuteScalar)
            If dsSt.Tables(0).Rows.Count > 0 Then
                Dim i As Integer
                Dim jumlah As Integer
                Dim palet As Integer
                Dim tumpuk As Integer
                Dim jml As Double
                Dim stk As Double
                Dim qty As Integer = 0
                For i = 0 To dsSt.Tables(0).Rows.Count - 1
                    '' ''Scom.CommandText = "select d.PLU_KODE,e.MBR_QTY_PALET,e.MBR_PALET_TOTAL," & _
                    '' ''                          "sum(nvl(d.FRAC_HH,0)) as FRAC_HH,sum(nvl(d.FRAC,0)) as FRAC,d.plu_id " & _
                    '' ''                   "from dc_trnbpb_hdr_t c," & _
                    '' ''                        "dc_trnbpb_dtl_t d," & _
                    '' ''                        "dc_barang_dc_t e" & _
                    '' ''                   "where c.id_daftarpo = " & dsSt.Tables(0).Rows(i).Item(0) & " " & _
                    '' ''                         "and e.mbr_fk_dcid=" & DC_ID & " " & _
                    '' ''                         "and c.HDR_ID=d.HDR_FK_ID " & _
                    '' ''                         "and d.PLU_ID=e.MBR_FK_PLUID " & _
                    '' ''                         "and e.MBR_TGL_PLUMATI is null " & _
                    '' ''                   "group by d.plu_id,d.plu_kode,e.mbr_qty_palet,e.mbr_palet_total"
                    Scom.CommandText = "select nvl(c.plu_id,0) as PLUID,nvl(c.plu_kode,0) as KODE," & _
                                              "nvl(c.frac_hh,0) as FRAC_HH,nvl(c.frac,0)as FRAC," & _
                                              "nvl(d.MBR_QTY_PALET,0) as MBR_QTY_PALET,nvl(d.MBR_PALET_TOTAL,0) as MBR_PALET_TOTAL," & _
                                              "nvl(e.PODTL_QTYB,0) as PRCD,nvl(e.PODTL_ISI_SATB,0) as SATPO " & _
                                       "from dc_trnbpb_hdr_t b," & _
                                             "dc_trnbpb_dtl_t c," & _
                                             "dc_barang_dc_t d," & _
                                             "dc_podtl_t e " & _
                                       "where b.id_daftarpo = " & dsSt.Tables(0).Rows(i).Item(0) & " " & _
                                              "and b.hdr_id=c.hdr_fk_id " & _
                                              "and c.plu_id=d.mbr_fk_pluid " & _
                                              "and c.plu_id=e.podtl_plumd " & _
                                              "and c.no_po=e.podtl_fk_no_po " & _
                                              "and d.mbr_tgl_plumati is null"
                    Sdap = New OleDbDataAdapter
                    Sdap.SelectCommand = Scom
                    dsPal.Clear()
                    Sdap.Fill(dsPal)

                    If dsPal.Tables(0).Rows.Count = 0 Then
                        MsgBox("Tidak Ada Data")
                        Exit Try
                    End If
                    Dim k As Integer
                    Dim prcd, SatPO, pcsJual As Integer

                    For k = 0 To dsPal.Tables(0).Rows.Count - 1
                        prcd = dsPal.Tables(0).Rows(k)("PRCD")
                        SatPO = dsPal.Tables(0).Rows(k)("SATPO")
                        If dsPal.Tables(0).Rows(k)("FRAC") = 0 Then
                            GoTo selesai
                        End If

                        Scom.CommandText = "select mbr_pcs_jual " & _
                               "from dc_brg_dimensi_t " & _
                               "where mbr_fk_pluid=" & IFNULL(dsPal.Tables(0).Rows(k)("PLUID"), 0) & " " & _
                                     "and mbr_flag_ctn='Y' "
                        pcsJual = IIf(IsNothing(Scom.ExecuteScalar) Or IsDBNull(Scom.ExecuteScalar), 0, Scom.ExecuteScalar)

                        If pcsJual = 0 Then
                            pcsJual = SatPO
                        End If

                        jumlah = dsPal.Tables(0).Rows(k)("PRCD")
                        palet = IFNULL(dsPal.Tables(0).Rows(k)("MBR_QTY_PALET"), 0)
                        tumpuk = IFNULL(dsPal.Tables(0).Rows(k)("MBR_PALET_TOTAL"), 0)

                        If palet = 0 Or tumpuk = 0 Then
                            MsgBox("PLU " & dsPal.Tables(0).Rows(k).Item("KODE") & " Qty Palet Atau Tir Per Cell Tidak Ada")
                            GoTo selesai
                        End If

                        jml = (prcd * SatPO) / pcsJual 'jumlah / palet
                        jml = IIf((Int(jml) - jml) < 0, Int(jml) + 1, jml)

                        stk = (jumlah / palet) / tumpuk
                        stk = IIf((Int(stk) - stk) < 0, Int(stk) + 1, stk)

                        Scom.CommandText = "Select mbr_barcode " & _
                                           "from dc_brg_barcode_t " & _
                                           "where mbr_fk_pluid=" & IFNULL(dsPal.Tables(0).Rows(k)("PLUID"), 0) & " " & _
                                             "and rownum <=1 "
                        Dim Barcode As String = IIf(IsNothing(Scom.ExecuteScalar) Or IsDBNull(Scom.ExecuteScalar), 0, Scom.ExecuteScalar)

                        Dim r As Integer
                        For r = 0 To stk - 1
                            If jumlah > (palet * tumpuk) Then
                                PrintSticker(Barcode, _
                                         dsPal.Tables(0).Rows(k).Item("KODE"), _
                                         (palet * tumpuk), StkP, palet & "/" & jml & "/" & tumpuk)
                                jumlah = jumlah - (palet * tumpuk)
                            Else
                                PrintSticker(Barcode, _
                                             dsPal.Tables(0).Rows(k).Item("KODE"), _
                                             jumlah, StkP, palet & "/" & jml & "/" & tumpuk)
                            End If
                        Next
selesai:
                    Next
                Next
            End If
        Catch ex As Exception
            MsgBox("Tidak Bisa Print Sticker")
        Finally
            Scon.Close()
        End Try
    End Sub

    Private Function Print(ByVal Pr As String, ByVal Id As String) As String
        Dim _t As String = "-1"
        Dim Scon As New OleDb.OleDbConnection(ConStrORA)
        Dim Scom As New OleDb.OleDbCommand("", Scon)

        Try
            If Scon.State = ConnectionState.Open Then
                Scon.Close()
                Scon.Dispose()
            End If

            Scon.Open()
            If Scon.State = ConnectionState.Open Then
                Dim _t2 As String = "UPDATE DC_JLR_DAFTARJALUR_T SET PRINT_ID=" & Pr & " where ID_DAFTARJALUR=" & Id
                Scom = New OleDb.OleDbCommand(_t2, Scon)
                Scom.ExecuteNonQuery()
                _t = "0"
                Scom.Dispose()
                Scom = Nothing
            End If
        Catch ex As Exception
            _t = ex.Message
        End Try

        Return _t
    End Function

    Private Sub btnPrintUlang_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnPrintUlang.Click
        Dim NoUrut As String
        Dim Ps As New Printing.PrinterSettings
        Dim drSup As Object
        drSup = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Current
        Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").EndCurrentEdit()
        NoUrut = drSup.row("NOURUT")

        'Dim DC_ID As String = drSup.row("DC_ID")
        'Dim ID_PO As String = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").Current.row("ID_DAFTARPO")

        If NoUrut.Length = 2 Then
            NoUrut = "0" & NoUrut
        ElseIf NoUrut.Length = 1 Then
            NoUrut = "00" & NoUrut
        ElseIf NoUrut.Length = 0 Or NoUrut.Length > 3 Then
            MsgBox("No Urut Error, Tidak Bisa Print")
            Exit Sub
        End If
        Dim Tgl As String
        Dim m As String
        Dim d As String
        Dim day As String
        Tgl = Format(drSup.row("TANGGAL"), "MM/dd/yyyy")

        m = Tgl.Substring(0, 2)
        d = Tgl.Substring(3, 2)
        Tgl = Tgl.Substring(8, 2)
        If m.Length < 2 And d.Length < 2 Then
            m = "0" & m
            d = "0" & d
        ElseIf m.Length < 2 Then
            m = "0" & m
        ElseIf d.Length < 2 Then
            d = "0" & d
        End If
        day = d & m & Tgl
        NoUrut = "*" & NoUrut & day & "*"

        Dim Scon As New OleDbConnection(ConStrORA)
        Dim Scom As New OleDbCommand("", Scon)
        Dim Sdap As New OleDbDataAdapter
        Dim drpt As New DataSet
        Dim namaPrt As String = ""

        Try
            Scon.Open()
            Scom.CommandText = "select a.nourut,trunc(a.tanggal) as tgl,a.SUPCO,a.SNAMA,b.TBL_DC_KODE,b.TBL_DC_NAMA " & _
                               "from dc_jlr_daftarjalur_t a," & _
                                    "dc_tabel_dc_t b " & _
                               "where nourut='" & txtNoAntrian.Text & "' and to_char(tanggal,'dd-mm-yyyy')='" & txtTglDaftar.Text & "' " & _
                                     "and a.dc_id=b.TBL_DCID"
            Sdap.SelectCommand = Scom
            drpt.Clear()
            Sdap.Fill(drpt)
            drpt.Tables(0).Columns.Add("barcode")
            drpt.Tables(0).Rows(0).Item("barcode") = NoUrut
            drpt.WriteXml(Application.StartupPath & "PrintD.xml", XmlWriteMode.WriteSchema)

            Scom.CommandText = "select alamat from dc_printer_t where Printer='DAFTAR'"
            namaPrt = Scom.ExecuteScalar()

        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            Scon.Close()
            Scon = Nothing
        End Try

        If namaPrt = "" Then
            MsgBox("Alamat Printer Nomor Urut Tidak Diketahui !!")
            Exit Sub
        End If

        'prSticker(DC_ID, ID_PO)
        Dim KtsRpt As New CrystalDecisions.CrystalReports.Engine.ReportDocument
        'ktsrpt.PrintOptions.PaperSize=
        Dim Rpt As New CrystalDecisions.CrystalReports.Engine.ReportDocument
        Try
            Rpt = New CRpt

            Rpt.SetDataSource(drpt)
            Rpt.PrintOptions.PrinterName = namaPrt
            'Rpt.PrintOptions.PaperSize = CrystalDecisions.Shared.PaperSize.PaperEnvelopePersonal
            'Rpt.PrintOptions.PaperSize = CrystalDecisions.Shared.PaperSize.DefaultPaperSize
            'Rpt.PrintOptions.PaperOrientation = CrystalDecisions.Shared.PaperOrientation.DefaultPaperOrientation
            ''Rpt.PrintOptions.PaperSize = paper_size()
            ''CrystalDecisions.Shared.PaperSize.DefaultPaperSize()
            'MsgBox(Rpt.PrintOptions.PageContentWidth & "," & Rpt.PrintOptions.PageContentHeight & "," & Rpt.PrintOptions.PageMargins.topMargin & "," & Rpt.PrintOptions.PageMargins.bottomMargin)
            'Exit Try

            ' '' ''Dim _outFile As FileStream
            ' '' ''Dim _fileWriter As StreamWriter
            ' '' ''Dim SA As SECURITY_ATTRIBUTES
            ' '' ''Try
            ' '' ''    _outFile = New FileStream(CreateFile(namaPrt, GENERIC_WRITE, 0, SA, OPEN_EXISTING, 0, 0), FileAccess.Write)
            ' '' ''    _fileWriter = New StreamWriter(_outFile)
            ' '' ''Catch ex As Exception
            ' '' ''    MsgBox("Printer Tidak Dapat Ditemukan", MsgBoxStyle.Critical)
            ' '' ''    Exit Sub
            ' '' ''End Try

            Rpt.PrintToPrinter(1, True, 0, 0)
        Catch ex As Exception
            MsgBox("Tidak Bisa Print No. Urut - " & ex.ToString)
        End Try
        Rpt.Dispose()


        'RawPrinterHelper.SendStringToPrinter(Ps.PrinterName, Chr(27) & "M" & Chr(15))
        'RawPrinterHelper.SendStringToPrinter(Ps.PrinterName, (Chr(27) + Chr(40) + Chr(66) + Chr(15) + Chr(0) + Chr(5) + Chr(2) + Chr(0) + Chr(80) + Chr(0) + Chr(2)) & NoUrut & vbCrLf)
        'RawPrinterHelper.SendStringToPrinter(Ps.PrinterName, "" & vbCrLf)
        'RawPrinterHelper.SendStringToPrinter(Ps.PrinterName, "" & vbCrLf)
        RECID()
    End Sub

    Dim brs_papersize As Integer
    Dim PgSetting As New Printing.PageSettings
    'Dim defPrinter As String 'menampung nama default Printer di comp 
    Dim ctk_rpt As New System.Drawing.Printing.PrintDocument

    Public Function paper_size() As Integer
        For i As Integer = 0 To ctk_rpt.PrinterSettings.PaperSizes.Count - 1
            'MsgBox(ctk_rpt.PrinterSettings.PaperSizes(i).PaperName)
            If ctk_rpt.PrinterSettings.PaperSizes(i).PaperName = "Card 148 x 105 mm" Then
                brs_papersize = CInt(ctk_rpt.PrinterSettings.PaperSizes(i).GetType().GetField("kind", Reflection.BindingFlags.Instance Or Reflection.BindingFlags.NonPublic).GetValue(ctk_rpt.PrinterSettings.PaperSizes(i)))
                paper_size = brs_papersize
                Exit For
            End If
        Next
        Return paper_size
    End Function

    Private Sub PrintSticker(ByVal bar As String, ByVal plu As String, ByVal qty As String, ByVal stk As String, ByVal tabcell As String)

        Dim _print As New ZebraLabels.ZebraPrint

        '_print.StartWrite("//192.168.9.104//ZebraZM4")
        _print.StartWrite(stk)
        _print.Write("^XA")  ''-->start code

        _print.Write("^FO90,40^BY4")  ''-->FO:posisi text yg akan diprint, BY:lebar barcode
        _print.Write("^BEN,100,Y,N,N")  ''-->BC:membuat barcode kode 128
        _print.Write("^FD" & bar & "^FS")  ''-->data diapit oleh FD & FS

        _print.Write("^CF0,150")
        _print.Write("^FO150,190")
        _print.Write("^FD" & plu & "^FS")

        _print.Write("^CF0,50")
        _print.Write("^FO80,320")
        _print.Write("^FDQty^FS")
        _print.Write("^FO150,320")
        _print.Write("^FD:" & qty & "^FS")
        _print.Write("^FO320,320")
        _print.Write("^FD" & tabcell & "^FS")

        _print.Write("^XZ")  ''-->end code
        _print.EndWrite()

    End Sub

    Public Sub mobil()
        If lblSUPCO.Text = "" Or lblSUPCO.Text = "lblSUPCO" Then
            Exit Sub
        End If
        Dim Scon As New OleDbConnection(ConStrORA)
        Dim Scom As New OleDbCommand("", Scon)
        Dim Sdap As New OleDbDataAdapter
        Try
            Dim dt_NOMOBIL As DataTable = getDS(" SELECT nomobil FROM dc_jlr_daftarjalur_t" & _
"  WHERE to_char(TRUNC(tanggal),'dd/mm/yyyy')='" & Format(txtTglDaftar.Value, "dd/MM/yyyy") & "' and SUPCO='" & lblSUPCO.Text & "' AND nourut = " & txtNoAntrian.Text, ConStrORA).Tables(0)

            If dt_NOMOBIL.Rows.Count > 0 Then
                LBMobil.DataSource = dt_NOMOBIL
                LBMobil.DisplayMember = "NOMOBIL"
                If btnDaftar.Enabled = True And btnTambahPO.Enabled = True Then
                    LBMobil.ClearSelected()
                End If
            Else
                Scon.Open()
                'Scom.CommandText = "select NOMOBIL from DC_JLR_DAFTARMOBIL_HDR_T where to_char(TRUNC(TGLMASUK),'dd/mm/yyyy')='" & Format(txtTglDaftar.Value, "dd/MM/yyyy") & "' and SUPCO='" & lblSUPCO.Text & "'"
                'Scom.CommandText = "select NOMOBIL from DC_JLR_DAFTARMOBIL_HDR_T where TGLMASUK=to_date('" & CmbNama.SelectedValue & "', 'MM/dd/yyyy hh:mi:ss am') and SUPCO='" & lblSUPCO.Text & "'"
                Scom.CommandText = "select NOMOBIL from DC_JLR_DAFTARMOBIL_HDR_T where TGLMASUK=to_date('" & Convert.ToDateTime(CmbNama.SelectedValue).ToString("MM/dd/yyyy hh:mm:ss tt") & "', 'MM/dd/yyyy hh:mi:ss am') and SUPCO='" & lblSUPCO.Text & "'"
                Sdap.SelectCommand = Scom
                ds.Clear()
                Sdap.Fill(ds)
                If ds.Tables(0).Rows.Count > 0 Then
                    LBMobil.DataSource = ds.Tables(0)
                    LBMobil.DisplayMember = "NOMOBIL"
                    If btnDaftar.Enabled = True And btnTambahPO.Enabled = True Then
                        LBMobil.ClearSelected()
                    End If
                Else
                    Scom.CommandText = " SELECT NOMOBIL FROM dc_jlr_daftarjalur_t" & _
                        "  WHERE supco = '" & lblSUPCO.Text & "'" & _
                        "    AND nourut = '" & txtNoAntrian.Text & "'" & _
                        "    AND TO_CHAR (TRUNC (tanggal), 'dd/MM/yyyy') = '" & Format(txtTglDaftar.Value, "dd/MM/yyyy") & "'"
                    Sdap.SelectCommand = Scom
                    ds.Clear()
                    Sdap.Fill(ds)
                    LBMobil.DataSource = ds.Tables(0)
                    LBMobil.DisplayMember = "NOMOBIL"
                    If btnDaftar.Enabled = True And btnTambahPO.Enabled = True Then
                        LBMobil.ClearSelected()
                    End If
                End If
            End If
        Catch ex As Exception

        Finally
            Scon.Close()
            Scon = Nothing
        End Try
    End Sub

    Private Sub BtnPrintStck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnPrintStck.Click
        Dim drSup As Object
        drSup = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Current
        Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").EndCurrentEdit()

        Dim DC_ID As String = drSup.row("DC_ID")
        Dim ID_JLR As String = drSup.row("ID_DAFTARJALUR")
        'Dim ID_PO As String = Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T.Daf_PO").Current.row("ID_DAFTARPO")
        prSticker(DC_ID, ID_JLR)
    End Sub

    Private Sub txtNoFak_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtNoFak.KeyDown
        'MsgBox(e.KeyCode)
        'Dim a As Integer = txtNoFak.Text.Length - 1
        'Dim arr = txtNoFak.Text.ToCharArray
        'Dim txt = ""
        'For i As Int16 = 0 To a
        '    If Char.IsDigit(arr(i)) = True Then
        '        txt &= arr(i)
        '    End If
        'Next
        'txtNoFak.Text = txt
    End Sub

    Private Sub txtNoFak_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNoFak.TextChanged
        Dim arr = txtNoFak.Text.ToCharArray
        Dim txt = ""
        For i As Int16 = 0 To txtNoFak.Text.Length - 1
            If Char.IsDigit(arr(i)) = True Then
                txt &= arr(i)
            End If
        Next
        txtNoFak.Text = txt
        txtNoFak.SelectionStart = txtNoFak.TextLength
    End Sub
    Public Sub btn_Next(ByVal supco As String) 'fungsi next per faktur
        Dim dt_noFaktur As New DataTable

        If LBMobil.SelectedIndex = -1 And LBMobil.Items.Count <> 0 Then
            LBMobil.SelectedIndex = 0
        End If
        'dt_noFaktur = getDS("select no_faktur, hdr_id from dc_trnbpb_hdr_t where supco = '" & supco & "' ", ConStrORA).Tables(0)
        dt_noFaktur = getDS(" SELECT no_faktur, hdr_id FROM dc_trnbpb_hdr_t WHERE no_faktur IN" & _
" (SELECT no_fak FROM dc_jlr_daftarpo_t WHERE id_daftarjalur IN" & _
" (SELECT id_daftarjalur FROM dc_jlr_daftarjalur_t WHERE supco = '" & supco & "' AND nomobil = '" & LBMobil.Text & "' )) and supco = '" & supco & "'", ConStrORA).Tables(0)
        If dt_noFaktur.Rows.Count <> 0 Then
            Pointer += 1
            If Pointer > dt_noFaktur.Rows.Count - 1 Then
                Pointer = 0 'disini coy
            End If
            txtNoFak.Text = dt_noFaktur.Rows(Pointer)(0).ToString
            Dim dt_loadPerFaktur As New DataTable
            Dim testabs As String = "  SELECT   a.no_po, b.tot_item, b.tgl_PO, SUM (a.qty) AS qty, SUM (a.nilai) AS nilai," & _
                       "   SUM (a.ppnrp + (a.tot_disc / 10)) AS ppn," & _
                       "   SUM (a.nilai + a.ppnrp) AS total" & _
                   "  FROM dc_trnbpb_dtl_t a, dc_trnbpb_hdr_t b" & _
                   "      WHERE a.hdr_fk_id = b.hdr_id AND a.hdr_fk_id = '" & dt_noFaktur.Rows(Pointer)(1).ToString & "'" & _
                " GROUP BY a.no_po, b.tgl_po, a.hdr_fk_id, b.tot_item"
            ' dt_loadPerFaktur = getDS("SELECT SUM(qty) as qty, SUM(nilai) as nilai, SUM(ppnrp + (tot_disc/10)) as ppn, SUM(nilai+ppnrp) as total FROM dc_trnbpb_dtl_t  WHERE hdr_fk_id = " & dt_noFaktur.Rows(Pointer)(1).ToString, ConStrORA).Tables(0)
            dt_loadPerFaktur = getDS(testabs, ConStrORA).Tables(0)
            Dim dt_gettglpo As DataTable
            txtPO_QTY.Text = dt_loadPerFaktur.Rows(0)(3).ToString
            txtPO_GROSS.Text = dt_loadPerFaktur.Rows(0)(4).ToString
            txtPO_PPN.Text = dt_loadPerFaktur.Rows(0)(5).ToString
            txtPO_Total.Text = dt_loadPerFaktur.Rows(0)(6).ToString
            txtNo_PO.Text = dt_loadPerFaktur.Rows(0)(0).ToString
            txtTgl_PO.Text = dt_loadPerFaktur.Rows(0)(2).ToString
            txtTot_Item.Text = dt_loadPerFaktur.Rows(0)(1).ToString
            'Dim 
        Else
            txtPO_QTY.Text = ""
            txtPO_GROSS.Text = ""
            txtPO_PPN.Text = ""
            txtPO_Total.Text = ""
            txtNo_PO.Text = ""
            txtTgl_PO.Text = ""
            txtTot_Item.Text = ""
            txtNoFak.Text = ""
            txtTGL_MULAI.Text = ""
            txtTglFaktur.Text = ""
        End If
    End Sub

    Private Sub btn_Prev(ByVal supco As String) 'fungsi next per faktur
        Dim dt_noFaktur As New DataTable

        If LBMobil.SelectedIndex = -1 And LBMobil.Items.Count <> 0 Then
            LBMobil.SelectedIndex = 0
        End If
        'dt_noFaktur = getDS("select no_faktur, hdr_id from dc_trnbpb_hdr_t where supco = '" & supco & "' ", ConStrORA).Tables(0)
        dt_noFaktur = getDS(" SELECT no_faktur, hdr_id FROM dc_trnbpb_hdr_t WHERE no_faktur IN" & _
" (SELECT no_fak FROM dc_jlr_daftarpo_t WHERE id_daftarjalur IN" & _
" (SELECT id_daftarjalur FROM dc_jlr_daftarjalur_t WHERE supco = '" & supco & "' AND nomobil = '" & LBMobil.Text & "' )) and supco = '" & supco & "'", ConStrORA).Tables(0)
        If dt_noFaktur.Rows.Count <> 0 Then
            Pointer -= 1
            If Pointer < 0 Then
                Pointer = dt_noFaktur.Rows.Count - 1
            End If
            txtNoFak.Text = dt_noFaktur.Rows(Pointer)(0).ToString
            Dim dt_loadPerFaktur As New DataTable
            Dim testabs As String = "  SELECT   a.no_po, b.tot_item, b.tgl_PO, SUM (a.qty) AS qty, SUM (a.nilai) AS nilai," & _
                "   SUM (a.ppnrp + (a.tot_disc / 10)) AS ppn," & _
                "   SUM (a.nilai + a.ppnrp) AS total" & _
            "  FROM dc_trnbpb_dtl_t a, dc_trnbpb_hdr_t b" & _
            "      WHERE a.hdr_fk_id = b.hdr_id AND a.hdr_fk_id = '" & dt_noFaktur.Rows(Pointer)("hdr_id").ToString & "'" & _
         " GROUP BY a.no_po, b.tgl_po, a.hdr_fk_id, b.tot_item"
            ' dt_loadPerFaktur = getDS("SELECT SUM(qty) as qty, SUM(nilai) as nilai, SUM(ppnrp + (tot_disc/10)) as ppn, SUM(nilai+ppnrp) as total FROM dc_trnbpb_dtl_t  WHERE hdr_fk_id = " & dt_noFaktur.Rows(Pointer)(1).ToString, ConStrORA).Tables(0)
            dt_loadPerFaktur = getDS(testabs, ConStrORA).Tables(0)
            txtPO_QTY.Text = dt_loadPerFaktur.Rows(0)(3).ToString
            txtPO_GROSS.Text = dt_loadPerFaktur.Rows(0)(4).ToString
            txtPO_PPN.Text = dt_loadPerFaktur.Rows(0)(5).ToString
            txtPO_Total.Text = dt_loadPerFaktur.Rows(0)(6).ToString
            txtNo_PO.Text = dt_loadPerFaktur.Rows(0)(0).ToString
            txtTgl_PO.Text = dt_loadPerFaktur.Rows(0)(2).ToString
            txtTot_Item.Text = dt_loadPerFaktur.Rows(0)(1).ToString
            'Dim queryget As String = "SELECT nourut FROM dc_jlr_daftarjalur_t WHERE id_daftarjalur =" & _
            '" (SELECT id_daftarjalur FROM dc_jlr_daftarpo_t WHERE supco = '" & dt_noFaktur.Rows(Pointer)("supco").ToString & "' AND no_fak = '" & dt_noFaktur.Rows(Pointer)("no_fak").ToString & "' )"

            'Dim dt_getnourut As DataTable = getDS(queryget, ConStrORA).Tables(0)
            'If dt_getnourut.Rows.Count > 0 Then
            '    Dim loadnourut As String = dt_getnourut.Rows(0)(0).ToString
            '    For i As Integer = 0 To DsPO1.DC_JLR_DAFTARJALUR_T.Rows.Count - 1
            '        If DsPO1.DC_JLR_DAFTARJALUR_T.Rows(i)("NOURUT").ToString = loadnourut Then
            '            Exit For
            '        Else
            '            Me.BindingContext(DsPO1, "DC_JLR_DAFTARJALUR_T").Position += 1
            '        End If
            '    Next
            'End If
        Else
            txtPO_QTY.Text = ""
            txtPO_GROSS.Text = ""
            txtPO_PPN.Text = ""
            txtPO_Total.Text = ""
            txtNo_PO.Text = ""
            txtTgl_PO.Text = ""
            txtTot_Item.Text = ""
            txtNoFak.Text = ""
            txtTGL_MULAI.Text = ""
            txtTglFaktur.Text = ""
        End If
    End Sub
    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs) _
                              Handles txtNo_PO.KeyPress

        If Not (Asc(e.KeyChar) = 8) Then
            If Char.IsLetterOrDigit(e.KeyChar) = False Then
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub btnTambahPO_EnabledChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTambahPO.EnabledChanged
        If btnTambahPO.Enabled = True Then
            btnSimpanPO.Enabled = False
            btnBatalPO.Enabled = False
        Else
            btnSimpanPO.Enabled = True
            btnBatalPO.Enabled = True
        End If
    End Sub

    Public Sub LoadNoAntrian() Handles Me.BindingContextChanged
        Dim queryNOPO As String = ""
        If txtNo_PO.Text <> "" Then
            queryNOPO = " and nopo = '" & txtNo_PO.Text & "'"
        End If
        txtNoAntrianPO.Text = execScalar(" select nvl((SELECT nourut_jalur " & _
                                        "   FROM DC_JLR_DAFTARPO_T " & _
                                        "  WHERE id_daftarjalur = " & _
                                        "           (SELECT id_daftarjalur " & _
                                        "              FROM DC_JLR_DAFTARJALUR_T " & _
                                        "             WHERE nourut = '" & txtNoAntrian.Text & "' " & _
                                        "               AND TRUNC (tanggal) = TRUNC (TO_DATE ('" & txtTglDaftar.Text & "', 'dd/mm/yyyy'))) " & queryNOPO & _
                                        "  ), ' ') as nourut_jalur FROM dual", ConStrORA)
    End Sub
    Public Function execScalar(ByVal Query As String, ByVal conStr As String) As String
        Dim connection As New OleDb.OleDbConnection(conStr)
        Dim cmd As New OleDb.OleDbCommand("", connection)
        Dim adapter As New OleDb.OleDbDataAdapter
        Try
            If connection.State = ConnectionState.Open Then
                connection.Close()
            End If
            connection.Open()
            'Buat data adapter
            cmd = New OleDbCommand(Query, connection)
            execScalar = cmd.ExecuteScalar() 'IIf(IsDBNull(cmd.ExecuteScalar()), 0, cmd.ExecuteScalar())
            Return execScalar
        Catch ex As Exception
            Return "-_GAGAL_-" & ex.Message
        Finally
            connection.Close()
        End Try
    End Function
End Class



